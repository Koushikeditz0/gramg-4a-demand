# K-Desk Suite by Koushik (আগের নাম: G RAM G Demand-Allocation Helper)

এই সংস্করণে Extension-এর ফাইলগুলো কাজ অনুযায়ী আলাদা folder-এ সাজানো হয়েছে। v1.0.7-এর Work Demand, Work Allocation, e-KYC/ABPS Sync এবং MR PDF workflow-এর processing logic ইচ্ছাকৃতভাবে পরিবর্তন করা হয়নি।

## v1.10.0 — "Not saved — no message" ভুল ফল ঠিক
- Save-এর পরে portal কোনো message না দিলে (page ধীরে/আধখানা এসেছে) আগে সরাসরি "Not saved" লিখত, যদিও আসলে অনেক সময় Save হয়ে যেত। এখন work আবার খুলে MR list দেখে: MR আর list-এ না থাকলে **Saved**, থাকলে Not saved (Retry later)। Attendance আর Payment দুটোতেই।

## v1.9.9 — Fill Attendance only-ও আটকে গেলে থামে না
- Payment-এর মত: Save হয়নি ("no message from the portal"), safety check, target দিন না মেলা, MR খুলছে না — এগুলো "Retry later" হয়ে পরে যায়; সব শেষে আর একবার চলে। দ্বিতীয় দফাতেও target না মিললে আগের মত থেমে হাতে ঠিক করার অপেক্ষা।
- আগের Save আসলে হয়ে গিয়ে থাকলে MR আর list-এ থাকে না — তখন log-এ লেখা "the earlier Save probably went through … check it on the portal"।

## v1.9.8 — "session expired" বলে মাঝপথে থামা কমল
- Fill Attendance only / Payment only: postback-এর পরে page ধীরে বা আধখানা load হলে আগে "The page closed or the session expired" বলে run থেমে যেত (Resume চাপলেই চলত)। এখন ১৫ সেকেন্ড পর্যন্ত অপেক্ষা করে, তারপরও না এলে page নিজে আবার খোলে (৩ বার পর্যন্ত) আর run চলতে থাকে। সত্যিই logout হলে (login page) আগের মতই থামে।

## v1.9.7 — Admin panel (IAY Tracker) থেকে job
- **Work Demand** panel-এ নতুন বোতাম **📥 Admin job (IAY Tracker)**: Tracker-এ বানানো Demand + Allocation job (Reg No, Applicant, From, Days, প্রতি row-এর নিজের Work Code) queue-তে আসে। Start চাপলে Demand, তারপর সফলদের নিয়ে Work Allocation নিজে থেকে (প্রতি worker তার নিজের Work Code-এ)। প্রতিটা row-এর ফল Tracker-এ ফেরে।
- **Fill Attendance only** আর **Payment only** panel-এ **📥 Admin job**: job-এর Work Code, MR No (Payment-এ MB No, Page No-ও) panel-এর নিজের Excel পথেই load হয় — run আগের Excel run-এর মতোই। Save / Skip / Error ফল Tracker-এ যায়; Test run-এর ফল যায় না।
- নিজে অন্য Excel দিলে সেই run আর job-এর সাথে যুক্ত থাকে না। আগের সব Excel / List Builder পথ আগের মতোই আছে।
- লাগে: List Builder-এর kdesk login (একই login) আর server-এ v199 SQL।

## v1.9.6 — Payment only: আটকে গেলে থামে না
- কোনো MR আটকে গেলে (খুলছে না, Save হয়নি, safety check, amount target মেলেনি) run থামে না: "Retry later" হয়ে পরের MR-এ যায়। সব work শেষ হলে আটকে যাওয়াগুলো **আর একবার** চলে; তখনও target না মিললে আগের মত থেমে হাতে ঠিক করার জন্য অপেক্ষা করে।
- "Not found" ধরনের skip (MR/work page-এ নেই, MB নেই, সময় শেষ হয়নি, আগেই entry হয়ে গেছে) আবার চালানো হয় না।

## v1.9.5 — MR Fill এখন K-Desk-এর অংশ
- MR Fill v1.7.1-এর **Fill Attendance only** আর **Payment only** এখন K-Desk feature: Dashboard-এ দুটো আলাদা On/Off tile, K-Dock-এ icon, panel-এ K-Desk নাম/logo, PC activation লাগে। কাজের code MR Fill v1.7.1-এর মতই।
- K-Desk-এর পুরনো **MR Attendance (IF works)** পুরো বাদ। Copy/Paste K-Desk-এর নিজেরটা।
- আলাদা MR Fill extension Remove করে দিন। Excel একবার আবার upload করতে হবে।

## v1.8.9 — ১০০-র বেশি লোক হলে "not found" ঠিক

- Portal-এর Work Allocation grid একবারে সর্বোচ্চ ১০০ জন দেখায়। Excel-এ তার বেশি লোক থাকলে বাকিরা তখন grid-এ থাকেন না, তাই "not found in portal grid" হয়ে skip হতেন।
- এখন একটা round শেষ হলে, যাঁরা "not found" ছিলেন তাঁদের নিয়ে K-Desk নিজেই আবার round চালায় (আগের লোকেরা allocate হয়ে grid থেকে সরে গেলে এঁরা দেখা দেন)। কোনো round-এ নতুন কেউ allocate না হলে, বা ৮ round হলে থামে।

## v1.8.8 — Trial ৩ দিনের

- নতুন PC-তে key ছাড়া Trial এখন প্রথম ব্যবহারের দিন থেকে ৩ দিন (আগে ৭ দিন)। যাঁদের Trial ৩ দিনের বেশি আগে শুরু হয়েছে, update করলে তাঁদের Trial সঙ্গে সঙ্গে শেষ দেখাবে।

## v1.8.7 — v1.8.6-এর ধীর ভাব কমানো

- লোক grid-এ পেলেই সঙ্গে সঙ্গে এগোয়। না পেলে portal নতুন grid আনা শেষ করলেই (বা ~2 সেকেন্ডে) এগোয়, আগের মতো পুরো 8 সেকেন্ড বসে থাকে না।

## v1.8.6 — ভুল "not found in portal grid" কমানো

- Work Code বদলানোর পরেও কিছুক্ষণ grid-এ আগের Work-এর লোক দেখায়। আগে K-Desk সেই পুরোনো grid দেখেই "not found" বলে skip করে দিত।
- এখন এই Work-এর কোনো লোক grid-এ না আসা পর্যন্ত (সর্বোচ্চ ~8 সেকেন্ড) অপেক্ষা করে। তারপরও না পেলে তবেই skip করে (তখন সত্যিই Demand নেই, বা Allocation আগেই হয়ে গেছে)।

## v1.8.5 — Demand আর Allocation-এ একই Excel

- Demand-এ Excel-এর Days (যেমন 28) কাজের দিন হিসেবে যায়। Allocation-এ portal সেটাকে রবিবার যোগ করে period বানায় (28 + 28/6 = 32)।
- এখন Allocation-এ K-Desk বোঝে: Excel-এ 28 আর portal-এ ভরা 32 হলে দুটো মিলছে ধরে, কিছু না বদলে শুধু tick দিয়ে Save করে।
- portal-এ কিছু ভরা না থাকলে নিজে No of days = Days + Days/6 আর To = From + সেই দিন − 1 বসায় (28 → 32 দিন, To 03/12)।

## v1.8.4 — Portal-এর আগে থেকে ভরা তারিখ রেখে দেওয়া

- Allocation grid-এ portal নিজেই Demand থেকে From / No of days / To ভরে রাখে। Excel-এর From আর Days যদি তার সাথে মেলে, K-Desk শুধু tick দিয়ে Save করে, ঘরগুলোতে আর হাত দেয় না (হাতে করলে যেমন হয়)।
- শুধু যেটা Excel-এর সাথে মেলে না, সেটাই বদলায়। To ফাঁকা বা নিয়মের বাইরে হলে From + Days − 1 বসায়।

## v1.8.3 — v1.8.2-এর "Date.UTC is not a function" error ঠিক

- Portal page নিজের Date বসিয়ে রাখে, তাই v1.8.2-এর তারিখ হিসাব সব row-তে error দিচ্ছিল। এখন Date ছাড়াই হিসাব হয়।

## v1.8.2 — Allocation period (To date) ঠিক করা

- Portal-এর নিয়ম: Allocation Period (From থেকে To, দুই দিন ধরে) = Allocation Days অথবা Days + (Days/6)-এর পূর্ণ অংশ (যেমন 28 দিন → 28 বা 32)।
- আগে portal নিজে To date ভরে দিলে K-Desk সেটা আর দেখত না, তাই পুরোনো/ভুল To থেকে গেলে "Allocation Period days should be equal to…" error আসত।
- এখন Days বসানোর পর K-Desk To date যাচাই করে; ভুল বা ফাঁকা হলে নিজে From + (Days + Days/6) − 1 বসিয়ে দেয় (28 দিন → 32 দিনের period)।

## v1.8.1 — GP + PC key (KH5)

- GP key-তে এখন PC-র সংখ্যাও বেঁধে দেওয়া যায়: Key Generator-এ GP code-এর সাথে Device ID দিলে (যেমন ২টা PC-র) key শুধু ওই PC-গুলোতে আর ওই GP-তেই চলে।
- Device ID ফাঁকা রাখলে আগের মতো KH4 key (GP-র যত PC খুশি)।

## v1.8.0 — GP License key (KH4)

- নতুন GP key: key-এ এক বা একাধিক GP code (যেমন WB-08-005-014) আর মেয়াদ থাকে। কোনো PC-তে বাঁধা নয়, ওই GP-র যত PC-তে খুশি একই key চলে।
- Work Demand, Work Allocation আর ABPS Sync শুধু key-এ থাকা GP-র Job Card-এ চলে। অন্য GP-র Job Card থাকলে Start হয় না (ABPS Sync প্রথম village-এই থেমে যায়, কিছু save হয় না)।
- Dashboard-এ "Licensed to … · GP: …" দেখায়।
- পুরনো KH1/KH2/KH3 key আর Trial (v1.8.8 থেকে ৩ দিন) আগের মতোই চলে, এগুলোতে GP-র বাধা নেই।
- Key Generator-এ "GP key" ধরন যোগ হয়েছে (Device ID লাগে না)।

## v1.7.7 — MR Attendance: Work Start Date নিজে থেকে ভরে

- MR Attendance-এ কোনো MR-এর Work Start Date খালি থাকলে (একটা work-এর জীবনে একবারই লাগে) এখন সেই MR-এর From date বসিয়ে Save করে। আগে এমন MR skip হত।
- Work Start Date-এ আগে থেকে কিছু লেখা থাকলে সেটা কখনো বদলায় না। ঘরটা বন্ধ (disabled) থাকলে আগের মতো কারণসহ skip।
- Save-এর আগে safety check: Work Start Date খালি নয়, আর MR-এর From date-এর পরে নয়।
- "First ___ days" ঘরে আর আগে থেকে 7 বসে থাকে না, নিজে সংখ্যা লিখতে হবে।
- Log-এ "Work Start Date filled dd/mm/yyyy" দেখাবে।

## v1.7.6 — Demand: portal পুরো group ফেরালে একজন একজন করে আবার চেষ্টা

- একটা registration-এর কয়েকজনকে একসঙ্গে পাঠানোর পর portal error দিলে (প্রায়ই একজনের সমস্যার জন্য) আগে সবাই Error হয়ে যেত। এখন প্রত্যেককে আলাদা করে আবার পাঠানো হয়। যাকে portal একা পাঠালেও ফেরায়, শুধু সে-ই Error হয়, বাকিরা সফল হন।
- একজন একজন করে পাঠানোর সময় আগে সফল হওয়া worker-এর তারিখ মোছা হয় না, তাই তাঁর demand থেকেই যায়।
- Reset চাপলে retry-র গোনাও শূন্য থেকে শুরু হয়।
- Activity log-এ "portal refused … retrying them one by one" আর "retrying alone" লেখা দেখাবে। Driver version 1.2.0।

## v1.7.5 — List-এর নিজের Work Code আর ফলাফল List Builder-এ

- Admin panel-এ কোনো list-এ Work Code দেওয়া থাকলে ☁ List Builder dialog-এ সেটা দেখায়, আর load করলে নিজে থেকেই সেই Work Code নেয়। Work Code-এর ঘরে যা লিখবেন, সেটা শুধু Work Code ছাড়া list-গুলোর জন্য।
- Demand শেষ হলে প্রত্যেক worker-এর ফল (সফল / Error / বাদ) List Builder app-এ পাঠানো হয়। Work Allocation শেষ হলে তার ফলও যায়। Admin panel আর Supervisor-এর app-এ "📋 ফলাফল" দেখায়।
- শুধু ☁ List Builder থেকে আনা run-এর ফলই যায়। Excel থেকে load করা run কোথাও পাঠানো হয় না।
- Work Allocation page-এও List Builder link (gramg-link.js) load হয়।

## v1.7.4 — ABPS Sync থেকে List Builder-এর eKYC/ABPS update
- ABPS Sync শেষ হলেই K-Desk নিজে থেকে List Builder app-এ প্রতি worker-এর ৪টা হ্যাঁ/না (Aadhaar Seeded, Authentication, ABPS, eKYC) পাঠায়, Job Card + Applicant No ধরে। নাম পাঠানো হয় শুধু মেলানোর জন্য, যখন report-এ Applicant No থাকে না। Aadhaar নম্বর বা account যায় না।
- শর্ত: Work Demand page-এর ☁ বোতাম থেকে একবার kdesk login করা থাকতে হবে। না থাকলে status-এ সেটা বলে দেয়।
- Supabase: `kdesk_sync_flags` (শুধু নিজের GP-র আগে থেকে থাকা worker, শুধু এই ৪টা ঘর; প্রতিবার audit log-এ `flags_synced_kdesk`)।

## v1.7.3 — Demand + Allocation এক report
- List Builder থেকে Work Code দিয়ে চালালে Demand শেষে আলাদা Demand file নামে না। Allocation শেষ হলে একটাই Excel নামে: `Demand-Allocation-report-….xlsx`।
- **Summary** sheet-এ থাকে Demand মোট/সফল/Error/Skipped আর Allocation মোট/সফল/Error/Skipped। **Demand + Allocation** sheet-এ প্রতি worker-এর এক সারি: Demand-এর ফল, তার পাশে Allocation-এর ফল। Demand-এ সফল না হলে লেখা থাকে "পাঠানো হয়নি"।
- Demand-এ কেউ সফল না হলে শুধু Demand report নামে। Allocation panel-এর ⭳ Export results-ও এই মিলিত report দেয়।

## v1.7.2 — List Builder থেকে Demand, তারপর নিজে থেকেই Work Allocation
- ☁ List Builder dialog-এ নতুন **Work Code** ঘর। Work Code দিলে Demand run শেষ হওয়ার পর যাদের demand সফল (done) হয়েছে, শুধু তারাই একই From/Days আর ওই Work Code নিয়ে Work Allocation-এর queue-তে যায়।
- "Demand শেষ হলে ... Work Allocation নিজে থেকে চালাও" টিক থাকলে Demand শেষে ৩ সেকেন্ড পর Work Allocation page খোলে। সেখানে list load হয়, তারপর ৫ সেকেন্ড গুনে নিজে Start হয়। এর মধ্যে Stop চাপলে auto-start বাতিল হয়। টিক না থাকলে Work Allocation page খুললে list তৈরি থাকে, Start আপনি চাপবেন।
- Demand-এ error বা skipped worker Allocation-এ যায় না। Hand-off ৩ দিন পর্যন্ত থাকে (chrome.storage.local `kdlb_handoff`, `kdlb_alloc_pending`)।
- Work Allocation-এর driver (alloc-driver.js) ছোঁয়া হয়নি, শুধু panel-এ list নেওয়ার অংশ যোগ হয়েছে।

## v1.7.0 — List Builder app থেকে সরাসরি Demand list
- Work Demand panel-এ নতুন বোতাম **☁ List Builder app থেকে আনো**। Supervisor-রা ফোনে G RAM-G 4A/Demand List Builder app-এ যে list জমা দেন, সেগুলো এখানে বেছে Work From আর Days দিলেই queue-তে চলে আসে। Excel export/choose করতে হয় না।
- Login: app-এর Admin panel → Users-এ একটা login-কে **🖥 K-Desk login করুন** চাপলে সেটা K-Desk-এর login হয়। এই login শুধু নিজের GP-র জমা পড়া list দেখতে আর lock করতে পারে, অন্য কিছু নয়। PIN সেভ হয় না, শুধু login token (`kdlb_sess`) থাকে।
- Data যায় শুধু Koushik-এর নিজের Supabase project থেকে K-Desk-এ। K-Desk থেকে app-এ কিছু ফেরত যায় না, শুধু "এই list নেওয়া হলো / lock করো"।
- একই worker দুটো list-এ থাকলে একবারই নেওয়া হয়; app-এ inactive বা অযোগ্য worker বাদ যায় (admin-এর K-Desk export-এর মতো)। এরপর eKYC/ABPS নিয়ম আগের মতোই চলে।
- File: `shared/gramg-link.js` (নতুন), `content/demand/demand-autofill.js`-এ বোতাম।

## v1.7.1 — English Dashboard, একসঙ্গে v1.7.0
- Dashboard (popup) এখন English-এ। Today tab থেকে List Builder আর Print MR বোতাম সরানো হয়েছে (List Builder Demand/Allocation panel-এ আছে)।
- ABPS Data Sync আর NPCI সবসময় চালু, Features-এ এদের toggle নেই (আগে Off করা থাকলেও চলবে)।
- K-Dock bar-এ আগে ABPS Data Sync, তারপর NPCI, তারপর বাকিগুলো।
- v1.6.5: Dashboard খোলার দেরি ঠিক (খোলার সময় জোর করে layout বন্ধ, emoji font সরাসরি, "＋" চিহ্ন বাদ)। Settings-এ "Open time"।
- v1.7.0-এর List Builder app link এর সঙ্গে মেলানো।

## v1.6.3 — Dashboard আরও তাড়াতাড়ি, আর Side panel
- License যাচাই আর data পড়া এখন একসঙ্গে চলে, আর আগের বারের license অবস্থা সঙ্গে সঙ্গে দেখায় (আগে data পড়া শেষ হলে তবে যাচাই শুরু হতো)।
- Settings tab-এ "খোলার সময়": Dashboard দেখা যেতে, সংখ্যা আসতে আর license যাচাই হতে কত ms লাগল।
- Header-এ "⇥ পাশে": Dashboard Chrome-এর side panel-এ খোলে, tab বদলালেও খোলা থাকে, তাই বারবার popup খোলার দেরি থাকে না। নতুন permission "sidePanel" (কোনো সতর্কবার্তা আসে না)।

## v1.6.2 — নতুন Dashboard: tab আর নির্দিষ্ট মাপ
- Dashboard এখন তিনটে tab-এ: **🏠 আজ** (আজকের হিসাব, জমা data, সাম্প্রতিক কাজ, link), **🧩 Features** (সব On/Off আর Portal সুবিধা), **⚙ Settings** (Dark/Compact, Notification, Tour, shortcut)। শেষ বার যে tab খোলা ছিল সেটাই খোলে।
- Popup-এর মাপ নির্দিষ্ট (৫৮০px), ভেতরে scroll করে। তাই খোলার সময় Chrome আর বারবার আকার বদলায় না, ঝাঁকুনি হয় না।
- আগের বারের সংখ্যা আর Dark mode সঙ্গে সঙ্গে দেখায়, তারপর নতুন মান আসে (আগে ফাঁকা ঝিকমিক box দেখাত)।
- Fix: Autofill-এর default ✕ দিয়ে মুছলে তালিকা সঙ্গে সঙ্গে update হয়।

## v1.6.1 — Dashboard আবার ছোট
- Autofill, Copy/Paste, Password দেখা, Login ধরে রাখা: এই চারটে এখন Dashboard-এ এক ভাঁজে, **🧰 Portal সুবিধা**। ভাঁজ বন্ধ থাকলে Dashboard v1.5.3-এর চেয়েও ছোট। খোলা/বন্ধ মনে থাকে, আর Autofill-এর তালিকা শুধু খুললে পড়া হয়।

## v1.6.0 — Ninja v11 থেকে নতুন সুবিধা (Allocation-এ হাত দেওয়া হয়নি)
- **MR Attendance (IF works)**: Muster Roll Attendance (`mustrollattend.aspx`) page-এ panel। IF work-এ tick দিন, **Full** (প্রতিদিন) বা **প্রথম N দিন** বাছুন, Start। যে MR-এর সময় শেষ, তাতে তালিকার সব worker উপস্থিত করে Save; সময় শেষ হয়নি / worker নেই / Work Start Date নেই / zero-attendance tick থাকলে কারণসহ skip। **Test run** (ভরে কিন্তু Save চাপে না) আছে, আগে সেটা দিয়ে দেখুন। Save-এর আগে প্রতিটা row আবার মিলিয়ে দেখে, না মিললে Save করে না। পরপর ৫টা MR Save না হলে নিজে থামে। Log Excel-এ। ⏱ গতি setting এখানেও কাজ করে। Block login-এ Panchayat বাছতে হয়, অন্য Panchayat-এ চলে যায় না।
- **Work Demand → "Work Demand To date"**: Portal-এর নিয়ম (default, আগের মতোই) বা **আসল তারিখ** (Work From + days − 1)। Portal প্রতি ৬ দিনে ১ দিন বেশি যোগ করে (১৪ দিন, 21/10 থেকে → portal 05/11, আসল 03/11)। আসল তারিখ বাছলে Proceed-এর ঠিক আগে প্রত্যেকের To box আবার দেখে নেয়; না মিললে ওই registration submit করে না আর run থামায়। Results Excel-এ নতুন "Work Demand To" column।
- **Field Autofill**: Dashboard → **🎯 Field বাছুন** → portal-এর field-এ click → default লিখে রাখুন। পরের বার ওই page খুললে নিজে ভরে (আগে থেকে ঠিক value থাকলে আর লেখে না, তাই postback loop হয় না; আপনার টাইপ করা জিনিস বদলায় না)। Dashboard-এ সব default-এর তালিকা, ✕ দিয়ে মোছা যায়। শুধু এই PC-তে থাকে।
- **Copy / Paste চালু**: portal যেখানে paste, copy, right-click বন্ধ করে রাখে, সেখানে চালু করে।
- **Password দেখা**: password box-এর পাশে 👁 বোতাম; চাপলে দেখায়, আবার চাপলে লুকায়। Login চাপার আগে নিজে লুকিয়ে দেয়। (Ninja সব password নিজে খুলে দেয়; এখানে আপনি চাপলে তবেই, অফিসের PC-র জন্য নিরাপদ।)
- **Login ধরে রাখা**: portal tab খোলা থাকলে প্রতি ৪ মিনিটে portal-এর menu page-এ একটা হালকা request, যাতে মাঝপথে logout না হয়। Bulk run চললে সেটাও "ব্যবহার" ধরে। ৮ ঘণ্টা কেউ কিছু না করলে থেমে যায়। Request শুধু portal-এর নিজের server-এ যায়।
- নতুন ৫টা feature-এরই Dashboard-এ আলাদা On/Off tile। MR Attendance K-Dock-এও আছে।
- Ninja-র Supervisor App, Usage statistics আর Tracker নেওয়া হয়নি: ওগুলো বাইরের server-এ data পাঠায়।

## v1.5.3 — Demand / Allocation-এর গতি
- Work Demand আর Work Allocation panel-এ ধাপের নিচে নতুন **⏱ গতি**: খুব ধীর / ধীর / স্বাভাবিক / দ্রুত। Default "স্বাভাবিক" = আগের মতই।
- Portal ধীর থাকলে "ধীর" (২ গুণ) বা "খুব ধীর" (৩ গুণ) দিন: প্রতিটা ধাপের মাঝে বেশি বিরতি, আর data load হওয়ার জন্য বেশি অপেক্ষা। তাতে data আসার আগে পরের জনে চলে যাবে না।
- "দ্রুত" শুধু ধাপের মাঝের বিরতি কমায়; portal-এর data-র জন্য অপেক্ষা কখনো কমায় না।
- দুটো panel-এ একই setting, মনে থাকে, চলমান কাজেও পরের ধাপ থেকে লেগে যায়।

## v1.5.2 — K-Dock Maximize (নাম সহ)
- K-Dock-এর একদম নিচে নতুন **«** বোতাম। চাপলে bar চওড়া হয়ে প্রতিটা icon-এর পাশে নাম দেখায় (Work Demand, ABPS Data Sync ইত্যাদি)। "» ছোট করুন" চাপলে আবার শুধু icon।
- উপরের **K** আগের মতই: চাপলে bar ছোট (minimize), আবার চাপলে ফিরে আসে। কোন অবস্থায় ছিল সেটা মনে থাকে।
- পাশে খোলা panel-গুলো bar চওড়া / সরু হলে নিজে থেকেই সরে যায়। বাকি সব আগের মতই।

## v1.5.1 — Tour fix
- পরিচয় tour-এর ৩, ৪ আর ৫ নম্বর ধাপে "আগের" / "পরের" বোতাম চাপা যাচ্ছিল না (পেছনের কালো পর্দা বোতামের উপরে চলে আসছিল)। এখন সব ধাপে কাজ করে।

## v1.5.0 — নতুন icon
- K-Dock আর Dashboard-এ **ABPS Data Sync**-এর icon এখন আঙুলের ছাপ + "ABPS" লেখা।
- **ABPS Enable (NPCI)**-এর icon এখন ঢালে ✓ + "NPCI" লেখা।
- আর কিছু বদলায়নি (v1.4.1-এর trial ও মেয়াদি key সহ সব আগের মতই)।
- Update: একই folder-এ file বদলে Reload করুন, activation আর data থেকে যাবে।

## Folder structure
- `manifest.json` — Extension configuration
- `ui/` — Popup ও List Builder page
- `content/demand/` — Work Demand script
- `content/allocation/` — Work Allocation script
- `content/sync/` — e-KYC / ABPS Sync
- `content/mr/` — Muster Roll PDF page helper
- `background/` — MR PDF save ও tab management
- `shared/` — common core এবং List Builder logic
- `vendor/` — XLSX library
- `assets/icons/` — Extension icon

## Install
1. ZIP extract করো।
2. Chrome-এ `chrome://extensions` খোলো এবং Developer mode চালু করো।
3. **Load unpacked** চাপো এবং extract করা `G_RAM_G_Demand-Allocation_Helper_v1.0.9_Folderized` folder নির্বাচন করো—যেখানে `manifest.json` আছে।
4. আগের সফল ZIP backup হিসেবে রেখে দিও।

## v1.0.9-এ কী বদলেছে
- কোড, UI, vendor library, icon ও background script আলাদা folder-এ সাজানো হয়েছে।
- নতুন file path অনুযায়ী manifest ও HTML asset path update করা হয়েছে।
- Demand, Allocation, e-KYC/ABPS Sync বা MR PDF processing logic-এ ইচ্ছাকৃত পরিবর্তন করা হয়নি।

## যাচাই
Manifest-এর সব script/icon path file-এর সঙ্গে মিলিয়ে দেখা হয়েছে, HTML resource path validate করা হয়েছে, JavaScript syntax check ও ZIP integrity test সফল। Packaging update হিসেবে live portal end-to-end পরীক্ষা করা হয়নি; ১–২টি record দিয়ে পরীক্ষা করে তারপর বড় batch চালিও।

## Source attribution
এই Extension-এর Work Demand ও Work Allocation workflow ব্যবহারকারীর দেওয়া GramG Ninja v7.0.0 থেকে adapted। এটি স্বাধীন, unofficial customized build; original author-এর endorsement বোঝায় না।


UI update v1.0.9: gerua/orange theme, Noto Sans Bengali-first font stack, and source/adaptation labels removed from the visible interface as requested.


## v1.1.6 Work Allocation fix
- Restored the original Ninja direct-`tbody` Grid row strategy for Work Allocation instead of the later custom descendant-row parsing.
- Kept G RAM G branding, gerua UI, ABPS/e-KYC badges, and existing demand/allocation workflow.
- Syntax checked; live portal testing still required.


## v1.1.8 Stop Fix
- Fix: Stop request is now preserved when an async portal step finishes and the engine tries to save an older in-memory state. This prevents the old state from switching the run back to active.
- Applied the same stale-state protection to Work Demand and Work Allocation.
- JavaScript syntax, manifest JSON, and ZIP integrity checked. Live portal Stop behavior still needs user-side confirmation.


## v1.1.9 MR PDF Landscape + White Background
- সমস্যা: Portal-এর নিজস্ব print CSS (`@page` portrait) Chrome-এর landscape setting-কে override করছিল, তাই MR PDF portrait-এ আসছিল এবং পেছনে ধূসর/রঙিন background থাকত।
- সমাধান: PDF তৈরির ঠিক আগে MR tab-এ একটি style inject করা হয় — A4 landscape, সাদা background, কালো লেখা।
- শুধু `background/mr-pdf-background.js` বদলানো হয়েছে; Work Demand, Work Allocation, ABPS Sync ও MR queue logic অপরিবর্তিত।
- Chromium-এ test PDF দিয়ে যাচাই: page size 11.69 × 8.27 inch (A4 landscape), background সাদা। Live portal-এ ১–২টি MR দিয়ে যাচাই করে নিও।


## v1.2.0 MR Batch Print integrated
- পুরনো MR PDF Saver (background service worker + Chrome debugger দিয়ে PDF) সরিয়ে Koushik-এর standalone **MR Batch Print v1.6.0** বসানো হয়েছে।
  - `content/mr/mr-batch-print.js` — panel, Fast/Safe engine, Excel/paste থেকে Work Code, Print All (A4 landscape, সাদা background, Scale)
  - `content/mr/mr-frame-guard.js` — শুধু MR-এর লুকানো iframe-এ alert/confirm/print আটকায়
- সরানো হয়েছে: `background/mr-pdf-background.js`, `content/mr/mr-pdf-helper.js`, আর শুধু ওদের জন্য লাগা `debugger`, `downloads`, `tabs` permission (Chrome-এর হলুদ "debugging" bar আর আসবে না)।
- MR script-এ একটাই পরিবর্তন: storage থেকে শুধু `mr…` key cache করে (একই storage-এ ABPS data থাকায়)। MR-এর কাজের logic অপরিবর্তিত।
- Popup-এ "Open Print Muster Roll" button যোগ; popup layout ও version ঠিক করা হয়েছে।
- Work Demand, Work Allocation, ABPS Sync, List Builder অপরিবর্তিত।
- যাচাই: সব JS syntax check; Chromium-এ extension load করে mock page-এ MR panel ও Demand panel দুটোই চলছে, কোনো error নেই। Live portal-এ ১–২টি Work Code দিয়ে যাচাই করে নিও।
- আলাদা "MR Batch Print by Koushik" extension আর চালু রাখার দরকার নেই — দুটো একসাথে চালু থাকলে কোনটার panel আসবে ঠিক থাকবে না, তাই standalone-টা Disable/Remove করো। জমা থাকা MR data নতুন extension-এ আসবে না (আলাদা storage)।


## v1.2.1 MR Batch Print-এর মতো নতুন look
- Work Demand, Work Allocation, ABPS Data Sync আর List Builder panel এখন MR Batch Print-এর মতো দেখতে: navy-indigo header, সোনালি "K" logo, সোনালি দাগ, গোল কোণা, গাঢ় Activity log, আর নিচে "✦ Crafted by KOUSHIK" footer।
- Popup নতুন করে সাজানো: জমা থাকা MR-এর সংখ্যা, List Builder আর Print Muster Roll button।
- Extension icon এখন MR Batch Print-এর "K" icon।
- শুধু রং আর layout বদলেছে। Demand, Allocation, ABPS, List Builder আর MR-এর কাজের কোড আগের মতোই।


## v1.2.2 Wage List Caste Map (SmartDesk format)
- নতুন file: `content/wage/wage-caste-map.js`। বাকি সব file আগের মতোই (শুধু manifest, popup, README বদলেছে)।
- **ধাপ ১:** Registration Application Register (`panchregpeople.aspx`) page খুলুন, পুরো list load হলে নিচে ডানদিকের **📋 Load Register Data** চাপুন। Job Card → Caste (SC / ST / OTH) map extension-এ জমা হয়। অন্য GP বা village-এর register load করলে আগের map মোছে না, নতুনগুলো যোগ হয়।
- **ধাপ ২:** Unskilled Wage List (`view_wagelist.aspx`, URL-এ `flag=UNSK`) খুলুন, **⚙ Generate Report** চাপুন। SmartDesk-এর একই table আসবে: Muster Roll অনুযায়ী General / SC / ST-এর Unskilled Wagelist No. আর amount, আর head code (101 / 789 / 796)।
- **Copy Report** শুধু data row copy করে (header নয়), Excel-এ paste করার জন্য।
- কোনো Job Card-এর caste না পাওয়া গেলে সেই amount কোনো column-এ যোগ হয় না, Remarks-এ লাল লেখায় "Unmatched Job Card" দেখায়। তখন register আবার load করুন।
- Popup-এ caste map-এ কত Job Card জমা আছে দেখা যায়।
- এখন সব `*.dord.gov.in` server-এ চলে (SmartDesk শুধু vbgramgde2 / vbgramgrep-এ চলত)।
- SmartDesk-এর caste data আলাদা storage-এ থাকে, তাই Helper-এ একবার register load করতে হবে।


## v1.2.3 Wage List Caste Breakup — Ninja-র মতো নিজে থেকে
- **Button চাপতে হয় না।** Registration Application Register page খুললে পুরো list load হলেই Job Card → Caste নিজে জমা হয় (toast-এ কতগুলো জমা হল দেখায়)। Page কোনো frame-এর ভিতরে খুললেও চলে।
- **Unskilled Wage List** পুরো load হলে ("Download In Excel" বা job card row দেখা দিলে) report নিজে থেকেই খোলে। বন্ধ করলে নিচে ডানদিকে **⚖ Caste breakup** দিয়ে আবার খোলা যায়। Skilled/Semi-skilled list-এ (URL-এ `flag=` UNSK ছাড়া অন্য কিছু) চলে না।
- Report-এর format SmartDesk-এর মতোই: MR অনুযায়ী General / SC / ST, head code 101 / 789 / 796, **Copy Report** শুধু data row copy করে।
- Ninja-র মতো page-এর সব row একসাথে পড়ে (wage list কয়েকটা table-এ ভাগ থাকলেও), আর page-এ লেখা wage list total-এর সঙ্গে হিসেব মিলিয়ে সবুজ ✓ বা কমলা ⚠ দেখায়।
- SC / ST ছাড়া অন্য যেকোনো caste (OTH, OBC ইত্যাদি) General-এ যায়। যে Job Card register-এ নেই তার টাকা কোনো category-তে যায় না, Remarks-এ লাল লেখায় দেখায়।
- Caste register ৭ দিনের বেশি পুরনো হলে মনে করিয়ে দেয়। v1.2.2-এ জমা করা data নিজে নতুন version-এ চলে আসে।
- নতুন file লাগেনি: শুধু `content/wage/wage-caste-map.js` বদলেছে, সঙ্গে manifest, popup আর README। Demand, Allocation, ABPS, MR অপরিবর্তিত।


## v1.2.4 Caste report popup compact
- Report popup আর পুরো screen জোড়ে না: table-এর মাপ অনুযায়ী মাঝখানে বসে (সর্বোচ্চ screen-এর 94% চওড়া, 80% উঁচু)।
- ছোট font আর padding, লম্বা column heading দুই-তিন লাইনে ভাঙে, ফলে বেশি column একসাথে দেখা যায়। অনেক MR থাকলে ভিতরে scroll হয়, header উপরে আটকে থাকে।
- শুধু দেখতে বদলেছে; হিসেব, Copy Report আর format আগের মতোই।


## v1.2.5 Wage List Status (পুরো GP-র status সহ)
- নতুন file: `content/wage/wagelist-status.js` (GramG Ninja v7.0.0-এর Wage List Status থেকে নেওয়া, Helper-এর MR-style look, বাইরের কোনো link নেই)।
- **View Wage List** page-এ ডানদিকে উপরে **Wage List Status** panel আসে (টেনে সরানো যায়, – দিয়ে ছোট করা যায়)।
  - প্রতিটি Job seeker Name-এর পাশে **eKYC ✓/✗** আর **ABPS ✓/✗**; mouse রাখলে পরের ধাপ (Aadhaar seed, eKYC, ABPS enable) দেখায়। Ready নয় এমন row-এর বাঁদিকে লাল দাগ।
  - "শুধু যারা ready নয়" tick দিলে বাকিরা লুকিয়ে যায়।
  - **⭳ এই wage list Excel-এ**: খোলা wage list-এর সব worker আর আলাদা "Not ready" sheet।
  - **⭳ Whole-GP report**: dropdown-এর সব wage list পিছনে একটা একটা করে পড়ে (page বদলায় না, ধীর portal-এ ৩ বার পর্যন্ত চেষ্টা করে), তারপর "All workers" আর "Not ready" sheet সহ একটা Excel দেয়। Login মেয়াদ শেষ হলে থেমে যায়।
- Status আসে **ABPS Data Sync**-এর জমা data থেকে (Helper-এর ABPS report sync), তাই আগে ABPS sync করা থাকতে হবে। Panel-এ দেখায় data কবে sync হয়েছে, এক সপ্তাহের বেশি পুরনো হলে মনে করায়।
- Aadhaar No. column কখনও পড়া হয় না; সব কিছু শুধু browser-এ।
- Caste breakup popup Status panel-এর উপরে আসে, দুটো একসাথে চলে।


## v1.2.6 Dashboard-এ feature On/Off
- Extension icon-এ click করলে যে popup (Dashboard) খোলে, সেখানে section অনুযায়ী toggle:
  - Work Demand & Allocation: **Work Demand**, **Work Allocation**
  - ABPS / eKYC: **ABPS Data Sync**
  - Wage List: **Caste Breakup**, **Wage List Status**
  - Muster Roll: **MR Batch Print**
- Off করা feature-এর panel portal page-এ আর আসে না। বদলের পর portal page একবার reload করতে হয়। প্রথমবার সব On থাকে।
- জমা data (MR, ABPS, caste) Off করলেও মোছে না, আবার On করলে আগের মতো পাওয়া যায়।
- Caste Breakup Off থাকলে register থেকে caste জমাও হয় না।
- Work Demand / Allocation-এর page-level "driver" (portal-এর alert/confirm সামলায়) সবসময় চালু থাকে, কারণ চলতি run মাঝপথে থামলে resume করার জন্য দরকার; panel Off থাকলে সে নিজে কিছু করে না।
- নতুন file: `shared/feature-gate.js`। ছয়টা panel script শুধু এই gate দিয়ে মোড়ানো হয়েছে, ভিতরের code অপরিবর্তিত।


## v1.2.7 শুধু Koushik branding
- Helper-এর code-এ (comment সহ) আর কোথাও GramG Ninja, VisionTech বা বাইরের link নেই।
- Wage list page-এ যে Ninja popup / Wage List Status দেখা যাচ্ছিল, সেটা Chrome-এ আলাদা করে চালু থাকা **GramG Ninja extension**-এর নিজের, Helper-এর নয়। Helper-এর Caste Breakup বা Wage List Status **On** থাকলে এখন একই page-এ Ninja আর SmartDesk-এর একই রকম popup, button আর ✓ চিহ্ন লুকিয়ে রাখা হয়, শুধু Helper-এর report দেখায়।
- Helper-এ ওই feature Off করলে Helper আর কিছু লুকায় না, তখন Ninja চালু থাকলে Ninja-রটা দেখা যাবে। তাই Ninja দরকার না হলে chrome://extensions-এ Off রাখুন।
- Wage List Status-এর ✓ চিহ্নের class নাম আলাদা করা হয়েছে, যাতে Ninja চালু থাকলেও Helper-এর চিহ্ন মুছে না যায়।

## v1.2.8 — ABPS Enable (NPCI) bulk run
- Portal-এর `UID/VUID_NPCI.aspx` page খুললে ডানদিকে "ABPS Enable (NPCI)" panel আসবে।
- যে village খোলা আছে সেখান থেকে শুরু করে প্রতিটি row-তে Show Aadhaar Number → Check with NPCI চালায়; সবুজ (OK) হলে Save করে, না হলে portal-এর কারণসহ log-এ রাখে। পরের page ও পরের village নিজে থেকে চলে।
- Stop / Resume, Download log, শুধু "Not enabled" list download, New run (clear) আছে।
- Dashboard-এ "ABPS / eKYC → ABPS Enable (NPCI)" toggle Off করলে panel আসবে না এবং চলমান run থেমে যাবে।
- Wage List Status এখন এই run-এর ফল (NPCI) থেকেও next step দেখায়।
- ⚠ এটা portal-এ আসল Save করে। প্রথমে একটা ছোট village দিয়ে চালিয়ে দেখুন। Ninja extension একই সাথে On রাখবেন না।

## v1.2.9 — PC lock (Activation key)
- নতুন PC-তে Helper lock অবস্থায় থাকে: Dashboard-এ সব toggle বন্ধ (ধূসর), কোনো feature portal-এ চলে না, List Builder খোলে না।
- Dashboard-এ এই PC-র Device ID দেখায় (যেমন KH-P3AZK-SLHEQ)। সেটা Koushik-কে পাঠাতে হবে।
- Koushik "KH Key Generator" file-এ Device ID দিয়ে key বানিয়ে দেন। Dashboard-এ paste করে Activate চাপলেই খুলে যায়। প্রতি PC-তে একবারই লাগে।
- এক PC-র key অন্য PC-তে কাজ করে না। Extension Remove করে আবার install করলে বা নতুন Chrome profile-এ নতুন Device ID হয়, তখন নতুন key লাগবে।

## v1.3.0 — K-Desk Suite (নতুন নাম আর design)
- নাম এখন **K-Desk Suite** (by Koushik)। সব panel-এ এক রকম "Indigo glass" theme, header-এ "K-Desk Suite", footer-এ "✦ Crafted by KOUSHIK"।
- **K-Dock:** portal-এর ডান ধারে সরু bar। যে page খোলা তার feature gold হয়, NPCI run চললে সবুজ dot, Off করা feature ধূসর। Icon-এ click করলে panel খোলে/লুকায়। উপরের "K"-তে click করলে bar ছোট হয়ে শুধু একটা K button থাকে। Dashboard থেকে "K-Dock bar" Off করা যায়।
- **নতুন Dashboard:** "Licensed to" badge, জমা থাকা data (MR, Caste map, ABPS worker, NPCI Saved), feature tile আর On/Off, সাম্প্রতিক কাজ।
- **Key-তে নাম:** Key Generator-এ "Licensed to" নাম দিলে নতুন ধরনের key (KH2) তৈরি হয়, Dashboard-এ সেই নাম দেখায়। পুরনো KH1 key-ও আগের মতো কাজ করে।
- Update: একই folder-এ files replace করে Reload করলে activation আর data দুটোই থাকে।

## v1.3.1 — নিজস্ব panel layout আর K-Dock থেকে page খোলা
- K-Dock-এর পাশে panel এখন পুরো উচ্চতার drawer হিসেবে বসে (ডান ধারে লাগানো)। Header-এ বড় feature নাম, উপরে "K-DESK SUITE"।
- Progress এখন গোল ring-এ % দেখায়। Activity log ভাঁজ করা থাকে (click করলে খোলে, কতগুলো entry তা পাশে লেখা)। নির্দেশনা আর সতর্কতা "ⓘ নির্দেশনা ও সতর্কতা"-র নিচে এক জায়গায়।
- Start button gold, Stop লাল border-এর; অবস্থা-বার্তা gold দাগ দেওয়া card-এ।
- K-Dock icon-এ click করলে সেই feature-এর page খোলে। কোনো কাজ চললে (Demand/Allocation/NPCI run, ABPS sync, MR print) আগে সতর্ক করে: নতুন tab-এ খুলুন / তবুও এই tab-এ / বাতিল।

## v1.3.2 — Readiness Report (Work Allocation)
- Work Allocation page-এ grid-এর উপরে **📋 Readiness Report (eKYC / ABPS / Account)** button। চাপলে list-এর প্রত্যেক beneficiary-র eKYC, ABPS আর Account আছে কিনা একটা table-এ দেখায়, সঙ্গে "কী বাকি"।
- Grid-এ কাউকে tick করা থাকলে শুধু তাদের report, না হলে পুরো list। Grid না থাকলে Work Allocation panel-এ load করা list থেকে।
- eKYC / ABPS আসে **ABPS Data Sync**-এর জমা data থেকে (আগে sync করা থাকতে হবে)।
- Account আসে portal-এর `pension_scheme.aspx` থেকে, **শুধু এই list-এর Job Card-গুলোর** জন্য, একটা একটা করে (প্রতি request-এর মাঝে বিরতি)। পুরো GP-র account টানা হয় না।
- জমা থাকে শুধু bank-এর নাম আর account-এর **শেষ ৪ digit**, ৭ দিন পরে নিজে মুছে যায়। পুরো account number বা IFSC কোথাও রাখা হয় না। "🗑 Account cache মুছুন" দিয়ে আগেই মোছা যায়।
- **🖨 Print** (A4, Prepared by / Verified by সহ), **⭳ Excel**, "শুধু যারা ready নয়" filter।
- Dashboard-এ "Readiness Report" toggle। নতুন file: `content/allocation/alloc-readiness.js`; বাকি feature-এর code অপরিবর্তিত।

## v1.3.3 — Readiness Report: নাম মেলানো আরও ভালো
- Pension page-এর নামে applicant no., বন্ধনী, S/O, আলাদা space ("SUDHA RANJAN") বা মাঝের নাম বাদ থাকলেও এখন মেলে।
- তবুও না মিললে "কী বাকি"-তে দেখায় pension page-এ ওই Job Card-এ কোন কোন নাম আছে।
- শুধু `content/allocation/alloc-readiness.js` বদলেছে।

## v1.3.4 — Account: Updated / Not Updated আর পুরো বিবরণ
- কারও নিজের নামে account না থাকলে (একই Job Card-এ অন্যদের থাকলেও) এখন সোজা **✕ Not Updated**, পাশে লেখা থাকে ওই Job Card-এ কার কার account আছে।
- Account থাকলে **✓ Updated**, সঙ্গে Account holder-এর নাম, Bank, Branch আর পুরো IFSC। Account number-এর শুধু শেষ ৪ digit দেখায়।
- Print আর Excel-এও একই (Excel-এ A/C Holder, Bank, Branch, IFSC আলাদা column)।
- নতুন field-এর জন্য account একবার নতুন করে check হবে (পুরনো cache নিজে মুছে যায়)।

## v1.3.5 — Account এক লাইনে, Readiness panel, নিচের ফাঁকা জায়গা
- Readiness Report-এ Account এখন এক লাইনে: **পুরো Account No. · Bank · IFSC**। Excel-এও শুধু এই তিনটে column।
- Report এখন অন্য panel-এর মতো ডান ধারের drawer। K-Dock-এ নতুন **Readiness Report** icon (Work Allocation-এর নিচে) দিয়ে খোলে/বন্ধ হয়। Grid-এর উপরের আটকে থাকা button সরানো হয়েছে। K-Dock Off থাকলে নিচে বাঁদিকে ছোট একটা button আসে।
- সব panel এখন যতটা content ততটাই লম্বা হয়, নিচে ফাঁকা জায়গা থাকে না (অনেক content হলে screen-এর উচ্চতা পর্যন্ত, ভিতরে scroll)।
- ABPS Data Sync-এর "ⓘ নির্দেশনা ও সতর্কতা" এখন বাংলায়।

## v1.3.6 — Report-এ আলাদা column, Demand/Allocation নির্দেশনা বাংলায়
- Readiness Report-এ "কী বাকি" column বাদ। Account No., Bank, IFSC এখন তিনটে আলাদা column (panel, Print, Excel সবখানে)। Account না থাকলে তিন column জুড়ে "✕ Not Updated" (mouse রাখলে কারণ দেখায়)।
- Work Demand আর Work Allocation panel-এর "ⓘ নির্দেশনা ও সতর্কতা" এখন বাংলায়।

## v1.4.0 — নতুন UI সুবিধা
- **ধাপে ধাপে guide:** Work Demand, Work Allocation, ABPS Data Sync, ABPS Enable (NPCI) আর Readiness Report panel-এর মাথায় ধাপগুলো দেখায়। যেটা হয়ে গেছে তাতে ✓, এখন যেটা করতে হবে সেটা gold, কাজ চললে gold বিন্দু জ্বলে-নেভে। নিচে এক লাইনে পরের কাজ।
- **কাজ শেষ হলে জানানো:** Demand / Allocation / NPCI run, ABPS sync, Readiness account check বা MR print শেষ হলে Windows notification, হালকা শব্দ আর page-এ একটা বার্তা। Dashboard থেকে শব্দ বা notification আলাদা করে বন্ধ করা যায়। ("notifications" permission যোগ হয়েছে।)
- **Dark mode আর Compact mode:** Dashboard-এ toggle, বা portal-এ `Alt+N` / `Alt+C`। সব panel, MR panel আর Dashboard-এ কাজ করে।
- **Panel-এর মাপ:** panel-এর বাঁ ধার টেনে চওড়া / সরু করা যায়, মাপ মনে থাকে। ধারে double-click করলে আগের মাপ।
- **Keyboard shortcut:** `Alt+K` K-Dock ছোট/বড়, `Alt+R` Readiness Report, `Alt+N` Dark, `Alt+C` Compact, `Esc` খোলা panel লুকানো, `Alt+/` সব shortcut।
- **Dashboard-এ "আজ":** আজ কতজনের Demand আর Allocation হয়েছে, আজ NPCI-তে কতজন Saved, ABPS data কত দিন পুরনো (৭ দিনের বেশি হলে লাল)। Demand / Allocation-এর হিসাব portal page খোলা থাকাকালীন জমা হয়।
- **Animation আর loading:** panel খোলার সময় নরম slide, Readiness Report-এ account আসার সময় ঝিলিক দেওয়া ধূসর দাগ, Dashboard-এর সংখ্যাও তাই।
- **প্রথমবারের tour:** নতুন install বা update-এর পর portal-এ ৫ ধাপের ছোট পরিচয়। Dashboard-এ "Tour আবার দেখুন" দিয়ে আবার দেখা যায়।
- নতুন file: `shared/kux.js`, `background/kd-bg.js`। বাকি feature-এর কাজের code অপরিবর্তিত।

## v1.4.1 — ৭ দিনের Trial আর মেয়াদি License
- নতুন PC-তে key ছাড়াই প্রথম ব্যবহারের দিন থেকে ৭ দিন সব feature চলে। Dashboard-এ "Trial: N দিন বাকি" দেখায়, শেষ ৩ দিন portal-এ দিনে একবার মনে করায়।
- Trial শেষ হলে সব feature বন্ধ, Dashboard-এ Device ID আর key box আসে।
- Key Generator-এ "মেয়াদ" বাছা যায়: আজীবন, ৭ দিন, ১/৩/৬ মাস, ১ বছর বা নিজের তারিখ। মেয়াদি key সেই তারিখের রাত পর্যন্ত চলে।
- মেয়াদ শেষ হতে ১৫ দিন বাকি থাকলে Dashboard-এ নতুন key দেওয়ার box খোলে; নতুন key দিলে পুরনোটার জায়গা নেয়।
- আগের KH1/KH2 key আগের মতোই আজীবন চলে, কাউকে নতুন key দিতে হবে না।
- Trial-এর শুরুর দিন Chrome sync-এও থাকে, তাই একই Chrome account-এ extension মুছে আবার বসালে Trial নতুন হয় না; PC-র ঘড়ি পিছিয়েও মেয়াদ বাড়ে না।


## v1.19.0 ⚖ WL Caste Breakup (অনেক wage list একসাথে)
- নতুন file: `content/wage/wl-caste-bulk.js` (আগের আলাদা test extension "WL Caste Breakup (Test)" v0.3.0, Koushik আসল portal-এ test করেছেন)। Dashboard toggle **WL Caste Breakup**, K-Dock-এ ⚖ (দাঁড়িপাল্লা) icon।
- **View Wagelist** page-এ K-Dock-এর ⚖ icon চাপলে panel খোলে। Financial Year → wage list tick (Range, খুঁজে tick, "K-Desk শেষ Generate run", বা **🆕 শেষ report-এর পরের নতুন WL**) → ▶ Start।
- Tick দেওয়া wage list গুলো background-এ পড়ে (dropdown বদলানোর মতো postback, শুধু পড়া; page বদলায় না)। আগে পড়া WL আবার পড়ে না; থামলে বা login গেলে আবার ▶ চাপলে বাকিগুলো।
- Report = আগের **Caste Breakup**-এর একই ১৬টা column, প্রতি wage list + Muster Roll-এ এক row → **⭳ Excel** (Caste Breakup + WL Check + Workers sheet) বা **📋 Copy (সব row)**।
- Caste আসে K-Desk-এর জমা register থেকে (Registration Application Register একবার খুললেই)।
- **🏠 শুধু IAY**: Work Code-এ /IAY/ নেই এমন row বাদ।
- Excel/Copy করলে WL গুলো "report দেওয়া" (📄) — এই PC-তে আর **Gram Setu**-তে (SQL v215) মনে থাকে, তাই অন্য PC থেকেও শুধু নতুন WL আসে। Gram Setu Admin panel → **⚖ WL Caste** tab-এ সব report, আবার Excel, আর **Undo** (WL গুলো আবার "নতুন" হয়)। Gram Setu-তে login না থাকলে শুধু এই PC-তে মনে থাকে, পরে login হলে পাঠিয়ে দেয়।
- Gram Setu-তে শুধু wage list নম্বর, তারিখ, MR-ভিত্তিক General/SC/ST টাকা আর caste না মেলা Job Card নম্বর যায়; নাম, account বা Aadhaar যায় না।
- v1.19.1: পুরনো **Caste Breakup** toggle Off থাকলেও ⚖ WL Caste Breakup নিজেই Registration Application Register থেকে caste জমা করে (`content/wage/caste-register.js`, table পড়ার নিয়ম `shared/wl-table-kit.js`-এ)।

## v1.20.0 — নতুন version এলে K-Desk নিজেই জানায়
- K-Desk ৬ ঘণ্টায় একবার `https://gramsetu.koushiktech.co.in/kdesk/latest.json` পড়ে (`shared/kd-update.js`)। এখানে শুধু version নম্বর আসে, কোনো portal data বাইরে যায় না।
- নতুন version থাকলে toolbar-এর K icon-এ সোনালি **NEW** badge, আর Dashboard-এর উপরে banner: কী নতুন (৪টা লাইন), **⬇ Download zip**, আর "কীভাবে বসাবেন?" ধাপ (পুরনো folder-এ Replace → chrome://extensions → ⟳ Reload)।
- **পরে** চাপলে ওই version ২৪ ঘণ্টা চুপ থাকে। `latest.json`-এ `min_version` দিলে তার নিচের version-এ লাল **জরুরি update** banner, "পরে" বোতাম থাকে না।
- Update বসানোর পরে ৩ দিন একবার সবুজ "✅ vX-এ update হয়েছে"।
- Settings tab → **Update**: আপনার version, শেষ কবে দেখা হয়েছে, আর **🔄 এখনই দেখুন**।
- Chrome নিজে থেকে update বসাতে পারে না: K-Desk unpacked extension (Web Store-এ নেই), তাই zip বদলানো এখনো হাতে করতে হয়, শুধু মনে রাখার কাজটা K-Desk করে।
