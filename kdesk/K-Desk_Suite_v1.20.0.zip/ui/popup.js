// Popup (K-Desk Suite Dashboard): জমা থাকা data-র হিসাব, সাম্প্রতিক কাজ, PC activation lock আর feature On/Off tile।
const KEYS = ['mr_index', 'kd_runs', 'kh_caste_meta_v2', 'dxAbpsMeta', 'khnpLastRun', 'kh_features', 'kd_today', 'kh_ui'];
const UI_DEF = { dark: false, compact: false, sound: true, notify: true };
// খোলার সময় মাপা (Settings tab-এ দেখায়): page তৈরি, data পড়া, license যাচাই আলাদা করে
kdm('js');
const PERF = {};
// Side panel-এ (popup নয়) খোলা হলে মাপ নির্দিষ্ট নয়, পুরো উচ্চতা জুড়ে থাকে
const IS_POPUP = (() => { try { return chrome.extension.getViews({ type: 'popup' }).includes(window); } catch (e) { return true; } })();
if (!IS_POPUP) document.documentElement.classList.add('sp');
kdm('views');
// দ্রুত খোলা: আগের বারের সংখ্যা আর Dark/Compact সঙ্গে সঙ্গে দেখানো (popup-এর নিজের localStorage),
// তারপর storage থেকে আসল মান এলে বদলানো। Popup-এর মাপ নির্দিষ্ট, তাই খোলার সময় আকার বদলায় না।
const CACHE_IDS = ['td', 'ta', 'tn', 'tab', 'n', 'c', 'ab', 'np'];
(function fromCache() {
  try {
    const c = JSON.parse(localStorage.getItem('kd_pop_cache') || 'null');
    if (c) {
      CACHE_IDS.forEach((id) => { if (c[id]) { const el = document.getElementById(id); el.textContent = c[id][0]; el.className = c[id][1] || ''; } });
      document.body.classList.toggle('dark', !!c.dark); document.body.classList.toggle('compact', !!c.compact);
    }
  } catch (e) {}
  kdm('cache');
})();
function saveCache(ui) {
  try {
    const c = { dark: !!ui.dark, compact: !!ui.compact };
    CACHE_IDS.forEach((id) => { const el = document.getElementById(id); c[id] = [el.textContent, el.className]; });
    localStorage.setItem('kd_pop_cache', JSON.stringify(c));
  } catch (e) {}
}
// Tab: আজ / Features / Settings (শেষ বারের tab মনে থাকে); Autofill তালিকা শুধু Features tab-এ পড়া হয়
// খোলার সময় scrollTop ছোঁয়া হয় না: ওটা page আঁকার আগেই পুরো layout জোর করে করিয়ে নেয় (Windows-এ ধীর)
function showTab(t, first) {
  document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.t === t));
  document.querySelectorAll('section[data-p]').forEach((sct) => { sct.hidden = sct.dataset.p !== t; });
  if (!first) document.querySelector('.b').scrollTop = 0;
  try { localStorage.setItem('kd_pop_tab', t); } catch (e) {}
  if (t === 'feat') afRender();
}
document.querySelectorAll('#tabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.t)));
(function () { let t = 'home'; try { t = localStorage.getItem('kd_pop_tab') || 'home'; } catch (e) {} if (!document.querySelector('section[data-p="' + t + '"]')) t = 'home'; showTab(t, true); })();

function isToday(t) { return !!t && new Date(t).toDateString() === new Date().toDateString(); }

function ago(t) {
  if (!t) return '';
  const d = new Date(t), now = new Date();
  const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  if (d.toDateString() === now.toDateString()) return 'Today ' + hm;
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday ' + hm;
  return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0');
}

kdm('get');
chrome.storage.local.get(KEYS).then((r) => {
  kdm('data');
  // জমা থাকা data
  document.getElementById('n').textContent = (r.mr_index || []).length;
  // Caste map-এর সংখ্যা meta থেকে (পুরো map পড়লে Dashboard দেরিতে খোলে); meta-য় না থাকলে পরে আলাদা করে পড়ে
  if (r.kh_caste_meta_v2 && r.kh_caste_meta_v2.count != null) document.getElementById('c').textContent = r.kh_caste_meta_v2.count;
  else setTimeout(() => chrome.storage.local.get('kh_caste_map_v2').then((m) => { document.getElementById('c').textContent = Object.keys(m.kh_caste_map_v2 || {}).length; }), 300);
  renderRuns(r.kd_runs || []);
  const abMeta = r.dxAbpsMeta || {};
  document.getElementById('ab').textContent = Object.values(abMeta).reduce((s, m) => s + ((m && m.count) || 0), 0);
  const npRes = (r.khnpLastRun && r.khnpLastRun.results) || [];
  document.getElementById('np').textContent = npRes.filter((x) => x.result === 'Saved').length;

  // আজ: portal page-এর kux.js যে হিসাব জমা রাখে, আর NPCI-এর আজকের Saved
  const dt = new Date(), key = dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
  const tday = r.kd_today && r.kd_today.date === key ? r.kd_today : null;
  document.getElementById('td').textContent = (tday && tday.demand) || 0;
  document.getElementById('ta').textContent = (tday && tday.alloc) || 0;
  document.getElementById('tn').textContent = npRes.filter((x) => x.result === 'Saved' && isToday(x.t)).length;
  const last = Math.max(0, ...Object.values(abMeta).map((m) => (m && m.savedAt) || 0));
  const abEl = document.getElementById('tab');
  if (last) {
    const days = Math.floor((Date.now() - last) / 86400000);
    abEl.textContent = days ? days + (days > 1 ? ' days' : ' day') : 'Today';
    abEl.className = days > 7 ? 'warn' : 'okc';
    abEl.title = days > 7 ? 'Older than 7 days, sync again' : 'ABPS data is recent';
  } else { abEl.textContent = 'None'; abEl.className = 'warn'; }
  document.getElementById('today').classList.remove('skel');
  document.getElementById('stored').classList.remove('skel');

  // Display ও সুবিধা
  const ui = Object.assign({}, UI_DEF, r.kh_ui || {});
  const applyUi = () => { document.body.classList.toggle('dark', !!ui.dark); document.body.classList.toggle('compact', !!ui.compact); saveCache(ui); };
  applyUi();
  document.querySelectorAll('input[data-u]').forEach((cb) => {
    cb.checked = !!ui[cb.dataset.u];
    cb.addEventListener('change', async () => { ui[cb.dataset.u] = cb.checked; await chrome.storage.local.set({ kh_ui: ui }); applyUi(); });
  });

  // সাম্প্রতিক কাজ: শুধু আসলে জমা থাকা data থেকে
  const items = [];
  Object.values(abMeta).forEach((m) => { if (m && m.savedAt) items.push({ t: m.savedAt, c: '#3730a3', s: 'ABPS Sync: ' + (m.name || m.code || 'GP') + ' — ' + (m.count || 0) + ' worker' }); });
  const cm = r.kh_caste_meta_v2;
  if (cm && cm.savedAt) items.push({ t: cm.savedAt, c: '#7c3aed', s: 'Caste map: ' + (cm.count || 0) + ' job cards saved' });
  if (npRes.length) {
    const t = Math.max(...npRes.map((x) => x.t || 0));
    const saved = npRes.filter((x) => x.result === 'Saved').length, notEn = npRes.filter((x) => x.result === 'Not enabled').length;
    items.push({ t, c: '#10b981', s: 'NPCI: ' + saved + ' Saved, ' + notEn + ' Not enabled' });
  }
  items.sort((a, b) => b.t - a.t);
  if (items.length && !(r.kd_runs || []).length) {
    const box = document.getElementById('recent'); box.innerHTML = '';
    items.slice(0, 4).forEach((x) => {
      const d = document.createElement('div'); d.className = 'a';
      const i = document.createElement('i'); i.style.background = x.c;
      const s = document.createElement('span'); s.textContent = x.s;
      const e = document.createElement('em'); e.textContent = ago(x.t);
      d.append(i, s, e); box.appendChild(d);
    });
  }

  // Feature tile On/Off
  const features = r.kh_features || {};
  document.querySelectorAll('input[data-f]').forEach((cb) => {
    const key = cb.dataset.f;
    const tile = cb.closest('.tile') || cb.closest('.opt');
    cb.checked = features[key] !== false;          // না থাকলে On
    tile.classList.toggle('off', !cb.checked);
    cb.addEventListener('change', async () => {
      const cur = (await chrome.storage.local.get('kh_features')).kh_features || {};
      cur[key] = cb.checked;
      await chrome.storage.local.set({ kh_features: cur });
      tile.classList.toggle('off', !cb.checked);
      const note = document.getElementById('note');
      note.textContent = 'Saved. Reload the portal page once.';
      note.classList.add('saved');
    });
  });
  PERF.data = performance.now(); showPerf();
});

// Lock: চালানো না গেলে toggle আর link বন্ধ, Device ID ও key box দেখায়।
// Trial বা মেয়াদি key-তে কাজ চলে, সঙ্গে কত দিন বাকি দেখায়; শেষের দিকে নতুন key দেওয়ার box খোলা থাকে।
const fmtDate = (ms) => { const d = new Date(ms); return String(d.getDate()).padStart(2, '0') + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + d.getFullYear(); };
function setLocked(locked, name, info) {
  info = info || { type: locked ? 'trial-over' : 'life' };
  const showBox = locked || info.type === 'trial' || (info.type === 'timed' && info.left <= 15);
  document.body.classList.toggle('locked', locked);
  const lock = document.getElementById('lock');
  lock.hidden = !showBox; lock.classList.toggle('renew', !locked);
  const T = document.getElementById('lockT'), S = document.getElementById('lockS');
  const send = 'Send the Device ID below to Koushik, paste the key you get and press Activate.';
  if (info.type === 'trial-over') { T.textContent = '⌛ The 3-day trial has ended'; S.textContent = 'A license is needed to keep using it. ' + send; }
  else if (info.type === 'expired') { T.textContent = '⌛ License expired (' + fmtDate(info.exp) + ')'; S.textContent = 'Get a renewed key. ' + send; }
  else if (info.type === 'trial') { T.textContent = '🎁 Trial running, get a full license'; S.textContent = 'All features stop when the trial ends. ' + send; }
  else if (info.type === 'timed') { T.textContent = '⏳ License ends in ' + info.left + ' days'; S.textContent = 'Get a new key in advance; it replaces the old one. ' + send; }
  else { T.textContent = '🔒 K-Desk is locked on this PC'; S.textContent = send + ' Needed only once per PC.'; }
  if (showBox) KH_LICENSE.deviceId(true, (id) => { document.getElementById('dev').textContent = id; });
  const unl = document.getElementById('unl');
  unl.hidden = locked;
  unl.classList.toggle('trial', info.type === 'trial');
  unl.classList.toggle('soon', info.type === 'timed' && info.left <= 15);
  document.querySelectorAll('input[data-f]').forEach((cb) => { cb.disabled = locked; });
  if (!locked) {
    const t = document.getElementById('licTxt');
    t.textContent = '';
    if (info.type === 'trial') { t.append('Trial: '); const b = document.createElement('b'); b.textContent = info.left + ' days left'; t.appendChild(b); t.append(' (until ' + fmtDate(info.exp) + ')'); }
    else {
      if (name) { t.append('Licensed to '); const b = document.createElement('b'); b.textContent = name; t.appendChild(b); }
      else t.textContent = 'This PC is activated';
      if (info.type === 'timed') t.append(' · until ' + fmtDate(info.exp));
      if (info.gps && info.gps.length) t.append(' · GP: ' + info.gps.join(', '));
    }
    KH_LICENSE.deviceId(false, (id) => { document.getElementById('licDev').textContent = id ? 'PC: ' + id.slice(0, 8) : ''; });
  }
}
function applyLock() {
  KH_LICENSE.check((ok, name, info) => {
    setLocked(!ok, name, info);
    try { localStorage.setItem('kd_pop_lic', JSON.stringify([!ok, name, info])); } catch (e) {}
    PERF.lic = performance.now(); kdm('lic'); showPerf();
  });
}
// License যাচাইয়ে (sync storage + signature) সময় লাগে, তাই আগের বারের ফল সঙ্গে সঙ্গে দেখানো,
// আর যাচাই data পড়ার সাথে একসঙ্গে চলে; ফল বদলালে নিজে থেকেই ঠিক হয়ে যায়।
try { const L = JSON.parse(localStorage.getItem('kd_pop_lic') || 'null'); if (L) setLocked(L[0], L[1], L[2]); } catch (e) {}
applyLock();
function showPerf() {
  const el = document.getElementById('perf'); if (!el) return;
  const ms = (x) => x == null ? '…' : Math.round(x) + ' ms';
  el.textContent = '';
  const add = (k, v) => { el.append(k + ' '); const b = document.createElement('b'); b.textContent = v; el.appendChild(b); el.append('  '); };
  add('Shown:', ms(PERF.page)); add('Numbers:', ms(PERF.data)); add('License:', ms(PERF.lic));
  // ধাপের বিস্তারিত: page আসা (nav), তারপর প্রতিটি ধাপ কখন হলো (ms, popup খোলার শুরু থেকে)
  const n = performance.getEntriesByType('navigation')[0] || {};
  const steps = [['req', n.requestStart], ['html', n.responseEnd], ['dom', n.domInteractive]].concat(window.KDT || [])
    .concat([['dcl', n.domContentLoadedEventEnd], ['load', n.loadEventEnd]]).filter((x) => x[1] > 0);
  const res = performance.getEntriesByType('resource').map((x) => x.name.split('/').pop() + ' ' + Math.round(x.startTime) + '→' + Math.round(x.responseEnd));
  const d = document.createElement('div'); d.style.cssText = 'margin-top:4px;font:10.5px/1.4 Consolas,monospace;word-break:break-all;user-select:all';
  d.textContent = steps.map((x) => x[0] + ' ' + Math.round(x[1])).join(' · ') + (res.length ? ' | ' + res.join(' · ') : '');
  el.appendChild(d);
  el.title = 'Click to copy';
  el.onclick = () => { navigator.clipboard.writeText(el.innerText).then(() => { el.style.borderColor = '#10b981'; }).catch(() => {}); };
}
requestAnimationFrame(() => { PERF.page = performance.now(); kdm('frame'); showPerf(); });
window.addEventListener('load', () => setTimeout(showPerf, 0));

// K-Desk পুরোটা On/Off (v1.15.0, Side button-এর জায়গায়): chrome.storage "kh_off" = true হলে কোনো feature, K-Dock, kux চলে না
(function master() {
  const cb = document.getElementById('master'), wrap = document.getElementById('mstWrap'), txt = document.getElementById('mstTxt'), bar = document.getElementById('offbar');
  const show = (off) => { cb.checked = !off; txt.textContent = off ? 'OFF' : 'ON'; wrap.classList.toggle('off', off); bar.hidden = !off; document.body.classList.toggle('kdoff', off); };
  try { show(localStorage.getItem('kd_pop_off') === '1'); } catch (e) {}
  chrome.storage.local.get('kh_off').then((r) => { show(!!(r && r.kh_off)); try { localStorage.setItem('kd_pop_off', r && r.kh_off ? '1' : '0'); } catch (e) {} });
  cb.addEventListener('change', async () => {
    const off = !cb.checked;
    await chrome.storage.local.set({ kh_off: off });
    try { localStorage.setItem('kd_pop_off', off ? '1' : '0'); } catch (e) {}
    show(off);
    const note = document.getElementById('note');
    note.textContent = off ? 'K-Desk OFF. Reload the portal page once.' : 'K-Desk ON. Reload the portal page once.';
    note.classList.add('saved');
  });
})();
document.getElementById('copy').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(document.getElementById('dev').textContent); document.getElementById('copy').textContent = 'Copied'; } catch (e) {}
});
document.getElementById('act').addEventListener('click', () => {
  const msg = document.getElementById('msg');
  KH_LICENSE.activate(document.getElementById('key').value, (ok, name, x) => {
    msg.className = 'msg ' + (ok ? 'ok' : 'err');
    msg.textContent = ok ? 'Activated! Reload the portal page once.' + (x && x.exp ? ' Valid until ' + fmtDate(x.exp) + '.' : '') + (x && x.gps ? ' GP: ' + x.gps.join(', ') + '.' : '')
      : x && x.expired ? 'This key has already expired. Get a new key.' : 'Key does not match. Check that it was made for this PC\'s Device ID.';
    if (ok) { document.getElementById('key').value = ''; applyLock(); }
  });
});
document.getElementById('tour').addEventListener('click', async () => {
  await chrome.storage.local.set({ kd_tour_v1: false });       // খোলা portal page-এ সঙ্গে সঙ্গে tour শুরু হয়
  const n = document.getElementById('note'); n.textContent = 'The tour starts on the portal page (reload it if not).'; n.classList.add('saved');
});
document.getElementById('test').addEventListener('click', () => {
  chrome.notifications.create('', { type: 'basic', iconUrl: '../assets/icons/icon128.png', title: 'K-Desk Suite', message: 'Notifications are working ✓', priority: 1 });
});
document.getElementById('v').textContent = 'v' + chrome.runtime.getManifest().version;

// Field Autofill: popup থেকে picker চালু, আর রাখা default-এর তালিকা (✕ দিয়ে মুছে ফেলা যায়)
function afRender() {
  chrome.storage.local.get('kdAutofillRules').then((r) => {
    const all = r.kdAutofillRules || [], box = document.getElementById('afList'); box.innerHTML = '';
    all.forEach((x) => {
      const row = document.createElement('div'); row.className = 'afr';
      const s = document.createElement('span'); s.textContent = (x.label || 'field') + ' = ' + (x.kind === 'checkbox' || x.kind === 'radio' ? (x.value === '1' ? 'ticked' : 'not ticked') : (x.value || '(empty)'));
      s.title = x.page + '  ' + x.sel;
      const e = document.createElement('em'); e.textContent = String(x.page || '').split('/').pop().replace(/\.aspx$/i, '');
      const b = document.createElement('button'); b.type = 'button'; b.textContent = '✕'; b.title = 'Delete this default';
      b.addEventListener('click', async () => {
        const cur = (await chrome.storage.local.get('kdAutofillRules')).kdAutofillRules || [];
        await chrome.storage.local.set({ kdAutofillRules: cur.filter((y) => y.id !== x.id) });
        afRender();
      });
      row.append(s, e, b); box.appendChild(row);
    });
  });
}
document.getElementById('afPick').addEventListener('click', async () => {
  const note = document.getElementById('afNote');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    if (!tab) throw new Error('no tab');
    await chrome.tabs.sendMessage(tab.id, { type: 'KD_AF_PICK' });
    if (IS_POPUP) window.close(); else { note.className = 'saved'; note.textContent = 'Now click the field on the portal page.'; }
  } catch (e) {
    note.className = 'warn';
    note.textContent = 'No portal page in this tab (or Field Autofill is Off / the page needs a reload). Open a portal page and press again.';
  }
});

// ===== Today's runs (v1.16.0): shared/kd-runlog.js প্রতিটা K-Desk Excel log-এর সারাংশ kd_runs-এ রাখে =====
let RUNS = [], RANGE = 0;
try { RANGE = +localStorage.getItem('kd_runs_range') || 0; } catch (e) {}
let RUNS_ALL = false;
function rangeStart(d) { const t = new Date(); t.setHours(0, 0, 0, 0); return t.getTime() - (d ? (d - 1) * 864e5 : 0); }
function hhmm(t) { const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function dd(t) { const d = new Date(t); return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0'); }
function renderRuns(runs) {
  RUNS = runs || [];
  const box = document.getElementById('runs');
  if (!RUNS.length) { box.hidden = true; return; }
  box.hidden = false; document.getElementById('recentLbl').textContent = "Today's runs · আজকের কাজ"; document.getElementById('recent').hidden = true;
  const from = rangeStart(RANGE), list = RUNS.filter((x) => x.t >= from);
  const warn = list.filter((x) => x.warn).length;
  document.getElementById('rhTxt').innerHTML = '<b>' + list.length + ' run</b>' + (warn ? ' · ' + warn + 'টায় দেখার আছে' : list.length ? ' · সব ঠিক' : '');
  document.querySelectorAll('#runs .chip span').forEach((c) => c.classList.toggle('on', +c.dataset.d === RANGE));
  const rows = document.getElementById('runRows'); rows.innerHTML = '';
  if (!list.length) { rows.innerHTML = '<div class="rnone">' + (RANGE ? 'এই সময়ে' : 'আজ') + ' কোনো run নেই</div>'; }
  (RUNS_ALL ? list : list.slice(0, 6)).forEach((x) => {
    const d = document.createElement('div'); d.className = 'r' + (x.warn ? ' warn' : '');
    const tm = document.createElement('span'); tm.className = 'tm'; tm.textContent = RANGE ? dd(x.t) + '\n' + hhmm(x.t) : hhmm(x.t);
    const nm = document.createElement('span'); nm.className = 'nm';
    const dot = document.createElement('i'); dot.style.background = x.c || '#64748b'; nm.append(dot, document.createTextNode(x.name));
    const dl = document.createElement('button'); dl.type = 'button'; dl.className = 'dl'; dl.textContent = '⭳ Log'; dl.title = x.file + (x.files > 1 ? ' (+' + (x.files - 1) + ' file)' : '');
    dl.addEventListener('click', () => downloadRun(x, dl));
    const rs = document.createElement('span'); rs.className = 'rs';
    const parts = (x.parts || []).length ? x.parts : [{ k: 'row', n: x.rows, bad: false }];
    parts.slice(0, 3).forEach((p, i) => {
      if (i) rs.append(document.createTextNode(' · '));
      const b = document.createElement('span'); b.className = p.bad ? 'bad' : (i ? '' : 'ok'); b.textContent = p.n + ' ' + p.k; rs.append(b);
    });
    d.append(tm, nm, dl, rs); rows.appendChild(d);
  });
  const more = document.getElementById('runMore');
  more.hidden = list.length <= 6; more.textContent = RUNS_ALL ? 'কম দেখাও ‹' : 'সব দেখো (' + list.length + ' run) ›';
}
document.querySelectorAll('#runs .chip span').forEach((c) => c.addEventListener('click', () => {
  RANGE = +c.dataset.d; RUNS_ALL = false; try { localStorage.setItem('kd_runs_range', RANGE); } catch (e) {} renderRuns(RUNS);
}));
document.getElementById('runMore').addEventListener('click', () => { RUNS_ALL = !RUNS_ALL; renderRuns(RUNS); });
// Excel library শুধু Log চাপলে load হয়
function loadXlsx() {
  if (window.XLSX) return Promise.resolve();
  return new Promise((ok, bad) => { const s = document.createElement('script'); s.src = '../vendor/xlsx.full.min.js'; s.onload = ok; s.onerror = bad; document.head.appendChild(s); });
}
async function downloadRun(x, btn) {
  const k = 'kd_runlog::' + x.id;
  const lg = (await chrome.storage.local.get(k))[k];
  if (!lg || !lg.files || !lg.files.length) { btn.textContent = 'নেই'; return; }
  btn.textContent = '…';
  try {
    await loadXlsx();
    lg.files.forEach((f) => {
      const wb = XLSX.utils.book_new();
      f.sheets.forEach((s, i) => XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(s.aoa.length ? s.aoa : [['']]), String(s.n || 'Sheet' + (i + 1)).slice(0, 31)));
      XLSX.writeFile(wb, f.file || (x.name + '.xlsx'));
    });
    btn.textContent = '✓';
  } catch (e) { btn.textContent = 'Error'; }
  setTimeout(() => { btn.textContent = '⭳ Log'; }, 2000);
}

// ===== v1.20.0: নতুন version-এর খবর (shared/kd-update.js) =====
// Banner: নতুন version থাকলে সোনালি (min_version-এর নিচে হলে লাল "জরুরি"), update হয়ে গেলে একবার সবুজ।
(function kdUpdUI() {
  if (!window.KDUpdate) return;
  const $ = (id) => document.getElementById(id);
  const box = $('upd');
  function fmt(t) { if (!t) return ''; return dd(t) + ' ' + hhmm(t); }
  function notes(list) {
    const ul = $('updNotes'); ul.innerHTML = '';
    (Array.isArray(list) ? list : []).slice(0, 4).forEach((n) => { const li = document.createElement('li'); li.textContent = String(n); ul.appendChild(li); });
    ul.hidden = !ul.children.length;
  }
  function zipUrl(d) { try { return new URL(d.url || '', KDUpdate.URL).href; } catch (e) { return ''; } }
  function status(i) {
    const el = $('updSt');
    if (!i.latest) { el.innerHTML = ''; el.append('আপনার ', Object.assign(document.createElement('b'), { textContent: 'v' + i.current }), ' · update server-এ পৌঁছানো যায়নি' + (i.at ? ' (' + fmt(i.at) + ')' : '')); return; }
    el.innerHTML = '';
    el.append('আপনার ', Object.assign(document.createElement('b'), { textContent: 'v' + i.current }), ' · ',
      i.newer ? Object.assign(document.createElement('b'), { textContent: 'নতুন v' + i.latest + ' আছে' }) : 'সবচেয়ে নতুন ✓',
      i.at ? ' · দেখা ' + fmt(i.at) : '');
  }
  function show(i) {
    status(i);
    if (!i.newer || i.snoozed) { box.hidden = true; return false; }
    const d = i.data || {};
    box.className = 'upd' + (i.must ? ' must' : '');
    $('updT').textContent = (i.must ? '⚠ জরুরি update: v' : '🆕 নতুন version এসেছে: v') + i.latest;
    $('updS').textContent = 'আপনার আছে v' + i.current + (d.date ? ' · প্রকাশ ' + d.date : '') + (i.must ? ' · এই version-এ কিছু কাজ ঠিকমতো চলবে না' : '');
    notes(d.notes);
    const u = zipUrl(d);
    $('updDl').href = u || '#'; $('updB').hidden = !u;
    $('updX').hidden = i.must; $('updX').textContent = 'পরে';
    $('updX').onclick = async () => { await KDUpdate.snooze(i.latest); box.hidden = true; KDUpdate.badge(Object.assign({}, i, { snoozed: true })); };
    box.hidden = false;
    return true;
  }
  // Update হয়ে যাওয়ার পরে প্রথম ৩ দিন একবার সবুজ "update হয়েছে" (✕ চাপলে আর নয়)
  async function done(i) {
    const r = (await chrome.storage.local.get('kd_upd_done')).kd_upd_done;
    if (!r || r.to !== i.current || Date.now() - r.at > 3 * 864e5) return;
    box.className = 'upd done';
    $('updT').textContent = '✅ K-Desk v' + r.to + '-এ update হয়েছে';
    $('updS').textContent = 'আগে ছিল v' + r.from;
    notes(i.data && i.data.version === r.to ? i.data.notes : []);
    $('updB').hidden = true; $('updSteps').hidden = true;
    $('updX').hidden = false; $('updX').textContent = '✕';
    $('updX').onclick = async () => { await chrome.storage.local.remove('kd_upd_done'); box.hidden = true; };
    box.hidden = false;
  }
  $('updHow').addEventListener('click', () => { const o = $('updSteps'); o.hidden = !o.hidden; $('updHow').textContent = 'কীভাবে বসাবেন? ' + (o.hidden ? '▾' : '▴'); });
  $('updExt').addEventListener('click', () => { chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }); });
  $('updChk').addEventListener('click', async () => {
    const b = $('updChk'); b.disabled = true; b.textContent = '…';
    try { await chrome.storage.local.remove('kd_upd_snooze'); const i = await KDUpdate.check(true); KDUpdate.badge(i); if (!show(i)) await done(i); } catch (e) {}
    b.disabled = false; b.textContent = '🔄 এখনই দেখুন';
  });
  KDUpdate.check(false).then(async (i) => { KDUpdate.badge(i); if (!show(i)) await done(i); }).catch(() => {});
})();
