// K-Desk Suite by Koushik — কাজ শেষ হলে Windows notification (content script পাঠায়)
chrome.runtime.onMessage.addListener(function (m) {
  if (!m || m.type !== "kd-notify") return;
  try {
    chrome.notifications.create("", { type: "basic", iconUrl: "assets/icons/icon128.png", title: m.title || "K-Desk Suite", message: m.msg || "", priority: 1 });
  } catch (e) {}
});

// v1.20.0: নতুন version এসেছে কিনা (shared/kd-update.js) — Chrome চালু হলে, install/update-এর পরে,
// আর service worker যখনই জাগে (৬ ঘণ্টার cache থাকায় বারবার network-এ যায় না)। নতুন থাকলে icon-এ "NEW" badge।
try { importScripts('../shared/kd-update.js'); } catch (e) {}
function kdUpdCheck(force) {
  try { if (self.KDUpdate) KDUpdate.check(force).then(KDUpdate.badge).catch(function () {}); } catch (e) {}
}
chrome.runtime.onStartup.addListener(function () { kdUpdCheck(false); });
chrome.runtime.onInstalled.addListener(function (d) {
  // Update হয়ে গেলে Dashboard একবার "✅ vX-এ update হয়েছে" দেখায়
  if (d && d.reason === 'update' && d.previousVersion && d.previousVersion !== chrome.runtime.getManifest().version) {
    chrome.storage.local.set({ kd_upd_done: { from: d.previousVersion, to: chrome.runtime.getManifest().version, at: Date.now() } });
  }
  kdUpdCheck(true);
});
chrome.runtime.onMessage.addListener(function (m) { if (m && m.type === 'kd-upd-badge') kdUpdCheck(false); });
kdUpdCheck(false);
