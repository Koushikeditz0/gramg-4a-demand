/* =====================================================================
   aadhaar-driver.js — K-Desk Suite by Koushik · Aadhaar Update (MAIN world, document_start)
   Page: GP login → Update Aadhaar details (…/vbgramg/BulkAadhaarUpdate.aspx).
   The portal shows browser alerts ("Enter valid Aadhaar number !!", save answers, …). An alert stops the page until
   someone clicks OK, so while a K-Desk run is going (localStorage kdaa_run.active) the alert's text is kept in
   localStorage kdaa_alerts for the panel instead of being shown. With no run going, alerts are left as they are.
   (No Date here: the portal replaces it in this world.)
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDAA_DRV) return; window.__KDAA_DRV = true;
  function running() { try { var r = JSON.parse(localStorage.getItem("kdaa_run") || "null"); return !!(r && r.active); } catch (e) { return false; } }
  var native = window.alert;
  window.alert = function (m) {
    if (!running()) return native.apply(window, arguments);
    try {
      var q = JSON.parse(localStorage.getItem("kdaa_alerts") || "[]");
      q.push(String(m == null ? "" : m)); localStorage.setItem("kdaa_alerts", JSON.stringify(q.slice(-20)));
    } catch (e) {}
  };
})();
