/* =====================================================================
   aadhaar-run.js — K-Desk Suite by Koushik · Aadhaar Update from Gram Setu (isolated world)
   GP login → "Update Aadhaar details" (…/vbgramg/BulkAadhaarUpdate.aspx).
   Supervisors send a worker's Aadhaar (photo + number + Name as per Aadhaar) in the Gram Setu app, the Admin checks
   it (✓ Verify). This panel loads those Aadhaar from Gram Setu (kdesk_aadhaar_pending) and, one worker at a time:
     1. Search by Job Card No. (the page reloads)
     2. finds the worker's row (Job Card + App. No.), types the Aadhaar No. and fires the box's own blur, so the
        portal's own ClientEncrypt() encrypts it (HF_Enc_uid / HF_Enc_key) and masks it to xxxxxxxx1234
     3. Name as per Aadhaar Card, consent Yes, presses Verify (async UpdatePanel) and reads the row's Status (lbl_msg)
     4. Verified (green) → "Save Verified Records of this page" (the page reloads), reads the answer
   Every result goes back to Gram Setu (kdesk_aadhaar_report): ok → request Updated (number wiped there);
   fail → stays with the Admin with the portal message as the comment.
   🧪 Test run (on by default): steps 1–3 only — Save is NOT pressed and nothing is sent back to Gram Setu.
   Aadhaar numbers are kept only in chrome.storage.local "kdaa_uids" (not readable by the portal page) and removed
   per worker when done; the run state (portal localStorage "kdaa_run") and the Excel log have only the last 4 digits.
   Dashboard toggle: "aadhaar".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDAA) return; window.__KDAA = true;
  if (!/\/bulkaadhaarupdate\.aspx$/i.test(location.pathname)) return;

  var P = "ctl00_ContentPlaceHolder1_", LS = "kdaa_run", ALERTS = "kdaa_alerts", UIDS = "kdaa_uids", MIRROR = "kdaaLastRun",
      HOST_ID = "kdaa-host", MIN_KEY = "kdaa_min", POS_KEY = "kdaa_pos", TEST_KEY = "kdaa_test", SENT_KEY = "kdaa_sent";
  var STALE = 5 * 60000, VERIFY_WAIT = 90000, MAX_ERR = 3;
  function $(id) { return document.getElementById(id); }
  function norm(s) { return String(s == null ? "" : s).replace(/ /g, " ").replace(/\s+/g, " ").trim(); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function bn(n) { return String(n).replace(/[0-9]/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function hm(t) { var d = new Date(t); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); }
  function stamp(t) { var d = new Date(t); return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + " " + hm(t); }
  function load() { try { return JSON.parse(localStorage.getItem(LS) || "null"); } catch (e) { return null; } }
  function save(r) { try { r.at = Date.now(); localStorage.setItem(LS, JSON.stringify(r)); } catch (e) {} try { var o = {}; o[MIRROR] = r; chrome.storage.local.set(o); } catch (e) {} }
  function note(r, text, level) { (r.log = r.log || []).push({ t: Date.now(), level: level || "info", text: text }); if (r.log.length > 600) r.log.splice(0, r.log.length - 600); }
  function takeAlerts() { var q = []; try { q = JSON.parse(localStorage.getItem(ALERTS) || "[]"); localStorage.removeItem(ALERTS); } catch (e) {} return q; }
  function testPref() { try { return localStorage.getItem(TEST_KEY) !== "0"; } catch (e) { return true; } }
  function sentPref() { try { return localStorage.getItem(SENT_KEY) === "1"; } catch (e) { return false; } }
  function mask(l4) { return "xxxxxxxx" + (l4 || "????"); }
  function who(it) { return it.jc + " (" + it.ap + ") " + (it.name || ""); }

  /* ---------- Aadhaar numbers: extension storage only ---------- */
  var uidMap = null;
  function uidsLoad() { return new Promise(function (res) { try { chrome.storage.local.get(UIDS, function (o) { uidMap = (o && o[UIDS]) || {}; res(uidMap); }); } catch (e) { uidMap = {}; res(uidMap); } }); }
  function uidsSave() { try { var o = {}; o[UIDS] = uidMap || {}; chrome.storage.local.set(o); } catch (e) {} }
  function uidDrop(id) { if (uidMap && uidMap[id]) { delete uidMap[id]; uidsSave(); } }
  function uidsClear() { uidMap = {}; try { chrome.storage.local.remove(UIDS); } catch (e) {} }

  /* ---------------------- the page ---------------------- */
  function onPage() { return !!$(P + "txt_SearchRegNo") && !!$(P + "btn_SearchbyRegNo"); }
  function grid() { return $(P + "gvData"); }
  // the grid row of this worker → id prefix "ctl00_ContentPlaceHolder1_gvData_ctlNN_"
  function findRow(it) {
    var g = grid(); if (!g) return null;
    var jc = norm(it.jc).toUpperCase(), ap = String(+it.ap || it.ap);
    var spans = g.querySelectorAll("span[id$='_lbl_jobcardno']");
    for (var i = 0; i < spans.length; i++) {
      if (norm(spans[i].textContent).toUpperCase() !== jc) continue;
      var k = spans[i].id.replace(/lbl_jobcardno$/, "");
      var a = $(k + "lbl_applicant_no"), h = $(k + "applicant_no");
      var got = norm(a ? a.textContent : h ? h.value : "");
      if (String(+got || got) === ap) return k;
    }
    return null;
  }
  function rowsFor(jc) { var g = grid(); if (!g) return 0; jc = norm(jc).toUpperCase(); return [].filter.call(g.querySelectorAll("span[id$='_lbl_jobcardno']"), function (s) { return norm(s.textContent).toUpperCase() === jc; }).length; }
  function pageMsg() { var u = $(P + "Up_lit"); if (!u) return ""; var c = u.cloneNode(true); var p = c.querySelector("[id$='UpdateProgress1']"); if (p) p.remove(); return norm(c.textContent); }
  function greenish(el) {
    if (!el) return false;
    var c = getComputedStyle(el), s = [c.backgroundColor, c.color];
    for (var i = 0; i < s.length; i++) {
      var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(s[i] || ""); if (!m || m[4] === "0") continue;
      var R = +m[1], G = +m[2], B = +m[3];
      if (G > R + 40 && G > B + 15) return true;
    }
    return false;
  }
  // the Status cell after Verify
  function verdict(k) {
    var lbl = $(k + "lbl_msg"), sts = $(k + "hf_uid_sts"), tr = lbl && lbl.closest("tr");
    var m = norm(lbl ? lbl.textContent : ""), st = norm(sts ? sts.value : "");
    var bad = /fail|not |mismatch|invalid|error|unable|wrong|exist|already|duplicate|incorrect|no record/i.test(m);
    var green = greenish(lbl) || greenish(tr) || (tr && greenish(tr.cells && tr.cells[1]));
    var good = !bad && (/success|verified|valid|match/i.test(m) || green);
    return { ok: good, known: good || bad, msg: m, sts: st };
  }
  function genderNote(it, k) {
    var g = $(k + "lbl_Gender"), pg = norm(g ? g.textContent : "").toUpperCase().charAt(0);
    if (!it.gender || !pg || it.gender === pg) return "";
    return "Gender mismatch (Job Card " + pg + ", Aadhaar " + it.gender + ") — GP login D1 \"Updation of Aadhar with gender Selection\" দিয়ে ঠিক করুন";
  }

  /* ---------------------- results ---------------------- */
  function counts(r) {
    var c = { ok: 0, test: 0, fail: 0, err: 0 };
    (r.results || []).forEach(function (x) { c[x.kind] = (c[x.kind] || 0) + 1; });
    return c;
  }
  function sumText(r) {
    var c = counts(r);
    return (r.test ? c.test + " জনের Verify হত/হয়েছে (test)" : c.ok + " জনের Aadhaar save") + (c.fail ? " · " + c.fail + " fail" : "") + (c.err ? " · " + c.err + " হয়নি" : "");
  }
  // kind: ok (saved) · test (verified, not saved) · fail (portal said no) · err (K-Desk could not do it)
  function record(r, kind, msg, extra) {
    var it = r.items[r.i];
    var res = { id: it.id, jc: it.jc, ap: it.ap, name: it.name, aname: it.aname, gender: it.gender, last4: it.last4, village: it.village,
                kind: kind, msg: msg || "", t: Date.now(), sent: "" };
    if (extra) for (var x in extra) res[x] = extra[x];
    r.results.push(res); r.done[it.id] = 1;
    r.phase = ""; r.tries = 0; r.vmsg = ""; r.i++;
    r.errs = kind === "err" ? (r.errs || 0) + 1 : 0;
    if (!r.test && (kind === "ok" || kind === "fail" || (kind === "err" && res.report))) {
      (r.rq = r.rq || []).push({ id: it.id, s: kind === "ok" ? "ok" : "fail", m: (msg || "").slice(0, 280) });
      res.sent = "queued";
    }
    if (kind === "ok" || kind === "fail" || r.test) uidDrop(it.id);
    var icon = { ok: "✓ Saved", test: "🧪 Verify OK", fail: "✗", err: "⚠" }[kind];
    note(r, who(it) + " · " + mask(it.last4) + ": " + icon + (msg ? " — " + msg : ""), kind === "ok" || kind === "test" ? "ok" : kind === "fail" ? "err" : "warn");
  }
  var flushing = false;
  function flush(r, done) {
    if (flushing || !r || !r.rq || !r.rq.length || r.test) { if (done) done(); return; }
    if (!window.KDLink || !window.KDLink.call) { status("Gram Setu link লোড হয়নি — page reload করে ⇪ চাপুন।", "warn"); if (done) done(); return; }
    flushing = true;
    var part = r.rq.slice(0, 200), ids = part.map(function (p) { return p.id; });
    window.KDLink.call("kdesk_aadhaar_report", { p_rows: part }, "🪪 Aadhaar Update → Gram Setu").then(function () {
      flushing = false;
      var x = load() || r; x.rq = (x.rq || []).filter(function (p) { return ids.indexOf(p.id) < 0; });
      (x.results || []).forEach(function (q) { if (ids.indexOf(q.id) >= 0 && q.sent === "queued") q.sent = "sent"; });
      save(x); render();
      if (x.rq.length) flush(x, done); else if (done) done();
    }, function (e) {
      flushing = false;
      status("Gram Setu-তে ফল পাঠানো গেল না: " + ((e && e.text) || (e && e.message) || e) + " — পরে ⇪ চাপুন।", "warn");
      if (done) done();
    });
  }
  function finish(r, why) {
    r.active = false; r.phase = "";
    if (!why) { r.finishedAt = Date.now(); note(r, "শেষ: " + sumText(r) + ".", "ok"); uidsClear(); }
    else note(r, why, "warn");
    save(r); render();
    flush(r);
    if (!why && !r.logSaved) { r.logSaved = 1; save(r); setTimeout(function () { download(true); }, 600); }
  }

  /* ---------------------- the run ---------------------- */
  function search(r, it, ph) {
    var rb = $(P + "rdbtn_rgno_familyid_0"), tx = $(P + "txt_SearchRegNo"), bt = $(P + "btn_SearchbyRegNo");
    if (!tx || !bt) { finish(r, "এটা Update Aadhaar details page নয়।"); return; }
    if (rb && !rb.checked) rb.checked = true;
    tx.value = it.jc;
    ph = ph || "search"; var i = r.i;
    r.phase = ph; r.tries = (r.tries || 0) + 1; save(r); render();
    bt.click();                                                   // full postback → the page reloads
    setTimeout(function () {                                      // still here = the Search did not reload the page
      var x = load(); if (!x || !x.active || x.phase !== ph || x.i !== i) return;
      note(x, "Search চাপার পর page reload হয়নি — আবার চেষ্টা।", "warn"); x.phase = ph === "check" ? "check-retry" : ""; save(x); step();
    }, 30000);
  }
  function step() {
    var r = load(); if (!r || !r.active) { render(); return; }
    if (Date.now() - (r.at || 0) > STALE) { finish(r, "Paused: page ৫ মিনিটের বেশি সাড়া দেয়নি (login শেষ?)। ▶ Resume চাপুন।"); return; }
    if (uidMap === null) { uidsLoad().then(step); return; }
    var alerts = takeAlerts(), it = r.items[r.i];
    if (!onPage()) { finish(r, "এটা Update Aadhaar details page নয়।"); return; }

    if (r.phase === "save" && it) {                               // the answer to Save
      var said = alerts.concat(pageMsg() ? [pageMsg()] : []).join(" · ");
      if (/success|saved|updated|sucess/i.test(said)) record(r, "ok", said || r.vmsg);
      else if (/fail|error|not |invalid|unable/i.test(said)) record(r, "fail", said);
      else { r.tries = 0; note(r, who(it) + ": Save-এর পর portal কিছু বলেনি — আবার খুঁজে দেখছি।", "info"); search(r, it, "check"); return; }
      save(r); render(); setTimeout(step, 800); return;
    }
    if (r.phase === "check-retry" && it) { if ((r.tries || 0) >= 3) { record(r, "err", "Save হয়েছে কিনা মেলানো গেল না — portal-এ দেখে নিন"); save(r); setTimeout(step, 300); } else search(r, it, "check"); return; }
    if (r.phase === "check" && it) {                              // after a silent Save: is the worker still listed?
      if (!findRow(it)) record(r, "ok", (r.vmsg ? r.vmsg + " · " : "") + "Save হয়েছে (worker list থেকে চলে গেছে)");
      else record(r, "fail", "Save চাপার পরও worker list-এ আছে" + (alerts.length ? " · " + alerts.join(" · ") : ""));
      save(r); render(); setTimeout(step, 800); return;
    }
    if (alerts.length && r.phase !== "verify") { note(r, "Portal: " + alerts.join(" · "), "warn"); save(r); }
    if (r.rq && r.rq.length >= 10) flush(r);                      // send results to Gram Setu every 10 workers

    if ((r.errs || 0) >= MAX_ERR) { finish(r, "পরপর " + bn(MAX_ERR) + " জনের কাজ করা গেল না — থামানো হল। Log দেখে ▶ Resume চাপুন।"); return; }
    if (r.stop) { finish(r, "Stopped। ▶ Resume চাপলে পরের worker থেকে চলবে।"); return; }
    while (it && r.done[it.id]) { r.i++; it = r.items[r.i]; }
    if (!it) { finish(r); return; }

    var uid = uidMap[it.id];
    if (!uid || !/^[2-9][0-9]{11}$/.test(uid)) { record(r, "err", "Aadhaar No. এই PC-তে নেই — Gram Setu থেকে আবার list আনুন"); save(r); setTimeout(step, 300); return; }

    var k = findRow(it);
    if (r.phase === "verify" && k) { afterVerify(r, it, k, alerts); return; }   // a Verify that reloaded the page
    if (!k) {
      if (r.phase === "search") {                                 // back from our Search: not in the list
        var n = rowsFor(it.jc);
        record(r, "fail", n ? "এই Job Card-এর list-এ App. No. " + it.ap + " নেই (হয়তো আগেই Aadhaar দেওয়া হয়েছে) — portal-এ দেখে নিন"
                                         : "Portal-এর Aadhaar Update list-এ এই Job Card নেই (হয়তো আগেই Aadhaar দেওয়া / worker inactive) — portal-এ দেখে নিন" + (alerts.length ? " · " + alerts.join(" · ") : ""));
        save(r); render(); setTimeout(step, 600); return;
      }
      if ((r.tries || 0) >= 3) { record(r, "err", "Job Card দিয়ে খোঁজা গেল না" + (alerts.length ? ": " + alerts.join(" · ") : "")); save(r); setTimeout(step, 300); return; }
      search(r, it); return;
    }

    // fill the row
    var tx = $(k + "txtUID_No"), nm = $(k + "txtName_as_per_Aadhar"), yes = $(k + "rdbtn_confirm_0"), vb = $(k + "btn_verifyuid"), enc = $(k + "HF_Enc_uid");
    if (!tx || !vb || !enc) { record(r, "err", "Row-এ Aadhaar box / Verify button পাওয়া গেল না"); save(r); setTimeout(step, 300); return; }
    if (tx.disabled || vb.disabled) { record(r, "fail", "Portal-এ এই row বন্ধ (Aadhaar box / Verify চাপা যাচ্ছে না)"); save(r); setTimeout(step, 300); return; }
    var gn = genderNote(it, k); if (gn) note(r, who(it) + ": ⚠ " + gn, "warn");
    tx.focus(); tx.value = uid;
    tx.dispatchEvent(new Event("input", { bubbles: true }));
    tx.dispatchEvent(new FocusEvent("blur"));                     // the portal's own onblur → ClientEncrypt(this)
    var bad = takeAlerts();
    if (bad.length || !enc.value || /^\d{12}$/.test(tx.value)) {
      record(r, "fail", "Portal Aadhaar No. নিল না" + (bad.length ? ": " + bad.join(" · ") : " (encrypt হয়নি)"));
      tx.value = ""; save(r); setTimeout(step, 300); return;
    }
    if (nm && it.aname) { nm.value = it.aname.replace(/[^A-Za-z .']/g, " ").replace(/\s+/g, " ").trim(); nm.dispatchEvent(new Event("change", { bubbles: true })); }
    if (yes && !yes.checked) yes.click();
    r.phase = "verify"; r.gn = gn; r.vAt = Date.now(); save(r); render();
    var oldGrid = grid(), oldLbl = $(k + "lbl_msg"), oldMsg = norm(oldLbl ? oldLbl.textContent : "");
    vb.click();                                                   // async (UpdatePanel UP_app)
    var t0 = Date.now();
    (function wait() {
      var x = load(); if (!x || !x.active || x.phase !== "verify" || x.i !== r.i) return;
      var g = grid(), kk = findRow(it), lbl = kk && $(kk + "lbl_msg");
      var replaced = g && g !== oldGrid, said = norm(lbl ? lbl.textContent : "");
      if (kk && (replaced || (said && said !== oldMsg))) { setTimeout(function () { var y = load(); if (y && y.active && y.phase === "verify" && y.i === r.i) afterVerify(y, it, findRow(it) || kk, takeAlerts()); }, 400); return; }
      if (Date.now() - t0 > VERIFY_WAIT) {
        var al = takeAlerts();
        record(x, al.length ? "fail" : "err", al.length ? al.join(" · ") : Math.round(VERIFY_WAIT / 1000) + " সেকেন্ডে Verify-এর উত্তর আসেনি");
        save(x); render(); setTimeout(step, 600); return;
      }
      setTimeout(wait, 500);
    })();
  }
  function afterVerify(r, it, k, alerts) {
    var v = verdict(k), extra = alerts && alerts.length ? alerts.join(" · ") : "";
    var msg = [v.msg, extra].filter(Boolean).join(" · ") || "(Status ফাঁকা)";
    if (!v.ok) {
      var m = (v.known ? "" : "Verify-এর ফল বোঝা গেল না: ") + msg + (r.gn ? " · " + r.gn : "");
      record(r, "fail", m, { sts: v.sts }); save(r); render(); setTimeout(step, 600); return;
    }
    if (r.test) { record(r, "test", "Verify OK (Save চাপা হয়নি): " + msg, { sts: v.sts }); save(r); render(); setTimeout(step, 600); return; }
    var sb = $(P + "btnProceed2"); if (!sb) { record(r, "err", "Save Verified Records button পাওয়া যায়নি"); save(r); setTimeout(step, 300); return; }
    r.phase = "save"; r.vmsg = msg; save(r); render();
    sb.click();                                                   // full postback → the page reloads
  }

  /* ---------------------- load / start / stop ---------------------- */
  var confirming = false, loading = false;
  function fetchList() {
    var r = load(); if (r && r.active) return;
    if (!window.KDLink || !window.KDLink.call) { status("Gram Setu link লোড হয়নি। Page reload করুন।", "warn"); return; }
    if (r && r.results && r.results.length && !r.logSaved && !window.confirm("আগের run-এর log মুছে নতুন list আনবেন? দরকার হলে আগে ⭳ Log download করুন।")) return;
    loading = true; render(); status("Gram Setu থেকে আনছি…");
    window.KDLink.call("kdesk_aadhaar_pending", { p_include_sent: sentPref() }, "🪪 Aadhaar Update ← Gram Setu").then(function (rows) {
      loading = false; rows = rows || [];
      uidMap = {}; var items = [];
      rows.forEach(function (x) {
        var uid = String(x.uid || "").replace(/\D/g, ""); if (!/^[2-9][0-9]{11}$/.test(uid) || !x.jc) return;
        uidMap[x.id] = uid;
        items.push({ id: x.id, jc: x.jc, ap: x.ap, name: x.name || "", aname: x.aname || "", gender: x.gender || "", village: x.village_no || "",
                     last4: uid.slice(-4), st: x.status || "", pnote: x.portal_status === "fail" ? (x.portal_note || "") : "" });
      });
      uidsSave();
      var nr = { v: 1, runId: "kdaa-" + Date.now(), loadedAt: Date.now(), active: false, items: items, i: 0, done: {}, results: [], log: [], rq: [] };
      note(nr, "Gram Setu থেকে " + items.length + " জনের Aadhaar এল" + (sentPref() ? " (Admin Verify না করা গুলোও)" : " (Admin ✓ Verify করা)") + "।");
      save(nr); confirming = false;
      status(items.length ? items.length + " জন load হয়েছে। এবার Start চাপুন।" : "এখন কোনো Aadhaar বাকি নেই (Admin ✓ Verify করলে এখানে আসবে)।", items.length ? "ok" : "warn");
      render();
    }, function (e) {
      loading = false; render();
      var t = (e && e.text) || (e && e.message) || String(e);
      if (/kdesk_aadhaar_pending|PGRST202|Could not find/i.test((e && e.code || "") + " " + (e && e.message || ""))) t = "Gram Setu-এ এখনো v214 SQL চালানো হয়নি।";
      status(t, "warn");
    });
  }
  function askStart() { var r = load(); if (!r || r.active || r.startedAt || !r.items.length) return; confirming = true; render(); }
  function doStart() {
    confirming = false;
    var r = load(); if (!r || r.active || r.startedAt) return;
    uidsLoad().then(function () {
      var miss = r.items.filter(function (it) { return !uidMap[it.id]; }).length;
      if (miss === r.items.length) { status("Aadhaar No. এই PC-তে নেই — ⭳ Gram Setu থেকে আবার list আনুন।", "warn"); return; }
      r.test = testPref(); r.active = true; r.stop = false; r.startedAt = Date.now(); r.i = 0; r.phase = ""; r.errs = 0;
      note(r, (r.test ? "🧪 TEST RUN শুরু (Verify পর্যন্ত, Save হবে না, Gram Setu-তে কিছু যাবে না): " : "শুরু: ") + r.items.length + " জন।");
      takeAlerts(); save(r); step();
    });
  }
  function resume() {
    var r = load(); if (!r || r.active || r.finishedAt || !r.startedAt) return;
    r.active = true; r.stop = false; r.phase = ""; r.errs = 0; r.tries = 0; note(r, "Resumed."); takeAlerts(); save(r); step();
  }
  function stopRun() { var r = load(); if (!r || !r.active) return; r.stop = true; note(r, "Stop চাপা হয়েছে: হাতের worker শেষ হলে থামবে।", "warn"); save(r); render(); }
  function newRun() {
    var r = load(); if (r && r.active) { status("আগে Stop করুন।", "warn"); return; }
    if (r && r.results && r.results.length && !r.logSaved && !window.confirm("আগের run-এর log মুছে দেবেন? দরকার হলে আগে ⭳ Log download করুন।")) return;
    if (r && r.rq && r.rq.length && !window.confirm(r.rq.length + " জনের ফল এখনো Gram Setu-তে যায়নি। তবুও মুছবেন?")) return;
    try { localStorage.removeItem(LS); } catch (e) {}
    uidsClear(); status("মুছে দেওয়া হয়েছে।", "ok"); render();
  }

  /* ---------------------- Excel log (last 4 digits only) ---------------------- */
  function download(auto) {
    var r = load(); if (!r || !r.results || !r.results.length) { if (!auto) status("Log খালি।", "warn"); return; }
    if (!window.XLSX) { status("Spreadsheet library load হয়নি — page reload করুন।", "warn"); return; }
    var KIND = { ok: "saved", test: "would save (test)", fail: "failed", err: "not done (error)" };
    var A = [["Village", "Job Card No.", "App. No.", "Applicant", "Aadhaar No.", "Name as per Aadhaar", "Gender (Aadhaar)", "Result", "Portal message", "Gram Setu", "Time"]];
    r.results.forEach(function (x) {
      A.push([x.village || "", x.jc, x.ap, x.name || "", mask(x.last4), x.aname || "", x.gender || "", KIND[x.kind] || x.kind, x.msg || "",
              x.sent === "sent" ? (x.kind === "ok" ? "Updated" : "back to Admin (comment)") : x.sent === "queued" ? "not sent yet" : r.test ? "test (not sent)" : "", stamp(x.t)]);
    });
    var ws = XLSX.utils.aoa_to_sheet(A); ws["!cols"] = [8, 24, 7, 24, 15, 24, 8, 16, 60, 14, 17].map(function (w) { return { wch: w }; });
    var wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, r.test ? "Test run" : "Aadhaar update");
    var d = new Date(), name = "AadhaarUpdate-" + (r.test ? "TEST-" : "") + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
    XLSX.writeFile(wb, name); status("Saved " + name + "।", "ok");
  }

  /* ---------------------- panel ---------------------- */
  var sel = {};
  function status(m, kind) { if (!sel.st) return; sel.st.textContent = m || ""; sel.st.className = "st" + (kind ? " " + kind : ""); sel.st.hidden = !m; }
  function render() {
    if (!sel.sum) return;
    var r = load(), active = !!(r && r.active), started = !!(r && r.startedAt), paused = started && !active && !r.finishedAt, test = testPref();
    var N = r ? r.items.length : 0, D = r ? r.results.length : 0, pct = N ? Math.round(100 * D / N) : 0, c = r ? counts(r) : {};
    if (!r) {
      sel.sum.innerHTML = "<b>⭳ Gram Setu থেকে আনুন</b> চাপলে supervisor-দের পাঠানো আর Admin-এর <b>✓ Verify</b> করা Aadhaar আসবে। " +
        "তারপর Start: প্রতিটা worker-কে Job Card দিয়ে খুঁজে Aadhaar No. + Name as per Aadhaar দিয়ে <b>Verify</b>, সবুজ হলে <b>Save</b>।";
      sel.prog.hidden = true;
    } else if (!started) {
      sel.sum.innerHTML = "Load হয়েছে <b>" + bn(N) + "</b> জন" + (N ? " · Start চাপুন।" : "।");
      sel.prog.hidden = true;
    } else {
      var it = active && r.items[r.i];
      sel.sum.innerHTML = (r.test ? "<b style='color:#0f766e'>🧪 TEST RUN</b> · " : "") + (r.finishedAt ? "✓ শেষ · " : active ? "চলছে · " : "Paused · ") + "<b>" + D + "/" + N + "</b> জন" +
        "<br>" + (r.test ? "Verify OK <b>" + (c.test || 0) + "</b>" : "Saved <b>" + (c.ok || 0) + "</b>") + (c.fail ? " · fail <b>" + c.fail + "</b>" : "") + (c.err ? " · হয়নি <b>" + c.err + "</b>" : "") +
        (r.rq && r.rq.length ? "<br><span class='cur'>⇪ " + bn(r.rq.length) + " জনের ফল Gram Setu-তে যাওয়া বাকি</span>" : "") +
        (it ? "<br><span class='cur'>এখন: " + esc(who(it)) + (r.phase === "search" ? " — খুঁজছে" : r.phase === "verify" ? " — Verify" : r.phase === "save" ? " — Save" : r.phase === "check" ? " — মিলিয়ে দেখছে" : "") + "</span>" : "");
      sel.prog.hidden = false; sel.fill.style.width = pct + "%"; sel.ptxt.textContent = D + "/" + N + " (" + pct + "%)";
    }
    // list preview (before start) / results
    var rows = "";
    if (r && !started) {
      rows = r.items.slice(0, 150).map(function (x) {
        return "<div class='it'><b>" + esc(x.jc.replace(/^.*-(\d+\/\d+)$/, "$1")) + "-" + esc(x.ap) + "</b> " + esc(x.name) + " <span class='m'>" + mask(x.last4) + "</span>" +
          (x.st === "sent" ? " <span class='tg'>Verify হয়নি</span>" : "") + (x.pnote ? "<div class='pn'>আগের বার: " + esc(x.pnote) + "</div>" : "") + "</div>";
      }).join("") + (N > 150 ? "<div class='it'>… আরও " + (N - 150) + " জন</div>" : "");
    }
    sel.list.innerHTML = rows; sel.list.hidden = !rows;
    sel.loadrow.hidden = active || (started && !r.finishedAt) || confirming;
    sel.loadb.disabled = loading; sel.loadb.textContent = loading ? "আনছি…" : r ? "⟳ Gram Setu থেকে আবার আনুন" : "⭳ Gram Setu থেকে আনুন";
    sel.sentrow.hidden = active || (started && !r.finishedAt);
    sel.starts.hidden = !(r && !started && N) || confirming;
    sel.res.hidden = !paused || confirming; sel.testrow.hidden = active || started;
    sel.start.textContent = test ? "🧪 Test run শুরু" : "▶ Start (সত্যি Save করবে)";
    sel.start.className = "btn " + (test ? "iay" : "fill");
    sel.cfm.hidden = !confirming;
    if (confirming) {
      sel.cfmh.textContent = test ? "🧪 Test run — Save হবে না" : "⚠ সত্যি portal-এ Aadhaar Save হবে";
      sel.cfm.className = "cfm" + (test ? " t" : "");
      sel.cfmtxt.innerHTML = test
        ? bn(N) + " জনকে একে একে খুঁজে Aadhaar No. আর Name as per Aadhaar দিয়ে <b>Verify</b> চাপবে। <b>Save চাপবে না, Gram Setu-তে কিছু পাঠাবে না।</b>"
        : bn(N) + " জনের প্রত্যেককে খুঁজে Aadhaar দিয়ে <b>Verify</b>, সবুজ হলে <b>Save Verified Records</b> চাপবে। ফল Gram Setu-তে যাবে (ok → Updated, fail → Admin-এর কাছে comment সহ)।";
    }
    sel.stop.disabled = !active || !!(r && r.stop);
    sel.dl.disabled = !(r && r.results && r.results.length);
    sel.up.hidden = !(r && r.rq && r.rq.length); sel.up.disabled = active || flushing;
    sel.newr.disabled = active || !r;
    var L = (r && r.log) || [], h = "";
    for (var q = L.length - 1, m = 0; q >= 0 && m < 200; q--, m++) h += "<div class='l-" + esc(L[q].level) + "'><span class='lt'>" + hm(L[q].t) + "</span>" + esc(L[q].text) + "</div>";
    sel.logbox.innerHTML = h || "<div class='l-info'>এখনো কিছু হয়নি।</div>";
  }
  var STYLE =
    ".panel{width:370px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:13px;color:#1e1b4b;background:linear-gradient(180deg,#f3f4ff,#e8eafc);border:1px solid #c9cef3;border-radius:16px;box-shadow:0 18px 50px rgba(30,27,75,.30);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:10px 12px;display:flex;align-items:center;justify-content:space-between;cursor:move}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hdl{display:flex;align-items:center;gap:9px;min-width:0}.ttl b{display:block;font-size:14px}.ttl small{display:block;font-size:10px;color:#c7d2fe;letter-spacing:.6px;text-transform:uppercase}.ttl small i{font-style:normal;color:#f5b942;font-weight:600;text-transform:none}" +
    ".logo{width:28px;height:28px;border-radius:8px;flex:0 0 auto;display:grid;place-items:center;font:800 15px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:24px;height:24px;border-radius:6px;font-size:15px;line-height:1}" +
    ".bd{padding:10px 12px;max-height:80vh;overflow:auto}" +
    ".summary{font-size:12px;background:#fff;border:1px solid #d4d8f5;border-left:4px solid #f5b942;border-radius:10px;padding:8px 10px;line-height:1.45}.summary .cur{color:#5b6472}" +
    ".prog{margin:8px 0}.progbar{height:8px;background:#d4d8f5;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#e08e0b;transition:width .3s}.progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".btn{padding:8px 9px;border:none;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;min-height:34px}.btnrow{display:flex;gap:6px;margin-top:7px}.btnrow .btn{flex:1}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.iay{color:#fff;background:linear-gradient(135deg,#0f766e,#0d9488)}.btn.blue{color:#fff;background:linear-gradient(135deg,#3730a3,#4f46e5)}.btn.blue:disabled{opacity:.6;cursor:wait}" +
    ".btn.stop{background:#c5221f;color:#fff}.btn.stop:disabled{background:#e6a6a4;cursor:not-allowed}" +
    ".btn.ghost{background:#f5f6ff;color:#1e1b4b;border:1px solid #d4d8f5}.btn.ghost:disabled{color:#aab;cursor:not-allowed}.btn.ghost.danger{background:#fff1f2;color:#be123c;border-color:#fecdd3}.btn.ghost.danger:disabled{background:#f5f6ff;color:#c9a9a8}" +
    ".cfm{margin:8px 0;padding:8px;border:1px solid #f2d98a;background:#fef7e0;border-radius:9px;font-size:11.5px;color:#5a4300;line-height:1.45}.cfmh{font-weight:700;color:#9a6700;margin-bottom:4px}" +
    ".cfm.t{border-color:#99f6e4;background:#f0fdfa;color:#134e4a}.cfm.t .cfmh{color:#0f766e}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:7px;background:#f5f6ff;line-height:1.35}.st.ok{background:#dcfce7;color:#166534}.st.warn{background:#fef3c7;color:#92400e}" +
    ".sec{font-weight:700;color:#3730a3;margin:10px 0 6px;border-top:1px solid #d4d8f5;padding-top:8px;font-size:12px}" +
    ".list{margin-top:8px;max-height:190px;overflow:auto;background:#fff;border:1px solid #d4d8f5;border-radius:9px;padding:4px 8px}.it{font-size:11.5px;padding:4px 0;border-bottom:1px dotted #d4d8f5;line-height:1.35}.it:last-child{border:0}" +
    ".it .m{font-family:Consolas,monospace;color:#5b6472}.it .tg{font-size:10px;background:#fef3c7;color:#92400e;border-radius:5px;padding:0 4px}.it .pn{font-size:10.5px;color:#be123c}" +
    ".logbox{max-height:170px;overflow:auto;font-size:10.5px;line-height:1.4;background:#0b1437;color:#cbd5e1;border-radius:8px;padding:6px 8px}.logbox div{padding:1px 0;border-bottom:1px dotted #1e2a5a}" +
    ".l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#cbd5e1}.lt{display:inline-block;color:#aab2c0;margin-right:6px}" +
    ".hint{font-size:11px;color:#5b6472;margin-top:7px;line-height:1.4}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#7a8090;line-height:1.35;background:#f5f6ff;border:1px solid #d4d8f5;border-radius:7px;padding:5px 7px}" +
    ".opt{display:flex;gap:6px;align-items:flex-start;font-size:11.5px;margin-top:8px;cursor:pointer;line-height:1.35}.opt input{margin:2px 0 0;accent-color:#3730a3}.foot{margin-top:8px;padding-top:6px;border-top:1px solid #d4d8f5;display:flex;justify-content:space-between;font-size:10.5px;color:#5b5f8a}.foot b{color:#1e1b4b}.foot em{font-style:normal;color:#c2770a}[hidden]{display:none!important}";
  var HTML =
    "<div class='hd' id='ka_hd'><span class='hdl'><span class='logo'>K</span><span class='ttl'><b>🪪 Aadhaar Update</b><small><i>K-Desk</i> Suite · Gram Setu → portal</small></span></span><button class='mn' id='ka_min'>–</button></div>" +
    "<div class='bd' id='ka_bd'>" +
    "<div class='summary' id='ka_sum'></div>" +
    "<div class='prog' id='ka_prog' hidden><div class='progbar'><div class='progfill' id='ka_fill'></div></div><div class='progtxt' id='ka_ptxt'></div></div>" +
    "<label class='opt' id='ka_sentrow'><input type='checkbox' id='ka_sent'> Admin ✓ Verify না করা (শুধু supervisor পাঠানো) Aadhaar-ও আনো</label>" +
    "<div class='btnrow' id='ka_loadrow'><button class='btn blue' id='ka_load'>⭳ Gram Setu থেকে আনুন</button></div>" +
    "<div class='list' id='ka_list' hidden></div>" +
    "<label class='opt' id='ka_testrow'><input type='checkbox' id='ka_test'> 🧪 Test run: Verify পর্যন্ত — Save চাপবে না, Gram Setu-তে ফল পাঠাবে না</label>" +
    "<div class='btnrow' id='ka_starts' hidden><button class='btn iay' id='ka_start'>🧪 Test run শুরু</button></div>" +
    "<div class='btnrow' id='ka_res' hidden><button class='btn fill' id='ka_resume'>▶ Resume</button></div>" +
    "<div class='cfm' id='ka_cfm' hidden><div class='cfmh' id='ka_cfmh'></div><div id='ka_cfmtxt'></div>" +
      "<div class='btnrow'><button class='btn fill' id='ka_yes'>হ্যাঁ, শুরু করুন</button><button class='btn ghost' id='ka_no'>বাতিল</button></div></div>" +
    "<div class='btnrow'><button class='btn stop' id='ka_stop'>■ Stop</button><button class='btn ghost' id='ka_dl'>⭳ Log (Excel)</button></div>" +
    "<div class='btnrow'><button class='btn ghost' id='ka_up' hidden>⇪ ফল Gram Setu-তে পাঠান</button><button class='btn ghost danger' id='ka_new'>↺ New run (clear)</button></div>" +
    "<div class='st' id='ka_st' hidden></div>" +
    "<div class='sec'>Activity</div><div class='logbox' id='ka_logbox'></div>" +
    "<div class='hint'>প্রতিটা worker: <b>Job Card No.</b> দিয়ে Search (page reload) → Aadhaar No. (portal নিজেই encrypt করে) + Name as per Aadhaar + Consent Yes → <b>Verify</b> → সবুজ হলে <b>Save Verified Records of this page</b>। " +
      "Fail হলে portal-এর message Admin-এর কাছে comment হয়ে যায়। Gender mismatch হলে D1 page-এ ঠিক করতে হয়।</div>" +
    "<div class='disclaimer'>⚠ এটা সত্যিকারের Aadhaar portal-এ Save করে। আগে 🧪 Test run চালিয়ে দেখে নিন। Aadhaar No. শুধু এই extension-এর storage-এ থাকে, কাজ শেষে মুছে যায়; Log-এ শুধু শেষ ৪ সংখ্যা।</div>" +
    "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>K-Desk v<span id='ka_ver'></span></em></div>" +
    "</div>";

  function build() {
    if ($(HOST_ID)) return;
    var host = document.createElement("div"); host.id = HOST_ID;
    var kdW = 58; try { if (localStorage.getItem("kd_wide") === "1" && localStorage.getItem("kd_collapsed") !== "1") kdW = 200; } catch (e) {}
    host.style.cssText = "position:fixed;top:0;right:" + kdW + "px;left:auto;z-index:2147483646;";
    var pos = null; try { pos = JSON.parse(localStorage.getItem(POS_KEY) || "null"); } catch (e) {}
    if (pos && pos.l >= 0 && pos.t >= 0 && pos.l < window.innerWidth - 60 && pos.t < window.innerHeight - 40) { host.style.left = pos.l + "px"; host.style.top = pos.t + "px"; host.style.right = "auto"; }
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE; root.appendChild(css);
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML; root.appendChild(box);
    ["hd", "min", "bd", "ver", "sum", "prog", "fill", "ptxt", "sentrow", "sent", "loadrow", "load", "list", "testrow", "test", "starts", "start", "res", "resume",
     "cfm", "cfmh", "cfmtxt", "yes", "no", "stop", "dl", "up", "new", "st", "logbox"]
      .forEach(function (id) { sel[id === "new" ? "newr" : id === "load" ? "loadb" : id] = root.getElementById("ka_" + id); });
    try { sel.ver.textContent = chrome.runtime.getManifest().version; } catch (e) {}
    try { if (localStorage.getItem(MIN_KEY) === "1") { sel.bd.style.display = "none"; sel.min.textContent = "+"; } } catch (e) {}
    sel.test.checked = testPref(); sel.sent.checked = sentPref();
    sel.test.addEventListener("change", function () { try { localStorage.setItem(TEST_KEY, sel.test.checked ? "1" : "0"); } catch (e) {} confirming = false; render(); });
    sel.sent.addEventListener("change", function () { try { localStorage.setItem(SENT_KEY, sel.sent.checked ? "1" : "0"); } catch (e) {} });
    sel.loadb.addEventListener("click", fetchList);
    sel.start.addEventListener("click", askStart);
    sel.yes.addEventListener("click", doStart);
    sel.no.addEventListener("click", function () { confirming = false; render(); });
    sel.resume.addEventListener("click", resume);
    sel.stop.addEventListener("click", stopRun);
    sel.dl.addEventListener("click", function () { download(false); });
    sel.up.addEventListener("click", function () { var r = load(); if (r) { status("পাঠাচ্ছি…"); flush(r, function () { var x = load(); if (x && !(x.rq || []).length) status("Gram Setu-তে ফল পাঠানো হয়েছে।", "ok"); render(); }); } });
    sel.newr.addEventListener("click", newRun);
    sel.min.addEventListener("click", function () { var hide = sel.bd.style.display !== "none"; sel.bd.style.display = hide ? "none" : "block"; sel.min.textContent = hide ? "+" : "–"; try { localStorage.setItem(MIN_KEY, hide ? "1" : "0"); } catch (e) {} });
    var sx, sy, ox, oy, drag = false;
    sel.hd.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
    document.addEventListener("mouseup", function () {
      if (!drag) return; drag = false;
      var rr = host.getBoundingClientRect(); try { localStorage.setItem(POS_KEY, JSON.stringify({ l: Math.max(0, Math.round(rr.left)), t: Math.max(0, Math.round(rr.top)) })); } catch (e) {}
    });
    render(); setInterval(render, 1500);
  }
  function boot() {
    if (!onPage()) return;
    build();
    uidsLoad().then(function () {
      var r = load();
      if (r && !r.active && r.rq && r.rq.length && !r.test) flush(r);   // results left from an earlier page
      setTimeout(step, 700);
    });
  }
  function start() { if (window.KH_FEATURE) window.KH_FEATURE("aadhaar", boot); else boot(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
