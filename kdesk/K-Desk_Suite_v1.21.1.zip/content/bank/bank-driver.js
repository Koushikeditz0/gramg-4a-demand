/* =====================================================================
   K-Desk Suite by Koushik — 🏦 Bank A/c Update   (…/vbgramg/EditAppBank.aspx)
   Ported from Koushik's own Tampermonkey script "Bulk Bank Account Updater
   (Excel)" v1.4.1 — same steps, already proven on the real portal:
   Bank → IFSC/Branch → Family-Id search → (grid pages) → tick the applicant →
   Account No twice (+ holder name if empty) → Update (Auto) or the user presses
   Update (Manual). Results are read from the portal's alert / message.
   New in K-Desk: rows can also come from the Gram Setu app
   ("☁ Gram Setu" = accounts the Admin ✔ Verified); OK/Fail goes back to the app.
   MAIN world, document_start (needs the page's PageRequestManager, __doPostBack and
   alert). bank-bridge.js (isolated world) checks licence/toggle and talks to Gram Setu.
   ===================================================================== */
(function () {
  'use strict';
  if (window.__KDBANK) return; window.__KDBANK = true;
  const W = window;
  const NDate = Date;                       // native Date, captured before the portal's scripts run
  const KEY = 'kdbank_state_v1';
  const P = 'ctl00_ContentPlaceHolder1_';

  /* ---------------- State (page reload হলেও থাকে) ---------------- */
  const DEF = { rows: [], idx: 0, running: false, auto: false, phase: 'idle', msgs: [], delay: 400, min: false };
  let S = DEF;
  try { S = Object.assign({}, DEF, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { S = Object.assign({}, DEF); }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
  function modOff() { try { return localStorage.getItem('kdbank_off') !== '0'; } catch (e) { return true; } }

  /* ---------------- alert() ধরা – document-start এ, যাতে server-এর alert-ও log হয় ---------------- */
  const origAlert = W.alert.bind(W);
  W.alert = function (m) {
    m = String(m == null ? '' : m);
    if (S.running || S.phase !== 'idle') { S.msgs.push(m); save(); try { log('Portal alert: ' + m); } catch (e) {} }
    if (!(S.running && S.auto)) origAlert(m);   // Auto mode-এ alert চেপে রাখা হয়, log-এ দেখা যাবে
  };

  // licence/toggle guard (bank-bridge.js) আগে "kdbank_off" লিখে নিক
  function boot() {
    let n = 0;
    (function wait() {
      let v = null; try { v = localStorage.getItem('kdbank_off'); } catch (e) {}
      if (v === '0') return init();
      if (v === '1' && n > 4) { if (S.running) { S.running = false; save(); } return; }
      if (++n > 40) return;                 // ~6 s: guard did not answer → stay off
      setTimeout(wait, 150);
    })();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else setTimeout(boot, 0);

  /* ---------------- Helpers ---------------- */
  const $ = id => document.getElementById(P + id);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const normName = s => String(s || '').toUpperCase().replace(/[^A-Z]/g, '');
  const normTxt = s => String(s || '').toUpperCase().replace(/&/g, 'AND').replace(/[^A-Z0-9]/g, '');
  const normJC = s => String(s || '').toUpperCase().replace(/\s+/g, '');

  function lev(a, b) {
    const m = a.length, n = b.length; if (!m || !n) return Math.max(m, n);
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[n];
  }
  const sim = (a, b) => { a = normName(a); b = normName(b); if (!a || !b) return 0; return 1 - lev(a, b) / Math.max(a.length, b.length); };

  function prm() { return W.Sys && W.Sys.WebForms && W.Sys.WebForms.PageRequestManager.getInstance(); }

  // UpdatePanel async postback শেষ হওয়া পর্যন্ত অপেক্ষা
  function postback(trigger, timeout = 60000) {
    return new Promise((resolve, reject) => {
      const p = prm();
      if (!p) { trigger(); return reject(new Error('ScriptManager পাওয়া যায়নি')); }
      let started = false, done = false;
      const onBegin = () => { started = true; };
      const onEnd = (s, a) => {
        if (done) return; done = true; cleanup();
        const err = a.get_error && a.get_error();
        if (err) { a.set_errorHandled(true); reject(new Error('Server error: ' + err.message)); }
        else setTimeout(resolve, 250);
      };
      const cleanup = () => { p.remove_beginRequest(onBegin); p.remove_endRequest(onEnd); };
      p.add_beginRequest(onBegin); p.add_endRequest(onEnd);
      trigger();
      setTimeout(() => { if (!started && !done && !p.get_isInAsyncPostBack()) { done = true; cleanup(); reject(new Error('Postback হয়নি (validation আটকেছে?)')); } }, 2500);
      setTimeout(() => { if (!done) { done = true; cleanup(); reject(new Error('Timeout – portal সাড়া দেয়নি')); } }, timeout);
    });
  }
  async function idle() { const p = prm(); let t = 0; while (p && p.get_isInAsyncPostBack() && t < 600) { await sleep(100); t++; } }
  const fire = (el, type) => el.dispatchEvent(new Event(type, { bubbles: true }));

  /* ---------------- Bank mapping ---------------- */
  const IFSC_BANK = {
    SBIN: 'State Bank of India', IDIB: 'Indian Bank', ALLA: 'Indian Bank', PUNB: 'Punjab National Bank', UTBI: 'Punjab National Bank',
    ORBC: 'Punjab National Bank', BARB: 'Bank of Baroda', VIJB: 'Bank of Baroda', BKDN: 'Bank of Baroda', UCBA: 'UCO Bank',
    UBIN: 'Union Bank of India', ANDB: 'Union Bank of India', CORP: 'Union Bank of India', CNRB: 'Canara Bank', SYNB: 'Canara Bank',
    BKID: 'Bank of India', CBIN: 'Central Bank Of India', IOBA: 'Indian Overseas Bank', PSIB: 'Punjab & Sind Bank', MAHB: 'Bank of Maharastra',
    HDFC: 'HDFC Bank', ICIC: 'ICICI BANK', UTIB: 'AXIS BANK', IBKL: 'IDBI Bank', IPOS: 'India Post Payments Bank', BDBL: 'Bandhan Bank Limited',
    KKBK: 'KOTAK MAHINDRA BANK LTD', YESB: 'YES BANK LTD', FDRL: 'FEDERAL BANK', INDB: 'INDUSIND BANK LTD.', AIRP: 'Airtel Payments Bank Limited',
    FINO: 'Fino Payments Bank Ltd', UJVN: 'UJJIVAN SMALL FINANCE BANK', AUBL: 'AU Small Finance Bank Limited', ESFB: 'Equitas Small Finance Bank Limited',
    IDFB: 'IDFC Bank', KARB: 'KARNATAKA BANK', KVBL: 'Karur Vysya Bank', SIBL: 'South Indian Bank', TMBL: 'Tamilnadu Mercantile Bank',
    DBSS: 'DBS Bank India Limited', RATN: 'Ratnakar Bank', JAKA: 'JK Bank', CSBK: 'Catholic Syrian Bank Ltd.', DLXB: 'Dhanalakshmi Bank Ltd.',
    SCBL: 'STANDARD CHARTERED BANK LTD.', CITI: 'CITI BANK', CIUB: 'Citi Union Bank Ltd.', NTBL: 'NAINITAL BANK', DCBL: 'Development Credit Bank Ltd.'
  };
  const NAME_ALIAS = { SBI: 'State Bank of India', PNB: 'Punjab National Bank', BOB: 'Bank of Baroda', UBI: 'Union Bank of India', BOI: 'Bank of India',
    CBI: 'Central Bank Of India', IOB: 'Indian Overseas Bank', UNITEDBANKOFINDIA: 'Punjab National Bank', ALLAHABADBANK: 'Indian Bank',
    IPPB: 'India Post Payments Bank', BANKOFMAHARASHTRA: 'Bank of Maharastra' };

  function bankCandidates(bankName, ifsc) {
    const sel = $('ddlBankCodeName'); const opts = [...sel.options].filter(o => o.value !== '00');
    const out = [];
    const add = o => { if (o && !out.includes(o)) out.push(o); };
    const byText = t => opts.find(o => normTxt(o.text) === normTxt(t));
    let n = normTxt(bankName);
    if (n) {
      add(byText(bankName));
      if (NAME_ALIAS[n]) add(byText(NAME_ALIAS[n]));
      if (/GRAMIN|KSHETRIYA|RRB/.test(n)) add(opts.find(o => /GRAMIN/i.test(o.text)));
      if (!out.length) add(opts.find(o => normTxt(o.text).startsWith(n) || n.startsWith(normTxt(o.text))));
    }
    const pre = String(ifsc || '').slice(0, 4);
    if (IFSC_BANK[pre]) add(byText(IFSC_BANK[pre]));
    return out;
  }
  function findBranch(ifsc) {
    const sel = $('ddlBrCodeName'); if (!sel) return null;
    const tries = [ifsc]; if (ifsc[4] === 'O') tries.push(ifsc.slice(0, 4) + '0' + ifsc.slice(5));
    const opts = [...sel.options];
    for (const t of tries) {
      const o = opts.find(x => x.value.split(':')[0].toUpperCase() === t) ||
                opts.find(x => x.value.toUpperCase().includes(t) || x.text.toUpperCase().includes(t));
      if (o) return o;
    }
    return null;
  }

  /* ---------------- Excel / Gram Setu rows ---------------- */
  function parseAcc(v) {
    if (typeof v === 'number') {
      if (!Number.isFinite(v)) return { err: 'Account number ভুল' };
      const s = BigInt(Math.round(v)).toString();
      if (s.length > 15) return { acc: s, err: 'Excel-এ Number হিসেবে আছে, 15 digit-এর বেশি – শেষের digit হারিয়ে যেতে পারে। Column টা Text করে আবার লিখুন' };
      return { acc: s };
    }
    const raw = String(v || '').trim();
    if (/e\+/i.test(raw)) return { err: 'Scientific format (E+) – আসল নম্বর নেই, Excel-এ ঠিক করুন' };
    const s = raw.replace(/[\s'`]/g, '');
    if (!/^\d+$/.test(s)) return { err: 'Account-এ শুধু digit থাকা উচিত: ' + raw };
    return { acc: s };
  }
  function makeRow(xl, jcRaw, name, bank, ifscRaw, accRaw, extra) {
    const jc = normJC(jcRaw), a = parseAcc(accRaw);
    const ifsc = String(ifscRaw || '').toUpperCase().replace(/\s+/g, '');
    const row = Object.assign({ xl, jc, name: String(name || '').trim(), bank: String(bank || '').trim(), ifsc, acc: a.acc || '', status: 'PENDING', note: '' }, extra || {});
    if (!/^[A-Z0-9-]+\/\d+$/.test(jc)) { row.status = 'BAD'; row.note = 'Job Card format ভুল'; }
    else if (a.err) { row.status = 'BAD'; row.note = a.err; }
    else if (a.acc.length < 9 || a.acc.length > 18) { row.status = 'BAD'; row.note = 'Account length ' + a.acc.length + ' (9–18 হওয়া উচিত)'; }
    else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc) && !/^[A-Z]{4}O[A-Z0-9]{6}$/.test(ifsc)) { row.status = 'BAD'; row.note = 'IFSC format ভুল: ' + ifsc; }
    return row;
  }

  function parseSheet(buf) {
    if (!W.XLSX) throw new Error('Excel reader লোড হয়নি – page reload করুন');
    const wb = W.XLSX.read(buf, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const aoa = W.XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' });
    const hi = aoa.findIndex(r => r.some(c => /job\s*card/i.test(String(c))));
    if (hi < 0) throw new Error('"Job Card no" header পাওয়া যায়নি');
    const H = aoa[hi].map(c => String(c).trim());
    const col = re => H.findIndex(h => re.test(h));
    const cJC = col(/job\s*card/i), cAcc = col(/account|a\/c|ac\.?\s*no/i), cIFSC = col(/ifsc/i);
    const cName = H.findIndex((h, i) => i !== cJC && /name/i.test(h));
    const cBank = H.findIndex((h, i) => i !== cAcc && i !== cIFSC && /bank/i.test(h));
    if ([cJC, cName, cAcc, cIFSC].some(x => x < 0)) throw new Error('Column মেলেনি। লাগবে: Job Card no, Name, Account, Bank, IFSC');
    const rows = [];
    for (let i = hi + 1; i < aoa.length; i++) {
      const r = aoa[i]; if (!normJC(r[cJC])) continue;
      rows.push(makeRow(i + 1, r[cJC], r[cName], cBank >= 0 ? r[cBank] : '', r[cIFSC], r[cAcc]));
    }
    return rows;
  }

  /* ---------------- একটি record process ---------------- */
  async function ensureBankBranch(rec) {
    const cands = bankCandidates(rec.bank, rec.ifsc);
    if (!cands.length) throw new Error('Bank dropdown-এ মেলেনি: ' + (rec.bank || rec.ifsc.slice(0, 4)));
    for (const opt of cands) {
      const sel = $('ddlBankCodeName');
      if (sel.value !== opt.value) {
        log(`Bank select: ${opt.text}`);
        await postback(() => { sel.value = opt.value; fire(sel, 'change'); });
        await sleep(S.delay);
      }
      let br = findBranch(rec.ifsc);
      if (!br && $('txtifsc') && $('ImageButton1')) {
        log(`IFSC search: ${rec.ifsc}`);
        try {
          await postback(() => { const t = $('txtifsc'); t.value = rec.ifsc; fire(t, 'input'); $('ImageButton1').click(); });
          await sleep(S.delay);
        } catch (e) { log('IFSC search: ' + e.message); }
        br = findBranch(rec.ifsc);
        const bsNow = $('ddlBrCodeName');
        if (!br && bsNow && bsNow.selectedIndex > 0 && bsNow.value.toUpperCase().includes(rec.ifsc)) br = bsNow.selectedOptions[0];
      }
      if (br) {
        const bs = $('ddlBrCodeName');
        if (bs.value !== br.value) { bs.value = br.value; fire(bs, 'change'); await idle(); }
        return opt.text + ' / ' + br.text.split('::').pop();
      }
      log(`IFSC ${rec.ifsc} "${opt.text}"-এর branch list-এ নেই, পরের option দেখছি…`);
    }
    const bs = $('ddlBrCodeName');
    throw new Error(`IFSC branch list-এ পাওয়া যায়নি: ${rec.ifsc} [Bank=${$('ddlBankCodeName').selectedOptions[0].text}; branch options=${bs ? bs.options.length : 'none'}; উদাহরণ: ${bs ? [...bs.options].slice(1, 3).map(o => o.value.slice(0, 30)).join(' , ') : ''}]`);
  }

  function gridRegs() { const g = $('grdData'); return g ? [...g.querySelectorAll('[id$="_HF_Reg_No"]')].map(h => normJC(h.value)) : []; }
  function diag(key) {
    const regs = gridRegs(), bs = $('ddlBrCodeName');
    return `[key=${$('jcr_srch_key') ? $('jcr_srch_key').value : '?'} (চাওয়া ${key}); grid rows=${regs.length}; প্রথম: ${regs.slice(0, 3).join(', ') || '-'}; Bank=${$('ddlBankCodeName').selectedOptions[0].text}; Branch=${bs && bs.selectedOptions[0] ? bs.selectedOptions[0].text.slice(0, 30) : '-'}]`;
  }
  const gridHasKey = key => gridRegs().some(r => r.endsWith('/' + key));
  async function doSearch(key) {
    const j = $('jcr_srch_key'), btn = $('ImgbtnSearch');
    log(`Search: ${key}`);
    if (btn) { j.value = key; await postback(() => btn.click()); }
    else await postback(() => { j.value = key; fire(j, 'change'); });
    await sleep(S.delay);
    if (!gridHasKey(key)) {
      log('Search button-এ ফল আসেনি, onchange দিয়ে আবার চেষ্টা…');
      try { await postback(() => { const j2 = $('jcr_srch_key'); j2.value = key; fire(j2, 'change'); }); await sleep(S.delay); } catch (e) { log(e.message); }
    }
  }

  function findRow(rec) {
    const grid = $('grdData'); if (!grid) return { err: 'Grid আসেনি (search result নেই) ' + diag(rec.jc.split('/').pop()) };
    const head = [...grid.rows[0].cells].map(c => c.innerText);
    let nameIdx = head.findIndex(h => /applicant\s*name/i.test(h)); if (nameIdx < 0) nameIdx = 3;
    let cands = [...grid.querySelectorAll('[id$="_HF_Reg_No"]')]
      .filter(h => normJC(h.value) === rec.jc)
      .map(h => { const tr = h.closest('tr'); const ap = tr.querySelector('[id$="_HF_Applicant_no"]'); return { tr, name: tr.cells[nameIdx].innerText.trim(), ap: ap ? String(ap.value).trim() : '' }; });
    if (!cands.length) return { err: 'এই Job Card portal-এ পাওয়া যায়নি ' + diag(rec.jc.split('/').pop()) };
    // Gram Setu rows know the Applicant No: that decides, the name only has to look alike
    if (rec.ap) {
      const byAp = cands.find(c => c.ap === String(rec.ap));
      if (byAp && sim(byAp.name, rec.name) >= 0.5) return { row: byAp, fuzzy: sim(byAp.name, rec.name) < 1 };
    }
    cands.forEach(c => c.score = sim(c.name, rec.name));
    cands.sort((a, b) => b.score - a.score);
    const best = cands[0], second = cands[1];
    if (best.score === 1 && (!second || second.score < 1)) return { row: best };
    if (best.score >= 0.8 && (!second || best.score - second.score >= 0.15)) return { row: best, fuzzy: true };
    return { err: `Name মেলেনি। Portal-এ আছে: ${cands.map(c => c.name).join(', ')}`, names: cands.map(c => c.name) };
  }

  // Grid-এ প্রতি page-এ 15 জন – পরের page খোঁজা
  function pagerInfo() {
    const grid = $('grdData'); if (!grid) return null;
    const a = grid.querySelector('a[href*="Page$"]'); if (!a) return null;
    const m = (a.getAttribute('href') || '').match(/__doPostBack\('([^']+)'/);
    const prow = a.closest('tr');
    const curSpan = prow && [...prow.querySelectorAll('span')].find(sp => /^\d+$/.test(sp.textContent.trim()));
    return { target: m ? m[1] : null, cur: curSpan ? +curSpan.textContent.trim() : 1, a };
  }
  const gridPostback = (pi, arg) => postback(() => { if (typeof W.__doPostBack === 'function' && pi.target) W.__doPostBack(pi.target, arg); else pi.a.click(); });

  function nextPage() {
    const grid = $('grdData'); if (!grid) return null;
    const links = [...grid.querySelectorAll('a[href*="Page$"]')].map(a => {
      const m = (a.getAttribute('href') || '').match(/__doPostBack\('([^']+)','(Page\$(\w+))'\)/);
      return m ? { a, target: m[1], arg: m[2], num: /^\d+$/.test(m[3]) ? +m[3] : null, word: m[3], label: a.textContent.trim() } : null;
    }).filter(Boolean);
    if (!links.length) return null;
    const prow = links[0].a.closest('tr');
    const curSpan = prow && [...prow.querySelectorAll('span')].find(sp => /^\d+$/.test(sp.textContent.trim()));
    const cur = curSpan ? +curSpan.textContent.trim() : 1;
    return links.find(l => l.num === cur + 1) ||
           links.filter(l => l.num && l.num > cur).sort((x, y) => x.num - y.num)[0] ||
           links.find(l => l.word === 'Next') || null;
  }

  async function findRowPaged(rec) {
    const seen = new Set(), names = []; let lastErr = '';
    const pi = pagerInfo();
    if (pi && pi.cur !== 1) {
      log(`Grid page ${pi.cur} থেকে page 1-এ ফিরছি…`);
      await gridPostback(pi, 'Page$1'); await sleep(S.delay);
    }
    for (let n = 0; n < 40; n++) {
      const f = findRow(rec);
      if (f.row) return f;
      lastErr = f.err; if (f.names) names.push(...f.names);
      const nx = nextPage();
      if (!nx || seen.has(nx.arg)) break;
      seen.add(nx.arg);
      log(`Grid page ${nx.label} দেখছি…`);
      await postback(() => { if (typeof W.__doPostBack === 'function') W.__doPostBack(nx.target, nx.arg); else nx.a.click(); });
      await sleep(S.delay);
    }
    if (names.length) throw new Error(`Name মেলেনি (সব page দেখা হয়েছে)। Portal-এ এই Job Card-এ আছে: ${[...new Set(names)].join(', ')}`);
    throw new Error(lastErr + (seen.size ? ` (${seen.size + 1} টা page দেখা হয়েছে)` : ''));
  }

  const cleanName = n => String(n || '').replace(/[^A-Za-z. ]/g, ' ').replace(/\s+/g, ' ').trim();
  function fillRow(tr, acc, holderName) {
    document.querySelectorAll(`#${P}grdData [id$="_input_chkRowEdit"]`).forEach(c => { if (c.checked && !tr.contains(c)) c.click(); });
    const chk = tr.querySelector('[id$="_input_chkRowEdit"]');
    const a1 = tr.querySelector('[id$="_txtAcNo"]'), a2 = tr.querySelector('[id$="_txtAcNo1"]');
    if (!chk || !a1 || !a2) throw new Error('Row-এ checkbox/account box পাওয়া যায়নি');
    const old = a1.value;
    if (!chk.checked) chk.click();
    for (const el of [a1, a2]) { el.focus(); el.value = acc; fire(el, 'input'); fire(el, 'change'); fire(el, 'keyup'); fire(el, 'blur'); }
    let holderSet = '';
    const hn = tr.querySelector('[id$="_txtApp_Name_BankPO"]');
    if (hn && hn.value.trim().length < 3) {
      const nm = cleanName(holderName).slice(0, 50);
      if (nm.length >= 3) { hn.focus(); hn.value = nm; fire(hn, 'input'); fire(hn, 'change'); fire(hn, 'blur'); holderSet = nm; }
    }
    document.querySelectorAll('.kdb-hl').forEach(e => e.classList.remove('kdb-hl'));
    tr.classList.add('kdb-hl'); tr.scrollIntoView({ block: 'center' });
    return { old, holderSet };
  }

  function judge(msgs) {
    const t = msgs.join(' | ').replace(/<br\s*\/?>/gi, ' ').trim();
    if (/no\s+records?\s+updated|cannot|can not|already\s+exist|invalid|error|fail|wrong|mismatch/i.test(t)) return ['FAIL', t];
    if (/[1-9]\d*\s*record\(?s?\)?\s*updated|success|সফল/i.test(t)) return ['OK', t];
    return ['DONE?', t || '(portal কোনো message দেয়নি – নিজে একবার মিলিয়ে নিন)'];
  }
  function pageMsgs() {
    return [...document.querySelectorAll(`#aspnetForm span[id*="msg" i], #aspnetForm span[id*="Message" i], #aspnetForm span[id*="lblErr" i]`)]
      .filter(s => s.offsetParent && s.innerText.trim()).map(s => s.innerText.trim());
  }

  /* ---------------- Gram Setu link (via bank-bridge.js) ---------------- */
  const LB_SRC = 'kdbank-main', BR_SRC = 'kdbank-bridge';
  function toBridge(msg) { try { W.postMessage(Object.assign({ src: LB_SRC }, msg), location.origin); } catch (e) {} }
  // OK → app marks "Portal updated"; FAIL/ERROR → "Portal: failed" (stays in the pending list for next time)
  function reportLB(rec) {
    if (!rec || !rec.lbId) return;
    const s = rec.status === 'OK' ? 'ok' : (rec.status === 'FAIL' || rec.status === 'ERROR') ? 'fail' : null;
    if (!s) return;
    const parts = String(rec.note || '').split('|').map(x => x.trim()).filter(Boolean);
    toBridge({ type: 'report', rows: [{ id: rec.lbId, s, m: (parts[parts.length - 1] || rec.status).slice(0, 300) }] });
  }
  W.addEventListener('message', e => {
    const d = e.data; if (e.source !== W || !d || d.src !== BR_SRC) return;
    if (d.type === 'rows') {
      if (S.running) { setStatus('আগে Pause করুন'); return; }
      const prevLB = S.rows.filter(r => r.lbId && r.status !== 'OK');
      const have = new Set(prevLB.map(r => r.lbId));
      const add = (d.rows || []).filter(r => !have.has(r.id)).map(r =>
        makeRow('LB', r.jc, r.name, '', r.ifsc, String(r.acc || ''), { lbId: r.id, ap: r.ap ? String(r.ap) : '', holder: r.holder || '' }));
      let excel = S.rows.filter(r => !r.lbId);
      if (excel.length && !confirm(`Excel-এর ${excel.length} টা row-ও list-এ রাখবো?\nOK = রাখো, Cancel = সরিয়ে দাও`)) excel = [];
      S.rows = excel.concat(prevLB, add);
      S.idx = 0; S.phase = 'idle'; save(); render();
      const bad = add.filter(r => r.status === 'BAD').length;
      setStatus(`☁ Gram Setu: ${d.rows.length} টা verified account (নতুন ${add.length})${bad ? ` – ${bad} টা ভুল data` : ''}. Start চাপুন।`);
    } else if (d.type === 'status') setStatus(d.text || '');
  });

  let userClickResolve = null;
  async function processOne(rec) {
    await idle();
    S.msgs = []; save();
    const bb = await ensureBankBranch(rec);
    const key = rec.jc.split('/').pop();
    log(`▶ ${rec.jc} – ${rec.name}`);
    await doSearch(key);
    { const want = findBranch(rec.ifsc), bs = $('ddlBrCodeName');
      if (!want || !bs || bs.value !== want.value) {
        log('Search-এর পরে Bank/Branch বদলে গেছে – আবার সেট করছি');
        await ensureBankBranch(rec);
        if (!gridHasKey(key)) await doSearch(key);
      } }
    const f = await findRowPaged(rec);
    const { old, holderSet } = fillRow(f.row.tr, rec.acc, rec.holder || f.row.name);
    rec.note = `${bb}; Portal name: ${f.row.name}${f.fuzzy ? ' (approx match)' : ''}; আগের A/c: ${old || '-'}${holderSet ? '; Holder name বসানো: ' + holderSet : ''}`;
    S.msgs = []; save();

    if (S.auto) {
      S.phase = 'submitted'; save();
      await postback(() => $('BtnUpdate').click());
    } else {
      S.phase = 'await-user'; save();
      setStatus(`দেখে নিয়ে নিজে "Update" চাপুন → (${rec.jc} / ${rec.name} / ${rec.acc})`);
      const act = await new Promise(r => { userClickResolve = r; });
      if (act === 'skip') { rec.status = 'SKIPPED'; rec.note += ' | user skip'; S.phase = 'idle'; save(); return; }
      if (act === 'pause') { rec.status = 'PENDING'; S.phase = 'idle'; save(); return; }
    }
    await sleep(300);
    const [st, msg] = judge(S.msgs.concat(pageMsgs()));
    rec.status = st; rec.note += ' | ' + msg;
    S.phase = 'idle'; S.msgs = []; save();
  }

  // Manual mode: user Update চাপলে ধরো
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[id$="BtnUpdate"]');
    if (!b || S.phase !== 'await-user' || !userClickResolve) return;
    const p = prm();
    setTimeout(() => {
      if (!p || !p.get_isInAsyncPostBack()) { setStatus('Validation আটকেছে – ঠিক করে আবার Update চাপুন'); return; }
      S.phase = 'submitted'; save();
      const h = () => { p.remove_endRequest(h); const r = userClickResolve; userClickResolve = null; r && r('updated'); };
      p.add_endRequest(h);
    }, 400);
  }, true);

  async function runLoop() {
    let errRun = 0;
    while (S.running) {
      if (modOff()) { S.running = false; save(); setStatus('K-Desk-এ Bank A/c Update বন্ধ – থামানো হলো'); break; }
      const i = S.rows.findIndex(r => r.status === 'PENDING');
      if (i < 0) { S.running = false; save(); setStatus('সব শেষ ✔'); break; }
      S.idx = i; save(); render();
      const rec = S.rows[i];
      try { await processOne(rec); }
      catch (e) {
        S.phase = 'idle';
        if (/Timeout|ParserError|Server error/i.test(e.message) && !(rec.retry >= 1)) {
          rec.retry = (rec.retry || 0) + 1; rec.status = 'PENDING'; rec.note = '';
          log(`⚠ ${rec.jc}: ${e.message.slice(0, 60)} – 8 সেকেন্ড পরে আবার চেষ্টা`);
          save(); await sleep(8000); continue;
        }
        rec.status = 'ERROR'; rec.note = (rec.note ? rec.note + ' | ' : '') + e.message; log('✖ ' + rec.jc + ': ' + e.message);
      }
      reportLB(rec);
      errRun = (rec.status === 'ERROR' && /Timeout|Server error|Postback|Grid আসেনি|ScriptManager|dropdown/.test(rec.note)) ? errRun + 1 : 0;
      save(); render();
      if (errRun >= 5) { S.running = false; save(); render(); setStatus('পরপর 5টা Error – থামানো হলো। Note/Log দেখে ঠিক করুন, তারপর আবার Start।'); break; }
      await sleep(S.delay);
    }
    render();
  }

  /* ---------------- UI ---------------- */
  let box, logEl;
  function log(m) { console.log('[K-Desk Bank]', m); if (!logEl) return; const d = document.createElement('div'); d.textContent = new NDate().toLocaleTimeString() + '  ' + m; logEl.prepend(d); while (logEl.children.length > 80) logEl.lastChild.remove(); }
  function setStatus(m) { const s = box && box.querySelector('#kdb-status'); if (s) s.textContent = m; log(m); }

  function render() {
    if (!box) return;
    const c = s => S.rows.filter(r => r.status === s).length;
    box.querySelector('#kdb-count').textContent =
      `মোট ${S.rows.length} | বাকি ${c('PENDING')} | OK ${c('OK')} | DONE? ${c('DONE?')} | Fail/Error ${c('FAIL') + c('ERROR')} | Bad data ${c('BAD')}`;
    box.querySelector('#kdb-auto').checked = S.auto;
    box.querySelector('#kdb-start').textContent = S.running ? '⏸ Pause' : '▶ Start';
    box.querySelector('#kdb-body').style.display = S.min ? 'none' : '';
    const tb = box.querySelector('#kdb-tbody'); tb.innerHTML = '';
    const frag = document.createDocumentFragment();
    S.rows.forEach((r, i) => {
      const tr = document.createElement('tr'); tr.dataset.i = i;
      tr.className = 'st-' + r.status.replace('?', 'q') + (i === S.idx && S.running ? ' cur' : '');
      const parts = String(r.note || '').split('|').map(x => x.trim()).filter(Boolean);
      const shortNote = parts.length ? parts[parts.length - 1] : '';
      [r.lbId ? '☁' : r.xl, r.jc + (r.ap ? ' #' + r.ap : ''), r.name, r.acc, r.ifsc, r.status, shortNote].forEach((v, k) => {
        const td = document.createElement('td'); td.textContent = v; if (k === 6) td.title = r.note || ''; if (k === 0 && r.lbId) td.title = 'Gram Setu (Admin ✔ Verified)'; tr.appendChild(td);
      });
      frag.appendChild(tr);
    });
    tb.appendChild(frag);
    const tw = box.querySelector('#kdb-tw'), target = tb.children[Math.max(0, S.idx - 1)];
    if (target) tw.scrollTop = target.offsetTop - tb.offsetTop;
  }

  function exportCSV() {
    const q = v => '"' + String(v).replace(/"/g, '""') + '"';
    const lines = [['Excel Row', 'Job Card', 'Applicant No', 'Name', 'Account', 'IFSC', 'Bank', 'Status', 'Note'].map(q).join(',')]
      .concat(S.rows.map(r => [r.lbId ? 'Gram Setu' : r.xl, r.jc, r.ap || '', r.name, "'" + r.acc, r.ifsc, r.bank, r.status, r.note].map(q).join(',')));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv' }));
    a.download = 'Bank_Update_Result_' + new NDate().toISOString().slice(0, 16).replace(/[:T]/g, '-') + '.csv';
    a.click();
  }

  function init() {
    if (box || !document.body) return;
    const css = document.createElement('style');
    css.textContent = `
#kb-box{display:none!important}
#kdb-box{position:fixed;left:0;right:0;bottom:0;z-index:2147483000;background:#fff;border-top:3px solid #f5b942;box-shadow:0 -6px 20px rgba(11,20,55,.28);font:12px/1.35 'Segoe UI','Nirmala UI',Arial,sans-serif;color:#0f172a}
#kdb-box .hd{background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);color:#fff;padding:4px 10px;display:flex;gap:12px;align-items:center;white-space:nowrap;overflow:hidden}
#kdb-box .hd .k{width:20px;height:20px;border-radius:6px;display:grid;place-items:center;font:800 12px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b);flex:none}
#kdb-box .hd .t{font-weight:700}
#kdb-box .hd #kdb-count{color:#c7d2fe}
#kdb-box .hd #kdb-status{flex:1;overflow:hidden;text-overflow:ellipsis;font-weight:700;color:#fde68a}
#kdb-box .hd button{background:rgba(255,255,255,.14);border:0;border-radius:6px;color:#fff;font-size:13px;cursor:pointer;padding:1px 7px}
#kdb-body{display:grid;grid-template-columns:1fr 260px;gap:4px 8px;padding:5px 8px 6px}
#kdb-box .ctl{grid-column:1/-1;display:flex;gap:4px;flex-wrap:wrap;align-items:center}
#kdb-box .ctl .sep{width:1px;height:18px;background:#cbd5e1;margin:0 4px}
#kdb-box button.b{padding:3px 8px;border:1px solid #c7d2fe;background:#eef2ff;color:#1e1b6b;border-radius:7px;cursor:pointer;font-size:11px;font-weight:600}
#kdb-box button.b:hover{background:#e0e7ff}
#kdb-box button.b.lb{background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b);border-color:#e08e0b;color:#1a1300}
#kdb-box input[type=file]{font-size:11px;width:170px}
#kdb-tw{height:62px;overflow:auto;border:1px solid #e2e8f0;border-radius:6px}
#kdb-box table{border-collapse:collapse;width:100%;table-layout:fixed;font-size:11px}
#kdb-box th,#kdb-box td{border:1px solid #e2e8f0;padding:1px 4px;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:20px}
#kdb-box th{background:#f1f5f9;position:sticky;top:0;z-index:1}
#kdb-box tbody tr{cursor:pointer}
#kdb-box tr.st-OK td{background:#ecfdf5}#kdb-box tr.st-DONEq td{background:#fffbeb}
#kdb-box tr.st-FAIL td,#kdb-box tr.st-ERROR td{background:#fff1f2}#kdb-box tr.st-BAD td{background:#fef2f2;color:#b91c1c}
#kdb-box tr.cur td{background:#fde68a !important;font-weight:bold}
#kdb-full{margin-top:3px;font-size:11px;color:#475569;max-height:30px;overflow:auto;white-space:normal}
#kdb-log{height:62px;overflow:auto;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:3px;font-family:Consolas,monospace;font-size:10.5px;white-space:nowrap}
@media (max-width:900px){#kdb-body{grid-template-columns:1fr}#kdb-log{height:50px}}
tr.kdb-hl td{background:#fde68a !important}`;
    document.head.appendChild(css);

    box = document.createElement('div'); box.id = 'kdb-box';
    box.innerHTML = `
<div class="hd"><span class="k">K</span><span class="t">🏦 Bank A/c Update</span><span id="kdb-count"></span><span id="kdb-status">☁ Gram Setu বা Excel থেকে account আনুন</span><button id="kdb-min" title="ছোট/বড়">▁</button></div>
<div id="kdb-body">
  <div class="ctl">
    <button class="b lb" id="kdb-lb" title="Admin panel-এ ✔ Verify করা account (portal-এ এখনো update হয়নি)">☁ Gram Setu</button>
    <input type="file" id="kdb-file" accept=".xlsx,.xls,.csv">
    <button class="b" id="kdb-start">▶ Start</button>
    <button class="b" id="kdb-skip">⏭ Skip</button>
    <button class="b" id="kdb-retry">↻ Error আবার</button>
    <button class="b" id="kdb-csv">⬇ CSV</button>
    <button class="b" id="kdb-diag" title="Diagnose">🔍</button>
    <button class="b" id="kdb-reset" title="Reset">🗑</button>
    <span class="sep"></span>
    <label><input type="checkbox" id="kdb-auto"> Auto Update</label>
    <label>Delay <input type="number" id="kdb-delay" min="0" step="100" style="width:55px"> ms</label>
  </div>
  <div>
    <div id="kdb-tw"><table><colgroup><col style="width:36px"><col style="width:160px"><col style="width:130px"><col style="width:108px"><col style="width:88px"><col style="width:62px"><col></colgroup>
      <thead><tr><th>Row</th><th>Job Card</th><th>Name</th><th>Account</th><th>IFSC</th><th>Status</th><th>Note (row-এ ক্লিক = পুরো লেখা)</th></tr></thead><tbody id="kdb-tbody"></tbody></table></div>
    <div id="kdb-full"></div>
  </div>
  <div id="kdb-log"></div>
</div>`;
    document.body.appendChild(box);
    logEl = box.querySelector('#kdb-log');
    box.querySelector('#kdb-delay').value = S.delay;

    const pad = () => { document.body.style.paddingBottom = (box.offsetHeight + 10) + 'px'; };
    try { new ResizeObserver(pad).observe(box); } catch (e) {} pad();
    box.querySelector('#kdb-tbody').addEventListener('click', e => {
      const tr = e.target.closest('tr'); if (!tr) return; const r = S.rows[+tr.dataset.i]; if (!r) return;
      box.querySelector('#kdb-full').textContent = `Row ${r.lbId ? 'Gram Setu' : r.xl} | ${r.jc}${r.ap ? ' #' + r.ap : ''} | ${r.name} | ${r.acc} | ${r.status} → ${r.note || '-'}`;
    });

    box.querySelector('#kdb-min').onclick = () => { S.min = !S.min; save(); render(); };
    box.querySelector('#kdb-auto').onchange = e => { S.auto = e.target.checked; save(); };
    box.querySelector('#kdb-delay').onchange = e => { S.delay = Math.max(0, +e.target.value || 0); save(); };
    box.querySelector('#kdb-lb').onclick = () => {
      if (S.running) return setStatus('আগে Pause করুন');
      setStatus('☁ Gram Setu থেকে verified account আনা হচ্ছে…'); toBridge({ type: 'load' });
    };

    box.querySelector('#kdb-file').onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      if (S.running) return origAlert('আগে Pause করুন');
      try {
        const rows = parseSheet(new Uint8Array(await f.arrayBuffer()));
        S.rows = rows; S.idx = 0; S.phase = 'idle'; save(); render();
        const bad = rows.filter(r => r.status === 'BAD').length;
        setStatus(`${rows.length} টা row লোড হয়েছে${bad ? ` – ${bad} টা ভুল data (লাল), সেগুলো skip হবে` : ''}. Start চাপুন।`);
      } catch (err) { setStatus('Excel পড়া যায়নি: ' + err.message); }
      e.target.value = '';
    };

    box.querySelector('#kdb-start').onclick = () => {
      if (S.running) { S.running = false; save(); render(); setStatus('Pause হয়েছে (চলতি কাজ শেষ হলে থামবে)'); if (userClickResolve) { const r = userClickResolve; userClickResolve = null; r('pause'); } return; }
      if (!S.rows.some(r => r.status === 'PENDING')) return setStatus('কোনো PENDING row নেই');
      S.running = true; save(); render(); runLoop();
    };
    box.querySelector('#kdb-skip').onclick = () => {
      const r = S.rows[S.idx]; if (!r) return;
      if (S.phase === 'await-user' && userClickResolve) { const f = userClickResolve; userClickResolve = null; f('skip'); return; }
      if (r.status === 'PENDING') { r.status = 'SKIPPED'; save(); render(); }
    };
    box.querySelector('#kdb-retry').onclick = () => { S.rows.forEach(r => { if (['ERROR', 'FAIL', 'SKIPPED'].includes(r.status)) { r.status = 'PENDING'; r.note = ''; } }); save(); render(); };
    box.querySelector('#kdb-csv').onclick = exportCSV;
    box.querySelector('#kdb-diag').onclick = () => {
      const bs = $('ddlBrCodeName'), p = prm();
      const ids = ['ddlBankCodeName', 'txtifsc', 'ImageButton1', 'ddlBrCodeName', 'jcr_srch_key', 'ImgbtnSearch', 'grdData', 'BtnUpdate'].map(i => i + ':' + ($(i) ? 'ok' : 'NONE')).join(' ');
      const t = `DIAG ${ids} | ScriptManager=${!!p} | branch opts=${bs ? bs.options.length : 0} | ${diag('-')}`;
      log(t); try { navigator.clipboard.writeText(t); setStatus('Diagnose তথ্য log-এ আর clipboard-এ copy হয়েছে'); } catch (e) {}
    };
    box.querySelector('#kdb-reset').onclick = () => { if (!confirm('সব data ও result মুছে যাবে। নিশ্চিত?')) return; S = Object.assign({}, DEF); save(); render(); setStatus('Reset হয়েছে'); };

    render();

    // Full page reload হয়ে গেলে (Update full postback হলে) result ধরে এগিয়ে চলো
    if (S.phase === 'submitted' && S.rows[S.idx]) {
      const rec = S.rows[S.idx]; const [st, msg] = judge(S.msgs.concat(pageMsgs()));
      rec.status = st; rec.note += ' | ' + msg; S.phase = 'idle'; S.msgs = []; save(); render(); reportLB(rec);
    } else if (S.phase === 'await-user') { S.phase = 'idle'; save(); }
    if (S.running) { setStatus('আগের কাজ আবার শুরু হচ্ছে…'); setTimeout(runLoop, 1200); }
  }
})();
