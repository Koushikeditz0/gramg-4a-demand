KH_FEATURE("mr", function () {
/*!
 * MR Batch Print by Koushik — Chrome Extension
 * VB-G RAM G Muster Roll batch reprint -> A4 landscape print / merged PDF
 * (Tampermonkey version-এর একই code, শুধু storage chrome.storage-এ)
 */
(async function () {
  'use strict';
  // শুধু Print Muster Roll page-এ চলবে (URL-এর বড়/ছোট হাতের অক্ষর যাই হোক)
  if (!/reprintmsr\.aspx/i.test(location.pathname)) return;
  // আমাদের নিজের লুকানো iframe-এর ভিতরে panel দেখাবে না
  // (portal নিজে menu-র frame-এ page খুললে সেখানে panel দেখাবে)
  try { if (window.frameElement && window.frameElement.id === 'mrbp-frame') return; } catch (e) { /* cross-origin */ }
  if (document.getElementById('mrbp')) return;
  console.log('[MR Batch Print] চালু হয়েছে:', location.href);

  // ---- Extension storage (Tampermonkey-এর GM_* এর বদলে chrome.storage, memory cache সহ) ----
  // K-Desk Suite-এ integrated: একই storage-এ ABPS/List data-ও আছে, তাই শুধু MR-এর key ("mr…") cache-এ রাখা হয়
  const __all = await chrome.storage.local.get(null);
  const __cache = {};
  Object.keys(__all).forEach((k) => { if (/^mr/.test(k)) __cache[k] = __all[k]; });
  const GM_getValue = (k, d) => (k in __cache ? __cache[k] : d);
  const GM_setValue = (k, v) => { __cache[k] = v; chrome.storage.local.set({ [k]: v }); };
  const GM_deleteValue = (k) => { delete __cache[k]; chrome.storage.local.remove(k); };

  // ================= CONFIG =================
  const PAGE_URL = location.origin + location.pathname;  // যে reprintmsr page খোলা আছে সেটাই
  const LOAD_TIMEOUT = 60000;          // প্রতিটা postback-এর সর্বোচ্চ অপেক্ষা (ms)
  const PRINT_WIDTH_PX = 1075;         // A4 landscape, 6mm margin => প্রায় 1075px
  const CODE_RE = /\b\d{10}\/[A-Z0-9]+\/[A-Z0-9]+\/\d+\b/gi;
  // ==========================================

  const S = {
    get: (k, d) => GM_getValue(k, d),
    set: (k, v) => GM_setValue(k, v),
    del: (k) => GM_deleteValue(k),
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let running = false, stopFlag = false;

  // ---------- Stored MR list ----------
  const getIndex = () => S.get('mr_index', []);
  const setIndex = (a) => S.set('mr_index', a);
  const mrKey = (code, msr, skill) => `mr::${skill}::${code}::${msr}`;
  const getLog = () => S.get('mr_log', []);
  const addLog = (row) => { const l = getLog(); l.push(row); S.set('mr_log', l); };

  // ================= UI =================
  const css = `
  #mrbp{--ink:#0f172a;--navy:#0b1437;--indigo:#3730a3;--gold:#f5b942;--gold2:#e08e0b;--mut:#64748b;--line:#e2e8f0;--soft:#f8fafc;--ok:#10b981;
    position:fixed;left:auto;top:auto;right:16px;bottom:16px;width:400px;z-index:2147483000;color:var(--ink);
    font:13px/1.45 'Segoe UI','Nirmala UI',system-ui,sans-serif;background:#fff;border-radius:16px;overflow:hidden;
    box-shadow:0 18px 50px rgba(11,20,55,.28),0 2px 8px rgba(11,20,55,.12);border:1px solid rgba(255,255,255,.6)}
  #mrbp *{box-sizing:border-box}
  #mrbp header{position:relative;display:flex;align-items:center;gap:10px;padding:12px 12px 12px 14px;cursor:move;user-select:none;touch-action:none;
    color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%)}
  #mrbp header:after{content:"";position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,var(--gold),var(--gold2),transparent)}
  #mrbp .logo{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;flex:none;
    font:800 19px/1 Georgia,'Times New Roman',serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,var(--gold) 45%,var(--gold2));
    box-shadow:0 3px 10px rgba(245,185,66,.45),inset 0 1px 0 rgba(255,255,255,.6)}
  #mrbp .ttl{flex:1;min-width:0}
  #mrbp .ttl b{display:block;font-size:14.5px;font-weight:700;letter-spacing:.2px;white-space:nowrap}
  #mrbp .ttl small{display:block;font-size:11px;color:#c7d2fe;letter-spacing:.3px;white-space:nowrap}
  #mrbp .ttl small i{font-style:normal;color:var(--gold);font-weight:600}
  #mrbp #mrbp-stat{font-size:11px;padding:3px 9px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18);white-space:nowrap}
  #mrbp .hb{width:28px;height:28px;border:0;border-radius:8px;cursor:pointer;color:#fff;font:700 15px/1 system-ui;background:rgba(255,255,255,.12)}
  #mrbp .hb:hover{background:rgba(255,255,255,.25)}
  #mrbp .bd{padding:12px 14px 6px;max-height:70vh;overflow:auto;background:linear-gradient(#fbfcff,#fff)}
  #mrbp .cards{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}
  #mrbp .card{border:1px solid var(--line);border-radius:12px;padding:8px 10px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}
  #mrbp .card span{display:block;font-size:10.5px;color:var(--mut);text-transform:uppercase;letter-spacing:.5px}
  #mrbp .card b{display:block;font-size:20px;font-weight:700;color:var(--navy);line-height:1.2}
  #mrbp .card.g b{color:var(--ok)} #mrbp .card.a b{color:var(--gold2)}
  #mrbp .lbl{font-size:11px;font-weight:600;color:var(--mut);text-transform:uppercase;letter-spacing:.6px;margin:10px 0 5px}
  #mrbp .drop{display:flex;align-items:center;gap:8px;border:1.5px dashed #c7d2fe;border-radius:10px;padding:8px 10px;background:#f5f7ff;font-size:12px;color:var(--indigo)}
  #mrbp .drop input{flex:1;min-width:0;font-size:11.5px}
  #mrbp textarea{width:100%;height:66px;margin-top:6px;border:1px solid var(--line);border-radius:10px;padding:7px 9px;resize:vertical;
    font:12px/1.4 Consolas,monospace;background:#fff;outline:none}
  #mrbp textarea:focus,#mrbp select:focus,#mrbp input[type=number]:focus{border-color:#818cf8;box-shadow:0 0 0 3px rgba(129,140,248,.2)}
  #mrbp .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  #mrbp .fld{display:flex;flex-direction:column;gap:3px;font-size:11px;color:var(--mut)}
  #mrbp select,#mrbp input[type=number]{height:30px;border:1px solid var(--line);border-radius:8px;padding:0 8px;background:#fff;color:var(--ink);font-size:12.5px;outline:none;width:100%}
  #mrbp .chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
  #mrbp .chip{display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border:1px solid var(--line);border-radius:999px;background:#fff;font-size:12px;cursor:pointer}
  #mrbp .chip input{accent-color:var(--indigo);margin:0}
  #mrbp .acts{display:grid;grid-template-columns:1.3fr .8fr 1.3fr;gap:8px;margin:12px 0 8px}
  #mrbp button.b{height:36px;border-radius:10px;border:1px solid var(--line);background:#fff;color:var(--ink);font:600 13px 'Segoe UI','Nirmala UI',sans-serif;cursor:pointer;transition:.15s}
  #mrbp button.b:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 4px 12px rgba(15,23,42,.1)}
  #mrbp button.b:disabled{opacity:.45;cursor:default}
  #mrbp button.go{color:#fff;border:0;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}
  #mrbp button.pr{color:#1a1300;border:0;background:linear-gradient(135deg,#ffd77a,var(--gold) 50%,var(--gold2))}
  #mrbp button.st{color:#b91c1c;border-color:#fecaca;background:#fff5f5}
  #mrbp .mini{display:flex;flex-wrap:wrap;align-items:center;gap:6px}
  #mrbp .mini button{height:28px;padding:0 10px;border-radius:8px;border:1px solid var(--line);background:var(--soft);font-size:12px;cursor:pointer;color:var(--ink)}
  #mrbp .mini button:hover{background:#eef2ff}
  #mrbp .mini label{font-size:12px;color:var(--mut);display:inline-flex;align-items:center;gap:4px;margin-left:auto}
  #mrbp .bar{height:8px;background:#eef2ff;border-radius:99px;overflow:hidden;margin:10px 0 8px}
  #mrbp .bar i{display:block;height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,#34d399,#10b981,#f5b942);transition:width .3s}
  #mrbp .log{height:140px;overflow:auto;border-radius:10px;padding:8px 10px;background:#0b1437;color:#c7d2fe;font:11px/1.5 Consolas,monospace;white-space:pre-wrap}
  #mrbp iframe{width:100%;height:160px;border:1px solid var(--line);border-radius:10px;margin-top:8px}
  #mrbp iframe.hide{display:none}
  #mrbp footer.brand{display:flex;justify-content:space-between;align-items:center;padding:7px 14px;font-size:10.5px;color:var(--mut);border-top:1px solid var(--line);background:var(--soft)}
  #mrbp footer.brand b{color:var(--navy);letter-spacing:.4px} #mrbp footer.brand em{font-style:normal;color:var(--gold2)}
  #mrbp.min{width:auto;border-radius:14px} #mrbp.min .bd,#mrbp.min footer.brand{display:none}
  #mrbp.min header{padding:8px 8px 8px 10px} #mrbp.min .logo{width:30px;height:30px;font-size:16px}
  #mrbp{--line:#d4d8f5;--soft:#f5f6ff;--ink:#1e1b4b;background:linear-gradient(180deg,#eef0ff,#e3e6fb);border:1px solid #c9cef3;box-shadow:0 18px 50px rgba(30,27,75,.30)}
  #mrbp .ttl small{text-transform:uppercase;letter-spacing:.9px;font-size:9.5px}
  #mrbp .ttl{display:flex;flex-direction:column-reverse} #mrbp .ttl b{font-size:15.5px}
  #mrbp[data-kd=drawer]{height:100vh;max-height:100vh;border-radius:18px 0 0 18px;border-right:0;display:flex;flex-direction:column}
  #mrbp[data-kd=drawer].min{height:auto} #mrbp[data-kd=drawer] .logo{display:none}
  #mrbp[data-kd=drawer] .bd{flex:1;max-height:none;overflow:auto} #mrbp .bd{background:transparent}`;
  document.head.appendChild(Object.assign(document.createElement('style'), { textContent: css }));

  const box = document.createElement('div');
  box.id = 'mrbp';
  box.innerHTML = `
  <header title="টেনে সরাও · double-click করলে ছোট/বড়">
    <div class="logo">K</div>
    <div class="ttl"><b>MR Batch Print</b><small><i>K-Desk</i> Suite · by Koushik</small></div>
    <span id="mrbp-stat">0 MR জমা</span>
    <button class="hb" id="mrbp-min" title="ছোট / বড় করো">–</button>
  </header>
  <div class="bd">
    <div class="cards">
      <div class="card"><span>Work Code</span><b id="mrbp-count">0</b></div>
      <div class="card g"><span>MR জমা</span><b id="mrbp-mr">0</b></div>
      <div class="card a"><span>Progress</span><b id="mrbp-pct">0%</b></div>
    </div>

    <div class="lbl">Work Code</div>
    <label class="drop">📄 Excel <input type="file" id="mrbp-file" accept=".xlsx,.xls,.csv"></label>
    <textarea id="mrbp-codes" placeholder="অথবা এখানে Work Code paste করো…&#10;3208005001/IF/IAY/6065850"></textarea>
    <div class="chips">
      <label class="chip"><input type="checkbox" id="mrbp-us" checked> Un-Skilled</label>
      <label class="chip"><input type="checkbox" id="mrbp-sk"> Skilled</label>
    </div>

    <div class="lbl">Settings</div>
    <div class="grid">
      <label class="fld">Mode<select id="mrbp-mode"><option value="fast">⚡ Fast</option><option value="safe">Safe (ধীর)</option></select></label>
      <label class="fld">একসাথে<select id="mrbp-par"><option>1</option><option>2</option><option selected>3</option><option>4</option><option>5</option></select></label>
      <label class="fld">Delay (ms)<input type="number" id="mrbp-delay" value="0" min="0" step="100"></label>
      <label class="fld">Debug<span class="chip" style="height:30px"><input type="checkbox" id="mrbp-show"> iframe দেখাও</span></label>
    </div>

    <div class="acts">
      <button class="b go" id="mrbp-start">▶ Start</button>
      <button class="b st" id="mrbp-stop" disabled>■ Stop</button>
      <button class="b pr" id="mrbp-print">🖨 Print All</button>
    </div>
    <div class="mini">
      <button id="mrbp-xl" title="জমা সব MR-এর worker: Job card, নাম, Village, Bank, A/c No, Caste, eKYC, ABPS + Not ready sheet">📊 MR Excel</button>
      <button id="mrbp-csv">⬇ Log CSV</button>
      <button id="mrbp-clear">🗑 সব মুছো</button>
      <label title="হাতে Proceed চাপলে MR নতুন tab-এ খুলবে"><input type="checkbox" id="mrbp-newtab"> Proceed → নতুন tab</label>
    </div>
    <div class="bar"><i id="mrbp-bar"></i></div>
    <div class="log" id="mrbp-log"></div>
    <iframe id="mrbp-frame" class="hide"></iframe>
  </div>
  <footer class="brand"><span>✦ Crafted by <b>KOUSHIK</b></span><em>v${(chrome.runtime && chrome.runtime.getManifest && chrome.runtime.getManifest().version) || ""}</em></footer>`;
  document.body.appendChild(box);
  const $ = (id) => document.getElementById(id);
  // ---------- Minimize + Drag (অবস্থান মনে রাখে) ----------
  const hdr = box.querySelector('header');
  function setMin(m) {
    box.classList.toggle('min', m);
    $('mrbp-min').textContent = m ? '+' : '–';
    S.set('mr_min', m);
    clampBox();
  }
  $('mrbp-min').onclick = (e) => { e.stopPropagation(); setMin(!box.classList.contains('min')); };
  hdr.addEventListener('dblclick', () => setMin(!box.classList.contains('min')));

  function placeBox(x, y) {
    box.style.right = 'auto'; box.style.bottom = 'auto';
    box.style.left = x + 'px'; box.style.top = y + 'px';
  }
  function clampBox() {
    if (box.style.left === '' || box.style.left === 'auto') return;
    const r = box.getBoundingClientRect();
    const x = Math.min(Math.max(0, r.left), window.innerWidth - Math.min(r.width, window.innerWidth));
    const y = Math.min(Math.max(0, r.top), window.innerHeight - 30);
    placeBox(x, y);
  }
  hdr.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button')) return;
    e.preventDefault();
    const r = box.getBoundingClientRect();
    const dx = e.clientX - r.left, dy = e.clientY - r.top;
    hdr.setPointerCapture(e.pointerId);
    const move = (ev) => placeBox(ev.clientX - dx, ev.clientY - dy);
    const up = () => {
      hdr.removeEventListener('pointermove', move);
      hdr.removeEventListener('pointerup', up);
      clampBox();
      const b = box.getBoundingClientRect();
      S.set('mr_pos', { x: Math.round(b.left), y: Math.round(b.top) });
    };
    hdr.addEventListener('pointermove', move);
    hdr.addEventListener('pointerup', up);
  });
  window.addEventListener('resize', clampBox);
  const savedPos = S.get('mr_pos', null);
  if (savedPos) placeBox(savedPos.x, savedPos.y);
  setMin(S.get('mr_min', false));

  const logEl = $('mrbp-log');
  function log(msg) {
    const t = new Date().toLocaleTimeString();
    logEl.textContent += `[${t}] ${msg}\n`;
    logEl.scrollTop = logEl.scrollHeight;
  }
  function refreshStat() { const n = getIndex().length; $('mrbp-stat').textContent = `${n} MR জমা`; $('mrbp-mr').textContent = n; }

  function extractCodes(text) {
    const seen = new Set(), out = [];
    (String(text).match(CODE_RE) || []).forEach((c) => {
      c = c.toUpperCase();
      if (!seen.has(c)) { seen.add(c); out.push(c); }
    });
    return out;
  }
  const codesFromBox = () => extractCodes($('mrbp-codes').value);
  $('mrbp-codes').addEventListener('input', () => { $('mrbp-count').textContent = codesFromBox().length; S.set('mr_codes_text', $('mrbp-codes').value); });
  $('mrbp-codes').value = S.get('mr_codes_text', '');
  $('mrbp-count').textContent = codesFromBox().length;
  $('mrbp-delay').value = S.get('mr_delay2', 0);
  $('mrbp-mode').value = S.get('mr_mode', 'fast');
  $('mrbp-mode').onchange = () => S.set('mr_mode', $('mrbp-mode').value);
  $('mrbp-par').value = String(S.get('mr_par', 3));
  $('mrbp-par').onchange = () => S.set('mr_par', +$('mrbp-par').value);
  $('mrbp-delay').onchange = () => S.set('mr_delay2', +$('mrbp-delay').value);
  $('mrbp-show').onchange = () => $('mrbp-frame').classList.toggle('hide', !$('mrbp-show').checked);

  // ---------- নিজস্ব Excel reader (বাইরের library বা internet লাগে না) ----------
  // .xlsx = zip-এর ভিতরে XML; Chrome-এর DecompressionStream দিয়ে খুলে সব cell-এর লেখা Excel-এর ক্রমে বের করে
  async function inflateRaw(bytes) {
    const ds = new DecompressionStream('deflate-raw');
    const buf = await new Response(new Blob([bytes]).stream().pipeThrough(ds)).arrayBuffer();
    return new Uint8Array(buf);
  }
  async function unzip(buf) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf), files = {};
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) { if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; } }
    if (eocd < 0) throw new Error('zip নয়');
    const n = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const dec = new TextDecoder();
    for (let k = 0; k < n; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true);
      const nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true);
      const lho = dv.getUint32(p + 42, true);
      const name = dec.decode(u8.subarray(p + 46, p + 46 + nl));
      p += 46 + nl + el + cl;
      if (!/^xl\/(sharedStrings\.xml|worksheets\/[^/]+\.xml)$/i.test(name)) continue;
      const start = lho + 30 + dv.getUint16(lho + 26, true) + dv.getUint16(lho + 28, true);
      const data = u8.subarray(start, start + csize);
      files[name] = dec.decode(method === 8 ? await inflateRaw(data) : data);
    }
    return files;
  }
  async function readSheetText(file) {
    const buf = await file.arrayBuffer();
    const head = new Uint8Array(buf, 0, 4);
    if (head[0] === 0x50 && head[1] === 0x4b) {           // .xlsx
      const files = await unzip(buf);
      const xp = new DOMParser();
      const ss = files['xl/sharedStrings.xml']
        ? [...xp.parseFromString(files['xl/sharedStrings.xml'], 'application/xml').getElementsByTagName('si')].map((si) => si.textContent)
        : [];
      const sheets = Object.keys(files).filter((k) => /worksheets\//i.test(k))
        .sort((x, y) => (parseInt(x.match(/(\d+)\.xml$/)?.[1] || 0)) - (parseInt(y.match(/(\d+)\.xml$/)?.[1] || 0)));
      const out = [];
      sheets.forEach((k) => {
        const d = xp.parseFromString(files[k], 'application/xml');
        for (const c of d.getElementsByTagName('c')) {
          const t = c.getAttribute('t');
          const v = c.getElementsByTagName('v')[0];
          if (t === 's' && v) out.push(ss[+v.textContent] || '');
          else if (t === 'inlineStr') out.push(c.textContent);
          else if (v) out.push(v.textContent);
        }
      });
      return out.join('\n');
    }
    // .csv / .txt / পুরনো .xls — সরাসরি লেখা খুঁজে নেয়
    const u8 = new Uint8Array(buf);
    return new TextDecoder('latin1').decode(u8) + '\n' + new TextDecoder('utf-16le').decode(u8);
  }

  // Excel file -> সব sheet, সব cell থেকে Work Code (column আগে-পিছে হলেও চলবে)
  $('mrbp-file').onchange = async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    let text;
    try { text = await readSheetText(f); }
    catch (err) { return alert('Excel পড়া গেল না (' + err.message + ')। Work Code গুলো copy করে box-এ paste করো।'); }
    const codes = extractCodes(text);
    $('mrbp-codes').value = codes.join('\n');
    $('mrbp-codes').dispatchEvent(new Event('input'));
    log(`Excel "${f.name}" থেকে ${codes.length} টা Work Code পাওয়া গেছে`);
  };

  // ---------- হাতে Proceed চাপলে নতুন tab ----------
  $('mrbp-newtab').checked = S.get('mr_newtab', false);
  $('mrbp-newtab').onchange = () => S.set('mr_newtab', $('mrbp-newtab').checked);
  const btnProceed = document.getElementById('btnproceed');
  if (btnProceed) {
    btnProceed.addEventListener('click', () => {
      if (!$('mrbp-newtab').checked) return;
      const f = btnProceed.form;
      f.target = '_blank';
      setTimeout(() => { f.target = ''; }, 1500);
    }, true);
  }

  // ================= Safe engine: iframe driver (আগের পদ্ধতি) =================
  const frame = $('mrbp-frame');
  const fdoc = () => frame.contentDocument;
  const fwin = () => frame.contentWindow;
  let lastAlert = '';

  function waitLoad(action) {
    return new Promise((resolve, reject) => {
      const to = setTimeout(() => { frame.onload = null; reject(new Error('Timeout: page load হয়নি' + (lastAlert ? ` (alert: ${lastAlert})` : ''))); }, LOAD_TIMEOUT);
      frame.onload = () => {
        clearTimeout(to);
        frame.onload = null;
        try {
          fwin().alert = (m) => { lastAlert = String(m); };
          fwin().confirm = () => true;
          fwin().print = () => {};
        } catch (e) { /* ignore */ }
        resolve();
      };
      lastAlert = '';
      action();
    });
  }

  function checkSession() {
    const d = fdoc();
    if (!d || !/reprintmsr/i.test(fwin().location.pathname) || d.querySelector('input[type=password]')) {
      throw new Error('SESSION');
    }
  }

  const realOptions = (sel) => [...sel.options].filter((o) => o.value && !/^--/.test(o.text.trim()) && !/select/i.test(o.text));
  const findWorkOpt = (ws, code) => realOptions(ws).find((o) => o.text.toUpperCase().includes(code) || o.value.toUpperCase().includes(code));

  async function openFresh(skill) {
    await waitLoad(() => { frame.src = PAGE_URL + '?t=' + Date.now(); });
    checkSession();
    const d = fdoc();
    if (skill === 'S') {
      const r = d.getElementById('ssk_1');
      if (r && !r.checked) await waitLoad(() => r.click());
    } else {
      const r = d.getElementById('ssk_0');
      if (r && !r.checked) await waitLoad(() => {
        // __doPostBack-এর সমান কাজ, শুধু DOM দিয়ে (extension-এও চলে)
        const f = d.forms[0];
        r.checked = true;
        f.elements.__EVENTTARGET.value = 'ssk$0';
        f.elements.__EVENTARGUMENT.value = '';
        f.submit();
      });
    }
  }

  async function searchWorkSafe(code, skill) {
    await openFresh(skill);
    let d = fdoc();
    d.getElementById('txtWork').value = code;
    await waitLoad(() => d.getElementById('imgButtonSearch').click());
    checkSession();
    d = fdoc();
    const ws = d.getElementById('ddlworkcode');
    if (!ws) throw new Error('Work dropdown পাওয়া যায়নি');
    const opt = findWorkOpt(ws, code);
    if (!opt) return null;
    ws.value = opt.value;
    await waitLoad(() => ws.dispatchEvent(new Event('change')));
    checkSession();
    const ms = fdoc().getElementById('ddlmsrno');
    return ms ? realOptions(ms).map((o) => ({ text: o.text.trim(), value: o.value })) : [];
  }

  async function openMSRSafe(code, msr, skill) {
    const list = await searchWorkSafe(code, skill);
    if (!list) throw new Error('Work মেলেনি');
    const d = fdoc();
    d.getElementById('ddlmsrno').value = msr.value;
    await waitLoad(() => d.getElementById('btnproceed').click());
    const nd = fdoc();
    if (nd.getElementById('ddlmsrno') || !/Muster Roll/i.test(nd.body.textContent)) {
      throw new Error('MR page খোলেনি' + (lastAlert ? ` (alert: ${lastAlert})` : ''));
    }
    return { d: nd, url: fwin().location.href };
  }

  // iframe একটাই — Safe engine একসাথে একটাই কাজ করবে
  let safeChain = Promise.resolve();
  const withSafeLock = (fn) => { const r = safeChain.then(fn, fn); safeChain = r.catch(() => {}); return r; };

  // ================= Fast engine: fetch + DOMParser (page render হয় না, অনেক দ্রুত) =================
  const parser = new DOMParser();
  async function req(url, body) {
    const opt = body
      ? { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body }
      : { credentials: 'include', cache: 'no-store' };
    const ctl = new AbortController();
    const to = setTimeout(() => ctl.abort(), LOAD_TIMEOUT);
    let r;
    try { r = await fetch(url, { ...opt, signal: ctl.signal }); } finally { clearTimeout(to); }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const d = parser.parseFromString(await r.text(), 'text/html');
    if (/login/i.test(r.url) || d.querySelector('input[type=password]')) throw new Error('SESSION');
    return { d, url: r.url };
  }
  // ASP.NET form-এর সব field (ViewState সহ) নিয়ে postback body বানায়
  function formBody(st, over) {
    const f = st.d.forms[0];
    if (!f) throw new Error('form পাওয়া যায়নি');
    const p = new URLSearchParams();
    for (const e of f.elements) {
      if (!e.name || e.disabled) continue;
      const t = (e.type || '').toLowerCase();
      if (['submit', 'image', 'button', 'reset', 'file'].includes(t)) continue;
      if ((t === 'radio' || t === 'checkbox') && !e.checked) continue;
      if (e.tagName === 'SELECT') { const o = e.options[e.selectedIndex]; if (o) p.append(e.name, o.value); continue; }
      p.append(e.name, e.value);
    }
    for (const [k, v] of Object.entries(over)) p.set(k, v);
    return p.toString();
  }
  const postBack = (st, over) => {
    const act = new URL(st.d.forms[0].getAttribute('action') || st.url, st.url).href;
    return req(act, formBody(st, { __EVENTTARGET: '', __EVENTARGUMENT: '', ...over }));
  };

  async function searchWorkFast(code, skill) {
    let st = await req(PAGE_URL);
    const r0 = st.d.getElementById('ssk_0'), r1 = st.d.getElementById('ssk_1');
    if (skill === 'S' && r1 && !r1.checked) st = await postBack(st, { ssk: r1.value, __EVENTTARGET: 'ssk$1' });
    if (skill === 'U' && r0 && !r0.checked) st = await postBack(st, { ssk: r0.value, __EVENTTARGET: 'ssk$0' });
    st = await postBack(st, { txtWork: code, 'imgButtonSearch.x': '10', 'imgButtonSearch.y': '10' });
    const ws = st.d.getElementById('ddlworkcode');
    if (!ws) throw new Error('Work dropdown পাওয়া যায়নি');
    const opt = findWorkOpt(ws, code);
    if (!opt) return { msrs: null };
    st = await postBack(st, { ddlworkcode: opt.value, __EVENTTARGET: 'ddlworkcode' });
    const ms = st.d.getElementById('ddlmsrno');
    return { st, msrs: ms ? realOptions(ms).map((o) => ({ text: o.text.trim(), value: o.value })) : [] };
  }
  // একই ViewState থেকে প্রতিটা MSR-এর Proceed — বারবার search করতে হয় না
  async function openMSRFast(st, msr) {
    const btn = st.d.getElementById('btnproceed');
    const r = await postBack(st, { ddlmsrno: msr.value, [btn ? btn.name : 'btnproceed']: btn ? btn.value : 'Proceed' });
    if (r.d.getElementById('ddlmsrno') || !/Muster Roll/i.test(r.d.body ? r.d.body.textContent : '')) throw new Error('MR page খোলেনি');
    return r;
  }

  // MR page থেকে শুধু MR অংশটুকু (form, Home/Print link, script বাদ)
  function captureMR(src) {
    const d = src.d;
    const body = d.body.cloneNode(true);
    body.querySelectorAll('form, script, noscript, iframe, style, link, title, [id^="claude-"]').forEach((e) => e.remove());
    body.querySelectorAll('a').forEach((a) => {
      if (/^(home|print|signout|sign out|back)$/i.test(a.textContent.trim())) a.remove();
    });
    [...body.children].filter((e) => /^(P|CENTER)$/.test(e.tagName)).forEach((e) => {
      if (!e.textContent.trim() && !e.querySelector('img, table')) e.remove();
    });
    const trim = (pick) => { let n; while ((n = pick()) && (n.nodeName === 'BR' || (n.nodeType === 3 && !n.textContent.trim()))) n.remove(); };
    trim(() => body.lastChild);
    trim(() => body.firstChild);
    if (!S.get('mr_css2')) {
      const links = [...d.querySelectorAll('link[rel=stylesheet]')].map((l) => new URL(l.getAttribute('href'), src.url).href);
      const styles = [...d.querySelectorAll('style')].map((x) => x.textContent).join('\n');
      const bodyStyle = d.body.getAttribute('style') || '';
      S.set('mr_css2', { links, styles, bodyStyle });
    }
    return body.innerHTML;
  }

  function saveMR(key, code, msr, skill, ord, src) {
    S.set(key, captureMR(src));
    const idx = getIndex(); idx.push({ key, code, msr: msr.text, skill, ord }); setIndex(idx);
    addLog([code, msr.text, skill, 'OK', '']);
    refreshStat();
  }

  // ================= Main loop =================
  async function run() {
    const codes = codesFromBox();
    if (!codes.length) return alert('কোনো Work Code নেই');
    const skills = [];
    if ($('mrbp-us').checked) skills.push('U');
    if ($('mrbp-sk').checked) skills.push('S');
    if (!skills.length) return alert('Un-Skilled / Skilled কোনটা বাছো');

    running = true; stopFlag = false;
    $('mrbp-start').disabled = true; $('mrbp-stop').disabled = false;
    const delayMs = +$('mrbp-delay').value || 0;
    const delay = () => (delayMs ? sleep(delayMs) : Promise.resolve());
    const fast = $('mrbp-mode').value === 'fast';
    const par = fast ? Math.max(1, Math.min(5, +$('mrbp-par').value || 1)) : 1;
    const jobs = [];
    codes.forEach((c) => skills.forEach((s) => jobs.push([c, s])));
    const t0 = Date.now();
    $('mrbp-bar').style.width = '0%'; $('mrbp-pct').textContent = '0%';
    let done = 0, sessionLost = false;
    log(`শুরু: ${codes.length} Work Code — ${fast ? `Fast, একসাথে ${par}টা` : 'Safe mode'}`);

    async function safeMSR(code, msr, skill, ord, key) {
      await withSafeLock(async () => saveMR(key, code, msr, skill, ord, await openMSRSafe(code, msr, skill)));
    }

    async function processJob(i) {
      const [code, skill] = jobs[i];
      const tag = `[${i + 1}/${jobs.length}] ${code}${skill === 'S' ? ' (Skilled)' : ''}`;
      let res;
      try {
        res = fast ? await searchWorkFast(code, skill) : { msrs: await withSafeLock(() => searchWorkSafe(code, skill)) };
      } catch (e) {
        if (e.message === 'SESSION') throw e;
        if (!fast) { log(`${tag} → ERROR ${e.message}`); addLog([code, '', skill, 'ERROR', e.message]); return; }
        log(`${tag} → Fast-এ সমস্যা (${e.message}), Safe-এ চেষ্টা…`);
        try { res = { msrs: await withSafeLock(() => searchWorkSafe(code, skill)) }; }
        catch (e2) { if (e2.message === 'SESSION') throw e2; log(`${tag} → ERROR ${e2.message}`); addLog([code, '', skill, 'ERROR', e2.message]); return; }
      }
      if (res.msrs === null) { log(`${tag} → Work পাওয়া যায়নি`); addLog([code, '', skill, 'NOT FOUND', '']); return; }
      if (!res.msrs.length) { log(`${tag} → কোনো MSR নেই`); addLog([code, '', skill, 'NO MSR', '']); return; }
      log(`${tag} → MSR: ${res.msrs.map((m) => m.text).join(', ')}`);

      for (let k = 0; k < res.msrs.length && !stopFlag; k++) {
        const msr = res.msrs[k];
        const key = mrKey(code, msr.text, skill);
        const ord = i * 1000 + k;
        if (S.get(key)) { log(`   ${code} MSR ${msr.text}: আগেই আছে, skip`); continue; }
        await delay();
        try {
          if (res.st) {
            let mr;
            try { mr = await openMSRFast(res.st, msr); }
            catch (e) {
              if (e.message === 'SESSION') throw e;
              const again = await searchWorkFast(code, skill);   // ViewState নতুন করে নিয়ে আর একবার
              mr = await openMSRFast(again.st, msr);
            }
            saveMR(key, code, msr, skill, ord, mr);
          } else {
            await safeMSR(code, msr, skill, ord, key);
          }
          log(`   ${code} MSR ${msr.text}: OK`);
        } catch (e) {
          if (e.message === 'SESSION') throw e;
          try { await safeMSR(code, msr, skill, ord, key); log(`   ${code} MSR ${msr.text}: OK (Safe)`); }
          catch (e2) {
            if (e2.message === 'SESSION') throw e2;
            log(`   ${code} MSR ${msr.text}: ERROR ${e2.message}`); addLog([code, msr.text, skill, 'ERROR', e2.message]);
          }
        }
      }
    }

    let next = 0;
    async function worker() {
      while (!stopFlag) {
        const i = next++;
        if (i >= jobs.length) return;
        try { await processJob(i); }
        catch (e) {
          if (e.message === 'SESSION') {
            stopFlag = true;
            if (!sessionLost) {
              sessionLost = true;
              log('⚠ Session শেষ / login চাইছে। আবার login করে Start চাপো — যা হয়েছে সেগুলো skip হবে।');
              alert('Session শেষ। আবার login করে এই page-এ এসে Start চাপো।');
            }
            return;
          }
          log(`[${i + 1}] ERROR ${e.message}`);
        }
        done++;
        const pct = Math.round((done / jobs.length) * 100);
        $('mrbp-bar').style.width = pct + '%';
        $('mrbp-pct').textContent = pct + '%';
        $('mrbp-mr').textContent = getIndex().length;
        $('mrbp-stat').textContent = `${getIndex().length} MR · ${done}/${jobs.length}`;
      }
    }
    await Promise.all(Array.from({ length: par }, worker));

    const secs = Math.round((Date.now() - t0) / 1000);
    log(stopFlag ? `থামানো হয়েছে (${secs} সেকেন্ড)।` : `শেষ! ${secs} সেকেন্ডে। মোট ${getIndex().length} MR জমা। এবার "Print All" চাপো।`);
    running = false;
    $('mrbp-start').disabled = false; $('mrbp-stop').disabled = true;
  }

  // ================= Print All =================
  // Portal-এর page যেমন দেখায় ঠিক তেমনই print — শুধু: সাদা background, A4 landscape, আর Scale (Auto/100/90/80/70)
  function printAll() {
    const idx = getIndex();
    if (!idx.length) return alert('কোনো MR জমা নেই');
    const cssData = S.get('mr_css2', { links: [], styles: '', bodyStyle: '' });
    const scale = S.get('mr_scale', 'auto');
    const PRINT_CSS = `
      @page { size: A4 landscape; margin: 6mm; }
      .mr { break-after: page; page-break-after: always; }
      .mr:last-of-type { break-after: auto; page-break-after: auto; }
      .tb { position: sticky; top: 0; background: linear-gradient(135deg,#0b1437,#3730a3); color: #fff; padding: 8px 12px; font: 14px Segoe UI, Arial; z-index: 9; }
      .tb button, .tb select { font-size: 14px; padding: 3px 10px; margin-left: 8px; cursor: pointer; }
      @media screen { body { background: #888 !important; } .mr { background: #fff; margin: 12px auto; width: ${PRINT_WIDTH_PX}px; overflow: hidden; } }
      @media print {
        .tb { display: none !important; }
        html, body, .mr { background: #fff !important; }
        * { background-color: transparent !important; background-image: none !important; box-shadow: none !important; }
      }`;
    // Excel-এর ক্রমে সাজানো (একসাথে কয়েকটা চললেও print-এ ক্রম ঠিক থাকবে)
    idx.forEach((it, n) => { if (it.ord == null) it.ord = -1e9 + n; });
    idx.sort((x, y) => x.ord - y.ord);
    const sections = idx.map((it) => `<section class="mr">${S.get(it.key, '')}</section>`).join('\n');
    const opts = ['auto', '100', '90', '80', '70', '60'].map((v) =>
      `<option value="${v}" ${v === String(scale) ? 'selected' : ''}>${v === 'auto' ? 'Auto (page-এ ফিট)' : v + '%'}</option>`).join('');
    // Portal-এর MR page-এ DOCTYPE নেই (quirks mode) — হুবহু একই দেখাতে এখানেও নেই
    const html = `<html><head><meta charset="utf-8">
      <title>MR Print - ${idx.length} MR</title><base href="${location.origin}/vbgramg/">
      ${cssData.links.map((h) => `<link rel="stylesheet" href="${h}">`).join('')}
      <style>${cssData.styles}</style><style>${PRINT_CSS}</style></head>
      <body style="${cssData.bodyStyle}">
      <div class="tb"><b style="color:#f5b942">K</b> MR Batch Print <small style="opacity:.75">by Koushik</small> &nbsp;|&nbsp; মোট ${idx.length} MR &nbsp;|&nbsp; Scale: <select id="sc">${opts}</select>
        <button onclick="window.print()">🖨 Print / Save PDF</button>
        <span style="font-size:12px;margin-left:10px">Print dialog-এ: Scale = Default, Background graphics = বন্ধ</span></div>
      ${sections}
      <script>
        var W = ${PRINT_WIDTH_PX};
        function applyScale(v) {
          document.querySelectorAll('section.mr').forEach(function (s) {
            s.style.zoom = 1;
            var z = 1;
            if (v === 'auto') {
              var w = s.scrollWidth;
              s.querySelectorAll('table').forEach(function (t) { w = Math.max(w, t.scrollWidth); });
              z = Math.min(1, W / Math.max(w, 1));
            } else { z = (+v) / 100; }
            s.style.zoom = z.toFixed(3);
          });
        }
        var sc = document.getElementById('sc');
        sc.addEventListener('change', function () { applyScale(sc.value); });
        window.addEventListener('load', function () { setTimeout(function () { applyScale(sc.value); }, 200); });
      <\/script></body></html>`;
    const w = window.open('', '_blank');
    if (!w) return alert('Popup block হয়েছে — এই site-এর জন্য popup allow করো');
    w.document.open(); w.document.write(html); w.document.close();
    // বাছাই করা scale পরের বার মনে থাকবে (DOM event — userscript ও extension দুটোতেই চলে)
    w.document.getElementById('sc').addEventListener('change', (ev) => S.set('mr_scale', ev.target.value));
  }

  // ================= MR Excel (সব worker + eKYC/ABPS) =================
  // জমা থাকা প্রতিটা MR-এর worker table পড়ে: Job card, নাম, Village, Bank/Account (আলাদা করে), Caste, eKYC, ABPS।
  // Portal-এর account cell = "Bank Indian Bank 50434375667" / "Post Office … 1234…" — bank আর নম্বর আলাদা column-এ।
  const JC_RE = /^[A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+$/;
  const nrm = (t) => String(t || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim();
  function acctParts(t) {
    // portal-এ cell-এর ভিতরের অংশ জোড়া লেগে আসে: "BankIndian Bank59033650828" — তাই space ছাড়াও ভাঙে
    const m = /^(?:Bank|Post\s*Office|PO)\s*(.*?)\s*([0-9*Xx]{4,})$/i.exec(nrm(t));
    return m ? { bank: m[1], no: m[2] } : { bank: '', no: t || '' };
  }
  function mrWorkers(d) {
    const sig = [...d.querySelectorAll('td,th')].find((c) => !c.querySelector('table') && /Signature\s*\/?\s*Thumb/i.test(c.textContent));
    if (!sig) return [];
    const t = sig.closest('table'), rows = [...t.rows].filter((r) => r.closest('table') === t);
    const isData = (r) => r.cells.length >= 6 && /^\d+$/.test(nrm(r.cells[0].textContent)) && !/^\d*$/.test(nrm(r.cells[1].textContent));
    const first = rows.findIndex(isData); if (first < 0) return [];
    const heads = [], taken = [];
    rows.slice(0, first).forEach((r, ri) => {
      let pos = 0;
      [...r.cells].forEach((c) => {
        while (taken[ri] && taken[ri][pos]) pos++;
        const txt = nrm(c.textContent), cs = c.colSpan || 1, rs = c.rowSpan || 1;
        for (let k = 0; k < cs; k++) {
          for (let q = 0; q < rs; q++) (taken[ri + q] = taken[ri + q] || [])[pos + k] = 1;
          if (txt && !/^\d+$/.test(txt)) heads[pos + k] = heads[pos + k] && ri && cs === 1 ? txt : (heads[pos + k] || txt);
          if (ri && txt && !/^\d+$/.test(txt) && cs === 1) heads[pos + k] = txt;   // sub-heading (Caste…) জেতে
        }
        pos += cs;
      });
    });
    const col = (re) => { for (let i = 0; i < heads.length; i++) if (re.test(heads[i] || '')) return i; return -1; };
    const at = (r, i) => { if (i < 0) return ''; let pos = 0; for (const c of r.cells) { const cs = c.colSpan || 1; if (i >= pos && i < pos + cs) return nrm(c.textContent); pos += cs; } return ''; };
    const cReg = col(/Name\s*\/\s*Reg|Reg\.?\s*No|Job\s*Card/i), cApp = col(/Name of Applicant/i), cSk = col(/Name of Un\s*skilled|Skilled labour/i);
    const cHead = col(/Head of Household|Father|Husband/i), cVil = col(/^Village/i), cAc = col(/^Account|Bank/i), cCaste = col(/^Caste$|^Category$|Caste/i);
    return rows.slice(first).filter(isData).map((r) => {
      let reg = at(r, cReg), name = at(r, cApp);
      if (!JC_RE.test(reg)) { const c = [...r.cells].map((x) => nrm(x.textContent)).find((x) => JC_RE.test(x)); if (c) reg = c; }
      if (cSk >= 0 && !reg) { const m = /^(.*?)\s*\(([^)]+)\)\s*$/.exec(at(r, cSk)); name = m ? m[1] : at(r, cSk); reg = m ? m[2] : ''; }
      let acct = at(r, cAc);
      if (!/\d{4,}/.test(acct)) { const c = [...r.cells].map((x) => nrm(x.textContent)).find((x) => /^(Bank|Post\s*Office|PO)\s*\D.*\d{4,}$/i.test(x)); if (c) acct = c; }
      return { sno: at(r, 0), reg, name, head: at(r, cHead), village: at(r, cVil), acct, caste: at(r, cCaste) };
    });
  }
  function mrDates(d) {
    const t = nrm(d.body ? d.body.textContent : d.textContent), D = '(\\d{1,2}[\\/\\-.]\\d{1,2}[\\/\\-.]\\d{4})';
    const f = new RegExp('From\\s*(?:Date)?\\s*:?-?\\s*' + D, 'i').exec(t), to = new RegExp('To\\s*(?:Date)?\\s*:?-?\\s*' + D, 'i').exec(t);
    return { from: f ? f[1] : '', to: to ? to[1] : '' };
  }
  async function exportExcel() {
    const idx = getIndex();
    if (!idx.length) return alert('কোনো MR জমা নেই — আগে Start দিয়ে MR জমা করো');
    if (!window.XLSX) return alert('Excel library load হয়নি — page reload করো');
    const abps = await new Promise((res) => { try { window.DX && DX.abpsLoad ? DX.abpsLoad((m) => res(m || {})) : res({}); } catch (e) { res({}); } });
    const casteMap = await new Promise((res) => { try { chrome.storage.local.get('kh_caste_map_v2', (d) => res((d && d.kh_caste_map_v2) || {})); } catch (e) { res({}); } });
    const hasAbps = Object.keys(abps).length > 0;
    idx.forEach((it, n) => { if (it.ord == null) it.ord = -1e9 + n; });
    idx.sort((x, y) => x.ord - y.ord);
    const people = []; let noTable = 0;
    idx.forEach((it) => {
      const d = new DOMParser().parseFromString(`<html><body>${S.get(it.key, '')}</body></html>`, 'text/html');
      const ws = mrWorkers(d), dt = mrDates(d);
      if (!ws.length) { noTable++; return; }
      ws.forEach((w) => {
        const jc = JC_RE.test(w.reg);
        const a = jc && hasAbps && window.DX && DX.abpsFind ? DX.abpsFind(abps, w.reg, w.name) : null;
        let caste = w.caste;
        if (!caste && jc && window.DX && DX.normKey) caste = casteMap[DX.normKey(w.reg.split('/')[0], 'id')] || casteMap[DX.normKey(w.reg, 'id')] || '';
        const ac = acctParts(w.acct);
        const ekyc = hasAbps ? (a ? (a.ekyc ? 'Yes' : 'No') : 'Not found') : '';
        const ab = hasAbps ? (a ? (a.abps ? 'Yes' : 'No') : 'Not found') : '';
        const why = [];
        if (!/\d{6,}/.test(ac.no.replace(/\s+/g, ''))) why.push('Account নেই');
        if (hasAbps && jc && !(a && a.ekyc)) why.push('eKYC নেই');
        if (hasAbps && jc && !(a && a.abps)) why.push('ABPS নেই');
        people.push([it.skill === 'S' ? 'Skilled' : 'Un-Skilled', it.code, it.msr, dt.from, dt.to, w.sno, w.reg, w.name, w.head, w.village,
          ac.bank, ac.no, caste, ekyc, ab, why.join(', ')]);
      });
    });
    if (!people.length) return alert('জমা MR-এ কোনো worker row পাওয়া গেল না' + (noTable ? ` (${noTable} MR-এ table নেই)` : ''));
    const COLS = ['Category', 'Work Code', 'MR No', 'Date From', 'Date To', 'S.No', 'Job Card / Reg No', 'Name of Applicant', 'Head of Household / Father-Husband',
      'Village', 'Bank / Post Office', 'Account No', 'Caste', 'eKYC', 'ABPS', 'Not ready কেন'];
    const sheet = (list) => { const w = XLSX.utils.aoa_to_sheet([COLS, ...list]); w['!cols'] = [10, 30, 8, 11, 11, 5, 24, 24, 24, 16, 24, 18, 8, 8, 8, 22].map((n) => ({ wch: n })); return w; };
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet(people), 'All workers');
    XLSX.utils.book_append_sheet(wb, sheet(people.filter((x) => x[15])), 'Not ready');
    const p2 = (n) => String(n).padStart(2, '0'), nw = new Date();
    const gp = (String(idx[0].code || '').match(/^\d{10}/) || ['MR'])[0];
    const name = `MusterRolls-${gp}-${nw.getFullYear()}${p2(nw.getMonth() + 1)}${p2(nw.getDate())}-${p2(nw.getHours())}${p2(nw.getMinutes())}.xlsx`;
    XLSX.writeFile(wb, name);
    const nr = people.filter((x) => x[15]).length;
    log(`Excel: ${idx.length - noTable} MR, ${people.length} worker, ${nr} not ready → ${name}` + (hasAbps ? '' : ' (ABPS data নেই — eKYC/ABPS খালি; আগে ABPS Sync করো)'));
  }

  // ================= Buttons =================
  $('mrbp-xl').onclick = () => { exportExcel().catch((e) => alert('Excel error: ' + e.message)); };
  $('mrbp-start').onclick = () => { if (!running) run(); };
  $('mrbp-stop').onclick = () => { stopFlag = true; log('থামানো হচ্ছে… (চলতি MR শেষ হলে থামবে)'); };
  $('mrbp-print').onclick = printAll;
  $('mrbp-clear').onclick = () => {
    if (!confirm(`জমা থাকা ${getIndex().length} MR আর log মুছে ফেলবে? (Print করা হয়ে গেলে তবেই মোছো)`)) return;
    getIndex().forEach((it) => S.del(it.key));
    ['mr_index', 'mr_log', 'mr_css', 'mr_css2'].forEach(S.del);
    logEl.textContent = ''; refreshStat(); log('সব মুছে ফেলা হয়েছে');
  };
  $('mrbp-csv').onclick = () => {
    const rows = [['Work Code', 'MSR No', 'Type', 'Status', 'Note'], ...getLog()];
    const csv = '﻿' + rows.map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const a = Object.assign(document.createElement('a'), {
      href: URL.createObjectURL(new Blob([csv], { type: 'text/csv' })),
      download: `MR_log_${new Date().toISOString().slice(0, 10)}.csv`,
    });
    a.click();
  };

  refreshStat();
  log(`Ready. জমা আছে ${getIndex().length} MR।`);
})();
});
