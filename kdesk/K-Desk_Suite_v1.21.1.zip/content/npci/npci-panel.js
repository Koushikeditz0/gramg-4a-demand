/* =====================================================================
   npci-panel.js — K-Desk Suite by Koushik · ABPS Enable (NPCI)  (UI)
   Isolated-world panel on …/vbgramg/UID/VUID_NPCI.aspx. Starts / stops the
   run driven by npci-driver.js (MAIN world) and offers the downloadable log
   of every row: Saved, Not enabled (with the portal's own message), Error.
   The run lives in the portal-origin localStorage "khnp_run"; the latest
   run's results are mirrored to chrome.storage.local so the log survives
   anything that clears the page's storage. No Aadhaar number is ever read.
   ===================================================================== */
KH_FEATURE("npci", function () {
(function () {
  "use strict";
  if (window.__KHNP_UI) return; window.__KHNP_UI = true;

  var LS_RUN = "khnp_run", MIN_KEY = "khnp_min", MIRROR = "khnpLastRun", HOST_ID = "khnp-host";
  var PFX = "ctl00_ContentPlaceHolder1_";
  var sel = {}, confirming = false;

  function $(id) { return document.getElementById(id); }
  function loadRun() { try { return JSON.parse(localStorage.getItem(LS_RUN) || "null"); } catch (e) { return null; } }
  function saveRun(r) { try { r.updatedAt = Date.now(); localStorage.setItem(LS_RUN, JSON.stringify(r)); } catch (e) {} }
  function post(type) { try { window.postMessage({ source: "KHNP_UI", type: type }, "*"); } catch (e) {} }
  function minSaved() { try { return localStorage.getItem(MIN_KEY) === "1"; } catch (e) { return false; } }
  function minSave(on) { try { localStorage.setItem(MIN_KEY, on ? "1" : "0"); } catch (e) {} }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function fmtTime(t) { if (!t) return ""; var d = new Date(t); return isNaN(d) ? "" : pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()); }
  function fmtStamp(t) { if (!t) return ""; var d = new Date(t); return isNaN(d) ? "" : pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + " " + fmtTime(t); }
  function status(msg, kind) { if (!sel.st) return; sel.st.textContent = msg || ""; sel.st.className = "st" + (kind ? " " + kind : ""); }

  /* ---------------------- villages: from the open one onward ---------------------- */
  function villagesFromOpen() {
    var s = $(PFX + "DDL_Village"); if (!s) return [];
    var out = [], start = Math.max(0, s.selectedIndex);
    for (var i = 0; i < s.options.length; i++) {
      var o = s.options[i]; if (!o.value || o.value === "00" || o.value === "0") continue;
      if (i < start) continue;
      out.push({ value: o.value, text: (o.text || "").trim() });
    }
    return out;
  }

  /* ---------------------- actions ---------------------- */
  function askStart(resume) {
    var r = loadRun();
    if (resume && r && !r.finishedAt) {
      r.active = true; r.stopRequested = false; r.consec = 0;
      // rows that only failed because the portal didn't answer get another try
      var errs = (r.results || []).filter(function (x) { return x.result === "Error" && x.key; });
      if (errs.length) {
        errs.forEach(function (x) { if (r.done) delete r.done[x.key]; });
        r.results = r.results.filter(function (x) { return !(x.result === "Error" && x.key); });
        if (r.stats) { r.stats.errors = Math.max(0, (r.stats.errors || 0) - errs.length); r.stats.checked = Math.max(0, (r.stats.checked || 0) - errs.length); }
      }
      (r.log = r.log || []).push({ t: Date.now(), level: "info", text: "Resumed." + (errs.length ? " Retrying " + errs.length + " row(s) that had no answer from the portal." : "") });
      saveRun(r); post("start"); render(); return;
    }
    var v = villagesFromOpen();
    if (!v.length) { status("Pick a village on the page first.", "warn"); return; }
    confirming = true;
    sel.cfmtxt.innerHTML = "This will, for every worker from <b>" + esc(v[0].text) + "</b> to <b>" + esc(v[v.length - 1].text) + "</b> (" + v.length +
      " village" + (v.length === 1 ? "" : "s") + "): click <b>Show Aadhaar Number</b> and <b>Check with NPCI</b>, then <b>Save Records of this page</b> " +
      "whenever a page has green rows — which <b>enables those workers for DBT</b> on the portal. Rows that don't turn green go to the log.";
    render();
  }
  function doStart() {
    var v = villagesFromOpen(); if (!v.length) return;
    var dry = false; try { dry = localStorage.getItem("khnp_dry") === "1"; } catch (e) {}
    var r = { v: 1, runId: "np-" + Date.now(), active: true, stopRequested: false, startedAt: Date.now(), villages: v, vi: 0, page: 1, toFirstPage: true,
      done: {}, pendingOk: [], results: [], stats: { checked: 0, saved: 0, failed: 0, errors: 0 }, consec: 0, dryRun: dry,
      log: [{ t: Date.now(), level: "info", text: "Run started from " + v[0].text + " (" + v.length + " village(s))" + (dry ? " — DRY RUN, nothing will be saved" : "") + "." }] };
    confirming = false; saveRun(r); post("start"); render();
  }
  function doStop() { var r = loadRun(); if (!r) return; r.stopRequested = true; saveRun(r); post("stop"); status("Stopping after the current row…", "warn"); render(); }
  function doNew() {
    var r = loadRun();
    if (r && r.active) { status("Stop the run first.", "warn"); return; }
    try { localStorage.removeItem(LS_RUN); } catch (e) {}
    confirming = false; status("Cleared. Pick the village to start from, then press Start.", "ok"); render();
  }

  /* ---------------------- log download (Excel) ---------------------- */
  function results(cb) {
    var r = loadRun();
    if (r && r.results && r.results.length) return cb(r.results, r);
    try { chrome.storage.local.get(MIRROR, function (d) { var m = d && d[MIRROR]; cb((m && m.results) || [], m || null); }); } catch (e) { cb([], null); }
  }
  function download(failedOnly) {
    results(function (rows, run) {
      // "not enabled only" = rows that did NOT get enabled: NPCI said no, the portal errored, or Save failed
      if (failedOnly) rows = rows.filter(function (x) { return x.result === "Not enabled" || x.result === "Error" || x.result === "Save failed"; });
      if (!rows.length) { status(failedOnly ? "No failed rows in the log." : "The log is empty.", "warn"); return; }
      if (!window.XLSX) { status("The spreadsheet library isn't loaded — reload the page.", "warn"); return; }
      var aoa = [["Village", "Job Card No", "App No", "Applicant Name", "Name as per Aadhaar", "Page", "Result", "Portal message", "Time"]];
      rows.forEach(function (x) { aoa.push([x.village, x.job, x.app, x.name, x.nameAadhaar, x.page, x.result, x.msg, fmtStamp(x.t)]); });
      var ws = XLSX.utils.aoa_to_sheet(aoa), wb = XLSX.utils.book_new();
      ws["!cols"] = [{ wch: 18 }, { wch: 24 }, { wch: 7 }, { wch: 24 }, { wch: 24 }, { wch: 6 }, { wch: 14 }, { wch: 60 }, { wch: 20 }];
      XLSX.utils.book_append_sheet(wb, ws, failedOnly ? "Not enabled" : "NPCI ABPS log");
      var d = new Date(), name = "NPCI-ABPS-" + (failedOnly ? "failed" : "log") + "-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
      XLSX.writeFile(wb, name);
      status("Saved " + name + " — " + rows.length + " row(s).", "ok");
    });
  }
  var lastMirror = 0;
  function mirror(r) {
    if (!r || !r.results || Date.now() - lastMirror < 3000) return; lastMirror = Date.now();
    try { var o = {}; o[MIRROR] = { runId: r.runId, startedAt: r.startedAt, results: r.results }; chrome.storage.local.set(o); } catch (e) {}
  }

  /* ---------------------- render ---------------------- */
  function render() {
    if (!sel.sum) return;
    var r = loadRun(), active = !!(r && r.active), s = (r && r.stats) || {};
    sel.cfm.hidden = !confirming || active;
    if (!r) {
      var v = villagesFromOpen();
      sel.sum.innerHTML = v.length ? "Ready. Starts from the open village <b>" + esc(v[0].text) + "</b> — " + v.length + " village" + (v.length === 1 ? "" : "s") + " to go." : "Pick a village on the page to start from.";
      sel.prog.hidden = true;
    } else {
      var N = (r.villages || []).length, i = Math.min(r.vi, N - 1), vt = (r.villages[i] || {}).text || "";
      sel.sum.innerHTML = (r.finishedAt ? "✓ Finished · " : active ? "Running · " : "Paused · ") + "village <b>" + Math.min(r.vi + 1, N) + "/" + N + "</b> " + esc(vt) + " · page " + (r.page || 1) +
        "<br>Checked <b>" + (s.checked || 0) + "</b> · enabled <b>" + (s.saved || 0) + "</b> · not enabled <b>" + (s.failed || 0) + "</b> · errors <b>" + (s.errors || 0) + "</b>" +
        (r.dryRun ? " · <b>DRY RUN</b>" : "") + (active ? "<br><span class='cur'>Now: " + esc(r.current || "working…") + "</span>" : "");
      sel.prog.hidden = false;
      var pct = N ? Math.round(100 * (r.finishedAt ? N : r.vi) / N) : 0;
      sel.fill.style.width = pct + "%"; sel.ptxt.textContent = (r.finishedAt ? N : r.vi) + " of " + N + " village(s) done";
    }
    sel.start.textContent = r && !r.finishedAt && !active ? "▶ Resume" : "▶ Start";
    sel.start.disabled = active || confirming;
    sel.stop.disabled = !active;
    sel.newr.disabled = active || !r;
    var has = !!(r && r.results && r.results.length);
    sel.dl.disabled = !has; sel.dlf.disabled = !has;
    // activity, newest first
    var L = (r && r.log) || [], h = "";
    for (var k = L.length - 1, n = 0; k >= 0 && n < 300; k--, n++) h += "<div class='l-" + esc(L[k].level || "info") + "'><span class='lt'>" + esc(fmtTime(L[k].t)) + "</span>" + esc(L[k].text) + "</div>";
    sel.logbox.innerHTML = h || "<div class='l-info'>No activity yet.</div>";
    mirror(r);
  }

  /* ---------------------- panel ---------------------- */
  var HTML =
    "<div class='hd' id='np_hd'><span class='hdl'><span class='logo'>K</span><span class='ttl'><b>ABPS Enable (NPCI)</b><small><i>K-Desk</i> Suite · ABPS / eKYC</small></span></span><button class='mn' id='np_min'>–</button></div>" +
    "<div class='bd' id='np_bd'>" +
    "<div class='summary' id='np_sum'></div>" +
    "<div class='prog' id='np_prog' hidden><div class='progbar'><div class='progfill' id='np_fill'></div></div><div class='progtxt' id='np_ptxt'></div></div>" +
    "<div class='cfm' id='np_cfm' hidden><div class='cfmh'>⚠ এটা portal-এ record Save করবে</div><div id='np_cfmtxt'></div>" +
      "<div class='btnrow'><button class='btn fill' id='np_yes'>হ্যাঁ, শুরু করুন</button><button class='btn ghost' id='np_no'>বাতিল</button></div></div>" +
    "<div class='btnrow'><button class='btn fill' id='np_start'>▶ Start</button><button class='btn stop' id='np_stop'>■ Stop</button></div>" +
    "<div class='btnrow'><button class='btn ghost' id='np_dl'>⭳ Download log</button><button class='btn ghost' id='np_dlf'>⭳ শুধু Not enabled</button></div>" +
    "<div class='btnrow'><button class='btn ghost danger' id='np_new'>↺ New run (clear)</button></div>" +
    "<div class='st' id='np_st'></div>" +
    "<div class='sec'>Activity log</div><div class='logbox' id='np_logbox'></div>" +
    "<div class='hint'>Page-এ যে village খোলা আছে সেখান থেকে শুরু হয়। প্রতিটি row-তে <b>Show Aadhaar Number</b> → <b>Check with NPCI</b>। কোনো page-এ সবুজ row থাকলে Save হয়; লাল থেকে গেলে portal-এর কারণসহ log-এ যায়। Aadhaar নম্বর কোথাও জমা বা log হয় না।</div>" +
    "<div class='disclaimer'>⚠ এটা portal-এ আসল Save করে। প্রথমে একটা ছোট village দিয়ে চালিয়ে portal-এ ফল মিলিয়ে নিন।</div>" +
    "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>v<span id='np_ver'></span></em></div>" +
    "</div>";

  var STYLE =
    ".panel{width:360px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:13px;color:#0f172a;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 10px 30px rgba(11,20,55,.3);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:8px 10px;display:flex;align-items:center;justify-content:space-between}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hd b{font-size:12.5px;font-weight:700}.hdl{display:flex;align-items:center;gap:8px;min-width:0}" +
    ".logo{width:24px;height:24px;border-radius:7px;flex:0 0 auto;display:grid;place-items:center;font:800 14px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:22px;height:22px;border-radius:5px;font-size:15px;line-height:1;flex:0 0 auto}" +
    ".bd{padding:10px;max-height:80vh;overflow:auto}" +
    ".btn{padding:8px 9px;border:none;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit}" +
    ".btnrow{display:flex;gap:6px;margin-top:6px}.btnrow .btn{flex:1}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.fill:hover{filter:brightness(1.05)}.btn.fill:disabled{background:#f3e3bd;color:#8a7a55;cursor:not-allowed}" +
    ".btn.stop{background:#c5221f;color:#fff}.btn.stop:disabled{background:#e6a6a4;cursor:not-allowed}" +
    ".btn.ghost{background:#f2f4f8;color:#334;border:1px solid #d7dce6}.btn.ghost:disabled{color:#aab;cursor:not-allowed}" +
    ".btn.ghost.danger{background:#fdecea;color:#c5221f;border-color:#f3b4b0}.btn.ghost.danger:disabled{background:#f2f4f8;color:#c9a9a8;border-color:#e6d3d2}" +
    ".summary{font-size:11.5px;color:#1e1b6b;background:#eef2ff;border-radius:7px;padding:6px 8px;margin:0 0 8px;line-height:1.45}" +
    ".summary .cur{color:#5b6472;display:inline-block;min-height:1.45em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;vertical-align:top}" +
    ".prog{margin:8px 0}.progbar{height:8px;background:#e6e9f0;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#e08e0b;transition:width .3s}" +
    ".progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".cfm{margin:8px 0;padding:8px;border:1px solid #f2d98a;background:#fef7e0;border-radius:7px;font-size:11.5px;color:#5a4300;line-height:1.4}" +
    ".cfmh{font-weight:700;color:#9a6700;margin-bottom:4px}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:6px;background:#f2f4f8;min-height:15px;line-height:1.35}" +
    ".st.ok{background:#e7f4ec;color:#137333}.st.warn{background:#fef7e0;color:#9a6700}" +
    ".sec{font-weight:700;color:#1e1b6b;margin:10px 0 6px;border-top:1px solid #e6e9f0;padding-top:8px;font-size:12px}" +
    ".logbox{max-height:170px;overflow:auto;font-size:10.5px;line-height:1.4;background:#0b1437;color:#cbd5e1;border-radius:8px;padding:6px 8px}" +
    ".logbox div{padding:1px 0;border-bottom:1px dotted #1e2a5a}" +
    ".l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#cbd5e1}" +
    ".logbox .lt{display:inline-block;color:#aab2c0;font-variant-numeric:tabular-nums;margin-right:6px}" +
    ".hint{margin-top:8px;font-size:10.5px;color:#5b6472;line-height:1.35}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#8a92a0;line-height:1.35;background:#fbfbfd;border:1px solid #eef0f4;border-radius:6px;padding:5px 7px}" +
    ".foot{margin-top:8px;padding-top:6px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;font-size:10.5px;color:#64748b}.foot b{color:#0b1437}.foot em{font-style:normal;color:#e08e0b}" +
    "[hidden]{display:none!important}";

  // অন্য extension-এর নিজের NPCI panel চালু থাকলে লুকিয়ে রাখা (একসাথে দুটো run যেন না চলে)
  try { var hs = document.createElement("style"); hs.textContent = "#dxnp-host{display:none!important}"; (document.head || document.documentElement).appendChild(hs); } catch (e) {}
  function build() {
    try { var old = document.getElementById(HOST_ID); if (old) old.remove(); } catch (e) {}
    var host = document.createElement("div"); host.id = HOST_ID;
    host.style.cssText = "position:fixed;top:70px;right:16px;z-index:2147483647;";
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE; root.appendChild(css); if (window.KD_applySkin) KD_applySkin(root);
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML;
    if (minSaved()) { box.querySelector("#np_bd").style.display = "none"; box.querySelector("#np_min").textContent = "+"; }
    root.appendChild(box);
    ["hd", "min", "bd", "ver", "sum", "prog", "fill", "ptxt", "cfm", "cfmtxt", "yes", "no", "start", "stop", "dl", "dlf", "new", "st", "logbox"]
      .forEach(function (id) { sel[id === "new" ? "newr" : id] = root.getElementById("np_" + id); });
    try { sel.ver.textContent = chrome.runtime.getManifest().version; } catch (e) {}
    sel.start.addEventListener("click", function () { var r = loadRun(); askStart(!!(r && !r.finishedAt)); });
    sel.yes.addEventListener("click", doStart);
    sel.no.addEventListener("click", function () { confirming = false; render(); });
    sel.stop.addEventListener("click", doStop);
    sel.newr.addEventListener("click", doNew);
    sel.dl.addEventListener("click", function () { download(false); });
    sel.dlf.addEventListener("click", function () { download(true); });
    sel.min.addEventListener("click", function () {
      var hide = sel.bd.style.display !== "none"; sel.bd.style.display = hide ? "none" : "block"; sel.min.textContent = hide ? "+" : "–"; minSave(hide);
    });
    // drag by the header
    var sx, sy, ox, oy, drag = false; sel.hd.style.cursor = "move";
    sel.hd.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
    document.addEventListener("mouseup", function () { drag = false; });
    render();
  }

  window.addEventListener("message", function (ev) { if (ev.data && ev.data.source === "KHNP_DRV" && ev.data.type === "sync") render(); });
  setInterval(render, 1500);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", build); else build();
})();
});
