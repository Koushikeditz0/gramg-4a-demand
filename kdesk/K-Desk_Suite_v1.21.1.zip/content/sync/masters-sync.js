/* =====================================================================
   K-Desk Suite by Koushik — Mate + Work sync → Gram Setu
   • …/vbgramg/matemapping.aspx  : mate dropdown "S-WB-08-005-014-011/1259172#NAME"
       → Gram Setu Supervisor list (Name + whole ID S-WB-08-005-014-011/1259172;
         the part before "/" is shared by several mates of one village)
   • …/citizen_html/Est_Expwork.aspx : "Work name (3208005014/DP/VB/…)", status, year
       → Gram Setu Works list (Name + Work Code)
   Reads the page only (nothing on the portal is pressed) and sends with the
   GP's K-Desk login through RPC kdesk_save_masters (SQL v188).
   ===================================================================== */
KH_FEATURE("msync", function () {
(function () {
  "use strict";
  if (window.__KDMSYNC) return;
  window.__KDMSYNC = true;

  var BAR_ID = "kdms-bar";
  var CODE_RE = /\(?\s*(\d{8,12}\/[A-Z]{2,3}\/[A-Z0-9\/]+)\s*\)?/i;
  var MATE_RE = /^\s*(S-[A-Z]{2}(?:-\d{2,3}){4}\/\d{1,12})\s*#\s*(.+?)\s*$/i;
  var DONE_RE = /complet|closed|suspend|cancel|reject|drop/i;
  function txt(el) { return el ? String(el.textContent || "").replace(/ /g, " ").replace(/\s+/g, " ").trim() : ""; }
  function bnNum(n) { return String(n).replace(/[0-9]/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); }
  function isMatePage() { return /matemapping\.aspx/i.test(location.pathname); }
  function titleCase(s) { return s.toLowerCase().replace(/(^|[\s.'-])([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); }); }

  // ---------- readers ----------
  function readMates() {
    var sel = document.getElementById("ctl00_ContentPlaceHolder1_ddl_mate") || document.querySelector('select[id$="ddl_mate"]');
    if (!sel) return { anchor: null, rows: [] };
    var out = [], seen = {};
    [].forEach.call(sel.options, function (o) {
      var m = MATE_RE.exec(o.text || ""); if (!m) return;
      var id = m[1].toUpperCase(); if (seen[id]) return; seen[id] = 1;
      out.push({ id: id, name: titleCase(m[2].replace(/[()#]/g, " ").replace(/\s+/g, " ").trim()) });
    });
    return { anchor: sel.closest("div,td") || sel, rows: out };
  }

  function readWorks() {
    var out = [], done = 0, seen = {}, table = null;
    var rows = document.querySelectorAll("tr");
    for (var i = 0; i < rows.length; i++) {
      var c = rows[i].cells; if (!c || c.length < 4) continue;
      for (var k = 0; k < Math.min(c.length, 3); k++) {
        var t = txt(c[k]), m = CODE_RE.exec(t); if (!m || !/\(/.test(t)) continue;
        var code = m[1].toUpperCase();
        var name = t.slice(0, m.index).replace(/[\s(]+$/, "").trim();
        if (!name || seen[code]) break;
        seen[code] = 1; table = table || rows[i].closest("table");
        var status = txt(c[k + 1]), year = txt(c[k + 2]);
        if (DONE_RE.test(status)) { done++; break; }
        out.push({ name: name, code: code, status: status, year: year });
        break;
      }
    }
    return { anchor: table, rows: out, done: done };
  }

  // ---------- bar ----------
  function render() {
    var mate = isMatePage(), d = mate ? readMates() : readWorks(), old = document.getElementById(BAR_ID);
    if (!d.anchor || !d.rows.length) { if (old) old.remove(); return; }
    var sig = (mate ? "m" : "w") + d.rows.length;
    if (old && old.getAttribute("data-sig") === sig) return;
    if (old) old.remove();
    var bar = document.createElement("div"); bar.id = BAR_ID; bar.setAttribute("data-sig", sig);
    bar.style.cssText = "margin:8px auto;padding:9px 12px;border-radius:12px;display:flex;flex-wrap:wrap;gap:10px;align-items:center;max-width:980px;box-sizing:border-box;" +
      "background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);color:#fff;font:13px/1.35 'Segoe UI','Nirmala UI',system-ui,sans-serif;box-shadow:0 6px 18px rgba(11,20,55,.25);text-align:left";
    var what = mate ? bnNum(d.rows.length) + " জন Mate পাওয়া গেছে" : bnNum(d.rows.length) + "টা কাজ পাওয়া গেছে (নাম + Work Code)";
    var sub = mate ? "Gram Setu-এর Supervisor তালিকায় যাবে: নাম + ID (যেমন " + d.rows[0].id + ")"
                   : "Gram Setu-এর Works তালিকায় যাবে" + (d.done ? " · " + bnNum(d.done) + "টা শেষ হওয়া কাজ বাদ" : "");
    bar.innerHTML =
      "<span style='width:26px;height:26px;border-radius:8px;display:grid;place-items:center;font:800 15px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)'>K</span>" +
      "<span style='flex:1;min-width:200px'><b>" + what + "</b><br><small class='kdms-sub' style='color:#c7d2fe'>" + sub + "</small></span>" +
      "<button type='button' style='cursor:pointer;border:0;border-radius:10px;padding:8px 12px;font:700 12.5px/1.2 inherit;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)'>☁ " +
      (mate ? "Mate → Supervisor sync" : "Work Code sync") + "</button>";
    var btn = bar.querySelector("button"), small = bar.querySelector(".kdms-sub");
    btn.addEventListener("click", function (e) {
      e.preventDefault(); e.stopPropagation();
      if (!window.KDLink || !window.KDLink.call) { alert("K-Desk: Gram Setu link লোড হয়নি। Page reload করুন।"); return; }
      var now = mate ? readMates() : readWorks();
      btn.disabled = true; btn.textContent = "পাঠানো হচ্ছে…";
      var args = mate ? { p_works: [], p_sups: now.rows } : { p_works: now.rows, p_sups: [] };
      window.KDLink.call("kdesk_save_masters", args, mate ? "☁ Mate sync" : "☁ Work Code sync").then(function (r) {
        var x = mate ? (r && r.sups) || {} : (r && r.works) || {}, bad = (r && r.bad) || [];
        small.style.color = "#bbf7d0";
        small.textContent = "✅ নতুন " + bnNum(x.added || 0) + " · update " + bnNum(x.updated || 0) + " · আগের মতোই " + bnNum(x.same || 0) +
          (bad.length ? " · অন্য GP/ভুল format বাদ " + bnNum(bad.length) : "");
        btn.textContent = "✓ হয়ে গেছে"; setTimeout(function () { btn.disabled = false; btn.textContent = "☁ আবার sync"; }, 2500);
      }, function (err) {
        small.style.color = "#fecaca";
        small.textContent = "❌ " + ((err && err.code === "NOT_LOGGED_IN") ? "K-Desk login বাতিল হয়েছে।" :
          (err && (err.code === "PGRST202" || /Could not find the function/i.test(err.message || ""))) ? "Gram Setu-এ এখনো v188 SQL চালানো হয়নি।" :
          ((err && (err.text || err.message)) || String(err)));
        btn.disabled = false; btn.textContent = "☁ আবার চেষ্টা";
      });
    });
    var a = d.anchor;
    if (mate) a.parentNode.insertBefore(bar, a.nextSibling); else a.parentNode.insertBefore(bar, a);
  }

  render();
  setInterval(render, 2000);   // ASP.NET postbacks (Work Code / mate type change) replace the dropdown
})();
});
