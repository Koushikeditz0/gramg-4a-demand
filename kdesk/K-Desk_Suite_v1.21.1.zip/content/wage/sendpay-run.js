/* =====================================================================
   sendpay-run.js — K-Desk Suite by Koushik · Send Wage List for Payment (isolated world)
   GP login → "Send Wagelist For Payment" (…/vbgramg/sendforpay.aspx).
   For every Financial Year in the list, and every wage list in "Wagelist No.": pick it (the page reloads), set every
   WageList Payment Agency row to EFMS — one row at a time, because each payment radio reloads the page — then press
   "Send Wagelist For Payment". The portal answers with an alert, which sendpay-driver.js keeps during a run.
   A sent wage list leaves the list. Every wage list is logged with its agencies, bank and amount.
   🧪 Test run (on by default): each wage list is only picked and read (agencies, bank, amount) — EFMS is NOT
   ticked and Send is NOT pressed, so nothing changes on the portal.
   Portal ids (from the live page): ddlfin (FY), ddl_sel (Wagelist No.), GridView1 rows with rdbPayment radios
   (value "E" = EFMS), Lbl_wg_ag_code, agencyname, lblbank, txt_chk_amt, btnsubmit.
   Run state: portal localStorage "kdsp_run" (carries across the reloads). Dashboard toggle: "sendpay".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDSP) return; window.__KDSP = true;
  if (!/\/sendforpay\.aspx$/i.test(location.pathname)) return;

  var P = "ctl00_ContentPlaceHolder1_", LS = "kdsp_run", ALERTS = "kdsp_alerts", MIRROR = "kdspLastRun", HOST_ID = "kdsp-host", MIN_KEY = "kdsp_min", POS_KEY = "kdsp_pos", TEST_KEY = "kdsp_test";
  var STALE = 5 * 60000, WAIT = 120000, MAX_ERR = 3;
  function $(id) { return document.getElementById(id); }
  function norm(s) { return String(s == null ? "" : s).replace(/ /g, " ").replace(/\s+/g, " ").trim(); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function bn(n) { return String(n).replace(/[0-9]/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function hm(t) { var d = new Date(t); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); }
  function stamp(t) { var d = new Date(t); return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + " " + hm(t); }
  function load() { try { return JSON.parse(localStorage.getItem(LS) || "null"); } catch (e) { return null; } }
  function save(r) { try { r.at = Date.now(); localStorage.setItem(LS, JSON.stringify(r)); } catch (e) {} try { var o = {}; o[MIRROR] = r; chrome.storage.local.set(o); } catch (e) {} }
  function note(r, text, level) { (r.log = r.log || []).push({ t: Date.now(), level: level || "info", text: text }); if (r.log.length > 600) r.log.splice(0, r.log.length - 600); }
  function takeAlerts() { var q = []; try { q = JSON.parse(localStorage.getItem(ALERTS) || "[]"); localStorage.removeItem(ALERTS); } catch (e) {} return q; }
  function short(wl) { return String(wl || "").replace(/^\d{10}/, ""); }
  function testPref() { try { return localStorage.getItem(TEST_KEY) !== "0"; } catch (e) { return true; } }

  /* ---------------------- the page ---------------------- */
  function fySel() { return $(P + "ddlfin"); }
  function wlSel() { return $(P + "ddl_sel"); }
  function listed() { var s = wlSel(); return s ? [].filter.call(s.options, function (o) { return o.value && !/^(select|0|-1)$/i.test(o.value) && !/select/i.test(o.text); }).map(function (o) { return o.value; }) : []; }
  // agency rows of the wage list shown: EFMS radio, agency no., bank, amount
  function agencies() {
    var out = [];
    [].forEach.call(document.querySelectorAll("input[type=radio][id*='GridView1_'][id*='rdbPayment']"), function (r) {
      if (r.value !== "E") return;
      var m = /GridView1_(ctl\d+)_/.exec(r.id); if (!m) return;
      var k = P + "GridView1_" + m[1] + "_", t = function (s) { var e = $(k + s); return e ? norm(e.tagName === "INPUT" ? e.value : e.textContent) : ""; };
      out.push({ radio: r, code: t("Lbl_wg_ag_code"), bank: t("agencyname") + (t("lblbank") ? " " + t("lblbank") : ""), amount: t("txt_chk_amt").replace(/,/g, "") });
    });
    return out;
  }

  /* ---------------------- the run ---------------------- */
  function counts(r) {
    var sent = 0, test = 0, other = 0, amt = 0;
    (r.results || []).forEach(function (x) {
      var a = 0; (x.agencies || []).forEach(function (g) { a += +g.amount || 0; });
      if (x.result === "sent") { sent++; amt += a; } else if (x.result === "would send (test)") { test++; amt += a; } else other++;
    });
    return { sent: sent, test: test, other: other, amt: amt };
  }
  function sumText(r) { var c = counts(r); return (r.test ? c.test + " wage list পাঠানো যেত (test)" : c.sent + " sent") + (c.amt ? " (₹" + c.amt + ")" : "") + (c.other ? " · " + c.other + " পাঠানো হয়নি" : ""); }
  function finish(r, why) {
    r.active = false; r.phase = ""; r.cur = null;
    if (!why) { r.finishedAt = Date.now(); note(r, "শেষ: " + sumText(r) + ".", "ok"); }
    else note(r, why, "warn");
    save(r); render();
    if (!why && !r.logSaved) { r.logSaved = 1; save(r); setTimeout(function () { download(true); }, 600); }
  }
  function record(r, res) {
    res.wl = r.cur; res.fy = r.fy || ""; res.agencies = r.curAg || res.agencies || []; res.t = Date.now();
    r.results.push(res); r.done[r.cur] = 1; r.phase = ""; r.cur = null; r.curAg = null; r.radioTries = 0;
    var good = res.result === "sent" || res.result === "would send (test)";
    r.errs = good || res.result === "not listed" ? 0 : (r.errs || 0) + 1;
    var amt = 0; res.agencies.forEach(function (a) { amt += +a.amount || 0; });
    note(r, short(res.wl) + ": " + (good ? (res.result === "sent" ? "payment-এ পাঠানো হল" : "🧪 পাঠানো যেত") + " · " + res.agencies.length + " agency" + (amt ? " · ₹" + amt : "") : res.msg || res.result), good ? "ok" : "err");
  }

  function step() {
    var r = load(); if (!r || !r.active) { render(); return; }
    if (Date.now() - (r.at || 0) > STALE) { finish(r, "Paused: page ৫ মিনিটের বেশি সাড়া দেয়নি (login শেষ?)। ▶ Resume চাপুন।"); return; }
    var alerts = takeAlerts();
    if (r.phase === "send" && r.cur) {                           // the answer to the Send just pressed
      var said = alerts.join(" · ");
      if (/success|sucess|sucessfully/i.test(said)) record(r, { result: "sent", msg: said });
      else if (said) record(r, { result: "error", msg: said });
      else if (listed().indexOf(r.cur) < 0) record(r, { result: "sent", msg: "(কোনো message নেই; wage list list থেকে চলে গেছে)" });
      else record(r, { result: "no answer", msg: "Portal কোনো message দেয়নি; wage list এখনও list-এ আছে" });
      save(r);
    } else if (alerts.length) { note(r, "Portal: " + alerts.join(" · "), "warn"); save(r); }
    if ((r.errs || 0) >= MAX_ERR) { finish(r, "পরপর " + bn(MAX_ERR) + "টা wage list পাঠানো যায়নি — থামানো হল। Log দেখে ▶ Resume চাপুন।"); return; }
    if (r.stop) { finish(r, "Stopped। ▶ Resume চাপলে পরের wage list থেকে চলবে।"); return; }
    var fy = fySel(); if (!fy) { finish(r, "এটা Send Wagelist for Payment page নয়।"); return; }
    r.fy = r.fys[r.fyi || 0];
    if (fy.value !== r.fy) {
      if ((r.fyTries = (r.fyTries || 0) + 1) > 3) { finish(r, "Financial year " + r.fy + " বাছা গেল না।"); return; }
      r.phase = "fy"; save(r); fy.value = r.fy; fy.dispatchEvent(new Event("change", { bubbles: true })); return;
    }
    r.fyTries = 0;
    var now = listed(), sel = wlSel(), next = null;
    if (!sel) { finish(r, "Wagelist No. list পাওয়া যায়নি।"); return; }
    if (!r.wls || r.wlsFy !== r.fy) {                            // this year's wage lists, once the year is shown
      r.wls = now.slice(); r.wlsFy = r.fy;
      note(r, r.fy + ": " + r.wls.length + "টা wage list।", "info"); save(r);
    }
    for (var i = 0; i < r.wls.length && !next; i++) {
      var w = r.wls[i]; if (r.done[w]) continue;
      if (now.indexOf(w) < 0) { r.cur = w; r.curAg = []; record(r, { result: "not listed", msg: "List-এ আর নেই (আগেই পাঠানো হয়েছে?)" }); continue; }
      next = w;
    }
    if (!next) {
      if ((r.fyi || 0) < r.fys.length - 1) { r.fyi = (r.fyi || 0) + 1; r.wls = null; save(r); setTimeout(step, 300); return; }
      finish(r); return;
    }
    if (sel.value !== next) {                                    // pick it (the page reloads)
      if (r.picking === next && (r.pickTries = (r.pickTries || 0) + 1) > 3) { r.cur = next; r.curAg = []; record(r, { result: "error", msg: "এই wage list খোলা গেল না" }); r.picking = null; save(r); setTimeout(step, 300); return; }
      r.picking = next; r.phase = "pick"; save(r); sel.value = next; sel.dispatchEvent(new Event("change", { bubbles: true })); return;
    }
    r.picking = null; r.pickTries = 0;
    var ag = agencies();
    // the amount boxes go once EFMS is ticked: keep each agency's amount the first time it shows
    r.amts = r.amts || {}; ag.forEach(function (a) { if (a.amount && !r.amts[a.code]) r.amts[a.code] = a.amount; });
    var info = function () { return ag.map(function (a) { return { code: a.code, bank: a.bank, amount: a.amount || r.amts[a.code] || "" }; }); };
    if (!ag.length) { r.cur = next; r.curAg = []; record(r, { result: "nothing to send", msg: "কোনো WageList Payment Agency row নেই (আগেই পাঠানো হয়েছে?)" }); save(r); setTimeout(step, 300); return; }
    var noE = ag.filter(function (a) { return a.radio.disabled; });
    if (noE.length) { r.cur = next; r.curAg = info(); record(r, { result: "skipped", msg: "EFMS বাছা যাচ্ছে না: " + noE.map(function (a) { return a.code; }).join(", ") }); save(r); setTimeout(step, 300); return; }
    if (r.test) {                                                // 🧪 read only: no EFMS, no Send
      r.cur = next; r.curAg = info();
      var already = ag.filter(function (a) { return a.radio.checked; }).length;
      record(r, { result: "would send (test)", msg: "Test run: EFMS দেওয়া বা Send চাপা হয়নি" + (already ? " (" + already + "টা row-এ আগেই EFMS)" : "") });
      save(r); render(); setTimeout(step, 400); return;
    }
    var todo = ag.filter(function (a) { return !a.radio.checked; });
    if (todo.length) {                                           // EFMS on the next row (each click reloads the page)
      if ((r.radioTries = (r.radioTries || 0) + 1) > ag.length + 3) { r.cur = next; r.curAg = []; record(r, { result: "error", msg: "EFMS tick থাকছে না" }); save(r); setTimeout(step, 300); return; }
      r.cur = next; r.phase = "radio"; save(r); render(); todo[0].radio.click(); return;
    }
    var btn = $(P + "btnsubmit"); if (!btn) { finish(r, "Send Wagelist For Payment button পাওয়া যায়নি।"); return; }
    r.cur = next; r.curAg = info(); r.phase = "send"; r.curAt = Date.now(); save(r); render();
    btn.click();
    setTimeout(function () {
      var x = load(); if (!x || !x.active || x.phase !== "send" || x.cur !== next) return;
      record(x, { result: "no answer", msg: Math.round(WAIT / 1000) + " সেকেন্ডে portal সাড়া দেয়নি" }); save(x); step();
    }, WAIT);
  }

  /* ---------------------- start / stop ---------------------- */
  var confirming = false;
  function fyList() { var fy = fySel(); return fy ? [].filter.call(fy.options, function (o) { return /\d{4}\s*-\s*\d{4}/.test(o.value); }).map(function (o) { return o.value; }) : []; }
  function askStart() {
    var r = load(); if (r && r.active) return;
    if (!fySel()) { status("এটা Send Wagelist for Payment page নয়।", "warn"); return; }
    if (!fyList().length) { status("Financial Year list-এ কোনো বছর নেই।", "warn"); return; }
    confirming = true; render();
  }
  function doStart() {
    confirming = false;
    var fys = fyList(); if (!fys.length) return;
    var test = testPref();
    var r = { v: 1, runId: "kdsp-" + Date.now(), active: true, stop: false, startedAt: Date.now(), test: test, fys: fys, fyi: 0, fy: fys[0], wls: null, done: {}, results: [], phase: "", cur: null, log: [] };
    note(r, (test ? "🧪 TEST RUN শুরু (কিছু পাঠানো হবে না): " : "শুরু: ") + fys.length + "টা Financial Year: " + fys.join(", ") + "।");
    takeAlerts(); save(r); step();
  }
  function resume() {
    var r = load(); if (!r || r.active || r.finishedAt) return;
    r.active = true; r.stop = false; r.phase = ""; r.errs = 0; note(r, "Resumed."); takeAlerts(); save(r); step();
  }
  function stopRun() { var r = load(); if (!r || !r.active) return; r.stop = true; note(r, "Stop চাপা হয়েছে: হাতের wage list শেষ হলে থামবে।", "warn"); save(r); render(); }
  function newRun() {
    var r = load(); if (r && r.active) { status("আগে Stop করুন।", "warn"); return; }
    if (r && !r.logSaved && !window.confirm("আগের run-এর log মুছে দেবেন? দরকার হলে আগে ⭳ Log download করুন।")) return;
    try { localStorage.removeItem(LS); } catch (e) {}
    status("মুছে দেওয়া হয়েছে।", "ok"); render();
  }

  /* ---------------------- Excel log ---------------------- */
  function download(auto) {
    var r = load(); if (!r || !r.results || !r.results.length) { if (!auto) status("Log খালি।", "warn"); return; }
    if (!window.XLSX) { status("Spreadsheet library load হয়নি — page reload করুন।", "warn"); return; }
    var A = [["Financial Year", "Wagelist No.", "WageList Payment Agency No.", "Bank", "Amount (₹)", "Payment Through", "Result", "Portal message", "Time"]];
    r.results.forEach(function (x) {
      var ag = x.agencies && x.agencies.length ? x.agencies : [{ code: "", bank: "", amount: "" }];
      ag.forEach(function (a) { A.push([x.fy || "", x.wl, a.code, a.bank, a.amount ? +a.amount || a.amount : "", x.result === "sent" ? "EFMS" : "", x.result, x.msg || "", stamp(x.t)]); });
    });
    var ws = XLSX.utils.aoa_to_sheet(A); ws["!cols"] = [12, 22, 34, 30, 11, 10, 16, 50, 17].map(function (w) { return { wch: w }; });
    var wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, r.test ? "Test run" : "Send for payment");
    var d = new Date(), name = "SendForPayment-" + (r.test ? "TEST-" : "") + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
    XLSX.writeFile(wb, name); status("Saved " + name + "।", "ok");
  }

  /* ---------------------- panel ---------------------- */
  var sel = {};
  function status(m, kind) { if (!sel.st) return; sel.st.textContent = m || ""; sel.st.className = "st" + (kind ? " " + kind : ""); sel.st.hidden = !m; }
  function render() {
    if (!sel.sum) return;
    var r = load(), active = !!(r && r.active), paused = !!(r && !active && !r.finishedAt), test = testPref();
    if (!r) {
      var n = listed().length, fys = fyList();
      sel.sum.innerHTML = "Start চাপলে প্রতিটা <b>Financial Year</b> (" + esc(fys.join(", ") || "—") + ") আর তার প্রতিটা wage list-এ " +
        "<b>EFMS</b> দিয়ে <b>Send Wagelist For Payment</b> চাপবে, একটা একটা করে।" + (n ? "<br>এই বছরের list-এ এখন <b>" + bn(n) + "</b>টা wage list।" : "");
      sel.prog.hidden = true;
    } else {
      var wls = r.wls || [], N = wls.length, D = wls.filter(function (w) { return r.done[w]; }).length, pct = N ? Math.round(100 * D / N) : 0, c = counts(r);
      var yr = r.fys && r.fys.length > 1 ? " (বছর " + bn((r.fyi || 0) + 1) + "/" + bn(r.fys.length) + ")" : "";
      sel.sum.innerHTML = (r.test ? "<b style='color:#0f766e'>🧪 TEST RUN</b> · " : "") + (r.finishedAt ? "✓ শেষ · " : active ? "চলছে · " : "Paused · ") + esc(r.fy || "") + yr + " · <b>" + D + "/" + N + "</b> wage list" +
        "<br>" + (r.test ? "পাঠানো যেত <b>" + c.test + "</b>" : "পাঠানো হয়েছে <b>" + c.sent + "</b>") + (c.amt ? " (₹" + c.amt + ")" : "") + (c.other ? " · পাঠানো হয়নি <b>" + c.other + "</b>" : "") +
        (active && r.cur ? "<br><span class='cur'>এখন: " + esc(short(r.cur)) + (r.phase === "radio" ? " — EFMS দিচ্ছে" : r.phase === "send" ? " — পাঠাচ্ছে" : "") + "</span>" : "");
      sel.prog.hidden = false; sel.fill.style.width = pct + "%"; sel.ptxt.textContent = D + "/" + N + " (" + pct + "%)";
    }
    var idle = !r || !!r.finishedAt;
    sel.starts.hidden = !idle || confirming; sel.res.hidden = !paused || confirming; sel.testrow.hidden = active;
    sel.start.textContent = test ? "🧪 Test run শুরু" : "▶ Start (সত্যি পাঠাবে)";
    sel.start.className = "btn " + (test ? "iay" : "fill");
    sel.cfm.hidden = !confirming;
    if (confirming) {
      var f = fyList();
      sel.cfmh.textContent = test ? "🧪 Test run — কিছু পাঠানো হবে না" : "⚠ সত্যি payment-এ পাঠানো হবে";
      sel.cfm.className = "cfm" + (test ? " t" : "");
      sel.cfmtxt.innerHTML = test
        ? "প্রতিটা Financial Year (" + esc(f.join(", ")) + ") আর তার প্রতিটা wage list খুলে agency, bank আর টাকা পড়বে। <b>EFMS দেবে না, Send চাপবে না।</b>"
        : "প্রতিটা Financial Year (" + esc(f.join(", ")) + ") আর তার <b>প্রতিটা wage list</b>-এ সব agency-তে <b>EFMS</b> দিয়ে <b>Send Wagelist For Payment</b> চাপবে। পাঠানো wage list portal-এ ফেরত আনা যায় না।";
    }
    sel.stop.disabled = !active || !!(r && r.stop);
    sel.dl.disabled = !(r && r.results && r.results.length);
    sel.newr.disabled = active || !r;
    var L = (r && r.log) || [], h = "";
    for (var k = L.length - 1, m = 0; k >= 0 && m < 200; k--, m++) h += "<div class='l-" + esc(L[k].level) + "'><span class='lt'>" + hm(L[k].t) + "</span>" + esc(L[k].text) + "</div>";
    sel.logbox.innerHTML = h || "<div class='l-info'>এখনো কিছু হয়নি।</div>";
  }
  var STYLE =
    ".panel{width:370px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:13px;color:#1e1b4b;background:linear-gradient(180deg,#f3f4ff,#e8eafc);border:1px solid #c9cef3;border-radius:16px;box-shadow:0 18px 50px rgba(30,27,75,.30);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:10px 12px;display:flex;align-items:center;justify-content:space-between;cursor:move}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hdl{display:flex;align-items:center;gap:9px;min-width:0}.ttl b{display:block;font-size:14px}.ttl small{display:block;font-size:10px;color:#c7d2fe;letter-spacing:.6px;text-transform:uppercase}.ttl small i{font-style:normal;color:#f5b942;font-weight:600;text-transform:none}" +
    ".logo{width:28px;height:28px;border-radius:8px;flex:0 0 auto;display:grid;place-items:center;font:800 15px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:24px;height:24px;border-radius:6px;font-size:15px;line-height:1}" +
    ".bd{padding:10px 12px;max-height:80vh;overflow:auto}" +
    ".summary{font-size:12px;background:#fff;border:1px solid #d4d8f5;border-left:4px solid #f5b942;border-radius:10px;padding:8px 10px;line-height:1.45}.summary .cur{color:#5b6472}" +
    ".prog{margin:8px 0}.progbar{height:8px;background:#d4d8f5;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#e08e0b;transition:width .3s}.progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".btn{padding:8px 9px;border:none;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;min-height:34px}.btnrow{display:flex;gap:6px;margin-top:7px}.btnrow .btn{flex:1}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.iay{color:#fff;background:linear-gradient(135deg,#0f766e,#0d9488)}" +
    ".btn.stop{background:#c5221f;color:#fff}.btn.stop:disabled{background:#e6a6a4;cursor:not-allowed}" +
    ".btn.ghost{background:#f5f6ff;color:#1e1b4b;border:1px solid #d4d8f5}.btn.ghost:disabled{color:#aab;cursor:not-allowed}.btn.ghost.danger{background:#fff1f2;color:#be123c;border-color:#fecdd3}.btn.ghost.danger:disabled{background:#f5f6ff;color:#c9a9a8}" +
    ".cfm{margin:8px 0;padding:8px;border:1px solid #f2d98a;background:#fef7e0;border-radius:9px;font-size:11.5px;color:#5a4300;line-height:1.45}.cfmh{font-weight:700;color:#9a6700;margin-bottom:4px}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:7px;background:#f5f6ff;line-height:1.35}.st.ok{background:#dcfce7;color:#166534}.st.warn{background:#fef3c7;color:#92400e}" +
    ".sec{font-weight:700;color:#3730a3;margin:10px 0 6px;border-top:1px solid #d4d8f5;padding-top:8px;font-size:12px}" +
    ".logbox{max-height:170px;overflow:auto;font-size:10.5px;line-height:1.4;background:#0b1437;color:#cbd5e1;border-radius:8px;padding:6px 8px}.logbox div{padding:1px 0;border-bottom:1px dotted #1e2a5a}" +
    ".l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#cbd5e1}.lt{display:inline-block;color:#aab2c0;margin-right:6px}" +
    ".hint{font-size:11px;color:#5b6472;margin-top:7px;line-height:1.4}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#7a8090;line-height:1.35;background:#f5f6ff;border:1px solid #d4d8f5;border-radius:7px;padding:5px 7px}" +
    ".opt{display:flex;gap:6px;align-items:flex-start;font-size:11.5px;margin-top:8px;cursor:pointer;line-height:1.35}.opt input{margin:2px 0 0;accent-color:#3730a3}.foot{margin-top:8px;padding-top:6px;border-top:1px solid #d4d8f5;display:flex;justify-content:space-between;font-size:10.5px;color:#5b5f8a}.foot b{color:#1e1b4b}.foot em{font-style:normal;color:#c2770a}[hidden]{display:none!important}";
  var HTML =
    "<div class='hd' id='ks_hd'><span class='hdl'><span class='logo'>K</span><span class='ttl'><b>Send Wage List for Payment</b><small><i>K-Desk</i> Suite · EFMS · একটা একটা wage list</small></span></span><button class='mn' id='ks_min'>–</button></div>" +
    "<div class='bd' id='ks_bd'>" +
    "<div class='summary' id='ks_sum'></div>" +
    "<div class='prog' id='ks_prog' hidden><div class='progbar'><div class='progfill' id='ks_fill'></div></div><div class='progtxt' id='ks_ptxt'></div></div>" +
    "<label class='opt' id='ks_testrow'><input type='checkbox' id='ks_test'> 🧪 Test run: শুধু wage list খুলে পড়বে — EFMS দেবে না, Send চাপবে না</label>" +
    "<div class='btnrow' id='ks_starts'><button class='btn iay' id='ks_start'>🧪 Test run শুরু</button></div>" +
    "<div class='btnrow' id='ks_res' hidden><button class='btn fill' id='ks_resume'>▶ Resume</button></div>" +
    "<div class='cfm' id='ks_cfm' hidden><div class='cfmh' id='ks_cfmh'></div><div id='ks_cfmtxt'></div>" +
      "<div class='btnrow'><button class='btn fill' id='ks_yes'>হ্যাঁ, শুরু করুন</button><button class='btn ghost' id='ks_no'>বাতিল</button></div></div>" +
    "<div class='btnrow'><button class='btn stop' id='ks_stop'>■ Stop</button><button class='btn ghost' id='ks_dl'>⭳ Log (Excel)</button></div>" +
    "<div class='btnrow'><button class='btn ghost danger' id='ks_new'>↺ New run (clear)</button></div>" +
    "<div class='st' id='ks_st' hidden></div>" +
    "<div class='sec'>Activity</div><div class='logbox' id='ks_logbox'></div>" +
    "<div class='hint'>প্রতিটা wage list: <b>Wagelist No.</b>-এ বাছে, প্রতিটা WageList Payment Agency-তে <b>EFMS</b> (প্রতিবার page reload হয়), তারপর <b>Send Wagelist For Payment</b>। Portal-এর উত্তর log-এ থাকে। পরপর " + MAX_ERR + "টা না গেলে নিজেই থামে।</div>" +
    "<div class='disclaimer'>⚠ এটা সত্যিকারের payment পাঠায়। আগে 🧪 Test run চালিয়ে log মিলিয়ে নিন। যেকোনো সময় ■ Stop চাপা যায়।</div>" +
    "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>K-Desk v<span id='ks_ver'></span></em></div>" +
    "</div>";

  function build() {
    if ($(HOST_ID)) return;
    var host = document.createElement("div"); host.id = HOST_ID;
    var kdW = 58; try { if (localStorage.getItem("kd_wide") === "1" && localStorage.getItem("kd_collapsed") !== "1") kdW = 200; } catch (e) {}
    host.style.cssText = "position:fixed;top:0;right:" + kdW + "px;left:auto;z-index:2147483646;";
    var pos = null; try { pos = JSON.parse(localStorage.getItem(POS_KEY) || "null"); } catch (e) {}
    if (pos && pos.l >= 0 && pos.t >= 0 && pos.l < window.innerWidth - 60 && pos.t < window.innerHeight - 40) { host.style.left = pos.l + "px"; host.style.top = pos.t + "px"; host.style.right = "auto"; }
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE + ".cfm.t{border-color:#99f6e4;background:#f0fdfa;color:#134e4a}.cfm.t .cfmh{color:#0f766e}"; root.appendChild(css);
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML; root.appendChild(box);
    ["hd", "min", "bd", "ver", "sum", "prog", "fill", "ptxt", "testrow", "test", "starts", "start", "res", "resume", "cfm", "cfmh", "cfmtxt", "yes", "no", "stop", "dl", "new", "st", "logbox"]
      .forEach(function (id) { sel[id === "new" ? "newr" : id] = root.getElementById("ks_" + id); });
    try { sel.ver.textContent = chrome.runtime.getManifest().version; } catch (e) {}
    try { if (localStorage.getItem(MIN_KEY) === "1") { sel.bd.style.display = "none"; sel.min.textContent = "+"; } } catch (e) {}
    sel.test.checked = testPref();
    sel.test.addEventListener("change", function () { try { localStorage.setItem(TEST_KEY, sel.test.checked ? "1" : "0"); } catch (e) {} confirming = false; render(); });
    sel.start.addEventListener("click", askStart);
    sel.yes.addEventListener("click", doStart);
    sel.no.addEventListener("click", function () { confirming = false; render(); });
    sel.resume.addEventListener("click", resume);
    sel.stop.addEventListener("click", stopRun);
    sel.dl.addEventListener("click", function () { download(false); });
    sel.newr.addEventListener("click", newRun);
    sel.min.addEventListener("click", function () { var hide = sel.bd.style.display !== "none"; sel.bd.style.display = hide ? "none" : "block"; sel.min.textContent = hide ? "+" : "–"; try { localStorage.setItem(MIN_KEY, hide ? "1" : "0"); } catch (e) {} });
    var sx, sy, ox, oy, drag = false;
    sel.hd.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
    document.addEventListener("mouseup", function () {
      if (!drag) return; drag = false;
      var rr = host.getBoundingClientRect(); try { localStorage.setItem(POS_KEY, JSON.stringify({ l: Math.max(0, Math.round(rr.left)), t: Math.max(0, Math.round(rr.top)) })); } catch (e) {}
    });
    render(); setInterval(render, 1500);
  }
  function boot() { if (fySel()) build(); setTimeout(step, 700); }
  function start() { if (window.KH_FEATURE) window.KH_FEATURE("sendpay", boot); else boot(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
