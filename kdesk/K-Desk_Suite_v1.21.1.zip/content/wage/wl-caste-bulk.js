KH_FEATURE("wlcaste", function () {
/* =====================================================================
   K-Desk Suite by Koushik — ⚖ WL Caste Breakup (many wage lists at once)   (…/vbgramg/view_wagelist.aspx)
   Ticked wage lists (PBA/IAY: 1–10 workers each) are read in the background (the Wage List dropdown
   postback, as in WL Export — the page itself never changes, nothing is saved on the portal) and turned
   into ONE report in the same 16 columns as the on-page Caste Breakup (content/wage/wage-caste-map.js),
   one row per wage list + Muster Roll → ⭳ Excel / 📋 Copy.
   • Caste = K-Desk's own register (kh_caste_map_v2, saved when the Registration Application Register opens).
   • 🏠 শুধু IAY: rows whose Work Code has no /IAY/ are left out.
   • Wage lists already read are kept (chrome.storage kdwcb_cache); stopping / login expiry resumes.
   • Reported wage lists (Excel / Copy) are remembered locally (kdwcb_reported) and in Gram Setu
     (kdesk_wl_caste_save / kdesk_wl_caste_reported, SQL v215) → "🆕 new since the last report" on any PC;
     the Gram Setu Admin panel (⚖ WL Caste tab) can download a report again or Undo it.
   Started as the separate test extension "WL Caste Breakup (Test)" v0.3.0 (Koushik tested it on the real portal).
   Panel = K-Dock drawer (host kdwcb-host), opened from the K-Dock ⚖ icon. Toggle: "wlcaste".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDWCB__) return;
  try { if (window.top !== window) return; } catch (e) { return; }
  var K = window.KDWCBKIT; if (!K) return;
  function wlSelOf(doc) { return doc.getElementById("ddl_sel") || doc.querySelector('select[id$="ddl_sel"]'); }
  var SEL = wlSelOf(document);
  if (!SEL) return;
  window.__KDWCB__ = true;

  var CACHE_KEY = "kdwcb_cache", DONE_KEY = "kdwcb_reported", PREF_KEY = "kdwcb_prefs", PEND_KEY = "kdwcb_pending", HOST_ID = "kdwcb-host";
  var FY = document.getElementById("ddlFinYr") || document.querySelector('select[id$="ddlFinYr"]') ||
    [].filter.call(document.querySelectorAll("select"), function (s) { return s !== SEL && [].some.call(s.options, function (o) { return /^\d{4}-\d{4}$/.test(o.value); }); })[0] || null;

  /* ---------------------- small helpers ---------------------- */
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function money(n) { return "₹" + Number(n || 0).toLocaleString("en-IN"); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-IN"); }
  function r2(n) { return Math.round((Number(n) || 0) * 100) / 100; }
  function stamp() { var d = new Date(); return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()); }
  function serial(wl) { var m = String(wl).match(/WL0*(\d+)\s*$/i); return m ? +m[1] : NaN; }
  function dur(ms) { var s = Math.round(ms / 1000); if (s < 60) return s + " সেকেন্ড"; var m = Math.floor(s / 60); if (m < 60) return m + " মিনিট"; return Math.floor(m / 60) + " ঘণ্টা " + (m % 60) + " মিনিট"; }
  function wlOptions(s) { return s ? [].filter.call(s.options, function (o) { return /WL/i.test(o.value); }).map(function (o) { return o.value; }) : []; }
  function years() { return FY ? [].filter.call(FY.options, function (o) { return /\d{4}-\d{4}/.test(o.value); }).map(function (o) { return o.value; }) : []; }
  function store(get, set) { return new Promise(function (res) { try { if (set) chrome.storage.local.set(set, function () { res(); }); else chrome.storage.local.get(get, function (d) { res(d || {}); }); } catch (e) { res({}); } }); }

  /* ---------------------- background postback (= dropdown বদলানো) ---------------------- */
  var rtts = [];
  function typical() { if (!rtts.length) return 6000; var a = rtts.slice().sort(function (x, y) { return x - y; }); return a[Math.min(a.length - 1, Math.floor(a.length * 0.75))]; }
  function timeoutFor(att) { return Math.min(240000, Math.round(Math.max(25000, typical() * 4) * Math.pow(1.6, att || 0))); }
  async function postback(state, name, value, att) {
    var form = state.forms[0], body = new URLSearchParams();
    [].forEach.call(form.querySelectorAll("input[type=hidden],select"), function (e) { if (e.name) body.set(e.name, e.value); });
    body.set("__EVENTTARGET", name); body.set("__EVENTARGUMENT", ""); body.set(name, value);
    var ac = new AbortController(), to = setTimeout(function () { ac.abort(); }, timeoutFor(att)), t0 = Date.now();
    try {
      var res = await fetch(new URL(form.getAttribute("action") || location.href, location.href).href, { method: "POST", body: body, credentials: "include", signal: ac.signal,
        headers: { "Content-Type": "application/x-www-form-urlencoded" } });
      if (!res.ok) throw new Error("portal answered " + res.status);
      var html = await res.text(); rtts.push(Date.now() - t0); if (rtts.length > 12) rtts.shift();
      var doc = new DOMParser().parseFromString(html, "text/html");
      if (!wlSelOf(doc)) throw new Error("session expired");
      return doc;
    } finally { clearTimeout(to); }
  }

  /* ---------------------- one wage list page → rows ---------------------- */
  function pageTotal(text) {
    var gt = /Grand\s*Total\s*:?\s*(\d[\d,]*(?:\.\d+)?)/i.exec(text);
    if (gt) return parseFloat(gt[1].replace(/,/g, "")) || 0;
    var m, subs = [], reSub = /sub\s*total[^0-9]{0,15}([0-9][0-9,]*(?:\.\d+)?)/gi;
    while ((m = reSub.exec(text))) subs.push(parseFloat(m[1].replace(/,/g, "")) || 0);
    if (subs.length) return r2(subs.reduce(function (a, b) { return a + b; }, 0));
    var mx = 0, re = /total[^0-9]{0,15}([0-9][0-9,]*)/gi;
    while ((m = re.exec(text))) { var n = parseFloat(m[1].replace(/,/g, "")) || 0; if (n > mx) mx = n; }
    return mx;
  }
  function parseWL(doc, wlReq) {
    var text = K.spaced(doc.body);
    var wl = ((text.match(/Wage\s*List\s*No\.?\s*:?\s*-?\s*(\d*WL\d+)/i) || [])[1]) || "";
    var date = ((text.match(/Wage\s*List\s*Date\.?\s*:?\s*-?\s*(\d{1,2}\/\d{1,2}\/\d{4})/i) || [])[1]) || "";
    if (wl && wlReq && wl.toUpperCase() !== String(wlReq).toUpperCase()) throw new Error("portal অন্য wage list দেখাল (" + wl + ")");
    if (!K.hasJobCardRow(doc)) throw new Error("wage list-এ কোনো worker row নেই / page পুরো আসেনি");
    var t = K.rawUnion(doc, "#" + HOST_ID);
    var cardIdx = K.colIndex(t, /job\s*card/i), mrIdx = K.colIndex(t, /must\s*roll|muster\s*roll|msr\s*no/i);
    var amtIdx = K.colIndex(t, /amount\s*of\s*wage/i); if (amtIdx < 0) amtIdx = K.colIndex(t, /amount/i);
    var codeIdx = K.colIndex(t, /work\s*code/i);
    if (cardIdx < 0 || mrIdx < 0 || amtIdx < 0) throw new Error("table-এ Job Card / Mustroll No / Amount column পাওয়া যায়নি");
    var rows = [];
    t.rows.forEach(function (r) {
      var amtRaw = String(r[amtIdx] == null ? "" : r[amtIdx]).replace(/[^\d.\-]/g, "");
      if (amtRaw === "" || isNaN(parseFloat(amtRaw))) return;
      var jcm = String(r[cardIdx] || "").match(K.JC_RE); if (!jcm) return;
      rows.push([jcm[0].toUpperCase(), K.cellStr(r[mrIdx]) || "—", parseFloat(amtRaw) || 0, codeIdx >= 0 ? K.cellStr(r[codeIdx]) : ""]);
    });
    if (!rows.length) throw new Error("worker row পড়া যায়নি");
    return { v: 2, wl: wl || wlReq, date: date, stated: pageTotal(text), rows: rows, at: Date.now() };
  }

  /* ---------------------- state ---------------------- */
  var ex = { fy: "", state: null, wls: [], ticks: {}, q: "" , loading: false };
  var run = { busy: false, stop: false, done: 0, total: 0, t0: 0, failed: {} };
  var cache = {}, reported = {}, caste = { map: {}, meta: null }, prefs = { conc: 2, reuse: true, rupee: true, iay: true };
  var report = null; // last built report
  var ui = {};

  async function loadStore() {
    var d = await store([CACHE_KEY, DONE_KEY, PREF_KEY, PEND_KEY, K.KEY, K.META_KEY]);
    pending = Array.isArray(d[PEND_KEY]) ? d[PEND_KEY] : [];
    cache = d[CACHE_KEY] || {}; reported = d[DONE_KEY] || {}; caste.map = d[K.KEY] || {}; caste.meta = d[K.META_KEY] || null;
    var p = d[PREF_KEY] || {}; for (var k in p) prefs[k] = p[k];
  }
  function savePrefs() { var o = {}; o[PREF_KEY] = prefs; store(null, o); }
  var cacheDirty = false, cacheTimer = null;
  function saveCacheSoon() {
    cacheDirty = true; if (cacheTimer) return;
    cacheTimer = setTimeout(function () { cacheTimer = null; if (!cacheDirty) return; cacheDirty = false; var o = {}; o[CACHE_KEY] = cache; store(null, o); }, 1500);
  }
  function flushCache() { if (cacheTimer) { clearTimeout(cacheTimer); cacheTimer = null; } cacheDirty = false; var o = {}; o[CACHE_KEY] = cache; return store(null, o); }

  async function loadYear(fy) {
    ex.fy = fy; ex.wls = []; ex.state = null; ex.ticks = {}; report = null; renderList(); renderResult();
    if (!fy) return;
    if ((!FY || FY.value === fy) && wlOptions(SEL).length) { ex.state = document; ex.wls = wlOptions(SEL); renderList(); return; }
    ex.loading = true; renderList();
    try {
      var doc = null;
      for (var att = 0; att < 3 && !doc; att++) {
        try { doc = await postback(document, FY.name || "ddlFinYr", fy, att); } catch (e) { if (/session/.test(e.message) || att === 2) throw e; await sleep(1500 * (att + 1)); }
      }
      if (ex.fy !== fy) return;
      ex.state = doc; ex.wls = wlOptions(wlSelOf(doc));
    } catch (e) { status(fy + "-এর wage list পড়া গেল না: " + (/session/.test(e.message) ? "login শেষ হয়ে গেছে, আবার login করুন" : e.message), "warn"); }
    finally { if (ex.fy === fy) { ex.loading = false; renderList(); } }
  }

  /* ---------------------- selection helpers ---------------------- */
  function shownWls() {
    var q = String(ex.q || "").trim(); if (!q) return ex.wls;
    var parts = q.split(/[\s,;]+/).filter(Boolean);
    return ex.wls.filter(function (w) { return parts.some(function (p) { return w.toUpperCase().indexOf(p.toUpperCase()) >= 0; }); });
  }
  function fresh(w) { return !!(cache[w] && cache[w].v === 2); }
  // report (Excel / Copy) দেওয়া হয়ে গেছে এমন WL মনে রাখা — পরের বার শুধু নতুনগুলো (এই PC + Gram Setu)
  function markReported(kind) {
    if (!report) return 0;
    var t = Date.now(), rows = [];
    report.check.forEach(function (c) {
      if (c.err) return;
      reported[c.wl] = t;
      var gs = report.groups.filter(function (g) { return g.wl === c.wl; }), s = { g: 0, sc: 0, st: 0, u: 0 };
      gs.forEach(function (g) { s.g += g.g; s.sc += g.sc; s.st += g.st; s.u += g.unknown; });
      rows.push({ wl: c.wl, date: c.date || "", n: gs.length ? c.n : 0, amt: gs.length ? c.sum : 0, g: r2(s.g), sc: r2(s.sc), st: r2(s.st), u: r2(s.u),
        page: gs.length ? (c.stated || null) : null, mrs: gs.map(function (g) { return { mr: g.mr, g: r2(g.g), sc: r2(g.sc), st: r2(g.st), u: r2(g.unknown), uj: g.unknownJobs }; }) });
    });
    var o = {}; o[DONE_KEY] = reported; store(null, o);
    if (rows.length) { pending.push({ kind: kind, fy: report.fy === "current" ? "" : report.fy, iay: !!prefs.iay, rows: rows }); savePending(); cloudPush(); }
    renderList();
    return rows.length;
  }
  /* ---------------------- Gram Setu: কোন WL-এর report দেওয়া হয়েছে (SQL v215) ---------------------- */
  var pending = [], cloud = { state: "", n: 0, msg: "" };      // state: "" | "ok" | "off" (login নেই) | "err"
  function savePending() { var o = {}; o[PEND_KEY] = pending; store(null, o); }
  function linkOk() { return !!(window.KDLink && window.KDLink.call && window.KDLink.signedIn); }
  function cloudErr(e) {
    var t = (e && (e.text || e.message)) || String(e);
    if (e && (e.code === "PGRST202" || e.status === 404 || /kdesk_wl_caste|Could not find the function|v184 SQL/i.test(t))) return "Gram Setu-তে v215 SQL এখনও চালানো হয়নি";
    return t;
  }
  // Gram Setu-র list-ই আসল (Admin Undo করলে সেই WL আবার "নতুন"); শুধু এখনও না-পাঠানো report এই PC থেকে যোগ হয়
  async function cloudLoad(ask) {
    if (!linkOk()) return;
    try {
      if (!ask && !(await window.KDLink.signedIn())) { cloud.state = "off"; renderCloud(); return; }
      await cloudPush(true);
      var rows = await window.KDLink.call("kdesk_wl_caste_reported", {}, "⚖ WL Caste ← Gram Setu");
      if (pending.length) await cloudPush(true);          // login এইমাত্র হলে বাকি report পাঠানো
      var next = {};
      (rows || []).forEach(function (r) { next[String(r.wl).toUpperCase()] = Date.parse(r.at) || Date.now(); });
      pending.forEach(function (b) { b.rows.forEach(function (x) { next[String(x.wl).toUpperCase()] = Date.now(); }); });
      var byUp = {}; ex.wls.forEach(function (w) { byUp[w.toUpperCase()] = w; });
      reported = {}; Object.keys(next).forEach(function (k) { reported[byUp[k] || k] = next[k]; });
      var o = {}; o[DONE_KEY] = reported; store(null, o);
      cloud.state = "ok"; cloud.n = (rows || []).length; cloud.msg = "";
    } catch (e) { cloud.state = e && e.code === "NOT_LOGGED_IN" ? "off" : "err"; cloud.msg = cloudErr(e); }
    renderAll();
  }
  var pushing = false;
  async function cloudPush(quiet) {
    if (pushing || !pending.length || !linkOk()) return;
    if (!(await window.KDLink.signedIn())) { cloud.state = "off"; renderCloud(); return; }
    pushing = true;
    try {
      while (pending.length) {
        var b = pending[0];
        await window.KDLink.call("kdesk_wl_caste_save", { p_kind: b.kind === "copy" ? "copy" : "excel", p_fy: b.fy || "", p_iay: !!b.iay, p_rows: b.rows }, "⚖ WL Caste → Gram Setu");
        pending.shift(); savePending();
      }
      cloud.state = "ok"; cloud.msg = "";
      if (!quiet) status("☁ Gram Setu-তে রাখা হয়েছে — অন্য PC থেকেও এই WL গুলো 'report দেওয়া' দেখাবে।", "ok");
    } catch (e) { cloud.state = "err"; cloud.msg = cloudErr(e); }
    finally { pushing = false; renderCloud(); }
  }
  function renderCloud() {
    if (!ui.cloud) return;
    var t = cloud.state === "ok" ? "☁ Gram Setu: যুক্ত" + (pending.length ? " · " + pending.length + "টা report পাঠানো বাকি" : "")
      : cloud.state === "off" ? "☁ Gram Setu-তে login নেই — report শুধু এই PC-তে মনে থাকবে"
      : cloud.state === "err" ? "☁ Gram Setu: " + cloud.msg + (pending.length ? " · " + pending.length + "টা report পাঠানো বাকি" : "")
      : linkOk() ? "☁ Gram Setu দেখছে…" : "";
    ui.cloud.textContent = t; ui.cloud.hidden = !t;
    ui.cloud.className = "cl" + (cloud.state === "ok" ? " ok" : cloud.state ? " bad" : "");
    ui.csync.hidden = !(cloud.state === "off" || cloud.state === "err");
    ui.csync.textContent = cloud.state === "off" ? "☁ Login" : "↻ আবার";
  }
  function lastReportedSerial() {
    var mx = -1; ex.wls.forEach(function (w) { if (reported[w]) { var s = serial(w); if (s > mx) mx = s; } }); return mx;
  }
  // নতুন = report দেওয়া হয়নি এমন সব WL, প্রথম report দেওয়া WL-এর পর থেকে (মাঝে যেগুলো পড়া যায়নি সেগুলোও ধরে)
  function newWls() {
    var mn = Infinity; ex.wls.forEach(function (w) { if (reported[w]) { var s = serial(w); if (s < mn) mn = s; } });
    if (mn === Infinity) return []; return ex.wls.filter(function (w) { return !reported[w] && serial(w) > mn; });
  }
  function isIay(code) { return /\/IAY\//i.test(code || ""); }
  function tickedWls() { return ex.wls.filter(function (w) { return ex.ticks[w]; }); }
  function lastGenRun() {
    try {
      var r = JSON.parse(localStorage.getItem("kdwg_run") || "null"); if (!r || !r.results) return null;
      var wls = r.results.filter(function (x) { return x.result === "generated" && x.wl; }).map(function (x) { return x.wl; });
      return wls.length ? { wls: wls, mode: r.mode, at: r.startedAt || r.at } : null;
    } catch (e) { return null; }
  }

  /* ---------------------- the run ---------------------- */
  async function readOne(wl) {
    var base = ex.state || document, name = (wlSelOf(base) || SEL).name || "ddl_sel", lastErr = null;
    for (var att = 0; att < 3; att++) {
      if (run.stop) throw new Error("stopped");
      try {
        var doc = base === document && SEL.value === wl && K.hasJobCardRow(document) ? document : await postback(base, name, wl, att);
        return parseWL(doc, wl);
      } catch (e) {
        lastErr = e;
        if (/session/.test(e.message)) throw e;
        if (att < 2) await sleep(1500 * (att + 1));
      }
    }
    throw lastErr || new Error("পড়া যায়নি");
  }
  async function start(onlyRead) {
    if (run.busy) return;
    var list = tickedWls();
    if (!list.length) { status("আগে wage list tick করুন।", "warn"); return; }
    var todo = onlyRead || list.filter(function (w) { return !(prefs.reuse && fresh(w)); });
    run = { busy: true, stop: false, done: 0, total: todo.length, t0: Date.now(), failed: {}, session: false };
    report = null; renderAll();
    var q = todo.slice(), conc = Math.max(1, Math.min(3, +prefs.conc || 1));
    async function worker() {
      while (q.length && !run.stop) {
        var wl = q.shift();
        try { cache[wl] = await readOne(wl); delete run.failed[wl]; saveCacheSoon(); }
        catch (e) {
          if (e.message === "stopped") break;
          if (/session/.test(e.message)) { run.session = true; run.stop = true; run.failed[wl] = "login শেষ"; break; }
          run.failed[wl] = e.name === "AbortError" ? "portal ধীর (timeout)" : e.message;
        }
        run.done++; progress();
      }
    }
    var ws = []; for (var i = 0; i < conc; i++) ws.push(worker());
    await Promise.all(ws);
    await flushCache();
    run.busy = false;
    report = build(list);
    renderAll();
    var nf = Object.keys(run.failed).length;
    status((run.session ? "⚠ Login শেষ হয়ে গেছে — আবার login করে View Wagelist খুলে ▶ চাপুন (পড়া WL মনে আছে)। " : run.stop ? "থামানো হল। " : "শেষ। ") +
      report.wlOk + "টা wage list-এর report তৈরি" + (nf ? ", " + nf + "টা পড়া যায়নি" : "") + "।", nf || run.session ? "warn" : "ok");
  }
  function progress() {
    if (!ui.fill) return;
    var p = run.total ? run.done / run.total : 1;
    ui.fill.style.width = Math.round(100 * p) + "%";
    var el = Date.now() - run.t0, eta = run.done ? el / run.done * (run.total - run.done) : 0;
    ui.ptxt.textContent = run.done + " / " + run.total + " wage list পড়া হল" + (run.done && run.total > run.done ? " · বাকি সময় ~" + dur(eta) : "") +
      (Object.keys(run.failed).length ? " · ⚠ " + Object.keys(run.failed).length + " পড়া যায়নি" : "");
  }

  /* ---------------------- build the K-Desk Caste Breakup report ---------------------- */
  function build(list) {
    var groups = [], check = [], workers = [], missing = {}, total = 0, wlOk = 0, notIay = [], noCode = 0;
    list.slice().sort(function (a, b) { var x = serial(a), y = serial(b); return (isNaN(x) || isNaN(y)) ? (a < b ? -1 : a > b ? 1 : 0) : x - y; }).forEach(function (wl) {
      var c = cache[wl];
      if (!c) { check.push({ wl: wl, date: "", n: 0, sum: 0, stated: 0, ok: "", miss: "", err: run.failed[wl] || "পড়া হয়নি" }); return; }
      var rows = c.rows;
      if (prefs.iay) {
        rows = rows.filter(function (r) { if (!r[3]) { noCode++; return true; } return isIay(r[3]); });
        if (!rows.length) { notIay.push(c.wl || wl); check.push({ wl: c.wl || wl, date: c.date, n: c.rows.length, sum: 0, stated: c.stated, ok: "", miss: "", err: "", skip: "IAY নয় — বাদ" }); return; }
      }
      wlOk++;
      var by = {}, order = [], sum = 0, miss = [];
      rows.forEach(function (r) {
        var jc = r[0], mr = r[1], amt = r[2], cs = caste.map[K.normId(jc)];
        var g = by[mr]; if (!g) { g = by[mr] = { wl: c.wl || wl, date: c.date, mr: mr, g: 0, sc: 0, st: 0, unknown: 0, unknownJobs: [] }; order.push(mr); }
        if (cs == null) { g.unknown += amt; if (g.unknownJobs.indexOf(jc) < 0) g.unknownJobs.push(jc); if (miss.indexOf(jc) < 0) miss.push(jc); missing[jc] = 1; }
        else { var b = K.bucket(cs); if (b === "SC") g.sc += amt; else if (b === "ST") g.st += amt; else g.g += amt; }
        sum += amt;
        workers.push({ wl: c.wl || wl, date: c.date, mr: mr, jc: jc, code: r[3] || "", caste: cs == null ? "" : cs, cat: cs == null ? "Unknown" : (K.bucket(cs) === "OTH" ? "General" : K.bucket(cs)), amt: amt });
      });
      order.sort(function (a, b) { return (Number(a) || 0) - (Number(b) || 0) || String(a).localeCompare(String(b)); }).forEach(function (mr) { groups.push(by[mr]); });
      total += sum;
      var part = rows.length !== c.rows.length;
      check.push({ wl: c.wl || wl, date: c.date, n: rows.length, sum: r2(sum), stated: c.stated, ok: part ? "আংশিক" : c.stated > 0 ? (Math.round(c.stated) === Math.round(sum) ? "✓" : "✗") : "?", miss: miss.join(", "), err: "", skip: part ? (c.rows.length - rows.length) + " জন IAY নয় — বাদ" : "" });
    });
    return { groups: groups, check: check, workers: workers, missing: Object.keys(missing), total: r2(total), wlOk: wlOk, fy: ex.fy, notIay: notIay, noCode: noCode,
      mismatch: check.filter(function (x) { return x.ok === "✗"; }).length, failed: check.filter(function (x) { return x.err; }).length };
  }
  // same 16 columns, same order as K-Desk's on-page Caste Breakup report
  function rowCells(x, i, asText) {
    var m = asText ? (prefs.rupee ? money : function (n) { return String(r2(n)); }) : function (n) { return r2(n); };
    var z = asText ? (prefs.rupee ? "₹0" : "0") : 0;
    var remarks = x.unknown ? "Unmatched Job Card: " + x.unknownJobs.join(", ") : "";
    return [i + 1, x.mr, x.date, x.g ? x.wl : "—", m(x.g), "—", z, x.sc ? x.wl : "—", m(x.sc), "—", z, x.st ? x.wl : "—", m(x.st), "—", z, remarks];
  }
  var HEAD1 = ["Sl. No.", "Muster Roll Number", "Wage List Date", "General Category (40-2505-02-101-00-011-3102)", "", "", "", "SC Category (40-2505-02-789-00-011-3102)", "", "", "", "ST Category (40-2505-02-796-00-011-3102)", "", "", "", "Remarks"];
  var HEAD2 = ["", "", "", "Unskilled Wagelist No.", "Amount of Unskilled Wage to be paid (in Rs.)", "Semi-Skilled and Skilled Wagelist No.", "Amount of Semi-Skilled and Skilled wage to be paid (in Rs.)",
    "Unskilled Wagelist No.", "Amount of Unskilled Wage to be paid (in Rs.)", "Semi-Skilled and Skilled Wagelist No.", "Amount of Semi-Skilled and Skilled wage to be paid (in Rs.)",
    "Unskilled Wagelist No.", "Amount of Unskilled to be paid (in Rs.)", "Semi-Skilled and Skilled Wagelist No.", "Amount of Semi-Skilled and Skilled wage to be paid (in Rs.)", ""];

  function exportXl() {
    if (!report || !report.groups.length) return;
    if (!window.XLSX) { status("Spreadsheet library load হয়নি — page reload করুন।", "warn"); return; }
    var aoa = [HEAD1, HEAD2].concat(report.groups.map(function (x, i) { return rowCells(x, i, false); }));
    var tot = report.groups.reduce(function (a, x) { a[0] += x.g; a[1] += x.sc; a[2] += x.st; return a; }, [0, 0, 0]);
    aoa.push(["", "Total", "", "", r2(tot[0]), "", 0, "", r2(tot[1]), "", 0, "", r2(tot[2]), "", 0, ""]);
    var ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 1, c: 0 } }, { s: { r: 0, c: 1 }, e: { r: 1, c: 1 } }, { s: { r: 0, c: 2 }, e: { r: 1, c: 2 } },
      { s: { r: 0, c: 3 }, e: { r: 0, c: 6 } }, { s: { r: 0, c: 7 }, e: { r: 0, c: 10 } }, { s: { r: 0, c: 11 }, e: { r: 0, c: 14 } }, { s: { r: 0, c: 15 }, e: { r: 1, c: 15 } }];
    ws["!cols"] = [6, 12, 11, 20, 14, 14, 14, 20, 14, 14, 14, 20, 14, 14, 14, 40].map(function (w) { return { wch: w }; });
    var ck = XLSX.utils.aoa_to_sheet([["Wage List No.", "Wage List Date", "Workers", "Total (হিসেব)", "Total (page-এ লেখা)", "মিলেছে", "Caste নেই এমন Job Card", "সমস্যা / বাদ"]]
      .concat(report.check.map(function (c) { return [c.wl, c.date, c.n, c.sum, c.stated, c.ok, c.miss, c.err || c.skip || ""]; })));
    ck["!cols"] = [22, 12, 8, 12, 14, 8, 40, 30].map(function (w) { return { wch: w }; });
    var wk = XLSX.utils.aoa_to_sheet([["Wage List No.", "Wage List Date", "Muster Roll", "Work Code", "Job Card", "Caste (register)", "Category", "Amount"]]
      .concat(report.workers.map(function (w) { return [w.wl, w.date, w.mr, w.code, w.jc, w.caste, w.cat, w.amt]; })));
    wk["!cols"] = [22, 12, 12, 30, 26, 14, 10, 10].map(function (w) { return { wch: w }; });
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Caste Breakup");
    XLSX.utils.book_append_sheet(wb, ck, "WL Check");
    XLSX.utils.book_append_sheet(wb, wk, "Workers");
    var first = report.check[0] ? report.check[0].wl : "", last = report.check.length ? report.check[report.check.length - 1].wl : "";
    var name = "WL-Caste-Breakup-" + (report.fy || "") + "-" + String(first).replace(/^\d+WL/i, "WL") + "_" + String(last).replace(/^\d+WL/i, "WL") + "-" + stamp() + ".xlsx";
    XLSX.writeFile(wb, name.replace(/[^\w.\-]+/g, "_"));
    status("Excel save হয়েছে: " + name + " — এই WL গুলো 'report দেওয়া' হিসেবে মনে রাখা হল।", "ok");
    markReported("excel");
  }
  function copyAll() {
    if (!report || !report.groups.length) return;
    var text = report.groups.map(function (x, i) { return rowCells(x, i, true).join("\t"); }).join("\n");
    function done(ok) { status(ok ? report.groups.length + "টা row copy হয়েছে — official sheet-এ প্রথম ঘরে click করে Ctrl+V। এই WL গুলো 'report দেওয়া' হিসেবে মনে রাখা হল।" : "Copy হয়নি, ⭳ Excel ব্যবহার করুন।", ok ? "ok" : "warn"); if (ok) markReported("copy"); }
    function fallback() {
      var ta = document.createElement("textarea"); ta.value = text; ta.style.cssText = "position:fixed;left:-9999px;top:0";
      document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand("copy"); } catch (e) {} ta.remove(); done(ok);
    }
    try { navigator.clipboard.writeText(text).then(function () { done(true); }, fallback); } catch (e) { fallback(); }
  }

  /* ---------------------- panel ---------------------- */
  var STYLE =
    ":host{all:initial}.panel{width:340px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:12.5px;color:#0f172a;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 10px 30px rgba(11,20,55,.3);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:8px 10px;display:flex;align-items:center;justify-content:space-between;cursor:move;user-select:none}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hd b{font-size:12.5px}.hd small{display:block;font-size:10px;opacity:.8}.hdl{display:flex;align-items:center;gap:8px}" +
    ".logo{width:24px;height:24px;border-radius:7px;display:grid;place-items:center;font:800 13px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:22px;height:22px;border-radius:5px;font-size:15px;line-height:1}" +
    ".bd{padding:9px 10px;max-height:78vh;overflow:auto}" +
    ".cs{font-size:11.5px;padding:6px 8px;border-radius:7px;background:#eef2ff;color:#1e1b6b;line-height:1.4}.cs.bad{background:#fdf0e3;color:#9a5a12}" +
    ".row{display:flex;gap:6px;margin-top:6px;align-items:center}.inp{flex:1;min-width:0;border:1px solid #c9d3e6;border-radius:7px;padding:5px 7px;font:12px 'Segoe UI',Arial,sans-serif;background:#fff}.inp.n{flex:0 0 70px}" +
    ".lk{background:none;border:none;color:#3730a3;cursor:pointer;font-size:11.5px;padding:0;text-decoration:underline;font-family:inherit}.lk:disabled{color:#aab;cursor:default}" +
    ".sec{font-weight:700;color:#3730a3;margin:9px 0 3px;border-top:1px solid #e2e8f0;padding-top:7px;font-size:12px;display:flex;justify-content:space-between;align-items:center}.sec small{font-weight:400;color:#64748b}" +
    ".exl{max-height:150px;overflow:auto;border:1px solid #e2e8f0;border-radius:7px;padding:3px 7px;margin-top:6px}.wl{display:flex;gap:6px;align-items:center;font:11.5px Consolas,monospace;padding:1px 0;cursor:pointer}.wl input{margin:0;accent-color:#3730a3}.wl i{font-style:normal;color:#137333;font-size:10px}.wl i.f{color:#b3261e}.empty{font-size:11px;color:#64748b;padding:4px 0}" +
    ".btn{padding:8px 9px;border:none;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;width:100%}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn:disabled{opacity:.5;cursor:not-allowed}" +
    ".btn.ghost{background:#f2f4f8;color:#334;border:1px solid #d7dce6}.btn.stop{background:#fde8e7;color:#b3261e;border:1px solid #f4c7c3}" +
    ".chk{display:flex;align-items:center;gap:6px;font-size:11.5px;cursor:pointer}.chk input{margin:0;accent-color:#3730a3}" +
    ".prog{margin-top:8px}.progbar{height:8px;background:#e6e9f0;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#e08e0b;transition:width .3s}" +
    ".progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:6px;background:#f2f4f8;line-height:1.35}.st:empty{display:none}.st.ok{background:#e7f4ec;color:#137333}.st.warn{background:#fef7e0;color:#9a6700}" +
    ".res{margin-top:8px;font-size:11.5px;line-height:1.5;background:#f8fafc;border:1px solid #e2e8f0;border-radius:7px;padding:6px 8px}.res b{color:#0b1437}.res .bad{color:#b3261e}.res .good{color:#137333}" +
    ".cl{flex:1;font-size:11px;padding:4px 7px;border-radius:6px;background:#f2f4f8;color:#475569}.cl.ok{background:#e7f4ec;color:#137333}.cl.bad{background:#fef7e0;color:#9a6700}" +
    ".foot{margin-top:8px;padding-top:6px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;font-size:10.5px;color:#64748b}.foot em{font-style:normal;color:#e08e0b}" +
    "[hidden]{display:none!important}";
  var HTML =
    "<div class='panel'><div class='hd' id='hd'><span class='hdl'><span class='logo'>K</span><span><b>⚖ WL Caste Breakup</b><small><i>K-Desk</i> Suite · অনেক wage list একসাথে</small></span></span><button class='mn' id='min' title='ছোট/বড়'>–</button></div>" +
    "<div class='bd' id='bd'>" +
    "<div class='cs' id='cs'></div>" +
    "<div class='row'><div class='cl' id='cloud' hidden></div><button class='lk' id='csync' hidden></button></div>" +
    "<div class='sec'><span>① Wage list বাছুন</span><small id='cnt'></small></div>" +
    "<div class='row' id='fyrow'><select class='inp' id='fy'></select></div>" +
    "<div class='row'><input class='inp' id='q' placeholder='Wage list No খুঁজুন (শেষের সংখ্যাও চলবে)'></div>" +
    "<div class='row'><span style='font-size:11.5px'>Range</span><input class='inp n' id='rf' placeholder='8645' inputmode='numeric'><span>–</span><input class='inp n' id='rt' placeholder='8653' inputmode='numeric'><button class='lk' id='rgo'>tick</button></div>" +
    "<div class='row'><button class='lk' id='all'>দেখানো সব tick</button><button class='lk' id='none'>সব untick</button><button class='lk' id='gen' hidden></button></div>" +
    "<div class='row'><button class='btn ghost' id='nw' hidden></button></div>" +
    "<div class='row' id='lastrep' style='font-size:11px;color:#64748b' hidden></div>" +
    "<div class='exl' id='exl'></div>" +
    "<div class='sec'><span>② পড়া</span><small>শুধু পড়া, portal-এ কিছু save হয় না</small></div>" +
    "<div class='row'><label class='chk'>একসাথে <select class='inp' id='conc' style='flex:0 0 auto;padding:2px 4px'><option>1</option><option>2</option><option>3</option></select></label>" +
    "<label class='chk' style='margin-left:auto'><input type='checkbox' id='reuse'>আগে পড়া WL আবার পড়বে না</label></div>" +
    "<div class='row'><label class='chk'><input type='checkbox' id='iay'>🏠 শুধু IAY (work code-এ /IAY/ নেই এমন WL report থেকে বাদ)</label></div>" +
    "<div class='row'><button class='btn fill' id='go'>▶ Start</button><button class='btn stop' id='stop' hidden>■ থামাও</button></div>" +
    "<div class='prog' id='prog' hidden><div class='progbar'><div class='progfill' id='fill'></div></div><div class='progtxt' id='ptxt'></div></div>" +
    "<div class='st' id='st'></div>" +
    "<div id='resbox' hidden><div class='sec'><span>③ Report</span><small id='rsum'></small></div><div class='res' id='res'></div>" +
    "<div class='row'><button class='btn fill' id='xl'>⭳ Excel</button><button class='btn ghost' id='cp'>📋 Copy (সব row)</button></div>" +
    "<div class='row'><label class='chk'><input type='checkbox' id='rupee'>Copy-তে ₹ ও comma (K-Desk-এর Copy Report-এর মতো)</label></div>" +
    "<div class='row'><button class='btn ghost' id='retry' hidden>↻ যেগুলো পড়া যায়নি আবার চেষ্টা</button></div></div>" +
    "<div class='foot'><button class='lk' id='clr'>পড়া WL-এর memory মুছুন</button><span>✦ Crafted by <b>KOUSHIK</b> <em>v" + esc((chrome.runtime.getManifest() || {}).version || "") + "</em></span></div>" +
    "</div></div>";

  function status(t, kind) { if (ui.st) { ui.st.textContent = t || ""; ui.st.className = "st" + (kind ? " " + kind : ""); } }
  function renderCaste() {
    if (!ui.cs) return;
    var n = Object.keys(caste.map).length;
    if (!n) { ui.cs.className = "cs bad"; ui.cs.innerHTML = "⚠ এখনও caste জমা নেই। এই GP-র <b>Registration Application Register</b> একবার খুলুন (Analytics &amp; Reports → Registration Application Register), পুরো list load হলে নিজেই জমা হবে।"; return; }
    var age = caste.meta && caste.meta.savedAt ? Math.floor((Date.now() - caste.meta.savedAt) / 86400000) : null;
    ui.cs.className = "cs" + (age != null && age > 7 ? " bad" : "");
    ui.cs.innerHTML = "Caste জমা: <b>" + fmt(n) + "</b>টি Job Card" + (age != null ? " · " + (age ? age + " দিন আগে" : "আজ") : "") + (age > 7 ? " — নতুন Job Card থাকলে register একবার খুলে নিন।" : "");
  }
  var listSig = "";
  function renderList() {
    if (!ui.exl) return;
    var ys = years();
    ui.fyrow.hidden = !FY;
    if (ui.fy.options.length !== ys.length + 1) ui.fy.innerHTML = "<option value=''>Financial Year বাছুন</option>" + ys.map(function (y) { return "<option>" + esc(y) + "</option>"; }).join("");
    if (ui.fy.value !== ex.fy) ui.fy.value = ex.fy;
    var list = shownWls(), sig = ex.fy + "|" + ex.loading + "|" + list.join(",") + "|" + JSON.stringify(ex.ticks) + "|" + run.busy + "|" + Object.keys(cache).length + "|" + Object.keys(reported).length + "|" + Object.keys(run.failed).join(",");
    if (sig !== listSig) {
      listSig = sig;
      ui.exl.innerHTML = ex.loading ? "<div class='empty'>" + esc(ex.fy) + "-এর wage list পড়ছে…</div>"
        : (FY && !ex.fy) ? "<div class='empty'>উপরে Financial Year বাছুন।</div>"
        : !list.length ? "<div class='empty'>কোনো wage list নেই।</div>"
        : list.map(function (w) {
          return "<label class='wl'><input type='checkbox' data-w='" + esc(w) + "'" + (ex.ticks[w] ? " checked" : "") + (run.busy ? " disabled" : "") + "><span>" + esc(w) + "</span>" +
            (reported[w] ? "<i title='report দেওয়া হয়ে গেছে' style='color:#3730a3'>📄</i>" : "") + (fresh(w) ? "<i title='আগে পড়া'>✓</i>" : run.failed[w] ? "<i class='f' title='" + esc(run.failed[w]) + "'>✗</i>" : "") + "</label>";
        }).join("");
    }
    var n = tickedWls().length;
    ui.cnt.textContent = n + " / " + ex.wls.length + " tick";
    ui.go.disabled = run.busy || ex.loading || !n;
    ui.go.textContent = "▶ Start" + (n ? " (" + n + "টা WL" + (prefs.reuse ? ", নতুন পড়বে " + tickedWls().filter(function (w) { return !fresh(w); }).length + "টা" : "") + ")" : "");
    var mx = lastReportedSerial(), nw = newWls();
    ui.lastrep.hidden = mx < 0;
    if (mx >= 0) { var lw = ex.wls.filter(function (w) { return serial(w) === mx; })[0]; ui.lastrep.textContent = "📄 শেষ report দেওয়া WL: " + lw + " (" + new Date(reported[lw]).toLocaleString("en-IN", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) + ")"; }
    ui.nw.hidden = mx < 0; ui.nw.disabled = run.busy || !nw.length;
    ui.nw.textContent = nw.length ? "🆕 শেষ report-এর পরের নতুন " + nw.length + "টা WL tick করো" : "🆕 শেষ report-এর পরে নতুন WL নেই";
    var g = lastGenRun();
    ui.gen.hidden = !g; if (g) ui.gen.textContent = "K-Desk শেষ Generate run-এর " + g.wls.length + "টা" + (g.mode === "iay" ? " (IAY)" : "");
    [ui.all, ui.none, ui.rgo, ui.gen, ui.clr].forEach(function (b) { b.disabled = run.busy; });
  }
  function renderResult() {
    if (!ui.resbox) return;
    ui.go.hidden = run.busy; ui.stop.hidden = !run.busy; ui.prog.hidden = !run.busy && !run.total;
    ui.resbox.hidden = !report || run.busy;
    if (!report) return;
    ui.rsum.textContent = report.groups.length + " row";
    var h = "<b>" + report.wlOk + "</b>টা wage list · <b>" + fmt(report.workers.length) + "</b> জন · মোট <b>" + money(report.total) + "</b>";
    var ok = report.check.filter(function (c) { return c.ok === "✓"; }).length;
    h += "<br><span class='good'>✓ " + ok + "টা WL-এর total page-এর সঙ্গে মিলেছে</span>";
    if (report.mismatch) h += "<br><span class='bad'>✗ " + report.mismatch + "টা WL-এর total মেলেনি (Excel-এর WL Check sheet দেখুন)</span>";
    if (report.missing.length) h += "<br><span class='bad'>⚠ " + report.missing.length + "টা Job Card-এর caste নেই — Remarks-এ লেখা আছে। Register খুলে আবার ▶ চাপুন (আবার পড়তে হবে না)।</span>";
    if (prefs.iay) h += "<br>🏠 শুধু IAY" + (report.notIay.length ? ": <b>" + report.notIay.length + "</b>টা WL IAY নয়, বাদ গেছে" : ": সব WL-ই IAY");
    if (prefs.iay && report.noCode) h += "<br><span class='bad'>⚠ " + report.noCode + " জনের Work Code পড়া যায়নি, তাদের রাখা হয়েছে</span>";
    if (report.failed) h += "<br><span class='bad'>⚠ " + report.failed + "টা WL পড়া যায়নি</span>";
    ui.res.innerHTML = h;
    ui.retry.hidden = !report.failed;
    ui.xl.disabled = ui.cp.disabled = !report.groups.length;
  }
  function renderAll() { renderCaste(); renderList(); renderResult(); renderCloud(); progress(); }

  function build_ui() {
    if (document.getElementById(HOST_ID)) return;
    var host = document.createElement("div"); host.id = HOST_ID;
    var pos = null; try { pos = JSON.parse(localStorage.getItem("kdwcb_pos") || "null"); } catch (e) {}
    var open = false; try { open = localStorage.getItem("kdwcb_open") === "1"; } catch (e) {}
    host.style.cssText = "position:fixed;z-index:2147483644;top:70px;right:16px;" + (open ? "" : "display:none;");
    if (pos && pos.x != null) { host.setAttribute("data-kdpos", "1"); host.style.left = pos.x + "px"; host.style.top = pos.y + "px"; host.style.right = "auto"; }
    document.body.appendChild(host);
    // K-Dock ⚖ icon shows / hides the panel (style.display): remember it for the next page load
    try { new MutationObserver(function () { try { localStorage.setItem("kdwcb_open", host.style.display === "none" ? "0" : "1"); } catch (e) {} }).observe(host, { attributes: true, attributeFilter: ["style"] }); } catch (e) {}
    var root = host.attachShadow({ mode: "open" });
    root.innerHTML = "<style>" + STYLE + "</style>" + HTML;
    ["hd", "min", "bd", "cs", "cnt", "fyrow", "fy", "q", "rf", "rt", "rgo", "all", "none", "gen", "exl", "conc", "reuse", "go", "stop", "prog", "fill", "ptxt", "st",
      "resbox", "rsum", "res", "xl", "cp", "rupee", "retry", "clr", "iay", "nw", "lastrep", "cloud", "csync"].forEach(function (id) { ui[id] = root.getElementById(id); });
    ui.conc.value = String(prefs.conc); ui.reuse.checked = !!prefs.reuse; ui.rupee.checked = !!prefs.rupee; ui.iay.checked = !!prefs.iay;
    var minimized = localStorage.getItem("kdwcb_min") === "1"; ui.bd.hidden = minimized; ui.min.textContent = minimized ? "+" : "–";
    ui.min.onclick = function (e) { e.stopPropagation(); minimized = !minimized; ui.bd.hidden = minimized; ui.min.textContent = minimized ? "+" : "–"; try { localStorage.setItem("kdwcb_min", minimized ? "1" : "0"); } catch (x) {} };
    // drag by header
    var drag = null;
    ui.hd.addEventListener("mousedown", function (e) { if (e.target === ui.min) return; var rr = host.getBoundingClientRect(); drag = { sx: e.clientX, sy: e.clientY, ox: rr.left, oy: rr.top }; host.style.right = "auto"; host.setAttribute("data-kdpos", "1"); e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = Math.max(0, drag.ox + e.clientX - drag.sx) + "px"; host.style.top = Math.max(0, drag.oy + e.clientY - drag.sy) + "px"; });
    document.addEventListener("mouseup", function () { if (!drag) return; drag = null; try { localStorage.setItem("kdwcb_pos", JSON.stringify({ x: parseInt(host.style.left, 10) || 0, y: parseInt(host.style.top, 10) || 0 })); } catch (e) {} });

    ui.fy.onchange = function () { loadYear(ui.fy.value); };
    ui.q.oninput = function () { ex.q = ui.q.value; renderList(); };
    ui.exl.addEventListener("change", function (e) { var w = e.target && e.target.getAttribute("data-w"); if (!w) return; if (e.target.checked) ex.ticks[w] = 1; else delete ex.ticks[w]; renderList(); });
    ui.all.onclick = function () { shownWls().forEach(function (w) { ex.ticks[w] = 1; }); renderList(); };
    ui.none.onclick = function () { ex.ticks = {}; renderList(); };
    ui.rgo.onclick = function () {
      var a = parseInt(ui.rf.value, 10), b = parseInt(ui.rt.value, 10);
      if (isNaN(a)) { status("Range-এর শুরুর সংখ্যা দিন (যেমন 8645)।", "warn"); return; }
      if (isNaN(b)) b = a; if (b < a) { var t = a; a = b; b = t; }
      var n = 0; ex.wls.forEach(function (w) { var s = serial(w); if (s >= a && s <= b) { ex.ticks[w] = 1; n++; } });
      status(n ? "Range " + a + "–" + b + ": " + n + "টা wage list tick হল।" : "এই range-এ কোনো wage list নেই (Financial Year ঠিক আছে?)।", n ? "" : "warn"); renderList();
    };
    ui.nw.onclick = function () { ex.ticks = {}; newWls().forEach(function (w) { ex.ticks[w] = 1; }); report = null; renderList(); renderResult(); status(tickedWls().length + "টা নতুন WL tick হল। ▶ Start চাপুন।", ""); };
    ui.gen.onclick = function () {
      var g = lastGenRun(); if (!g) return;
      var have = {}; ex.wls.forEach(function (w) { have[w.toUpperCase()] = w; });
      var n = 0, miss = 0; g.wls.forEach(function (w) { var k = have[String(w).toUpperCase()]; if (k) { ex.ticks[k] = 1; n++; } else miss++; });
      status(n + "টা wage list tick হল" + (miss ? ", " + miss + "টা এই year-এর list-এ নেই" : "") + "।", miss ? "warn" : ""); renderList();
    };
    ui.csync.onclick = function () { cloudLoad(true); };
    ui.conc.onchange = function () { prefs.conc = +ui.conc.value || 1; savePrefs(); };
    ui.reuse.onchange = function () { prefs.reuse = ui.reuse.checked; savePrefs(); renderList(); };
    ui.iay.onchange = function () { prefs.iay = ui.iay.checked; savePrefs(); if (report && !run.busy) { report = build(report.check.map(function (c) { return c.wl; })); renderResult(); } };
    ui.rupee.onchange = function () { prefs.rupee = ui.rupee.checked; savePrefs(); };
    ui.go.onclick = function () { start(); };
    ui.stop.onclick = function () { run.stop = true; status("থামছে… (চলতি wage list শেষ হলে)", "warn"); };
    ui.retry.onclick = function () { var f = report ? report.check.filter(function (c) { return c.err; }).map(function (c) { return c.wl; }) : []; if (f.length) start(f); };
    ui.xl.onclick = exportXl; ui.cp.onclick = copyAll;
    ui.clr.onclick = async function () { if (!confirm("এই PC-তে আগে পড়া সব wage list-এর data আর 'report দেওয়া' চিহ্ন মুছবে? (Caste register আর Gram Setu-র হিসাব মুছবে না — Gram Setu-তে Undo করতে Admin panel → ⚖ WL Caste)")) return; cache = {}; reported = {}; var o = {}; o[DONE_KEY] = {}; await store(null, o); await flushCache(); report = null; renderAll(); status("Memory মোছা হল।", "ok"); cloudLoad(false); };
    try {
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area !== "local" || !(ch[K.KEY] || ch[K.META_KEY])) return;
        caste.map = (ch[K.KEY] && ch[K.KEY].newValue) || caste.map; caste.meta = (ch[K.META_KEY] && ch[K.META_KEY].newValue) || caste.meta;
        if (report && !run.busy) report = build(report.check.map(function (c) { return c.wl; }));
        renderAll();
      });
    } catch (e) {}
  }

  async function boot() {
    await loadStore();
    build_ui(); renderAll();
    var ys = years();
    await loadYear(!FY ? "current" : /\d{4}-\d{4}/.test(FY.value) ? FY.value : ys.length ? ys[ys.length - 1] : "");
    cloudLoad(false);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
});
