/* kdock.js — K-Desk Suite by Koushik · K-Dock
   Portal-এর ডান ধারে সরু icon bar: সব feature এক জায়গায়। যে page খোলা আছে তার feature gold,
   চলমান কাজে সবুজ dot, Off করা feature ধূসর। Icon-এ click করলে সেই feature-এর panel খোলে/বন্ধ হয়,
   আর panel-গুলো bar-এর ঠিক পাশে বসে। শুধু activated PC-তে দেখায়। */
(function () {
  "use strict";
  if (window.top !== window || window.__KDOCK) return; window.__KDOCK = true;
  if (!document.body || document.body.tagName === "FRAMESET") return;

  var ICON = {
    demand: '<path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
    allocation: '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5"/><path d="M17 8h4M19 6v4"/>',
    readiness: '<path d="M9 4h6v3H9z"/><path d="M7 5H5v16h14V5h-2"/><path d="M8 12l2 2 4-4M8 18h8"/>',
    abps: "<path d='M10.01 10.43A2.2 2.2 0 1 1 13.99 10.43'/><path d='M7.17 10.79A5 5 0 1 1 16.83 10.79'/><path d='M12 9.8v2.6'/><text x='12' y='22.5' font-size='8' textLength='21' lengthAdjust='spacingAndGlyphs' font-family='Segoe UI,Arial,sans-serif' font-weight='800' text-anchor='middle' fill='currentColor' stroke='none'>ABPS</text>",
    npci: "<path d='M12 1.8l6.5 2.4v3.6c0 2.6-2.8 4.6-6.5 5.6-3.7-1-6.5-3-6.5-5.6V4.2z'/><path d='M9.4 7.2l1.8 1.8 3.4-3.4'/><text x='12' y='22.5' font-size='8' textLength='21' lengthAdjust='spacingAndGlyphs' font-family='Segoe UI,Arial,sans-serif' font-weight='800' text-anchor='middle' fill='currentColor' stroke='none'>NPCI</text>",
    caste: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    wlcaste: '<path d="M12 3v18M5 21h14M4 7h16"/><path d="M4 7l-3 6a3 3 0 0 0 6 0zM20 7l-3 6a3 3 0 0 0 6 0z"/>',
    wls: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    mr: '<path d="M6 9V3h12v6M6 18H4v-7h16v7h-2M6 14h12v7H6z"/>',
    mrattend: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4M8.5 15l2 2 4-4"/>',
    mrpay: '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9v.01M18 15v.01"/>',
    bank: '<path d="M3 9l9-5 9 5M4 9h16M6 9v8M10 9v8M14 9v8M18 9v8M3 20h18"/>',
    wlgen: '<path d="M5 4h10l4 4v12H5z"/><path d="M8 12h8M8 16h5M10 8l-2 2 2 2"/>',
    cert: '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13l2 2 4-4"/>',
    sendpay: '<path d="M3 12l18-8-7 18-3-7z"/><path d="M11 15l10-11"/>',
    aadhaar: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="11" r="2"/><path d="M5.5 16c.6-1.6 1.7-2.4 3-2.4s2.4.8 3 2.4M14 10h4M14 13.5h3"/>'
  };
  var FEATS = [
    { f: "abps", t: "ABPS Data Sync", host: "dxabps-host", url: "/vbgramg/UID/AppABPSRpt.aspx", where: "click করলে ABPS Status Report খুলবে" },
    { f: "npci", t: "ABPS Enable (NPCI)", host: "khnp-host", url: "/vbgramg/UID/VUID_NPCI.aspx", where: "click করলে Check with NPCI page খুলবে" },
    { f: "aadhaar", t: "Aadhaar Update", host: "kdaa-host", url: "/vbgramg/BulkAadhaarUpdate.aspx", where: "click করলে Update Aadhaar details page খুলবে (Gram Setu-র Aadhaar)" },
    "|",
    { f: "demand", t: "Work Demand", host: "dxwd-host", url: "/vbgramg/demand_new.aspx", where: "click করলে Work Demand page খুলবে" },
    { f: "allocation", t: "Work Allocation", host: "dxwa-host", url: "/vbgramg/workalloc.aspx", where: "click করলে Work Allocation page খুলবে" },
    { f: "readiness", t: "Readiness Report", host: "kdrd-host", api: "KD_READINESS", url: "/vbgramg/workalloc.aspx", where: "click করলে Work Allocation page খুলবে (list খুললে report)" },
    { f: "cert", t: "Certificate Auto-Fill", host: "kdcert-host", url: "/vbgramg/work_entry.aspx", where: "click করলে Work Entry page খুলবে" },
    { f: "mr", t: "MR Batch Print", host: "mrbp", url: "/vbgramg/reprintmsr.aspx", where: "click করলে Print Muster Roll page খুলবে" },
    { f: "bank", t: "Bank A/c Update", host: "kdb-box", url: "/vbgramg/EditAppBank.aspx", where: "click করলে Bank A/c (Add/Edit) page খুলবে" },
    "|",
    { f: "mrattend", t: "Fill Attendance only", host: "mrfa-host", url: "/vbgramg/mustrollattend.aspx", where: "click করলে Muster Roll Attendance page খুলবে" },
    { f: "mrpay", t: "Payment only", host: "mrfp-host", url: "/vbgramg/msrpayment.aspx", where: "click করলে Muster Roll Payment page খুলবে" },
    "|",
    { f: "wlgen", t: "Generate Wage List", host: "kdwg-host", url: "/vbgramg/SendMSRtoPO.aspx", where: "click করলে Generate Wagelist page খুলবে" },
    { f: "sendpay", t: "Send for Payment", host: "kdsp-host", url: "/vbgramg/sendforpay.aspx", where: "click করলে Send Wagelist For Payment page খুলবে" },
    { f: "wls", t: "Wage List Status / Export", host: "khwls-host", url: "/vbgramg/view_wagelist.aspx", where: "click করলে Wage List page খুলবে" },
    { f: "wlcaste", t: "WL Caste Breakup (অনেক WL)", host: "kdwcb-host", url: "/vbgramg/view_wagelist.aspx", where: "click করলে Wage List page খুলবে (অনেক wage list একসাথে → Caste report)" },
    { f: "caste", t: "Caste Breakup", host: "kh-wc-box", btn: "kh-wc-btn", url: "/vbgramg/view_wagelist.aspx", where: "click করলে Wage List page খুলবে (Unskilled list খুললে report আসে)" }
  ];
  var CSS =
    ":host{all:initial}" +
    ".rail{position:fixed;right:0;top:0;bottom:0;width:58px;display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 0;" +
    "background:linear-gradient(180deg,#0b1437,#1e1b6b 60%,#3730a3);box-shadow:-4px 0 18px rgba(11,20,55,.25);font-family:'Segoe UI','Nirmala UI',sans-serif}" +
    ".k{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;cursor:pointer;font:800 20px/1 Georgia,serif;color:#1a1300;" +
    "background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b);box-shadow:0 3px 10px rgba(245,185,66,.45);margin-bottom:6px;border:0}" +
    ".i{position:relative;width:42px;height:42px;border-radius:12px;display:grid;place-items:center;color:#7c86b8;cursor:pointer;border:0;background:transparent;transition:.15s}" +
    ".i svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}" +
    ".i:hover{background:rgba(255,255,255,.08);color:#e0e7ff}" +
    ".i.here{color:#fff;background:rgba(255,255,255,.10)}" +
    ".i.open{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b);box-shadow:0 3px 10px rgba(245,185,66,.5)}" +
    ".i.off{opacity:.3}" +
    ".i.run:after{content:'';position:absolute;right:4px;top:4px;width:8px;height:8px;border-radius:50%;background:#10b981;box-shadow:0 0 0 2px #1e1b6b}" +
    ".sep{width:28px;height:1px;background:rgba(255,255,255,.14);margin:3px 0}" +
    ".tip{position:fixed;right:66px;padding:6px 10px;border-radius:8px;background:#0b1437;color:#fff;font:600 12px/1.35 'Segoe UI','Nirmala UI',sans-serif;" +
    "box-shadow:0 6px 18px rgba(0,0,0,.3);max-width:260px;pointer-events:none;opacity:0;transition:opacity .12s}" +
    ".tip small{display:block;font-weight:400;color:#c7d2fe}.tip.on{opacity:1}" +
    ".mx{margin-top:auto;width:42px;height:30px;border-radius:10px;display:grid;place-items:center;color:#7c86b8;cursor:pointer;border:1px solid rgba(255,255,255,.12);background:transparent;transition:.15s}" +
    ".mx:hover{background:rgba(255,255,255,.08);color:#e0e7ff}.mx svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}" +
    ".i .lb{display:none}" +
    // Maximize: icon-এর পাশে নাম
    ".rail.wide{width:200px;align-items:stretch;padding:10px 10px}" +
    ".wide .kh{display:flex;align-items:center;gap:10px;margin-bottom:6px}.wide .kh .k{margin:0;flex:none}" +
    ".kh .kt{display:none}.wide .kh .kt{display:block;color:#fff;font:700 14px/1.2 'Segoe UI','Nirmala UI',sans-serif}.wide .kh .kt small{display:block;font-weight:400;font-size:11px;color:#a5b4fc}" +
    ".wide .i{width:auto;height:40px;display:flex;align-items:center;gap:11px;padding:0 11px;text-align:left}" +
    ".wide .i svg{flex:none}.wide .i .lb{display:block;font:600 13px/1.2 'Segoe UI','Nirmala UI',sans-serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
    ".wide .i.run:after{right:8px;top:50%;margin-top:-4px}" +
    ".wide .sep{width:auto;margin:3px 6px}" +
    ".wide .mx{width:auto;display:flex;align-items:center;justify-content:center;gap:8px;font:600 12px 'Segoe UI','Nirmala UI',sans-serif}" +
    ".mini{position:fixed;right:8px;bottom:12px}.mini .k{margin:0;box-shadow:0 6px 18px rgba(11,20,55,.4)}" +
    ".ov{position:fixed;inset:0;background:rgba(11,20,55,.45);display:grid;place-items:center;font-family:'Segoe UI','Nirmala UI',sans-serif}" +
    ".dlg{width:380px;max-width:calc(100vw - 32px);background:linear-gradient(180deg,#eef0ff,#e3e6fb);border:1px solid #c9cef3;border-radius:16px;overflow:hidden;box-shadow:0 20px 60px rgba(11,20,55,.45);color:#1e1b4b}" +
    ".dlg .dh{padding:12px 14px;color:#fff;background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);font:700 15px 'Segoe UI','Nirmala UI',sans-serif;position:relative}" +
    ".dlg .dh:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".dlg .db{padding:12px 14px;font-size:13px;line-height:1.5}.dlg ul{margin:6px 0 8px;padding-left:18px}.dlg li b{color:#be123c}" +
    ".dlg .bt{display:flex;flex-direction:column;gap:7px;padding:0 14px 14px}" +
    ".dlg button{height:38px;border-radius:11px;font:600 13px 'Segoe UI','Nirmala UI',sans-serif;cursor:pointer;border:1px solid #d4d8f5;background:#f5f6ff;color:#1e1b4b}" +
    ".dlg button.p{border:0;color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.dlg button.w{color:#be123c;border-color:#fecdd3;background:#fff}";

  var host, root, rail, tip, collapsed = false, wide = false, features = {}, hidden = {}, docked = {};
  try { collapsed = localStorage.getItem("kd_collapsed") === "1"; wide = localStorage.getItem("kd_wide") === "1"; } catch (e) {}
  // bar-এর চওড়া: সাধারণ 58px, Maximize (নাম সহ) 200px
  function W() { return wide && !collapsed ? 200 : 58; }

  function $(id) { return document.getElementById(id); }
  function npciRunning() { try { var r = JSON.parse(localStorage.getItem("khnp_run") || "null"); return !!(r && r.active); } catch (e) { return false; } }
  function present(d) { return !!($(d.host) || (d.btn && $(d.btn)) || (d.api && window[d.api])); }
  function isOpen(d) { var h = $(d.host); return !!(h && h.style.display !== "none" && !hidden[d.f]); }

  // Panel-কে rail-এর পাশে বসানো (একবারই; পরে user টেনে সরালে সেটাই থাকবে)
  function dock(d) {
    var h = $(d.host); if (!h || docked[d.f] || d.api) return; docked[d.f] = true;
    if (h.hasAttribute("data-kdpos")) return;                      // user নিজে টেনে রেখেছে (MR Fill panel): সেখানেই থাকে
    if (d.f === "caste") { var b = $(d.btn); if (b) b.style.right = (W() + 14) + "px"; return; }
    h.setAttribute("data-kd", "drawer");
    if (d.f === "bank") { h.style.right = W() + "px"; return; }   // bottom bar: stays at the bottom, just clears the rail
    if (d.f === "mr") { h.style.top = "0"; h.style.bottom = "auto"; h.style.right = W() + "px"; h.style.left = "auto"; return; }
    h.style.top = "0"; h.style.right = W() + "px"; h.style.left = "auto";
  }
  // Maximize / ছোট করলে rail-এর পাশে বসা panel-গুলোও সরে যায় (user নিজে টেনে সরালে সেটাতে হাত দেয় না)
  function setWide(on) {
    var o = W(); wide = on;
    try { localStorage.setItem("kd_wide", on ? "1" : "0"); } catch (e) {}
    reflow(o);
  }
  function setCollapsed(on) { var o = W(); collapsed = on; try { localStorage.setItem("kd_collapsed", on ? "1" : "0"); } catch (e) {} reflow(o); }
  function reflow(o) {
    var old = o + "px", now = W() + "px";
    FEATS.concat([{ host: "kdrd-host" }]).forEach(function (d) {
      if (d === "|") return;
      var h = $(d.host); if (h && h.style.right === old) h.style.right = now;
      if (d.btn && $(d.btn) && $(d.btn).style.right === (parseInt(old, 10) + 14) + "px") $(d.btn).style.right = (W() + 14) + "px";
    });
    if (tip) tip.classList.remove("on");
    render();
  }
  function setPad() {
    try { document.documentElement.style.setProperty("padding-right", collapsed ? "" : W() + "px", "important"); } catch (e) {}
  }
  function showTip(el, d, extra) {
    var r = el.getBoundingClientRect();
    tip.innerHTML = d.t + (extra ? "<small>" + extra + "</small>" : "");
    tip.style.top = Math.max(6, r.top + 4) + "px"; tip.style.right = (W() + 8) + "px"; tip.classList.add("on");
  }
  // এখন কোন কাজ চলছে: portal-এর run (localStorage) আর এই page-এর panel-এ চালু Stop button
  function lsActive(k) { try { var r = JSON.parse(localStorage.getItem(k) || "null"); return !!(r && r.active); } catch (e) { return false; } }
  function runningJobs() {
    var out = [];
    if (lsActive("dxwd_run")) out.push("Work Demand");
    if (lsActive("dxwa_run")) out.push("Work Allocation");
    if (lsActive("khnp_run")) out.push("ABPS Enable (NPCI)");
    if (lsActive("mrfa_run")) out.push("Fill Attendance only");
    if (lsActive("mrfp_run")) out.push("Payment only");
    try { var kb = JSON.parse(localStorage.getItem("kdbank_state_v1") || "null"); if (kb && kb.running) out.push("Bank A/c Update"); } catch (e) {}
    FEATS.forEach(function (d) {
      if (d === "|" || out.indexOf(d.t) >= 0) return;
      var h = $(d.host); if (!h) return;
      var scope = h.shadowRoot || h;
      var live = [].slice.call(scope.querySelectorAll("button")).some(function (b) { return !b.disabled && /stop/i.test(b.textContent || "") && b.offsetParent !== null; });
      if (live) out.push(d.t);
    });
    return out;
  }
  function go(d, newTab) {
    var url = location.origin + d.url;
    if (newTab) window.open(url, "_blank"); else location.href = url;
  }
  function warn(d, jobs) {
    var ov = document.createElement("div"); ov.className = "ov";
    var dlg = document.createElement("div"); dlg.className = "dlg";
    var dh = document.createElement("div"); dh.className = "dh"; dh.textContent = "⚠ এখন কাজ চলছে";
    var db = document.createElement("div"); db.className = "db";
    db.appendChild(document.createTextNode("এই কাজগুলো এখনো শেষ হয়নি:"));
    var ul = document.createElement("ul");
    jobs.forEach(function (j) { var li = document.createElement("li"); var b = document.createElement("b"); b.textContent = j; li.appendChild(b); ul.appendChild(li); });
    db.appendChild(ul);
    db.appendChild(document.createTextNode("এই tab-এ " + d.t + " page খুললে চলমান কাজ থেমে যাবে। নতুন tab-এ খুললে কাজ চলতে থাকবে।"));
    var bt = document.createElement("div"); bt.className = "bt";
    var b1 = document.createElement("button"); b1.className = "p"; b1.textContent = "নতুন tab-এ খুলুন (ভালো)";
    var b2 = document.createElement("button"); b2.className = "w"; b2.textContent = "তবুও এই tab-এ খুলুন";
    var b3 = document.createElement("button"); b3.textContent = "বাতিল";
    var close = function () { ov.remove(); };
    b1.onclick = function () { close(); go(d, true); };
    b2.onclick = function () { close(); go(d, false); };
    b3.onclick = close; ov.onclick = function (e) { if (e.target === ov) close(); };
    bt.append(b1, b2, b3); dlg.append(dh, db, bt); ov.appendChild(dlg); root.appendChild(ov);
  }
  function click(d) {
    if (features[d.f] === false) return;
    var h = $(d.host);
    if (d.api && window[d.api]) {
      window[d.api].toggle();                          // নিজের panel নিজে খোলে/বন্ধ করে
    } else if (h) {
      var open = isOpen(d); hidden[d.f] = open; h.style.display = open ? "none" : "";
    } else if (d.btn && $(d.btn)) {
      $(d.btn).click();
    } else if (d.url) {
      tip.classList.remove("on");
      var jobs = runningJobs();
      if (jobs.length) warn(d, jobs); else go(d, false);
    }
    paint();
  }
  function build() {
    host = document.createElement("div"); host.id = "kdock-host";
    host.style.cssText = "position:fixed;right:0;top:0;width:0;height:0;z-index:2147483646;";
    document.body.appendChild(host);
    var ps = document.createElement("style"); ps.textContent = "@media print{#kdock-host{display:none!important}html{padding-right:0!important}}";
    (document.head || document.documentElement).appendChild(ps);
    root = host.attachShadow({ mode: "open" });
    var st = document.createElement("style"); st.textContent = CSS; root.appendChild(st);
    tip = document.createElement("div"); tip.className = "tip"; root.appendChild(tip);
    rail = document.createElement("div"); root.appendChild(rail);
    render();
  }
  function render() {
    rail.innerHTML = ""; setPad();
    if (collapsed) {
      rail.className = "mini";
      var km = document.createElement("button"); km.className = "k"; km.textContent = "K"; km.title = "K-Desk খুলুন";
      km.onclick = function () { setCollapsed(false); };
      rail.appendChild(km); return;
    }
    rail.className = "rail" + (wide ? " wide" : "");
    var kh = document.createElement("div"); kh.className = "kh";
    var k = document.createElement("button"); k.className = "k"; k.textContent = "K";
    k.onmouseenter = function () { showTip(k, { t: "K-Desk Suite" }, "by Koushik · click করলে bar ছোট হবে"); };
    k.onmouseleave = function () { tip.classList.remove("on"); };
    k.onclick = function () { setCollapsed(true); };
    var kt = document.createElement("div"); kt.className = "kt"; kt.innerHTML = "K-Desk Suite<small>by Koushik</small>";
    kh.append(k, kt); rail.appendChild(kh);
    FEATS.forEach(function (d) {
      if (d === "|") { var s = document.createElement("div"); s.className = "sep"; rail.appendChild(s); return; }
      var b = document.createElement("button"); b.className = "i"; b.dataset.f = d.f;
      b.innerHTML = '<svg viewBox="0 0 24 24">' + ICON[d.f] + "</svg>";
      var lb = document.createElement("span"); lb.className = "lb"; lb.textContent = d.t; b.appendChild(lb);
      b.onmouseenter = function () {
        var extra = features[d.f] === false ? "Dashboard-এ Off করা আছে" : present(d) ? (isOpen(d) ? "click করলে লুকাবে" : "click করলে খুলবে") : d.where;
        showTip(b, d, extra);
      };
      b.onmouseleave = function () { tip.classList.remove("on"); };
      b.onclick = function () { click(d); };
      rail.appendChild(b);
    });
    // নিচে Maximize বোতাম: চাপলে icon-এর সাথে নাম দেখায়, আবার চাপলে শুধু icon
    var mx = document.createElement("button"); mx.className = "mx";
    mx.innerHTML = wide ? '<svg viewBox="0 0 24 24"><path d="M13 6l6 6-6 6M5 6l6 6-6 6"/></svg><span>ছোট করুন</span>' : '<svg viewBox="0 0 24 24"><path d="M11 6l-6 6 6 6M19 6l-6 6 6 6"/></svg>';
    mx.onmouseenter = function () { if (!wide) showTip(mx, { t: "Maximize" }, "icon-এর সাথে নাম দেখাবে"); };
    mx.onmouseleave = function () { tip.classList.remove("on"); };
    mx.onclick = function () { setWide(!wide); };
    rail.appendChild(mx);
    paint();
  }
  function paint() {
    if (collapsed || !rail) return;
    FEATS.forEach(function (d) {
      if (d === "|") return;
      var b = rail.querySelector('[data-f="' + d.f + '"]'); if (!b) return;
      var off = features[d.f] === false, here = !off && present(d);
      if (here) dock(d);
      b.className = "i" + (off ? " off" : "") + (here ? " here" : "") + (here && isOpen(d) && d.f !== "caste" ? " open" : "") +
        ((d.f === "npci" && !off && npciRunning()) || (d.f === "mrattend" && !off && lsActive("mrfa_run")) || (d.f === "mrpay" && !off && lsActive("mrfp_run")) ? " run" : "");
      if (d.f === "caste" && here && $(d.host)) b.className += " open";
    });
  }

  // kux.js-এর keyboard shortcut (Alt+K) এখান দিয়ে bar ছোট/বড় করে
  window.KDOCK = { width: W, toggle: function () { if (!rail) return; setCollapsed(!collapsed); } };

  KH_LICENSE.check(function (ok) {
    if (!ok) return;
    chrome.storage.local.get(["kh_features", "kh_off"], function (r) {
      if (r && r.kh_off) return;                                 // K-Desk OFF
      features = Object.assign({}, (r && r.kh_features) || {}, { abps: true, npci: true });   // এ দুটো সবসময় On
      if (features.dock === false) return;
      build();
      setInterval(paint, 1000);
    });
  });
})();
