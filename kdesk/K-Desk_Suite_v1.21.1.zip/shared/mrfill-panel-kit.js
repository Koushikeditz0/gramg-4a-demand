/* =====================================================================
   mrfill-panel-kit.js — K-Desk Suite by Koushik · MR Fill panel helpers (Fill Attendance only / Payment only, isolated world)
   Attendance আর Payment panel-এর একই অংশগুলো: style, work list (tick/search/paste), run summary,
   log, Excel download, drag/minimise। Run state থাকে portal-এর localStorage-এ (driver-এর সাথে ভাগ করা)।
   ===================================================================== */
(function () {
  "use strict";
  if (window.MRF_PANEL) return;

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function fmtTime(t) { if (!t) return ""; var d = new Date(t); return isNaN(d) ? "" : pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()); }
  function fmtStamp(t) { if (!t) return ""; var d = new Date(t); return isNaN(d) ? "" : pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + " " + fmtTime(t); }

  var STYLE =
    ".panel{width:380px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:13px;color:#1e1b4b;background:linear-gradient(180deg,#f3f4ff,#e8eafc);border:1px solid #c9cef3;border-radius:16px;box-shadow:0 18px 50px rgba(30,27,75,.30);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:10px 12px;display:flex;align-items:center;justify-content:space-between}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hdl{display:flex;align-items:center;gap:9px;min-width:0}.ttl b{display:block;font-size:14px}.ttl small{display:block;font-size:10px;color:#c7d2fe;letter-spacing:.6px;text-transform:uppercase}" +
    ".logo{width:28px;height:28px;border-radius:8px;flex:0 0 auto;display:grid;place-items:center;font:800 15px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}.ttl small i{font-style:normal;color:#f5b942;font-weight:600;text-transform:none}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:24px;height:24px;border-radius:6px;font-size:15px;line-height:1}" +
    ".bd{padding:10px 12px;max-height:80vh;overflow:auto}" +
    ".sec0{display:flex;justify-content:space-between;align-items:center;font-weight:700;color:#3730a3;font-size:12px;margin:8px 0 4px}.cnt{font-weight:400;color:#5b6472;font-size:11px}" +
    ".row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:7px;font-size:12px}.lbl{font-weight:700;color:#3730a3;min-width:92px}" +
    ".inp{border:1px solid #c9d3e6;border-radius:7px;padding:5px 7px;font:12px 'Segoe UI',Arial,sans-serif;background:#fff}.inp.num{width:70px}.inp.dt{width:92px}" +
    ".lk{background:none;border:none;color:#3730a3;cursor:pointer;font-size:11.5px;padding:0;text-decoration:underline}" +
    ".list{max-height:170px;overflow:auto;border:1px solid #d4d8f5;background:#fff;border-radius:8px;padding:3px 7px;margin-top:6px}" +
    ".w{display:flex;align-items:center;gap:6px;font:11.5px Consolas,monospace;padding:2px 0;cursor:pointer}.w input{margin:0;accent-color:#3730a3}" +
    ".chk{display:inline-flex;align-items:center;gap:5px;cursor:pointer}.chk input{margin:0;accent-color:#3730a3}" +
    ".days{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}.day{width:30px;padding:3px 0;border-radius:6px;border:1px solid #c9cef3;background:#fff;color:#1e1b4b;font:600 11.5px 'Segoe UI',Arial;cursor:pointer;text-align:center}" +
    ".day small{display:block;font-weight:400;font-size:8.5px;color:#6b7280}.day.on{background:#c5221f;border-color:#c5221f;color:#fff}.day.on small{color:#fde2e1}" +
    ".note{font-size:11px;color:#5b6472;margin-top:4px;line-height:1.4}" +
    ".btn{padding:8px 9px;border:none;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;min-height:34px}" +
    ".btnrow{display:flex;gap:6px;margin-top:7px}.btnrow .btn{flex:1}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.fill:disabled{background:#f3e3bd;color:#8a7a55;cursor:not-allowed}" +
    ".btn.stop{background:#c5221f;color:#fff}.btn.stop:disabled{background:#e6a6a4;cursor:not-allowed}" +
    ".btn.ghost{background:#f5f6ff;color:#1e1b4b;border:1px solid #d4d8f5}.btn.ghost:disabled{color:#aab;cursor:not-allowed}" +
    ".btn.ghost.danger{background:#fff1f2;color:#be123c;border-color:#fecdd3}.btn.ghost.danger:disabled{background:#f5f6ff;color:#c9a9a8;border-color:#e6d3d2}" +
    ".summary{font-size:12px;color:#1e1b4b;background:#fff;border:1px solid #d4d8f5;border-left:4px solid #f5b942;border-radius:10px;padding:8px 10px;line-height:1.45}" +
    ".summary .cur{color:#5b6472;display:inline-block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;vertical-align:top}" +
    ".prog{margin:8px 0}.progbar{height:8px;background:#d4d8f5;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#e08e0b;transition:width .3s}" +
    ".progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".cfm{margin:8px 0;padding:8px;border:1px solid #f2d98a;background:#fef7e0;border-radius:9px;font-size:11.5px;color:#5a4300;line-height:1.45}.cfmh{font-weight:700;color:#9a6700;margin-bottom:4px}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:7px;background:#f5f6ff;min-height:15px;line-height:1.35}.st.ok{background:#dcfce7;color:#166534}.st.warn{background:#fef3c7;color:#92400e}" +
    ".sec{font-weight:700;color:#3730a3;margin:10px 0 6px;border-top:1px solid #d4d8f5;padding-top:8px;font-size:12px}" +
    ".logbox{max-height:150px;overflow:auto;font-size:10.5px;line-height:1.4;background:#0b1437;color:#cbd5e1;border-radius:8px;padding:6px 8px}" +
    ".logbox div{padding:1px 0;border-bottom:1px dotted #1e2a5a}.l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#cbd5e1}" +
    ".logbox .lt{display:inline-block;color:#aab2c0;margin-right:6px}" +
    ".hint{font-size:11px;color:#666;padding:4px 0}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#7a8090;line-height:1.35;background:#f5f6ff;border:1px solid #d4d8f5;border-radius:7px;padding:5px 7px}" +
    ".foot{margin-top:8px;padding-top:6px;border-top:1px solid #d4d8f5;display:flex;justify-content:space-between;font-size:10.5px;color:#5b5f8a}.foot b{color:#1e1b4b}.foot em{font-style:normal;color:#c2770a}" +
    ".statbox{max-height:220px;overflow:auto;background:#fff;border:1px solid #d4d8f5;border-radius:8px;padding:2px 0}" +
    ".sl{display:flex;gap:7px;align-items:baseline;padding:4px 8px;border-bottom:1px solid #eef0fb;font-size:11.5px;line-height:1.35}.sl:last-child{border-bottom:none}" +
    ".sl .ic{flex:0 0 auto}.sl .wc{font:600 11.5px Consolas,monospace;color:#1e1b4b;flex:0 0 auto}.sl .mr{color:#6b7280;font-size:10.5px;flex:0 0 auto}.sl .tx{margin-left:auto;text-align:right}" +
    ".sl.ok .tx{color:#166534;font-weight:700}.sl.test .tx{color:#3730a3;font-weight:600}.sl.man{background:#fff1f2}.sl.man .tx{color:#c5221f;font-weight:700}.sl.skip .tx{color:#92400e}.sl.err .tx{color:#c5221f}" +
    "[hidden]{display:none!important}";

  /* cfg: { ns, hostId, title, sub, setupHtml, ifOnlyDefault, logName, sheetName, cols:[[head,key,width]],
            confirmHtml(works), validate(), makeRun(works), modeText(run), onBuilt(sel, api) } */
  window.MRF_PANEL = function (cfg) {
    var NS = cfg.ns, LS_RUN = NS + "_run", LS_PREFS = NS + "_prefs", MIN_KEY = NS + "_min", MIRROR = NS + "LastRun";
    var sel = {}, confirming = false, P = NS + "_";
    function $(id) { return document.getElementById(id); }
    function loadRun() { try { return JSON.parse(localStorage.getItem(LS_RUN) || "null"); } catch (e) { return null; } }
    function saveRun(r) { try { r.updatedAt = Date.now(); localStorage.setItem(LS_RUN, JSON.stringify(r)); } catch (e) {} }
    function post(type) { try { window.postMessage({ source: NS.toUpperCase() + "_UI", type: type }, "*"); } catch (e) {} }
    function prefs() { try { return JSON.parse(localStorage.getItem(LS_PREFS) || "null") || {}; } catch (e) { return {}; } }
    function savePrefs(p) { try { localStorage.setItem(LS_PREFS, JSON.stringify(p)); } catch (e) {} }
    function status(msg, kind) { if (!sel.st) return; sel.st.textContent = msg || ""; sel.st.className = "st" + (kind ? " " + kind : ""); }

    /* ---------------------- works on this page ---------------------- */
    function allWorks() {
      var s = $("ddlWorkCode"); if (!s) return [];
      var ifOnly = cfg.excelOnly ? false : sel.ifo ? sel.ifo.checked : cfg.ifOnlyDefault;
      return [].filter.call(s.options, function (o) { return o.value && !/select/i.test(o.text) && (!ifOnly || /\/IF\//i.test(o.value)); }).map(function (o) { return o.value; });
    }
    // the dropdown value can be "Work name(3208…/IF/IAY/…)" — show the code part
    function code(w) { var m = /\(([^()]*\/[^()]*)\)\s*$/.exec(w); return m ? m[1] : w; }
    function ticks() { return prefs().ticks || {}; }
    function setTicks(t) { var p = prefs(); p.ticks = t; savePrefs(p); }
    function shown() {
      var q = String(sel.q && sel.q.value || "").trim(), list = allWorks();
      if (!q) return list;
      var parts = q.split(/[\s,;]+/).filter(Boolean);
      if (parts.length > 1) return list.filter(function (w) { var c = code(w).toLowerCase(); return parts.some(function (p) { p = p.toLowerCase(); return c === p || c.slice(-p.length) === p; }); });
      return list.filter(function (w) { return w.toLowerCase().indexOf(q.toLowerCase()) >= 0; });
    }
    function picked() { if (cfg.excelOnly && cfg.pickWorks) return cfg.pickWorks(); var t = ticks(); return allWorks().filter(function (w) { return t[w]; }); }
    function poGp() {
      var s = document.querySelector("select[id$='ddlPanchayat']"); if (!s || ![].some.call(s.options, function (o) { return String(o.value || "").replace(/\D/g, "").length >= 10; })) return null;
      var o = s.selectedIndex >= 0 ? s.options[s.selectedIndex] : null;
      var v = o ? String(o.value || "").replace(/\D/g, "") : "", name = o ? String(o.text || "").replace(/\s+/g, " ").trim() : "";
      var ok = v.length >= 10 && !!name && !/select/i.test(name);
      return { picked: ok, gp10: ok ? v.slice(0, 10) : "", name: ok ? name : "" };
    }

    /* ---------------------- actions ---------------------- */
    function askStart() {
      var r = loadRun(), po = poGp();
      if (po && !po.picked) { status("আগে form-এ Panchayat বাছুন।", "warn"); return; }
      if (r && !r.finishedAt && !r.active) {                     // resume
        if (po && r.gp && r.gp.gp10.slice(4) !== po.gp10.slice(4)) { status("This run is for " + (r.gp.name || r.gp.gp10) + " — pick it in the form, then Resume.", "warn"); return; }
        var pz = r.paused; if (pz && cfg.onResume) cfg.onResume(r, pz); r.paused = null;
        r.active = true; r.stopRequested = false; r.consec = 0; r.selKey = null; r.selTries = 0;
        (r.log = r.log || []).push({ t: Date.now(), level: "info", text: "Resumed." + (pz ? " MR " + pz.msr + " of " + code(pz.work) + " left as you fixed it." : "") });
        saveRun(r); post("start"); render(); return;
      }
      var w = picked();
      if (!w.length) { status(cfg.excelOnly ? "আগে Excel upload করুন — এই page-এ Excel-এর কোনো work পাওয়া যায়নি।" : "অন্তত একটা work-এ tick দিন।", "warn"); return; }
      var bad = cfg.validate(); if (bad) { status(bad, "warn"); return; }
      confirming = true;
      sel.cfmtxt.innerHTML = cfg.confirmHtml(w);
      render();
    }
    function doStart() {
      var w = picked(); if (!w.length) return;
      var bad = cfg.validate(); if (bad) { confirming = false; status(bad, "warn"); render(); return; }
      var po = poGp();
      var r = cfg.makeRun(w), pre = r.preSkip || [];
      delete r.preSkip;
      w = w.filter(function (x) { return !pre.some(function (s) { return s.work === x; }); });
      if (!w.length) { confirming = false; status("কোনো tick দেওয়া work চালানো যাবে না: " + (pre[0] ? pre[0].why : ""), "warn"); render(); return; }
      r.v = 1; r.runId = NS + "-" + Date.now(); r.active = true; r.stopRequested = false; r.startedAt = Date.now(); r.works = w; r.wi = 0;
      r.gp = po && po.picked ? { gp10: po.gp10, name: po.name } : null;
      r.done = {}; r.results = []; r.stats = { saved: 0, skipped: pre.length, notSaved: 0, errors: 0 }; r.consec = 0;
      pre.forEach(function (s) { r.results.push({ t: Date.now(), work: s.work, msr: "—", from: "", to: "", workers: 0, detail: "", result: "Skipped", msg: s.why }); });
      r.log = [{ t: Date.now(), level: "info", text: "Run started: " + w.length + " work(s), " + cfg.modeText(r) + (r.dryRun ? " — TEST RUN, Save is not pressed" : "") + "." }];
      if (pre.length) r.log.push({ t: Date.now(), level: "warn", text: pre.length + " ticked work(s) skipped before start: " + pre[0].why + (pre.length > 1 ? " (and others — see the log Excel)" : "") });
      confirming = false; saveRun(r); post("start"); render();
    }
    function doStop() { var r = loadRun(); if (!r) return; r.stopRequested = true; saveRun(r); post("stop"); status("Stopping…", "warn"); render(); }
    function doNew() {
      var r = loadRun();
      if (r && r.active) { status("আগে run থামান (Stop)।", "warn"); return; }
      try { localStorage.removeItem(LS_RUN); } catch (e) {}
      confirming = false; status("মুছে দেওয়া হয়েছে। Work-এ tick দিয়ে Start চাপুন।", "ok"); render();
    }

    /* ---------------------- Excel ---------------------- */
    function download(problemsOnly) {
      var go = function (run) {
        var rows = (run && run.results) || [];
        if (problemsOnly) {
          // "Retry later" row-এর পরে একই MR-এর নতুন ফল থাকলে শুধু সেই নতুন ফলটাই গোনে
          var last = {}; rows.forEach(function (x, i) { last[x.work + "|" + x.msr] = i; });
          rows = rows.filter(function (x, i) { return x.result !== "Saved" && x.result !== "Would save (test)" && !(x.result === "Retry later" && last[x.work + "|" + x.msr] !== i); });
        }
        if (!rows.length) { status(problemsOnly ? "কোনো MR skip বা not saved হয়নি।" : "Log খালি।", "warn"); return; }
        if (!window.XLSX) { status("Spreadsheet library load হয়নি — page reload করুন।", "warn"); return; }
        var aoa = [["Work Code", "Muster Roll No", "Date From", "Date To", "Workers", "Details", "Result", "Reason / portal message", "Time"]];
        rows.forEach(function (x) { aoa.push([code(x.work), x.msr, x.from, x.to, x.workers, x.detail, x.result, x.msg, fmtStamp(x.t)]); });
        var ws = XLSX.utils.aoa_to_sheet(aoa), wb = XLSX.utils.book_new();
        ws["!cols"] = [{ wch: 30 }, { wch: 12 }, { wch: 11 }, { wch: 11 }, { wch: 8 }, { wch: 44 }, { wch: 18 }, { wch: 60 }, { wch: 20 }];
        XLSX.utils.book_append_sheet(wb, ws, problemsOnly ? "Skipped - not saved" : cfg.sheetName);
        var d = new Date(), name = cfg.logName + "-" + (problemsOnly ? "skipped" : "log") + "-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
        XLSX.writeFile(wb, name);
        status("Saved " + name + " — " + rows.length + " row(s).", "ok");
      };
      var r = loadRun(); if (r && r.results && r.results.length) return go(r);
      try { chrome.storage.local.get(MIRROR, function (d) { go(d && d[MIRROR]); }); } catch (e) { go(null); }
    }
    var lastMirror = 0;
    function mirror(r) {
      if (!r || !r.results || Date.now() - lastMirror < 3000) return; lastMirror = Date.now();
      try { var o = {}; o[MIRROR] = { runId: r.runId, startedAt: r.startedAt, results: r.results }; chrome.storage.local.set(o); } catch (e) {}
    }

    /* ---------------------- render ---------------------- */
    var lastList = "";
    // Status box: one line per muster roll the run reached, newest first
    function tail(w) { var c = code(w).split("/"); return c.length >= 2 ? c.slice(-2).join("/") : c[0]; }
    var lastStat = "";
    function renderStatus(r) {
      if (!sel.stat) return;
      var R = (r && r.results) || [], key = R.length + "|" + (R.length ? R[R.length - 1].t : 0);
      if (key === lastStat) return; lastStat = key;
      sel.statsec.hidden = sel.stat.hidden = !R.length || !cfg.statusLine;
      var h = "";
      for (var k = R.length - 1, n = 0; k >= 0 && n < 400; k--, n++) h += cfg.statusLine ? cfg.statusLine(R[k], esc, tail) : "";
      sel.stat.innerHTML = h;
    }
    function renderWorks(lock) {
      if (cfg.excelOnly) { sel.cnt.textContent = ""; return; }
      var t = ticks(), list = shown(), key = (lock ? "L" : "") + JSON.stringify(t) + "|" + list.join(",").length + "|" + list.length + "|" + (sel.q.value || "") + "|" + sel.ifo.checked + "|" + (cfg.tagKey ? cfg.tagKey() : "");
      if (key === lastList) return; lastList = key;
      sel.list.innerHTML = list.length ? list.map(function (w) {
        return "<label class='w'><input type='checkbox' data-w='" + esc(w) + "'" + (t[w] ? " checked" : "") + (lock ? " disabled" : "") + "><span>" + esc(code(w)) + "</span>" + (cfg.workTag ? cfg.workTag(w) : "") + "</label>";
      }).join("") : "<div class='hint'>" + (allWorks().length ? "Search-এর সাথে কোনো work মেলেনি।" : "এই page-এ কোনো work নেই।") + "</div>";
      sel.cnt.textContent = picked().length + " of " + allWorks().length + " work(s) ticked";
    }
    function render() {
      if (!sel.sum) return;
      var r = loadRun(), active = !!(r && r.active), s = (r && r.stats) || {};
      var running = !!(r && !r.finishedAt);
      renderWorks(running);
      sel.setup.hidden = running;
      sel.cfm.hidden = !confirming || active;
      if (!r) { sel.sum.innerHTML = cfg.idleHtml; sel.prog.hidden = true; }
      else {
        var N = (r.works || []).length, wi = Math.min(r.wi, N - 1);
        sel.sum.innerHTML = (r.paused && !active ? "<b style='color:#c5221f'>⏸ Paused — MR " + esc(r.paused.msr) + " হাতে ঠিক করে Save করুন, তারপর Resume</b><br>" : "") +
          (r.finishedAt ? "✓ Finished · " : active ? "Running · " : "Paused · ") + "work <b>" + Math.min(r.wi + 1, N) + "/" + N + "</b> " + esc(code((r.works || [])[wi] || "")) +
          "<br>Saved <b>" + (s.saved || 0) + "</b> · skipped <b>" + (s.skipped || 0) + "</b> · not saved <b>" + (s.notSaved || 0) + "</b> · errors <b>" + (s.errors || 0) + "</b>" + (s.manual ? " · <span style='color:#c5221f'>manual <b>" + s.manual + "</b></span>" : "") + (s.later ? " · পরে আবার <b>" + s.later + "</b>" + (r.pass === 2 ? " (২য় দফা চলছে)" : "") : "") +
          (r.dryRun ? " · <b>TEST RUN</b>" : "") + "<br>" + esc(cfg.modeText(r)) +
          (active ? "<br><span class='cur'>Now: " + esc(code(r.current || "working…")) + "</span>" : "");
        sel.prog.hidden = false;
        var dn = r.finishedAt ? N : r.wi, pct = N ? Math.round(100 * dn / N) : 0;
        sel.fill.style.width = pct + "%"; sel.ptxt.textContent = dn + " of " + N + " work(s) done";
      }
      sel.start.textContent = r && !r.finishedAt && !active ? "▶ Resume" : "▶ Start";
      sel.start.disabled = active || confirming;
      sel.stop.disabled = !active;
      sel.newr.disabled = active || !r;
      var has = !!(r && r.results && r.results.length);
      sel.dl.disabled = !has; sel.dlf.disabled = !has;
      var L = (r && r.log) || [], h = "";
      for (var k = L.length - 1, n = 0; k >= 0 && n < 300; k--, n++) h += "<div class='l-" + esc(L[k].level || "info") + "'><span class='lt'>" + esc(fmtTime(L[k].t)) + "</span>" + esc(L[k].text) + "</div>";
      sel.logbox.innerHTML = h || "<div class='l-info'>এখনো কিছু হয়নি।</div>";
      renderStatus(r);
      mirror(r);
      if (cfg.onRender) { try { cfg.onRender(r); } catch (e) {} }
    }

    /* ---------------------- panel ---------------------- */
    var HTML =
      "<div class='hd' id='" + P + "hd'><span class='hdl'><span class='logo'>K</span><span class='ttl'><b>" + cfg.title + "</b><small><i>K-Desk</i> Suite · " + cfg.sub + "</small></span></span><button class='mn' id='" + P + "min'>–</button></div>" +
      "<div class='bd' id='" + P + "bd'>" +
      "<div class='summary' id='" + P + "sum'></div>" +
      (cfg.statusTop ? "<div class='statbox' id='" + P + "stat' hidden></div><span id='" + P + "statsec' hidden></span>" : "") +
      "<div id='" + P + "setup'>" +
        "<div id='" + P + "wsec'" + (cfg.excelOnly ? " hidden" : "") + ">" +
        "<div class='sec0'><span>Works</span><span class='cnt' id='" + P + "cnt'></span></div>" +
        "<div class='row' style='margin-top:0'><input class='inp' id='" + P + "q' placeholder='Search, বা Excel থেকে work code paste' style='flex:1'><label class='chk'><input type='checkbox' id='" + P + "ifo'>IF only</label></div>" +
        "<div class='row' style='margin-top:4px'><button class='lk' id='" + P + "all'>Tick shown</button><button class='lk' id='" + P + "none'>Untick all</button></div>" +
        "<div class='list' id='" + P + "list'></div>" +
        "</div>" +
        cfg.setupHtml +
        "<div class='row'><label class='chk'><input type='checkbox' id='" + P + "dry'>Test run: ভরবে, কিন্তু Save চাপবে না</label></div>" +
      "</div>" +
      "<div class='prog' id='" + P + "prog' hidden><div class='progbar'><div class='progfill' id='" + P + "fill'></div></div><div class='progtxt' id='" + P + "ptxt'></div></div>" +
      "<div class='cfm' id='" + P + "cfm' hidden><div class='cfmh'>⚠ " + cfg.confirmHead + "</div><div id='" + P + "cfmtxt'></div>" +
        "<div class='btnrow'><button class='btn fill' id='" + P + "yes'>হ্যাঁ, শুরু করুন</button><button class='btn ghost' id='" + P + "no'>বাতিল</button></div></div>" +
      "<div class='btnrow'><button class='btn fill' id='" + P + "start'>▶ Start</button><button class='btn stop' id='" + P + "stop'>■ Stop</button></div>" +
      (cfg.compact ?
        "<div class='btnrow'><button class='btn ghost sm' id='" + P + "dl'>⭳ Log</button><button class='btn ghost sm' id='" + P + "dlf'>⭳ Skipped</button><button class='btn ghost danger sm' id='" + P + "new'>↺ New run</button></div>" :
        "<div class='btnrow'><button class='btn ghost' id='" + P + "dl'>⭳ Download log</button><button class='btn ghost' id='" + P + "dlf'>⭳ Skipped / not saved</button></div>" +
        "<div class='btnrow'><button class='btn ghost danger' id='" + P + "new'>↺ New run (clear)</button></div>") +
      "<div class='st' id='" + P + "st'></div>" +
      (cfg.statusTop ? "" : "<div class='sec' id='" + P + "statsec' hidden>Status</div><div class='statbox' id='" + P + "stat' hidden></div>") +
      "<div class='sec'>Activity</div><div class='logbox' id='" + P + "logbox'></div>" +
      "<div class='disclaimer'>" + cfg.disclaimer + "</div>" +
      "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>K-Desk v<span id='" + P + "ver'></span></em></div>" +
      "</div>";

    function minSaved() { try { return localStorage.getItem(MIN_KEY) === "1"; } catch (e) { return false; } }
    function minSave(on) { try { localStorage.setItem(MIN_KEY, on ? "1" : "0"); } catch (e) {} }

    function build() {
      try { var old = document.getElementById(cfg.hostId); if (old) old.remove(); } catch (e) {}
      var host = document.createElement("div"); host.id = cfg.hostId;
      // K-Desk: শুরু থেকেই K-Dock-এর পাশে (ডান দিকে) বসে, তাই reload-এ বাঁ→ডান লাফায় না
      var kdW = 58; try { if (localStorage.getItem("kd_wide") === "1" && localStorage.getItem("kd_collapsed") !== "1") kdW = 200; } catch (e) {}
      host.style.cssText = "position:fixed;top:0;right:" + kdW + "px;left:auto;z-index:2147483646;";
      // আগে টেনে যেখানে রাখা হয়েছিল, reload-এর পরেও সেখানে (header-এ double-click করলে আবার K-Dock-এর পাশে)
      var POS_KEY = NS + "_pos", pos = null;
      try { pos = JSON.parse(localStorage.getItem(POS_KEY) || "null"); } catch (e) {}
      if (pos && pos.l >= 0 && pos.t >= 0 && pos.l < window.innerWidth - 60 && pos.t < window.innerHeight - 40) {
        host.style.left = pos.l + "px"; host.style.top = pos.t + "px"; host.style.right = "auto"; host.setAttribute("data-kdpos", "1");
      }
      (document.body || document.documentElement).appendChild(host);
      var root = host.attachShadow({ mode: "open" });
      var css = document.createElement("style"); css.textContent = STYLE + (cfg.style || ""); root.appendChild(css);
      var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML;
      if (minSaved()) { box.querySelector("#" + P + "bd").style.display = "none"; box.querySelector("#" + P + "min").textContent = "+"; }
      root.appendChild(box);
      ["hd", "min", "bd", "ver", "sum", "setup", "cnt", "q", "ifo", "all", "none", "list", "dry", "prog", "fill", "ptxt", "cfm", "cfmtxt", "yes", "no",
        "start", "stop", "dl", "dlf", "new", "st", "logbox", "stat", "statsec"].forEach(function (id) { sel[id === "new" ? "newr" : id] = root.getElementById(P + id); });
      try { sel.ver.textContent = chrome.runtime.getManifest().version; } catch (e) {}
      var p = prefs();
      sel.ifo.checked = p.ifOnly == null ? !!cfg.ifOnlyDefault : !!p.ifOnly;
      if (p.dry) sel.dry.checked = true;
      var api = {
        root: root, prefs: prefs, savePrefs: savePrefs, status: status, render: render, code: code, allWorks: allWorks,
        tickOnly: function (list) { var t = {}; list.forEach(function (w) { t[w] = 1; }); setTicks(t); lastList = ""; confirming = false; render(); },
        changed: function () { confirming = false; render(); }
      };
      sel.dry.addEventListener("change", function () { var q = prefs(); q.dry = sel.dry.checked; savePrefs(q); api.changed(); });
      sel.ifo.addEventListener("change", function () { var q = prefs(); q.ifOnly = sel.ifo.checked; savePrefs(q); api.changed(); });
      sel.q.addEventListener("input", function () { render(); });
      sel.list.addEventListener("change", function (e) { var w = e.target && e.target.getAttribute("data-w"); if (!w) return; var t = ticks(); if (e.target.checked) t[w] = 1; else delete t[w]; setTicks(t); api.changed(); });
      sel.all.addEventListener("click", function () { var t = ticks(); shown().forEach(function (w) { t[w] = 1; }); setTicks(t); api.changed(); });
      sel.none.addEventListener("click", function () { setTicks({}); api.changed(); });
      sel.start.addEventListener("click", askStart);
      sel.yes.addEventListener("click", doStart);
      sel.no.addEventListener("click", function () { confirming = false; render(); });
      sel.stop.addEventListener("click", doStop);
      sel.newr.addEventListener("click", doNew);
      sel.dl.addEventListener("click", function () { download(false); });
      sel.dlf.addEventListener("click", function () { download(true); });
      sel.min.addEventListener("click", function () { var hide = sel.bd.style.display !== "none"; sel.bd.style.display = hide ? "none" : "block"; sel.min.textContent = hide ? "+" : "–"; minSave(hide); });
      var sx, sy, ox, oy, drag = false; sel.hd.style.cursor = "move";
      sel.hd.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
      document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
      document.addEventListener("mouseup", function () {
        if (!drag) return; drag = false;
        var rr = host.getBoundingClientRect(), l = Math.max(0, Math.round(rr.left)), t = Math.max(0, Math.round(rr.top));
        host.style.left = l + "px"; host.style.top = t + "px";
        try { localStorage.setItem(POS_KEY, JSON.stringify({ l: l, t: t })); } catch (e) {}
        host.setAttribute("data-kdpos", "1");
      });
      sel.hd.addEventListener("dblclick", function (e) {
        if (e.target === sel.min) return;
        try { localStorage.removeItem(POS_KEY); } catch (x) {}
        host.removeAttribute("data-kdpos"); host.style.left = "auto"; host.style.top = "0"; host.style.right = kdW + "px";
      });
      if (cfg.onBuilt) cfg.onBuilt(api);
      render();
    }

    window.addEventListener("message", function (ev) { if (ev.data && ev.data.source === NS.toUpperCase() + "_DRV" && ev.data.type === "sync") render(); });
    setInterval(render, 1500);
    function start() {
      if (!$("ddlWorkCode")) return;                             // not the form
      // Dashboard-এ এই mode Off থাকলে panel দেখায় না
      try {
        // K-Desk Dashboard toggle (mrattend / mrpay) + PC activation — feature-gate.js
        window.KH_FEATURE(cfg.mode === "pay" ? "mrpay" : "mrattend", build);
      } catch (e) { build(); }
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
    return { esc: esc };
  };
})();

/* ---------------------- IAY Tracker job → MR panel (v1.9.7) ----------------------
   MRF_IAY({ ns, kind: "attend"|"pay", api, readExcel }) → { open(), sync(run) }
   open(): KDLink job picker; the job's rows (Work Code, MR No [, MB No, Page No]) become an Excel File
   and go through the panel's own readExcel(), so the run is exactly an Excel run.
   sync(run): called on every render; once that job's run has started, each final result
   (Saved / Not saved / Error / Skipped; not Test-run rows) is sent back to the job (KDLink.iayReport). */
(function () {
  "use strict";
  if (window.MRF_IAY) return;
  window.MRF_IAY = function (o) {
    var KEY = o.ns + "_iayjob", job = null, busy = false;
    try { chrome.storage.local.get(KEY, function (d) { job = (d && d[KEY]) || null; }); } catch (e) {}
    function save() { try { var x = {}; x[KEY] = job; chrome.storage.local.set(x); } catch (e) {} }
    function codeOf(w) { var m = /\(([^()]*\/[^()]*)\)\s*$/.exec(String(w || "")); return String(m ? m[1] : w || "").replace(/\s+/g, "").toUpperCase(); }
    function open() {
      var r = null; try { r = JSON.parse(localStorage.getItem(o.ns + "_run") || "null"); } catch (e) {}
      if (r && r.active) { o.api.status("একটা run চলছে — আগে Stop করুন।", "warn"); return; }
      if (!window.KDLink || !KDLink.openJobs) { o.api.status("Gram Setu link load হয়নি — page refresh (F5) করুন।", "warn"); return; }
      KDLink.openJobs({ kind: o.kind, onJob: function (j) {
        var items = j.items || []; if (!items.length) return "এই job-এ কোনো row নেই।";
        if (!window.XLSX) return "Excel library load হয়নি — page refresh করুন।";
        var H = o.kind === "pay" ? ["Work Code", "MR No", "MB No", "Page No"] : ["Work Code", "MR No"];
        var aoa = [H].concat(items.map(function (x) { return o.kind === "pay" ? [x.work_code, String(x.mr), String(x.mb), String(x.page)] : [x.work_code, String(x.mr)]; }));
        var wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), "Job");
        var buf = XLSX.write(wb, { bookType: "xlsx", type: "array" });
        var keys = {};
        items.forEach(function (x) { keys[String(x.work_code).toUpperCase() + "|" + x.mr] = x.work_code + "|" + x.mr; });
        job = { id: j.id, title: j.title, at: Date.now(), runId: null, sent: 0, keys: keys, rep: {} }; save();
        o.readExcel(new File([buf], "IAY-job-" + j.id + ".xlsx", { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
        return true;
      } });
    }
    // Test-run rows are not sent: the job stays open for the real run
    var RES = { "Saved": "done", "Not saved": "error", "Error": "error", "Skipped": "skipped" };
    function sync(r) {
      if (!job || busy || !r || !r.runId) return;
      // the newest run started after the job was loaded belongs to the job (a Test run first, then the real run)
      if (job.runId !== r.runId) { if ((r.startedAt || 0) < job.at) return; job.runId = r.runId; job.sent = 0; save(); }
      var R = r.results || [], n = R.length; if (n <= job.sent) return;
      var rows = [];
      R.slice(job.sent).forEach(function (x) {
        var s = RES[x.result]; if (!s) return;                               // Retry later / Manual: not final yet
        var c = codeOf(x.work), m = String(x.msg || "");
        if (s === "skipped" && x.result === "Skipped" && /already/i.test(m)) { s = "done"; m = "আগেই হয়ে ছিল (portal) · " + m; }
        var list = x.msr && x.msr !== "—" ? [c + "|" + x.msr] : Object.keys(job.keys).filter(function (k) { return k.indexOf(c + "|") === 0 && !job.rep[k]; });
        list.forEach(function (k) { if (job.keys[k]) { rows.push({ key: job.keys[k], s: s, m: m }); job.rep[k] = 1; } });
      });
      if (!rows.length) { job.sent = n; save(); return; }
      busy = true;
      KDLink.iayReport(job.id, o.kind, rows, function (err) {
        busy = false;
        if (err) { if (!job.warned) { job.warned = 1; o.api.status("Job #" + job.id + "-এর ফল Tracker-এ পাঠানো যায়নি: " + (err.text || err.message || err.code) + " (পরে আবার চেষ্টা করবে)", "warn"); } return; }
        job.sent = n; job.warned = 0; save();
      });
    }
    // the user chose another Excel by hand: that run is not the job's
    function clear() { job = null; try { chrome.storage.local.remove(KEY); } catch (e) {} }
    return { open: open, sync: sync, clear: clear, current: function () { return job; } };
  };
})();
