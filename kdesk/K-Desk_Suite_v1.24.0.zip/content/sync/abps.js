KH_FEATURE("abps", function () {
/* Demand & Allocation Helper by Koushik — ABPS / eKYC data sync
   On the Aadhaar Seeding / Authentication / NPCI / ABPS Status Report page
   (…/vbgramg/UID/AppABPSRpt.aspx), harvest every village's full applicant list
   and cache it so Work Demand / Work Allocation can refuse to enter workers who
   are not eKYC-done / ABPS-enabled.

   Why fetch instead of scraping the DOM: the on-screen grid is PAGINATED
   (51 rows a page, ~18 pages). The complete village list exists only in the
   "Download In Excel" response, which is really an HTML table with a .xls name.
   So per village we POST twice — once to switch the village, once to pull the
   export — and parse the returned HTML. No page reloads, so no resume state. */
(function () {
  "use strict";
  if (window.__DXABPS) return; window.__DXABPS = true;

  var DXk = window.DX;                       // dx-core.js runs on every portal page
  var MAP_KEY = "dxAbpsMap", META_KEY = "dxAbpsMeta";
  var STALE_MS = 7 * 24 * 60 * 60 * 1000;
  var HOST_ID = "dxabps-host";

  var P = "ctl00_ContentPlaceHolder1_";
  var IDS = { village: P + "DDL_Village", grid: P + "gvData" };
  var UN = { village: "ctl00$ContentPlaceHolder1$DDL_Village", link: "ctl00$ContentPlaceHolder1$LinkButton1",
             active: "ctl00$ContentPlaceHolder1$rdbtn_IsActive", fresh: "ctl00$ContentPlaceHolder1$chbx_freshCase",
             rgno: "ctl00$ContentPlaceHolder1$rdbtn_rgno_familyid" };

  // The sync must see EVERY worker, whatever the operator left on screen. The page defaults to
  // "Active Workers" + "fresh case" ticked, which shows only newly-processed cases — a dataset built
  // from that would make the gating skip nearly everyone as "not in ABPS data". So force:
  //   All Workers (1) · fresh case OFF (an unticked checkbox is simply absent) · All (3)
  function forceFilters(fd) {
    fd.set(UN.active, "1");
    fd.delete(UN.fresh);
    fd.set(UN.rgno, "3");
    return fd;
  }

  var sel = {}, busy = false, stopReq = false;

  /* ---------------------- helpers ---------------------- */
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]; }); }
  function logoUrl() { try { return chrome.runtime.getURL("assets/icons/icon48.png"); } catch (e) { return ""; } }
  function ver() { try { return chrome.runtime.getManifest().version; } catch (e) { return ""; } }
  function yn(v) { return /^\s*y/i.test(String(v || "")) ? 1 : 0; }
  function normId(s) { try { return DXk && DXk.normKey ? DXk.normKey(s, "id") : String(s || "").toUpperCase().replace(/\s+/g, ""); } catch (e) { return String(s || ""); } }
  // WB-06-003-006-013/001 -> WB-06-003-006 (state-district-block-GP)
  function gpOf(card) { var a = String(card || "").split("/")[0].split("-"); return a.length >= 4 ? a.slice(0, 4).join("-") : ""; }
  // calendar days, same count as DX.syncedWhen() in the summary line ("synced 14 days ago")
  function daysOld(ms) {
    var day = function (t) { var d = new Date(t); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); };
    return Math.max(0, Math.round((day(Date.now()) - day(ms)) / 86400000));
  }
  function isStale(m) { return !m || !m.savedAt || (Date.now() - m.savedAt) > STALE_MS; }

  /* ---------------------- storage ---------------------- */
  function readStore(cb) {
    try { chrome.storage.local.get([MAP_KEY, META_KEY], function (d) { cb((d && d[MAP_KEY]) || {}, (d && d[META_KEY]) || {}); }); }
    catch (e) { cb({}, {}); }
  }
  function writeStore(map, meta, cb) {
    var o = {}; o[MAP_KEY] = map; o[META_KEY] = meta;
    try { chrome.storage.local.set(o, cb || function () {}); } catch (e) { if (cb) cb(); }
  }

  /* ---------------------- fetch pipeline ---------------------- */
  // Serialise a form exactly as the browser would, so ASP.NET accepts the postback.
  function serialize(doc) {
    var f = doc.forms && doc.forms[0];
    var fd = new URLSearchParams();
    if (!f) return fd;
    for (var i = 0; i < f.elements.length; i++) {
      var el = f.elements[i]; if (!el.name) continue;
      var t = String(el.type || "").toLowerCase();
      if (t === "checkbox" || t === "radio") { if (el.checked) fd.append(el.name, el.value); continue; }
      if (t === "submit" || t === "button" || t === "image" || t === "file") continue;
      fd.append(el.name, el.value == null ? "" : el.value);
    }
    return fd;
  }

  /* ---- adaptive timeout ----
     The portal's speed swings a lot from day to day. A fixed timeout either fails on a
     slow day or waits forever on a stuck request. So the timeout is learned from the
     response times actually observed this session: ~4x the recent typical (p75) response, never below
     T_FLOOR, never above T_CEIL, and it grows on each retry. */
  var T_FLOOR = 25000, T_CEIL = 240000, T_MULT = 4, T_GROW = 1.6, RETRIES = 2;
  var rtts = [];                                   // recent successful response times (ms)
  function recordRtt(ms) { rtts.push(ms); if (rtts.length > 8) rtts.shift(); }
  // p75, not p90: with only 8 samples p90 IS the max, so one freak slow reply would pin every
  // later timeout at the ceiling. p75 ignores a lone spike but still tracks a real slowdown.
  function typical() {
    if (!rtts.length) return 0;
    var s = rtts.slice().sort(function (a, b) { return a - b; });
    return s[Math.min(s.length - 1, Math.floor(s.length * 0.75))];
  }
  function timeoutFor(attempt) {
    var base = Math.max(T_FLOOR, typical() * T_MULT);
    return Math.min(T_CEIL, Math.round(base * Math.pow(T_GROW, attempt || 0)));
  }
  function secs(ms) { return Math.round(ms / 1000) + "s"; }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function postForm(fd, attempt) {
    var ms = timeoutFor(attempt);
    var ctl = typeof AbortController !== "undefined" ? new AbortController() : null;
    var t0 = performance.now(), timedOut = false;
    var timer = setTimeout(function () { timedOut = true; if (ctl) ctl.abort(); }, ms);
    return fetch(location.href, {
      method: "POST", credentials: "include",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: fd.toString(), signal: ctl ? ctl.signal : undefined
    }).then(function (res) {
      return res.text().then(function (txt) {
        clearTimeout(timer);
        if (!res.ok) { var he = new Error("portal returned HTTP " + res.status); he.retry = res.status >= 500; throw he; }
        recordRtt(performance.now() - t0);
        return { ok: true, status: res.status, txt: txt, cd: res.headers.get("content-disposition") || "" };
      });
    }, function (e) {
      clearTimeout(timer);
      var err = new Error(timedOut ? "no response after " + secs(ms) : (e && e.message) || String(e));
      err.retry = true;                             // timeouts and network blips are worth retrying
      throw err;
    });
  }

  // Retry a whole unit of work (one village) with a growing timeout and a short backoff.
  function withRetry(work, label) {
    function go(attempt) {
      return work(attempt).catch(function (e) {
        if (stopReq) throw e;
        if (e && e.retry && attempt < RETRIES) {
          status(label + " — " + e.message + ". Retrying " + (attempt + 1) + "/" + RETRIES +
            " (waiting up to " + secs(timeoutFor(attempt + 1)) + ")…", "warn");
          return sleep(2000 * (attempt + 1)).then(function () { return go(attempt + 1); });
        }
        throw e;
      });
    }
    return go(0);
  }

  function parseDoc(html) { return new DOMParser().parseFromString(html, "text/html"); }

  // Union of every leaf <tr>. textContent (not innerText) — a parsed doc has no layout.
  function rowsFrom(root) {
    var out = [], trs = root.querySelectorAll("tr");
    for (var i = 0; i < trs.length; i++) {
      var tr = trs[i];
      if (tr.querySelector("table")) continue;          // layout row wrapping a nested table
      var vals = [];
      for (var j = 0; j < tr.children.length; j++) {
        var c = tr.children[j];
        if (c.tagName === "TD" || c.tagName === "TH") vals.push((c.textContent || "").replace(/\s+/g, " ").trim());
      }
      if (vals.length) out.push(vals);
    }
    return out;
  }

  function colIdx(header, re) { for (var i = 0; i < header.length; i++) if (re.test(header[i])) return i; return -1; }

  // The export is one clean 10-column table, so detect columns directly rather than
  // running cleanTable (which is tuned for messy report pages and drops "total"-ish rows).
  function parseExport(html) {
    var rows = rowsFrom(parseDoc(html));
    if (!rows.length) return { rows: [], err: "no rows" };
    var hi = -1;
    for (var i = 0; i < Math.min(rows.length, 8); i++) { if (/job\s*card/i.test(rows[i].join(" "))) { hi = i; break; } }
    if (hi < 0) return { rows: [], err: "header not found" };
    var h = rows[hi];
    // Match on the portal's "Applicant Name" column ONLY — never "Name as per Aadhaar Card".
    // That is the name the Demand/Allocation sheets carry, so it is the one to compare against.
    var nameIx = -1;
    for (var n = 0; n < h.length; n++) { if (/^\s*applicant\s*name\b/i.test(h[n]) && !/aadhaar/i.test(h[n])) { nameIx = n; break; } }
    var ix = {
      card: colIdx(h, /job\s*card/i), app: colIdx(h, /applicant\s*no/i), name: nameIx,
      aadhaar: colIdx(h, /aadhaar\s*seeded/i), auth: colIdx(h, /authentication/i),
      abps: colIdx(h, /abps/i), ekyc: colIdx(h, /e\s*-?\s*kyc/i)
    };
    if (ix.card < 0 || ix.name < 0 || ix.ekyc < 0 || ix.abps < 0) return { rows: [], err: "required columns missing (Job Card / Applicant Name / eKyc / ABPS)" };
    var out = [];
    for (var k = hi + 1; k < rows.length; k++) {
      var r = rows[k], card = r[ix.card];
      if (!card || !/\w-\d/.test(card)) continue;       // skip footers / stray rows
      out.push({
        card: card,
        app: ix.app >= 0 ? String(r[ix.app] || "").trim() : "",
        name: ix.name >= 0 ? String(r[ix.name] || "").trim() : "",
        aadhaar: ix.aadhaar >= 0 ? yn(r[ix.aadhaar]) : 0,
        auth: ix.auth >= 0 ? yn(r[ix.auth]) : 0,
        abps: yn(r[ix.abps]),
        ekyc: yn(r[ix.ekyc])
      });
    }
    return { rows: out };
  }

  function villagesFrom(doc) {
    var s = doc.getElementById(IDS.village); var out = [];
    if (!s) return out;
    for (var i = 0; i < s.options.length; i++) {
      var v = String(s.options[i].value);
      if (v && v !== "00" && v !== "99") out.push({ value: v, text: (s.options[i].text || "").trim() });
    }
    return out;
  }
  function gridHasData(doc) { var g = doc.getElementById(IDS.grid); return !!g && g.rows.length >= 2; }

  /* ---------------------- the sync ---------------------- */
  function sync() {
    if (busy) { stopReq = true; status("Stopping after the current village…", "warn"); return; }
    var villages = villagesFrom(document);
    if (!villages.length) { status("No villages in the dropdown — pick your Panchayat first.", "warn"); return; }

    busy = true; stopReq = false; setBusy(true);
    var harvested = {}, done = 0, skipped = 0, total = 0, vnames = {};
    var failed = [];                                  // villages that never came back
    var gpOk = false;                                 // GP key: GP মিলেছে কিনা (একবারই দেখা হয়)

    // One village = two POSTs, retried together so a fresh ViewState is always used.
    function oneVillage(v, attempt) {
      var fd = forceFilters(serialize(document));     // 1. switch village -> fresh page + tokens
      fd.set(UN.village, v.value);
      fd.set("__EVENTTARGET", UN.village);
      fd.set("__EVENTARGUMENT", "");
      return postForm(fd, attempt).then(function (r1) {
        var doc = parseDoc(r1.txt);
        if (!gridHasData(doc)) return { empty: true };            // no data -> do nothing
        var fd2 = forceFilters(serialize(doc));                   // 2. pull the full export
        fd2.set("__EVENTTARGET", UN.link);
        fd2.set("__EVENTARGUMENT", "");
        return postForm(fd2, attempt).then(function (r2) {
          var p = parseExport(r2.txt);
          if (p.err) { var pe = new Error(p.err); pe.retry = true; throw pe; }   // truncated/odd reply: retry
          return { rows: p.rows };
        });
      });
    }

    function step(i) {
      if (stopReq) return finish(true);
      if (i >= villages.length) return finish(false);
      var v = villages[i];
      var label = "Village " + (i + 1) + "/" + villages.length + " — " + v.text;
      progress(i, villages.length, v.text);
      withRetry(function (attempt) { return oneVillage(v, attempt); }, label).then(function (res) {
        // GP key: প্রথম data-ওয়ালা village-এর Job Card দিয়ে GP মেলানো; key-এর বাইরের GP হলে sync বন্ধ, কিছু save হয় না
        if (!res.empty && !gpOk) return KH_LICENSE.gpCheck([res.rows[0].card], function (bad) {
          if (bad) { busy = false; setBusy(false); progress(0, 0, ""); status(KH_LICENSE.gpText(bad) + " Sync বন্ধ, কিছু save হয়নি।", "warn"); return; }
          gpOk = true; take(res);
        });
        take(res);
      }, function (e) {
        if (stopReq) return finish(true);
        failed.push(v.text);
        status(label + " failed after " + (RETRIES + 1) + " tries: " + (e && e.message ? e.message : e) + ". Moving on.", "warn");
        step(i + 1);
      });
      function take(res) {
        if (res.empty) {
          skipped++;
          status(label + ": no data, skipped.", "warn");
        } else {
          res.rows.forEach(function (row) {
            var key = normId(row.card);
            (harvested[key] || (harvested[key] = [])).push({ card: row.card, app: row.app, name: row.name, aadhaar: row.aadhaar, auth: row.auth, abps: row.abps, ekyc: row.ekyc });
          });
          total += res.rows.length; done++;
          // village number on the cards (…-013/…) -> the dropdown's name, for the Gram Setu's village picker
          var vno = parseInt(String(res.rows[0].card || "").split("/")[0].split("-")[4], 10);
          if (vno) vnames[vno] = v.text;
          status(label + ": " + res.rows.length + " records." + (rtts.length ? "  (portal ~" + secs(typical()) + "/request)" : ""), "");
        }
        step(i + 1);
      }
    }

    function finish(stopped) {
      var cards = Object.keys(harvested);
      if (!cards.length) {
        busy = false; setBusy(false); progress(0, 0, "");
        status(stopped ? "Sync stopped — nothing was saved." :
          failed.length ? "Nothing harvested — " + failed.length + " village(s) failed. The portal may be slow; try again." :
          "Nothing harvested — no village had data.", "warn");
        return;
      }
      // Keys are already normKey'd, so the GP is derived from the SAME normalised form the
      // Demand/Allocation gating will compute from a worker's Reg No — both sides must match.
      var gp = gpOf(cards[0]);
      readStore(function (map, meta) {
        for (var k in harvested) map[k] = harvested[k];      // merge, newest wins
        var g = gp || "GP";
        // labels for people: the portal-format code (WB-06-003-006) and the GP name, which is the
        // village prefix ("Dasghara-II/I-1" -> "Dasghara-II"). The key g stays normalised for lookup.
        var raw = (harvested[cards[0]][0] || {}).card || "";
        var code = raw.split("/")[0].split("-").slice(0, 4).join("-");
        var v0 = (villages[0] && villages[0].text) || "";
        var gpName = v0.indexOf("/") > 0 ? v0.split("/")[0].trim() : "";
        // record partial syncs honestly — a GP is only "complete" if every village came back
        meta[g] = { count: total, villages: done, skipped: skipped, failed: failed.slice(),
                    complete: !stopped && !failed.length, savedAt: Date.now(), code: code, name: gpName,
                    vnames: (function () { var o = {}, old = (meta[g] && meta[g].vnames) || {}, k; for (k in old) o[k] = old[k]; for (k in vnames) o[k] = vnames[k]; return o; })() };
        writeStore(map, meta, function () {
          busy = false; setBusy(false); progress(0, 0, "");
          var msg = "ABPS data saved — " + total + " records across " + done + " village(s)" +
            (skipped ? ", " + skipped + " empty skipped" : "") + ".";
          if (stopped) msg += " Stopped early — the rest were not synced.";
          if (failed.length) msg += " " + failed.length + " failed (" + failed.join(", ") + ") — sync again to fill them in.";
          status(msg, (stopped || failed.length) ? "warn" : "ok");
          toast("ABPS data saved — " + total + " records across " + done + " village(s).");
          refreshMeta();
          pushToListBuilder(harvested, msg, (stopped || failed.length) ? "warn" : "ok", !stopped && !failed.length);
        });
      });
    }
    step(0);
  }

  /* ---- Gram Setu app: after a sync, update its eKYC/ABPS yes/no (only when K-Desk is logged in there) ---- */
  // complete = every village came back and the sync was not stopped. Only then may Gram Setu make workers the
  // portal no longer lists (deleted Job Card / applicant) inactive — and the server still checks its own limits.
  function pushToListBuilder(harvested, msg, kind, complete) {
    if (!window.KDLink || !KDLink.syncFlags) return;
    var rows = [], vset = {};
    for (var k in harvested) (harvested[k] || []).forEach(function (r) {
      rows.push({ c: r.card, a: r.app || "", n: r.name || "", s: r.aadhaar ? 1 : 0, u: r.auth ? 1 : 0, b: r.abps ? 1 : 0, e: r.ekyc ? 1 : 0 });
      var vno = parseInt(String(r.card || "").split("/")[0].split("-")[4], 10); if (vno) vset[vno] = 1;
    });
    if (!rows.length) return;
    status(msg + " Gram Setu app-এ eKYC/ABPS update হচ্ছে…", kind);
    KDLink.syncFlags(rows, function (err, out) {
      if (err && err.code === "NOT_LOGGED_IN") { status(msg + " (Gram Setu app-এ update হয়নি: Work Demand page-এর ☁ বোতাম থেকে একবার login করুন।)", kind); return; }
      if (err) { status(msg + " ⚠ Gram Setu app-এ update হয়নি: " + (err.text || err.message), "warn"); return; }
      var m = out.missing, extra = "";
      if (out.restored) extra += " " + out.restored + " জন আবার portal-এ পাওয়া গেছে, app-এ ফিরেছে।";
      if (m && m.status === "applied") extra += " 🚫 portal-এ নেই (delete হয়েছে) এমন " + m.deactivated + " জনকে app-এ inactive করা হলো (Admin → 🚫 Portal removed-এ দেখা ও ফেরানো যায়)।";
      else if (m && m.status === "held") { extra += " ⚠ portal-এ নেই এমন " + m.missing + " জন — সংখ্যাটা বেশি, তাই কিছু বদলানো হয়নি। Admin → 🚫 Portal removed-এ দেখে ঠিক করুন।"; kind = "warn"; }
      else if (m && m.status === "partial") extra += " (Sync পুরো হয়নি, তাই portal থেকে delete হওয়াদের সরানো হয়নি।)";
      else if (m && m.status === "error") extra += " (Delete হওয়াদের হিসাব হয়নি: " + (m.note || "") + ")";
      status(msg + " ☁ Gram Setu app: " + out.matched + " জন মিলেছে, " + out.changed + " জনের eKYC/ABPS বদলেছে।" + extra, kind);
    }, { villages: Object.keys(vset).map(Number), complete: !!complete });
  }

  /* ---------------------- CSV ---------------------- */
  function downloadCsv() {
    readStore(function (map) {
      var t = DXk.abpsTable(map);
      if (!t.rows.length) { status("Nothing to download — sync first.", "warn"); return; }
      var d = new Date(), p2 = function (n) { return (n < 10 ? "0" : "") + n; };
      var name = "ABPS-eKYC-" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + "-" + p2(d.getHours()) + p2(d.getMinutes()) + ".csv";
      try { DXk.download(name, DXk.toCSV(t.headers, t.rows), "text/csv;charset=utf-8"); status("Downloaded " + t.rows.length + " rows.", "ok"); }
      catch (e) { status("Could not build the CSV: " + e.message, "warn"); }
    });
  }

  function clearData() {
    writeStore({}, {}, function () { status("Saved ABPS data cleared.", "ok"); refreshMeta(); });
  }

  /* ---------------------- branded panel ---------------------- */
  var THEME = ".panel{font-family:'Segoe UI','Nirmala UI',Noto Sans Bengali,system-ui,sans-serif;border:1px solid rgba(255,255,255,.6);border-left:0;border-radius:16px;box-shadow:0 18px 50px rgba(11,20,55,.28),0 2px 8px rgba(11,20,55,.12)}.hd{position:relative;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);border-bottom:0;padding:12px 12px 12px 14px;user-select:none}.hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}.hdl{gap:10px}.logo{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;flex:none;font:800 19px/1 Georgia,'Times New Roman',serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b);box-shadow:0 3px 10px rgba(245,185,66,.45),inset 0 1px 0 rgba(255,255,255,.6)}.ttl{display:block;min-width:0}.hd .ttl b{display:block;font-size:14.5px;font-weight:700;letter-spacing:.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ttl small{display:block;font-size:11px;color:#c7d2fe;letter-spacing:.3px;white-space:nowrap}.ttl small i{font-style:normal;color:#f5b942;font-weight:600}.mn{width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,.12);font:700 15px/1 system-ui}.mn:hover{background:rgba(255,255,255,.25)}.bd{padding:12px 14px 0;background:linear-gradient(#fbfcff,#fff)}.btn{border-radius:10px;font-family:inherit;font-weight:600;transition:.15s}.btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 4px 12px rgba(15,23,42,.1)}.btn.pick{border:1.5px dashed #c7d2fe;background:#f5f7ff;color:#3730a3}.btn.pick:hover:not(:disabled){background:#eef2ff}.btn.fill{min-height:36px;color:#fff;border:0;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.fill:hover{background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.fill:disabled{opacity:.45;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.stop{min-height:36px;color:#b91c1c;border:1px solid #fecaca;background:#fff5f5}.btn.stop:disabled{opacity:.45;background:#fff5f5;color:#b91c1c}.btn.ghost{background:#f8fafc;color:#0f172a;border:1px solid #e2e8f0}.btn.ghost:hover:not(:disabled){background:#eef2ff}.btn.ghost.danger{background:#fff5f5;color:#b91c1c;border-color:#fecaca}.summary{background:#eef2ff;color:#3730a3;border-radius:10px;padding:7px 10px}.progbar{background:#eef2ff;border-radius:99px}.progfill{border-radius:99px;background:linear-gradient(90deg,#34d399,#10b981,#f5b942)}.progtxt{color:#3730a3}.scroll{border-radius:10px;border-color:#e2e8f0}th{background:#f8fafc;color:#0b1437}.gate,.top{border-radius:10px;background:#fff}.gatehd{color:#64748b;text-transform:uppercase;letter-spacing:.6px}.st{border-radius:8px;background:#f8fafc}.sec{color:#64748b;text-transform:uppercase;letter-spacing:.6px;font-size:11px;font-weight:600;border-top-color:#e2e8f0}.logbox{max-height:140px;background:#0b1437;color:#c7d2fe;border:0;border-radius:10px;padding:8px 10px;font:11px/1.5 Consolas,monospace}.logbox div{border-bottom:1px dotted rgba(199,210,254,.14)}.l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#c7d2fe}.logbox .lt{color:#7c89c9}.disclaimer{border-radius:8px}.foot{display:flex;justify-content:space-between;align-items:center;gap:8px;margin:10px -14px 0;padding:7px 14px;font-size:10.5px;color:#64748b;border-top:1px solid #e2e8f0;background:#f8fafc;text-align:left}.foot b{color:#0b1437;letter-spacing:.4px}.foot em{font-style:normal;color:#e08e0b}";
  var STYLE =
    ".panel{width:360px;font-family:Noto Sans Bengali,Noto Sans,Arial,sans-serif;font-size:13px;color:#0f172a;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #4338ca;border-radius:14px;box-shadow:0 14px 36px rgba(11,20,55,.28);overflow:hidden}" +
    ".hd{background:linear-gradient(115deg,#0b1437,#3730a3);border-bottom:3px solid #f5b942;color:#fff;padding:10px 11px;display:flex;align-items:center;justify-content:space-between}" +".origin-strip{display:flex;align-items:center;gap:6px;padding:6px 10px;background:#f5f7ff;border-bottom:1px solid #c7d2fe;color:#0b1437;font-size:10px;font-weight:700;line-height:1.35}" +".origin-dot{width:7px;height:7px;border-radius:50%;background:#4338ca;flex:0 0 auto}" +".hd b{font-size:12.5px;font-weight:600}" +
    ".hdl{display:flex;align-items:center;gap:7px;min-width:0}" +
    ".logo{width:20px;height:20px;border-radius:4px;flex:0 0 auto;background:#fff}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:22px;height:22px;border-radius:5px;font-size:15px;line-height:1;flex:0 0 auto}" +
    ".bd{padding:10px;max-height:80vh;overflow:auto}" +
    ".summary{font-size:11.5px;color:#3730a3;background:#eef2ff;border-radius:7px;padding:6px 8px;margin-bottom:8px;line-height:1.35}" +
    ".btn{padding:8px 9px;border:none;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer}" +
    ".btn.pick{width:100%;background:#f5f7ff;color:#3730a3;border:1px solid #3730a3;margin-bottom:8px}" +
    ".btn.pick:disabled{opacity:.6;cursor:not-allowed}" +
    ".btnrow{display:flex;gap:6px;margin-top:6px}.btnrow .btn{flex:1}" +
    ".btn.ghost{background:#f5f7ff;color:#334;border:1px solid #d7dce6}.btn.ghost:disabled{color:#aab;cursor:not-allowed}" +
    ".btn.ghost.danger{background:#fdecea;color:#c5221f;border-color:#f3b4b0}.btn.ghost.danger:hover{background:#fbdbd8}" +
    ".prog{margin:8px 0}.progbar{height:8px;background:#e2e8f0;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#4338ca;transition:width .3s}" +
    ".progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:6px;background:#f5f7ff;min-height:15px;line-height:1.35}" +
    ".st.ok{background:#e7f4ec;color:#137333}.st.warn{background:#fef7e0;color:#9a6700}" +
    ".hint{font-size:11px;color:#666;margin-top:6px;line-height:1.35}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#8a92a0;line-height:1.35;background:#fbfbfd;border:1px solid #eef0f4;border-radius:6px;padding:5px 7px}" +
    ".foot{margin-top:8px;text-align:center;font-size:10px;color:#8a92a0;line-height:1.35}.foot a.vt{color:#3730a3;text-decoration:none}.foot a.vt:hover{text-decoration:underline}" +
    ".toast{position:fixed;left:18px;bottom:18px;background:#137333;color:#fff;padding:10px 14px;border-radius:8px;font:600 12.5px Noto Sans Bengali,Noto Sans,Arial,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.28)}";

  var HTML =
    "<div class='hd' id='ab_hd'><span class='hdl'><div class='logo' id='ab_logo'>K</div><span class='ttl'><b>ABPS Data Sync</b><small><i>K-Desk</i> Suite · by Koushik</small></span></span><button class='mn' id='ab_min'>–</button></div>" +
    "" +
    "<div class='bd' id='ab_bd'>" +
      "<div class='summary' id='ab_sum'>No ABPS data saved yet.</div>" +
      "<button class='btn pick' id='ab_sync'>⟳ Sync all villages</button>" +
      "<div class='prog' id='ab_prog' hidden><div class='progbar'><div class='progfill' id='ab_fill'></div></div><div class='progtxt' id='ab_ptxt'></div></div>" +
      "<div class='btnrow'><button class='btn ghost' id='ab_csv'>⭳ Download CSV</button><button class='btn ghost danger' id='ab_clear'>🗑 Clear</button></div>" +
      "<div class='st' id='ab_st'></div>" +
      "<div class='hint'>Sync প্রতিটা village-এর পুরো list পড়ে (screen-এ যে page দেখা যাচ্ছে শুধু সেটা নয়) আর জমা রাখে, যাতে Work Demand আর Work Allocation-এ যাদের eKYC হয়নি বা ABPS enable হয়নি তাদের বাদ দেওয়া যায়। Screen-এ যে filter-ই থাকুক, সবসময় <b>All workers</b>, <b>fresh case বন্ধ</b> আর <b>All</b> দিয়ে পড়ে।</div>" +
      "<div class='disclaimer'>⚠ এই data sync করার সময়ের portal-এর অবস্থা। বড় entry চালানোর আগে আবার sync করুন, আর ফলাফল সবসময় নিজে একবার দেখে নিন।</div>" +
      "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>v<span id='ab_ver'></span></em></div>" +
    "</div>";

  var MIN_KEY = "dxabps_min";
  function minSaved() { try { return localStorage.getItem(MIN_KEY) === "1"; } catch (e) { return false; } }
  function minSave(on) { try { localStorage.setItem(MIN_KEY, on ? "1" : "0"); } catch (e) {} }

  function status(t, kind) { if (sel.st) { sel.st.textContent = t || ""; sel.st.className = "st " + (kind || ""); } }
  function setBusy(on) {
    if (sel.sync) sel.sync.textContent = on ? "■ Stop sync" : "⟳ Sync all villages";
    if (sel.csv) sel.csv.disabled = on;
    if (sel.clear) sel.clear.disabled = on;
  }
  function progress(i, n, label) {
    if (!sel.prog) return;
    if (!n) { sel.prog.hidden = true; return; }
    sel.prog.hidden = false;
    var pct = Math.round((i / n) * 100);
    sel.fill.style.width = pct + "%";
    sel.ptxt.textContent = (i + 1) + " / " + n + (label ? " — " + label : "") + "  (" + pct + "%)";
  }
  function toast(msg) {
    try {
      var h = document.createElement("div");
      h.style.cssText = "position:fixed;inset:0;z-index:2147483646;pointer-events:none;";
      (document.body || document.documentElement).appendChild(h);
      var r = h.attachShadow({ mode: "open" });
      var s = document.createElement("style"); s.textContent = STYLE; r.appendChild(s);
      var t = document.createElement("div"); t.className = "toast"; t.textContent = msg; r.appendChild(t);
      setTimeout(function () { try { h.parentNode.removeChild(h); } catch (e) {} }, 4000);
    } catch (e) {}
  }

  function refreshMeta() {
    readStore(function (map, meta) {
      var cards = Object.keys(map).length, recs = 0;
      for (var k in map) recs += (map[k] || []).length;
      var gps = Object.keys(meta);
      if (!cards) { sel.sum.textContent = "No ABPS data saved yet. Click Sync to build it."; return; }
      var newest = 0; gps.forEach(function (g) { if (meta[g] && meta[g].savedAt > newest) newest = meta[g].savedAt; });
      var names = gps.map(function (g) { return (meta[g] && meta[g].name) || (meta[g] && meta[g].code) || g; });
      var txt = (names.length === 1 ? names[0] + " · " : "") + recs + " records · " + cards + " job cards";
      if (newest) txt += " · synced " + DX.syncedWhen(newest);
      var partial = gps.filter(function (g) { return meta[g] && meta[g].complete === false; });
      if (partial.length) txt += " · partial (some villages missing)";
      sel.sum.textContent = txt;
      if (newest && isStale({ savedAt: newest })) status("This data is " + daysOld(newest) + " days old — sync again before a big entry run.", "warn");
    });
  }

  function build() {
    try { var old = document.getElementById(HOST_ID); if (old && old.parentNode) old.parentNode.removeChild(old); } catch (e) {}
    var host = document.createElement("div");
    host.id = HOST_ID;
    host.style.cssText = "position:fixed;top:70px;right:16px;z-index:2147483647;";
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE + THEME; root.appendChild(css); if (window.KD_applySkin) KD_applySkin(root);
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML;
    if (minSaved()) {
      var b0 = box.querySelector("#ab_bd"), m0 = box.querySelector("#ab_min");
      if (b0) b0.style.display = "none";
      if (m0) m0.textContent = "+";
    }
    root.appendChild(box);

    ["hd", "bd", "min", "logo", "ver", "sum", "sync", "prog", "fill", "ptxt", "csv", "clear", "st"]
      .forEach(function (id) { sel[id] = root.getElementById("ab_" + id); });

    try { if (sel.logo) sel.logo.src = logoUrl(); if (sel.ver) sel.ver.textContent = ver(); } catch (e) {}

    sel.sync.addEventListener("click", sync);
    sel.csv.addEventListener("click", downloadCsv);
    sel.clear.addEventListener("click", clearData);
    sel.min.addEventListener("click", function () {
      sel.bd.style.display = sel.bd.style.display === "none" ? "block" : "none";
      sel.min.textContent = sel.bd.style.display === "none" ? "+" : "–";
      minSave(sel.bd.style.display === "none");
    });
    makeDraggable(box, sel.hd);
    refreshMeta();
  }

  function makeDraggable(box, handle) {
    var sx, sy, ox, oy, drag = false; handle.style.cursor = "move";
    handle.addEventListener("mousedown", function (e) {
      if (e.target === sel.min) return;
      drag = true; sx = e.clientX; sy = e.clientY;
      var host = document.getElementById(HOST_ID), rr = host.getBoundingClientRect();
      ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault();
    });
    document.addEventListener("mousemove", function (e) {
      if (!drag) return;
      var host = document.getElementById(HOST_ID);
      host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px";
    });
    document.addEventListener("mouseup", function () { drag = false; });
  }

  /* ---------------------- boot (wagebreakup's readiness pattern) ---------------------- */
  function ready() {
    return !!document.getElementById(IDS.village) && !!(document.forms && document.forms[0]);
  }
  var fired = false, obs = null;
  function tryFire() {
    if (fired || !ready()) return;
    if (!DXk) return;                        // dx-core must be present for normKey/toCSV/download
    fired = true; build();
    if (obs) { obs.disconnect(); obs = null; }
  }
  try {
    tryFire();
    if (!fired) {
      obs = new MutationObserver(tryFire);
      obs.observe(document.documentElement || document.body, { childList: true, subtree: true });
      setTimeout(function () { if (obs) { obs.disconnect(); obs = null; } }, 90000);
    }
  } catch (e) {}
})();
});
