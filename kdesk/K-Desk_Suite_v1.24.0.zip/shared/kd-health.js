/* =====================================================================
   kd-health.js — K-Desk Suite by Koushik · 🩺 Health Check (v1.24.0)

   shared/portal-map.js-এর তালিকা ধরে খোলা portal page-এ দেখে দরকারি
   field/বোতাম আছে কিনা। ফল বাংলায় দেখায়:
     ✅ ঠিক আছে       — map-এর ID-তেই পাওয়া গেছে
     ⚠ ID বদলেছে      — ঠিক ID-তে নেই, কিন্তু কাছাকাছি নামে আছে (নতুন ID দেখায়)
     ❌ পাওয়া যায়নি    — Start-এর সময় যেটা থাকতেই হবে, সেটা নেই
     ○ এখনো আসেনি     — এই field পরের ধাপে আসে (যেমন work বাছার পরে grid)

   দুইভাবে চলে:
     1) Dashboard-এর "🩺 Health Check" বোতাম → এই page-এ পুরো রিপোর্ট।
     2) Write feature-এর Start (Demand, Allocation, Send for Payment, Generate
        Wagelist, Bank A/c Update, Fill Attendance only, Payment only) চাপলে আগে
        চুপচাপ check; সব ঠিক থাকলে Start আগের মতোই, কিছু না মিললে Start থামে
        আর রিপোর্ট দেখায়। চুপচাপ ভুল এন্ট্রি হবে না।

   MAIN world-এও (Bank) চলে, তাই chrome.* শুধু try-এর ভেতরে, আর Date নেই।
   ===================================================================== */
(function () {
  "use strict";
  if (window.KD_HEALTH) return;

  var HOST_ID = "kdhc-host";
  function M() { return window.KD_MAP; }
  function css(s) { return String(s).replace(/["\\]/g, "\\$&"); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function qa(doc, sel) { try { return [].slice.call(doc.querySelectorAll(sel)); } catch (e) { return []; } }
  function txt(el) { return String((el && (el.textContent || "")) || "").replace(/\s+/g, " ").trim(); }
  function ver() { try { return chrome.runtime.getManifest().version; } catch (e) { return window.__KD_VER || ""; } }

  // portal-এর field-এর পাশে লেখা label (যেমন "Village") থেকে একই row-এর select/input
  function byLabel(doc, label) {
    if (!label) return null;
    var re = new RegExp("^\\s*" + String(label).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i");
    var cands = qa(doc, "td, th, label, span, b, font").filter(function (e) { return !e.children.length && re.test(txt(e)) && txt(e).length < 60; });
    for (var i = 0; i < cands.length; i++) {
      var tr = cands[i].closest && cands[i].closest("tr");
      var box = tr && tr.querySelector("select, input:not([type=hidden]), textarea");
      if (box && box.id && box.id.indexOf("kd") !== 0) return box;
    }
    return null;
  }

  // একটা field খোঁজা: আগে ঠিক ID, তারপর কাছাকাছি নাম
  function resolve(doc, f) {
    var map = M(), ids = map.ids(f), i, el;
    for (i = 0; i < ids.length; i++) {
      var want = map.full(f, ids[i]);
      el = f.by === "name" ? (doc.getElementsByName(want)[0] || null) : doc.getElementById(want);
      if (el) return { state: "ok", el: el, id: want };
    }
    var hits = [];
    for (i = 0; i < ids.length && !hits.length; i++) {
      var x = css(ids[i]);
      hits = f.raw
        ? qa(doc, '[id="' + x + '" i], [name="' + x + '" i], [id$="_' + x + '"]')
        : qa(doc, '[id$="_' + x + '"], [name$="$' + x + '"]');
    }
    hits = hits.filter(function (h, k) { return hits.indexOf(h) === k; });
    // validator/label span (যেমন rfv_ddlBankCodeName) বাদ দিয়ে আসল form control-কে আগে ধরা
    if (hits.length > 1) {
      var ctl = hits.filter(function (h) { return /^(SELECT|INPUT|TEXTAREA|BUTTON|TABLE|A|IMG)$/.test(h.tagName) && !/(^|_)(rfv|req|rev|cv|lbl)_?/i.test((h.id || "").slice(0, -ids[0].length)); });
      if (ctl.length) hits = ctl;
    }
    if (hits.length === 1) return { state: "moved", el: hits[0], id: map.full(f, ids[0]), now: hits[0].id || hits[0].name || "" };
    if (hits.length > 1) return { state: "many", id: map.full(f, ids[0]), now: hits.slice(0, 3).map(function (h) { return h.id || h.name; }).join(", ") };
    var lb = byLabel(doc, f.label);
    return { state: "none", id: map.full(f, ids[0]), hint: lb ? (lb.id || lb.name || "") : "" };
  }

  // পুরো page check → { page, bn, items[], rowNote, blocked, reasons[] }
  function check(pageKey, doc) {
    doc = doc || document;
    var map = M(), pg = map && map.page(pageKey);
    if (!pg) return null;
    var out = { page: pageKey, bn: pg.bn, path: (location.pathname || "").split("/").pop(), items: [], rows: [], rowNote: "", blocked: false, reasons: [] };
    var found = {};
    Object.keys(pg.fields).forEach(function (k) {
      var f = pg.fields[k], r = resolve(doc, f);
      var it = { key: k, bn: f.bn || k, id: r.id, start: !!f.start, state: r.state, now: r.now || "", hint: r.hint || "" };
      if (r.state === "none" && !f.start) it.state = "later";          // পরের ধাপে আসে — এখন না থাকা স্বাভাবিক
      if (r.state === "ok") found[k] = r.el;
      out.items.push(it);
      if (it.state === "moved" || it.state === "many") { out.blocked = true; out.reasons.push(it.bn + ": ID বদলেছে মনে হচ্ছে"); }
      if (it.state === "none") { out.blocked = true; out.reasons.push(it.bn + " পাওয়া যায়নি"); }
    });
    var rw = pg.rows;
    if (rw) {
      var scope = rw.grid ? found[rw.grid] : doc;
      // সব row দেখা হয়: কিছু row-এ box না থাকা স্বাভাবিক (যেমন আগেই জমা হওয়া worker) —
      // অন্তত একটা row-এ সব দরকারি field থাকলেই ঠিক; সেই row-টাই রিপোর্টে দেখানো হয়
      var anchors = scope ? qa(scope, rw.anchorSel || ('[id$="' + css(rw.anchor) + '"]')) : [];
      var a = null, best = -1;
      anchors.slice(0, 300).forEach(function (el) {
        var mm = rw.anchorRe ? rw.anchorRe.exec(el.id || "") : null, px = mm ? mm[1] : String(el.id || "").slice(0, -rw.anchor.length), miss = 0;
        Object.keys(rw.fields).forEach(function (k) { if (rw.fields[k].need && !doc.getElementById(px + rw.fields[k].suffix)) miss++; });
        if (best < 0 || miss < best) { best = miss; a = el; }
      });
      if (!a) {
        var rowsN = scope && scope.rows ? scope.rows.length : 0;
        out.rowNote = rowsN >= 2 ? "Grid-এ row আছে, কিন্তু চেনা " + rw.bn + " পাওয়া যায়নি — portal-এর grid বদলে থাকতে পারে।"
                                 : "Grid এখনো খালি — " + rw.bn + "-এর field দেখা হবে grid এলে (আবার Health Check চাপুন)।";
        out.rowWarn = rowsN >= 2;
      } else {
        var m = rw.anchorRe ? rw.anchorRe.exec(a.id || "") : null;
        var pfx = m ? m[1] : String(a.id || "").slice(0, -rw.anchor.length);
        Object.keys(rw.fields).forEach(function (k) {
          var f = rw.fields[k], el = doc.getElementById(pfx + f.suffix);
          var it = { key: k, bn: f.bn, id: pfx + f.suffix, state: el ? "ok" : (f.need ? "none" : "later"), row: true };
          out.rows.push(it);
          if (!el && f.need) { out.blocked = true; out.reasons.push("কোনো " + rw.bn + "-এ " + f.bn + " নেই"); }
        });
      }
    }
    // সব field একই নতুন prefix-এ সরে গেলে সেটা বলে দেওয়া
    var mv = out.items.filter(function (x) { return x.state === "moved" && x.now; });
    if (mv.length >= 2) {
      var p0 = map.prefixId(""), np = mv.map(function (x) { var i = x.now.lastIndexOf(x.id.slice(p0.length)); return i > 0 ? x.now.slice(0, i) : ""; });
      if (np[0] && np.every(function (p) { return p === np[0]; }) && np[0] !== p0) out.prefixNow = np[0];
    }
    return out;
  }

  var ICON = { ok: "✅", moved: "⚠", many: "⚠", none: "❌", later: "○" };
  function note(it) {
    if (it.state === "ok") return "";
    if (it.state === "moved") return "নতুন ID মনে হয়: " + it.now;
    if (it.state === "many") return "অনেকগুলো মিলেছে: " + it.now;
    if (it.state === "later") return "এখন page-এ নেই (সাধারণত পরের ধাপে আসে)";
    return "পাওয়া যায়নি" + (it.hint ? " · কাছাকাছি field: " + it.hint : "");
  }
  function reportText(res) {
    var L = ["K-Desk " + ver() + " · Health Check · " + res.bn + " (" + res.path + ")"];
    res.items.forEach(function (it) { L.push(ICON[it.state] + " " + it.bn + " — " + it.id + (note(it) ? " — " + note(it) : "")); });
    res.rows.forEach(function (it) { L.push(ICON[it.state] + " [row] " + it.bn + " — " + it.id + (note(it) ? " — " + note(it) : "")); });
    if (res.rowNote) L.push("• " + res.rowNote);
    if (res.prefixNow) L.push("• সব field-এর ID-র শুরুর অংশ বদলেছে: " + res.prefixNow);
    L.push(res.blocked ? "ফল: সমস্যা আছে — " + res.reasons.join("; ") : "ফল: সব ঠিক আছে");
    return L.join("\n");
  }

  function close() { var h = document.getElementById(HOST_ID); if (h) h.remove(); }
  function copy(t, btn) {
    function done() { btn.textContent = "✓ Copy হয়েছে"; }
    try { navigator.clipboard.writeText(t).then(done, fb); } catch (e) { fb(); }
    function fb() { try { var a = document.createElement("textarea"); a.value = t; document.body.appendChild(a); a.select(); document.execCommand("copy"); a.remove(); done(); } catch (e) {} }
  }

  var STYLE =
    ":host{all:initial}" +
    ".ov{position:fixed;inset:0;background:rgba(11,20,55,.45);z-index:2147483646;display:flex;align-items:flex-start;justify-content:center;padding-top:6vh;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif}" +
    ".bx{width:min(620px,94vw);max-height:84vh;display:flex;flex-direction:column;background:#f3f4ff;border:1px solid #c9cef3;border-radius:16px;box-shadow:0 18px 50px rgba(11,20,55,.35);overflow:hidden;color:#1e1b4b;font-size:13px}" +
    ".hd{background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);color:#fff;padding:11px 14px;display:flex;justify-content:space-between;align-items:center}" +
    ".hd b{font-size:14.5px}.hd small{display:block;color:#c7d2fe;font-size:11px;margin-top:2px}" +
    ".x{background:rgba(255,255,255,.2);border:0;color:#fff;width:26px;height:26px;border-radius:7px;font-size:15px;cursor:pointer}" +
    ".bd{padding:10px 14px;overflow:auto}" +
    ".sum{border-radius:10px;padding:9px 11px;margin-bottom:9px;line-height:1.45}.sum.ok{background:#e5f4e4;border:1px solid #b7dfb4}.sum.bad{background:#fff1f2;border:1px solid #fecdd3;color:#7f1d1d}" +
    "table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #d4d8f5;border-radius:10px;overflow:hidden}" +
    "td{padding:5px 7px;border-top:1px solid #eef0fb;vertical-align:top;font-size:12.5px}td.i{width:22px;text-align:center}td.id{font:11px Consolas,monospace;color:#4b5563;word-break:break-all}" +
    "tr.bad td{background:#fff5f5}tr.mv td{background:#fffbeb}tr.lt td{color:#6b7280}" +
    ".sub{font-weight:700;color:#3730a3;font-size:11.5px;margin:10px 0 4px}" +
    ".nt{font-size:11.5px;color:#5b6472;margin-top:8px;line-height:1.5}" +
    ".ft{display:flex;gap:7px;padding:10px 14px;border-top:1px solid #d4d8f5;background:#eef0fc;flex-wrap:wrap}" +
    ".b{flex:1;min-width:120px;padding:8px 10px;border-radius:10px;border:1px solid #d4d8f5;background:#fff;color:#1e1b4b;font:600 12.5px 'Segoe UI','Nirmala UI',Arial;cursor:pointer}" +
    ".b.pr{border:0;color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.b.rk{color:#9a3412;border-color:#fdba74;background:#fff7ed}";

  // res = check() ফল; opt = { gate: true, featureBn, onRun } (gate হলে "তবু চালাই" বোতাম থাকে)
  function show(res, opt) {
    opt = opt || {};
    close();
    var host = document.createElement("div"); host.id = HOST_ID;
    var root = host.attachShadow({ mode: "open" });
    var rows = function (list) {
      return list.map(function (it) {
        var cls = it.state === "none" ? "bad" : (it.state === "moved" || it.state === "many") ? "mv" : it.state === "later" ? "lt" : "";
        return "<tr class='" + cls + "'><td class='i'>" + ICON[it.state] + "</td><td>" + esc(it.bn) + (note(it) ? "<br><small>" + esc(note(it)) + "</small>" : "") + "</td><td class='id'>" + esc(it.id) + "</td></tr>";
      }).join("");
    };
    var head = opt.gate ? "⛔ " + esc(opt.featureBn || res.bn) + " শুরু হয়নি" : "🩺 Health Check · " + esc(res.bn);
    var sum = res.blocked
      ? "<div class='sum bad'><b>Portal-এর কিছু field পাওয়া যায়নি বা ID বদলেছে।</b>" + (opt.gate ? " ভুল এন্ট্রি এড়াতে run শুরু করা হল না।" : "") +
        "<br>" + res.reasons.map(esc).join("<br>") + "</div>"
      : "<div class='sum ok'><b>সব ঠিক আছে।</b> দরকারি field আর বোতাম portal-এ আছে।" + (res.rowNote ? "<br>" + esc(res.rowNote) : "") + "</div>";
    root.innerHTML = "<style>" + STYLE + "</style><div class='ov'><div class='bx'>" +
      "<div class='hd'><div><b>" + head + "</b><small>" + esc(res.path) + " · K-Desk " + esc(ver()) + "</small></div><button class='x' id='x' title='বন্ধ'>✕</button></div>" +
      "<div class='bd'>" + sum +
      (res.prefixNow ? "<div class='sum bad'>সব field-এর ID-র শুরুর অংশ বদলেছে মনে হচ্ছে: <code>" + esc(res.prefixNow) + "</code></div>" : "") +
      "<table>" + rows(res.items) + "</table>" +
      (res.rows.length ? "<div class='sub'>Grid-এর একটা row</div><table>" + rows(res.rows) + "</table>" : (res.rowNote && res.blocked ? "<div class='nt'>" + esc(res.rowNote) + "</div>" : "")) +
      "<div class='nt'>✅ ঠিক · ⚠ ID বদলেছে · ❌ পাওয়া যায়নি · ○ এখনো আসেনি (পরের ধাপে আসে)" +
      (res.blocked ? "<br>কী করবেন: \"📋 Copy report\" চেপে রিপোর্টটা Koushik-কে পাঠান, অথবা README_BN.md-এর \"Portal বদলালে কী করবেন\" দেখে shared/portal-map.js-এ নতুন ID বসান।" : "") + "</div>" +
      "</div><div class='ft'><button class='b' id='cp'>📋 Copy report</button>" +
      (opt.gate && res.blocked && opt.onRun ? "<button class='b rk' id='run'>⚠ তবু চালাই (নিজের দায়িত্বে)</button>" : "") +
      "<button class='b pr' id='ok'>বন্ধ করুন</button></div></div></div>";
    (document.body || document.documentElement).appendChild(host);
    root.getElementById("x").onclick = close;
    root.getElementById("ok").onclick = close;
    root.getElementById("cp").onclick = function () { copy(reportText(res), this); };
    var run = root.getElementById("run");
    if (run) run.onclick = function () {
      if (!run.dataset.sure) { run.dataset.sure = "1"; run.textContent = "নিশ্চিত? ভুল এন্ট্রি হতে পারে — আবার চাপুন"; return; }
      close(); opt.onRun();
    };
  }

  var API = {
    check: check,
    report: function (pageKey) { var r = check(pageKey); return r ? reportText(r) : ""; },
    // Dashboard বোতাম: এই page-এর পুরো রিপোর্ট দেখাও
    runHere: function () {
      var map = M(), key = map ? map.pageOf(location.pathname) : "";
      if (!key) {
        show({ bn: "এই page", path: (location.pathname || "").split("/").pop(), items: [], rows: [], blocked: false, reasons: [],
               rowNote: "এই page-এর জন্য Health Check এখনো তৈরি হয়নি। এখন আছে: Work Demand, Work Allocation, Send for Payment, Generate Wagelist, Bank A/c Update, Fill Attendance only, Payment only।" });
        return { ok: true, page: "" };
      }
      var res = check(key); show(res);
      return { ok: true, page: key, blocked: res.blocked };
    },
    // Write feature-এর Start: সব ঠিক থাকলে সাথে সাথে run(); না হলে থামাও আর রিপোর্ট দেখাও
    gate: function (pageKey, run, featureBn) {
      var res = null;
      try { res = check(pageKey); } catch (e) { res = null; }
      if (!res || !res.blocked) { run(); return true; }
      try { show(res, { gate: true, featureBn: featureBn, onRun: run }); } catch (e) { run(); return true; }
      return false;
    }
  };
  window.KD_HEALTH = API;

  try {
    if (window.chrome && chrome.runtime && chrome.runtime.onMessage && window === window.top) {
      chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
        if (msg && msg.type === "KD_HEALTH_RUN") { var r = { ok: false }; try { r = API.runHere(); } catch (e) { r = { ok: false, err: String(e && e.message || e) }; } try { sendResponse(r); } catch (e) {} }
        return false;
      });
    }
  } catch (e) {}
})();
