/* =====================================================================
   portal-map.js — K-Desk Suite by Koushik · Portal Map (v1.24.0)

   Portal-এর সব page path আর field ID এক জায়গায়। শুধু DATA — কোনো code চলে না।
   Portal কোনো field-এর ID বদলালে এখানে সেই field-এর "id" বদলালেই হবে
   (README_BN.md → "Portal বদলালে কী করবেন")। পরের version-এ এই map
   Gram Setu (Supabase) থেকেও আসবে, তখন extension আবার বানাতে হবে না।

   এই ফাইল দুই world-এই load হয় (MAIN driver আর isolated panel), তাই এখানে
   chrome.* বা Date ব্যবহার নেই (portal page নিজের Date বদলে রাখে)।

   Field-এর ঘর:
     id     portal-এর ID (prefix ছাড়া)। একাধিক নাম হলে array, প্রথমটা আসল।
     raw    true = prefix লাগে না (MR Fill-এর পুরোনো ধাঁচের page)
     by     "name" = name="…" দিয়ে খোঁজা (id নয়)
     bn     Health Check-এ দেখানো বাংলা নাম
     start  true = Start চাপার সময় page-এ থাকতেই হবে, না থাকলে Start হবে না
     label  (ঐচ্ছিক) portal-এ field-এর পাশে লেখা — ID না মিললে কাছাকাছি field খুঁজতে
   rows: grid-এর প্রতিটা row-এর field। anchor দিয়ে প্রথম row খোঁজা হয়, তারপর
     সেই row-এর prefix + suffix। need true = row থাকলে এই field থাকতেই হবে।
   ===================================================================== */
(function () {
  "use strict";
  if (window.KD_MAP) return;

  var MAP = {
    mapVersion: "1.24.0-bundled",
    prefix: { id: "ctl00_ContentPlaceHolder1_", name: "ctl00$ContentPlaceHolder1$" },
    pages: {
      demand: {
        bn: "Work Demand", path: /\/demand_new\.aspx$/i, feature: "demand",
        fields: {
          village: { id: "DDL_Village", bn: "Village dropdown", start: true, label: "Village" },
          reg: { id: "DDL_Registration", bn: "Registration (Job Card) dropdown", label: "Registration" },
          grid: { id: "gvData", bn: "Worker grid (gvData)" },
          proceed: { id: "btnProceed", bn: "Proceed বোতাম" }
        },
        rows: {
          grid: "grid", anchor: "_job", bn: "worker row",
          fields: {
            job: { suffix: "_job", bn: "Worker-এর নাম", need: true },
            app: { suffix: "_dt_app", bn: "Date of Application box", need: true },
            from: { suffix: "_dt_from", bn: "Work From box", need: true },
            days: { suffix: "_d3", bn: "দিনের সংখ্যা box", need: true },
            to: { suffix: "_dt_to", bn: "Work To box", need: true },
            aadhaar: { suffix: "_Is_Aadhaar_Auth", bn: "Aadhaar flag" }
          }
        }
      },
      allocation: {
        bn: "Work Allocation", path: /\/workalloc\.aspx$/i, feature: "allocation",
        fields: {
          cat: { id: "ddlworkcategory", bn: "Work Category dropdown", start: true, label: "Category" },
          search: { id: "txtwrksearchkey", bn: "Work search box" },
          work: { id: "ddlWork_code", bn: "Work Code dropdown", label: "Work" },
          grid: { id: "GridView1", bn: "Applicant grid (GridView1)" },
          save: { id: "cmdSave", bn: "Save বোতাম" }
        },
        rows: {
          grid: "grid", anchor: "_chkAllocate", bn: "applicant row",
          fields: {
            chk: { suffix: "_chkAllocate", bn: "Allocate tick", need: true },
            dfrom: { suffix: "_txtDemandFrom", bn: "Demand From" },
            from: { suffix: "_txtAllocFrom", bn: "Allocation From box", need: true },
            days: { suffix: "_txtWorkBalDays", bn: "Allocation দিন box", need: true },
            to: { suffix: "_txtAllocTo", bn: "Allocation To box", need: true }
          }
        }
      },
      sendpay: {
        bn: "Send Wagelist for Payment", path: /\/sendforpay\.aspx$/i, feature: "sendpay",
        fields: {
          fy: { id: "ddlfin", bn: "Financial Year dropdown", start: true, label: "Financial Year" },
          wl: { id: "ddl_sel", bn: "Wagelist No. dropdown", label: "Wagelist" },
          send: { id: "btnsubmit", bn: "Send Wagelist For Payment বোতাম" }
        },
        rows: {
          grid: null, anchorSel: "input[type=radio][id*='GridView1_'][id*='rdbPayment']", anchorRe: /^(.*GridView1_ctl\d+)_/, bn: "agency row",
          fields: {
            code: { suffix: "_Lbl_wg_ag_code", bn: "Agency code", need: true },
            amt: { suffix: "_txt_chk_amt", bn: "Amount", need: true }
          }
        }
      },
      wagegen: {
        bn: "Generate Wagelist", path: /\/sendmsrtopo\.aspx$/i, feature: "wlgen",
        fields: {
          agency: { id: "exe_agency", bn: "Agency (Panchayat) dropdown", start: true, label: "Agency" },
          fy: { id: "ddlstFinyear", bn: "Financial Year dropdown" },
          from: { id: "wgfromdt", bn: "From date" },
          to: { id: "wgtodt", bn: "To date" },
          go: { id: "go", bn: "Proceed বোতাম" },
          list: { id: "wagelist_msr", bn: "Work list table" },
          view: { id: "btn_go", bn: "View Wagelist বোতাম" },
          msg: { id: "lblmsg", bn: "Portal message" }
        }
      },
      bank: {
        bn: "Bank A/c Update", path: /\/editappbank\.aspx$/i, feature: "bank",
        fields: {
          bank: { id: "ddlBankCodeName", bn: "Bank dropdown", start: true, label: "Bank" },
          ifsc: { id: "txtifsc", bn: "IFSC box", start: true, label: "IFSC" },
          ifscGo: { id: "ImageButton1", bn: "IFSC search বোতাম" },
          branch: { id: "ddlBrCodeName", bn: "Branch dropdown", label: "Branch" },
          jc: { id: "jcr_srch_key", bn: "Job Card search box", start: true },
          jcGo: { id: "ImgbtnSearch", bn: "Job Card search বোতাম", start: true },
          grid: { id: "grdData", bn: "Worker grid (grdData)" },
          update: { id: "BtnUpdate", bn: "Update বোতাম" }
        },
        rows: {
          grid: "grid", anchor: "_HF_Reg_No", bn: "worker row",
          fields: {
            app: { suffix: "_HF_Applicant_no", bn: "Applicant No", need: true },
            chk: { suffix: "_input_chkRowEdit", bn: "Edit tick", need: true },
            ac: { suffix: "_txtAcNo", bn: "Account No box", need: true },
            ac2: { suffix: "_txtAcNo1", bn: "Account No (আবার) box", need: true },
            holder: { suffix: "_txtApp_Name_BankPO", bn: "Account holder name box" }
          }
        }
      },
      mrattend: {
        bn: "Fill Attendance only", path: /\/mustrollattend\.aspx$/i, feature: "mrattend",
        fields: {
          work: { id: "ddlWorkCode", raw: true, bn: "Work Code dropdown", start: true, label: "Work Code" },
          msr: { id: "ddlMsrNo", raw: true, bn: "Muster Roll No dropdown", start: true, label: "Muster Roll" },
          from: { id: "txtDatefrm", raw: true, bn: "MR From date" },
          to: { id: "txtDateTo", raw: true, bn: "MR To date" },
          wstart: { id: "txtWrkStartDate", raw: true, bn: "Work Start Date box" },
          zero: { id: "chk_zeroAtt", raw: true, bn: "Zero attendance tick" },
          save: { id: ["btnsave", "btnSave"], raw: true, bn: "Save বোতাম" },
          rows: { id: "totrecord", raw: true, by: "name", bn: "Worker সংখ্যা (totrecord)" },
          cols: { id: "colcnt", raw: true, by: "name", bn: "দিনের সংখ্যা (colcnt)" },
          all1: { id: "All1", raw: true, by: "name", bn: "প্রথম worker-এর tick (All1)" },
          day1: { id: "c1_1", raw: true, by: "name", bn: "প্রথম worker-এর দিন ১ (c1_1)" }
        }
      },
      mrpay: {
        bn: "Payment only", path: /\/msrpayment\.aspx$/i, feature: "mrpay",
        fields: {
          work: { id: "ddlWorkCode", raw: true, bn: "Work Code dropdown", start: true, label: "Work Code" },
          msr: { id: "ddlMsrNo", raw: true, bn: "Muster Roll No dropdown", start: true, label: "Muster Roll" },
          from: { id: "lblDateFrom", raw: true, bn: "MR From date" },
          to: { id: "lblDateTo", raw: true, bn: "MR To date" },
          rate: { id: "lblWageRate", raw: true, bn: "Wage rate" },
          wst: { id: "txtWrkStDate", raw: true, bn: "Work start date" },
          mb: { id: "mb_no_txt", raw: true, bn: "Measurement Book No box" },
          page: { id: "page_no_txt", raw: true, bn: "Page No box" },
          save: { id: ["btnSave", "btnsave"], raw: true, bn: "Save বোতাম" },
          rows: { id: "totrecord", raw: true, by: "name", bn: "Worker সংখ্যা (totrecord)" },
          minw: { id: "min_wage", raw: true, by: "name", bn: "Minimum wage (min_wage)" },
          wage1: { id: "wage_per_day1", raw: true, by: "name", bn: "প্রথম worker-এর Wage Per Day" },
          att1: { id: "totAtt1", raw: true, by: "name", bn: "প্রথম worker-এর মোট দিন" },
          amt1: { id: "APATA1", raw: true, by: "name", bn: "প্রথম worker-এর Amount" },
          tc1: { id: "TCA1", raw: true, by: "name", bn: "প্রথম worker-এর Total Cash" }
        }
      }
    }
  };

  function ids(f) { return [].concat(f.id || []); }
  function full(f, id) { return f.raw ? id : MAP.prefix.id + id; }

  var API = {
    data: MAP,
    // এই URL কোন page? (path দিয়ে) → page key, নইলে ""
    pageOf: function (path) {
      var p = String(path || ""), ks = Object.keys(MAP.pages);
      for (var i = 0; i < ks.length; i++) if (MAP.pages[ks[i]].path.test(p)) return ks[i];
      return "";
    },
    page: function (key) { return MAP.pages[key] || null; },
    // driver-এর জন্য: field-এর আসল ID (prefix ছাড়া); না থাকলে দেওয়া default
    id: function (page, key, dflt) {
      try { var f = MAP.pages[page].fields[key]; var v = ids(f)[0]; return v || dflt; } catch (e) { return dflt; }
    },
    prefixId: function (dflt) { return (MAP.prefix && MAP.prefix.id) || dflt; },
    prefixName: function (dflt) { return (MAP.prefix && MAP.prefix.name) || dflt; },
    fullId: function (page, key) {
      try { var f = MAP.pages[page].fields[key]; return full(f, ids(f)[0]); } catch (e) { return ""; }
    },
    ids: ids,
    full: full
  };
  window.KD_MAP = API;
})();
