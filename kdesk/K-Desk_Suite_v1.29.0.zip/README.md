# K-Desk Suite by Koushik (formerly G RAM G Demand-Allocation Helper)

A maintainability-focused packaging update. The extension files are organized by responsibility into folders while keeping the v1.0.7 workflow files and behavior intact.

## Source Attribution
This extension adapts Work Demand and Work Allocation workflows from the user-provided GramG Ninja v7.0.0 extension; v1.6.0 also adapts its MR Attendance, Autofill, paste-enable, password reveal and keep-alive modules (v11.0.1), rebranded and gated by the K-Desk licence and Dashboard toggles. Its UI, branding and additional customization are maintained as an independent, unofficial build by Koushik. It is not an official GramG Ninja release and does not imply endorsement by the original author.

## Folder structure
- `manifest.json` — Chrome extension configuration
- `ui/` — popup and List Builder page
- `content/demand/` — Work Demand page scripts
- `content/allocation/` — Work Allocation page scripts
- `content/sync/` — e-KYC / ABPS status sync page script
- `content/mr/` — Muster Roll PDF page helper and MR Attendance (IF works)
- `content/tools/` — portal helpers: paste enable, password reveal, field autofill, keep-alive
- `background/` — MR PDF download and tab workflow service worker
- `shared/` — common core and List Builder logic
- `vendor/` — XLSX library
- `assets/icons/` — extension icons

## Install
1. Extract the ZIP.
2. Open `chrome://extensions` and enable Developer mode.
3. Choose **Load unpacked** and select the extracted `G_RAM_G_Demand-Allocation_Helper_v1.0.9_Folderized` folder (the one containing `manifest.json`).
4. Keep the previous successful ZIP as a backup.

## Changes in v1.0.9
- Organized scripts, UI, vendor library, icons and background worker into folders.
- Updated manifest and relative asset paths to match the new structure.
- No intentional change to Demand, Allocation, e-KYC/ABPS sync or MR PDF processing logic.

## Testing status
Manifest paths were checked against the files in this package, HTML resource paths were validated, all JavaScript syntax checks passed, and ZIP integrity was checked. Live portal end-to-end behavior was not tested as part of this packaging-only update. Test a small batch before a large run.


UI update v1.0.9: gerua/orange theme, Noto Sans Bengali-first font stack, and source/adaptation labels removed from the visible interface as requested.


Version 1.1.6 restores the Ninja-compatible direct tbody row parsing strategy for Work Allocation.


## v1.1.8 Stop fix
- Preserve Stop requests if a delayed/asynchronous page operation later saves a stale run state.
- Applied to both Work Demand and Work Allocation.
- Syntax and package integrity checked; live portal behavior should still be confirmed.
