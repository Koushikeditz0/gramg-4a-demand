// K-Desk Suite by Koushik — কাজ শেষ হলে Windows notification (content script পাঠায়)
chrome.runtime.onMessage.addListener(function (m) {
  if (!m || m.type !== "kd-notify") return;
  try {
    chrome.notifications.create("", { type: "basic", iconUrl: "assets/icons/icon128.png", title: m.title || "K-Desk Suite", message: m.msg || "", priority: 1 });
  } catch (e) {}
});

// v1.20.0: নতুন version এসেছে কিনা (shared/kd-update.js) — Chrome চালু হলে, install/update-এর পরে,
// আর service worker যখনই জাগে (৬ ঘণ্টার cache থাকায় বারবার network-এ যায় না)। নতুন থাকলে icon-এ "NEW" badge।
try { importScripts('../shared/kd-update.js'); } catch (e) {}
function kdUpdCheck(force) {
  try { if (self.KDUpdate) KDUpdate.check(force).then(KDUpdate.badge).catch(function () {}); } catch (e) {}
}
chrome.runtime.onStartup.addListener(function () { kdUpdCheck(false); });
chrome.runtime.onInstalled.addListener(function (d) {
  // Update হয়ে গেলে Dashboard একবার "✅ vX-এ update হয়েছে" দেখায়
  if (d && d.reason === 'update' && d.previousVersion && d.previousVersion !== chrome.runtime.getManifest().version) {
    chrome.storage.local.set({ kd_upd_done: { from: d.previousVersion, to: chrome.runtime.getManifest().version, at: Date.now() } });
  }
  // v1.23.1: Aadhaar Update removed — wipe anything it left behind (numbers were only ever kept here)
  try { chrome.storage.local.remove(['kdaa_uids', 'kdaaLastRun']); } catch (e) {}
  kdUpdCheck(true);
});
chrome.runtime.onMessage.addListener(function (m) { if (m && m.type === 'kd-upd-badge') kdUpdCheck(false); });
kdUpdCheck(false);

// v1.29.0: 📚 7 Registers — opened only from Gram Setu Admin (content/gramsetu/gs-bridge.js).
// The Admin's token is checked with Gram Setu (get_my_context); only Super Admin / GP Admin may open it.
// Only the role + GP is kept (never the token), for 12 hours; the Registers page reads it and locks the GP.
chrome.runtime.onMessage.addListener(function (m, sender, reply) {
  if (!m || m.type !== "kd-reg-open") return;
  var SB = "https://wbzybizfpdalpukfzefk.supabase.co", KEY = "sb_publishable_fCY9paYMNTyepXdI7YRhkw_2u85P7bn";
  if (!sender || !sender.url || !/^https:\/\/gramsetu\.koushiktech\.co\.in\/v2\/admin\.html/.test(sender.url)) { reply({ ok: false, error: "Only from Gram Setu Admin." }); return; }
  fetch(SB + "/rest/v1/rpc/get_my_context", { method: "POST", cache: "no-store",
    headers: { apikey: KEY, Authorization: "Bearer " + m.token, "Content-Type": "application/json" }, body: "{}" })
    .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error("Gram Setu login could not be checked (" + r.status + "). Log in again.")); })
    .then(function (c) {
      if (!c || (c.role !== "super_admin" && c.role !== "gp_admin")) throw new Error("Only a GP Admin or Super Admin can make registers.");
      var scope = { role: c.role, gp: c.gp_name || "", jc: c.jc_prefix || "", user: c.username || "", at: Date.now(), req: m.req || {} };
      if (c.role === "gp_admin" && !scope.jc) throw new Error("This GP Admin login has no GP set in Gram Setu.");
      chrome.storage.local.set({ kd_reg_scope: scope }, function () {
        chrome.tabs.create({ url: chrome.runtime.getURL("ui/registers/registers.html") });
        reply({ ok: true });
      });
    })
    .catch(function (e) { reply({ ok: false, error: (e && e.message) || "Could not open." }); });
  return true;
});
