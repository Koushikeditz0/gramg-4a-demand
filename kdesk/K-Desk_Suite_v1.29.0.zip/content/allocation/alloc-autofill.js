KH_FEATURE("allocation", function () {
/* =====================================================================
   alloc-autofill.js  —  VB-G RAM G Work Allocation autofill (UI)

   Isolated-world content script on workalloc.aspx. Same panel and operation
   model as Work Demand (demand-autofill.js): pick .xlsx → review → Start →
   the MAIN-world engine (alloc-driver.js) drives the page; this UI mirrors
   progress and offers Start / Stop / Start over / Export / Download log /
   Clear queue, with the shared smart rate prompt. State: localStorage "dxwa_run".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__DXWA_UI) return; window.__DXWA_UI = true;

  var LS_RUN = "dxwa_run", LS_ALERT = "dxwa_lastAlert", LS_RESULTS = "dxwa_lastResults";
  // remember whether the user left the panel collapsed
  var MIN_KEY = "dxwa_min";
  function minSaved() { try { return localStorage.getItem(MIN_KEY) === "1"; } catch (e) { return false; } }
  function minSave(on) { try { localStorage.setItem(MIN_KEY, on ? "1" : "0"); } catch (e) {} }
  var CS_LOG = "dxwa_log_runs";
  var CS_LOG_MAX_RUNS = 15;
  var sel = {};
  var wasActive = false;
  var lastLogSig = "";

  /* ---------------- durable activity log (chrome.storage.local) ---------------- */
  function cstore() { try { return (chrome && chrome.storage && chrome.storage.local) || null; } catch (e) { return null; } }
  function persistLog(r, cb) {
    var cs = cstore();
    if (!cs || !r || !r.log) { if (cb) cb(); return; }
    var id = r.runId || ("wa-" + (r.sig || "nosig"));
    var sig = id + ":" + r.log.length;
    if (sig === lastLogSig && !cb) return;
    lastLogSig = sig;
    try {
      cs.get(CS_LOG, function (o) {
        var runs = (o && o[CS_LOG]) || [];
        var idx = -1; for (var i = 0; i < runs.length; i++) { if (runs[i].runId === id) { idx = i; break; } }
        var rec = { runId: id, sig: r.sig || "", startedAt: (idx >= 0 ? runs[idx].startedAt : Date.now()), updatedAt: Date.now(), entries: r.log };
        if (idx >= 0) runs[idx] = rec; else runs.push(rec);
        if (runs.length > CS_LOG_MAX_RUNS) runs = runs.slice(-CS_LOG_MAX_RUNS);
        var set = {}; set[CS_LOG] = runs;
        try { cs.set(set, function () { if (cb) cb(); }); } catch (e) { if (cb) cb(); }
      });
    } catch (e) { if (cb) cb(); }
  }
  function clearLogStore(cb) { var cs = cstore(); lastLogSig = ""; if (!cs) { if (cb) cb(); return; } try { cs.remove(CS_LOG, function () { if (cb) cb(); }); } catch (e) { if (cb) cb(); } }

  var DEBUG = (function () { try { return localStorage.getItem("dxwa_debug") !== "0"; } catch (e) { return true; } })();
  function dbg() { if (!DEBUG) return; try { console.log.apply(console, ["%c[DAH-WA/ui]", "color:#8a2be2;font-weight:bold"].concat([].slice.call(arguments))); } catch (e) {} }

  /* ---------------- smart rate & share prompt (shared across surfaces) ---------------- */
  function recordWin() {}
  function maybeShowRate() {}

  /* ---------------------- state store ---------------------- */
  function loadRun() { try { return JSON.parse(localStorage.getItem(LS_RUN) || "null"); } catch (e) { return null; } }
  function saveRun(r) { try { r.updatedAt = Date.now(); localStorage.setItem(LS_RUN, JSON.stringify(r)); } catch (e) {} }
  function post(type) { try { window.postMessage({ source: "DXWA_UI", type: type }, "*"); } catch (e) {} }

  /* ---------------------- parsing ---------------------- */
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function fmtTime(t) { if (!t) return ""; try { var d = new Date(t); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()); } catch (e) { return ""; } }
  function toDMY(v) {
    if (v == null || v === "") return "";
    if (v instanceof Date && !isNaN(v)) return pad2(v.getUTCDate()) + "/" + pad2(v.getUTCMonth() + 1) + "/" + v.getUTCFullYear();
    if (typeof v === "number" && isFinite(v)) { try { var dc = window.XLSX && XLSX.SSF && XLSX.SSF.parse_date_code(v); if (dc && dc.y) return pad2(dc.d) + "/" + pad2(dc.m) + "/" + dc.y; } catch (e) {} }
    var s = String(v).trim(); if (!s) return "";
    var iso = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if (iso) return pad2(+iso[3]) + "/" + pad2(+iso[2]) + "/" + iso[1];
    var m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{2,4})/);
    if (m) { var y = +m[3]; if (y < 100) y += 2000; return pad2(+m[1]) + "/" + pad2(+m[2]) + "/" + y; }
    return s;
  }
  function pick(obj, re) { for (var k in obj) if (obj.hasOwnProperty(k) && re.test(k)) return obj[k]; return ""; }
  function hashStr(s) { var h = 5381, i = s.length; while (i) h = (h * 33) ^ s.charCodeAt(--i); return (h >>> 0).toString(16); }

  // Parse workbook -> run grouped by WORK CODE. Columns: reg, Applicant, From, Days, WORK CODE.
  function parseWorkbook(ab) {
    if (!window.XLSX) throw new Error("spreadsheet library not loaded");
    var wb = XLSX.read(ab, { cellDates: false });
    var ws = wb.Sheets[wb.SheetNames[0]];
    return parseRows(XLSX.utils.sheet_to_json(ws, { defval: "", raw: true }));
  }
  // rows = [{ "Reg No": …, "Applicant": …, … }] from a sheet or from the List Builder
  function parseRows(rows) {
    var norm = [], sigParts = [];
    rows.forEach(function (o) {
      var reg = String(pick(o, /reg/i) || "").trim();
      var applicant = String(pick(o, /applic|worker|name/i) || "").trim();
      var from = toDMY(pick(o, /alloc.*from|work.*from|^from/i) || pick(o, /from/i));
      var daysRaw = String(pick(o, /day/i) || "").replace(/[^0-9]/g, "");
      var workCode = String(pick(o, /work\s*code/i) || pick(o, /code/i) || "").trim();
      if (!reg && !applicant) return;
      norm.push({ reg: reg, applicant: applicant, from: from, days: daysRaw, workCode: workCode });
      sigParts.push(reg + "|" + applicant.toLowerCase() + "|" + from + "|" + daysRaw + "|" + workCode);
    });
    if (!norm.length) throw new Error("no data rows found (need columns: reg, Applicant, From, Days, WORK CODE)");
    var groups = [], byCode = {};
    norm.forEach(function (n) {
      var key = n.workCode || "(no code)";
      if (!byCode[key]) { byCode[key] = { workCode: n.workCode, category: (String(n.workCode).split("/")[1] || "").toUpperCase(), drives: 0, workers: [] }; groups.push(byCode[key]); }
      byCode[key].workers.push({ reg: n.reg, applicant: n.applicant, from: n.from, days: n.days, status: "pending", message: "", at: 0 });
    });
    return { v: 1, sig: hashStr(sigParts.join("~")), createdAt: Date.now(), updatedAt: Date.now(), active: false, stopRequested: false, pendingSave: null, groups: groups, log: [] };
  }

  /* ---------------------- summary ---------------------- */
  function counts(r) {
    var t = 0, done = 0, err = 0, skip = 0, pend = 0;
    (r.groups || []).forEach(function (g) { (g.workers || []).forEach(function (w) { t++; if (w.status === "done") done++; else if (w.status === "error") err++; else if (w.status === "skipped") skip++; else pend++; }); });
    return { total: t, done: done, err: err, skip: skip, pend: pend, groups: (r.groups || []).length };
  }
  function formatTs(ms) { if (!ms) return ""; var d = new Date(ms); if (isNaN(d.getTime())) return ""; return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()); }

  /* ---------------------- panel ---------------------- */
  function status(msg, kind) { if (!sel.st) return; sel.st.textContent = msg || ""; sel.st.className = "st" + (kind ? " " + kind : ""); }

  /* ---------------- eKYC / ABPS gating ----------------
     The 4A rule: only eKYC-done (and ABPS-enabled) workers may be entered. The cached
     ABPS dataset (synced on the Aadhaar/ABPS Status Report page) lets us decide that
     BEFORE touching the portal, so ineligible rows never cost a postback. */
  var GATE_KEY = "dxwa_gate";
  var GATE_LABEL = { all: "All workers", ekyc: "Only eKYC done", abps: "Only ABPS enabled", ekyc_abps: "Only eKYC + ABPS enabled" };
  // the two ticks -> one rule
  function gateFromTicks(e, a) { return e && a ? "ekyc_abps" : e ? "ekyc" : a ? "abps" : "all"; }
  var abps = { map: {}, meta: {} };
  function gateSaved() { try { var v = localStorage.getItem(GATE_KEY); return GATE_LABEL[v] ? v : "all"; } catch (e) { return "all"; } }
  function gateSave(v) { try { localStorage.setItem(GATE_KEY, v); } catch (e) {} }
  function abpsReload() {
    if (!window.DX || !DX.abpsLoad) return;
    DX.abpsLoad(function (map, meta) {
      abps.map = map; abps.meta = meta; render(); injectPortalGridBadges();
    });
  }

  /* Put the status badges directly beside the beneficiary name in the portal's
     native Work Allocation grid (Registration No. = cell 2, Job seeker name = cell 4). */
  function injectPortalGridBadges() {
    try {
      var grid = document.getElementById("ctl00_ContentPlaceHolder1_GridView1");
      if (!grid || !grid.rows) return;
      if (!document.getElementById("dxwa-native-badge-style")) {
        var st = document.createElement("style");
        st.id = "dxwa-native-badge-style";
        st.textContent =
          ".dxwa-native-status{display:inline-flex;gap:3px;align-items:center;flex-wrap:wrap;margin-left:6px;vertical-align:middle}" +
          ".dxwa-native-badge{display:inline-block;border-radius:999px;padding:2px 5px;font:600 10px/1.25 'Noto Sans Bengali',Arial,sans-serif;white-space:nowrap;border:1px solid transparent}" +
          ".dxwa-native-good{background:#e1f5e8;color:#137333;border-color:#a8dab5}" +
          ".dxwa-native-no{background:#fce8e6;color:#b3261e;border-color:#f4b9b5}" +
          ".dxwa-native-unknown{background:#f1f3f4;color:#5f6368;border-color:#dadce0}" +
          ".dxwa-native-legend{display:flex;gap:5px;flex-wrap:wrap;margin:5px 0;padding:5px 8px;border:1px solid #e2e8f0;border-radius:6px;background:#ffffff;font:12px 'Noto Sans Bengali',Arial,sans-serif}" +
          ".dxwa-native-legend strong{color:#3730a3}";
        document.head.appendChild(st);
      }
      var header = grid.rows[0];
      if (header && !document.getElementById("dxwa-native-legend")) {
        var legend = document.createElement("div");
        legend.id = "dxwa-native-legend";
        legend.className = "dxwa-native-legend";
        legend.innerHTML = "<strong>e-KYC / ABPS:</strong><span class='dxwa-native-badge dxwa-native-good'>✓ Enabled / Done</span><span class='dxwa-native-badge dxwa-native-no'>✕ Not enabled / Done</span><span class='dxwa-native-badge dxwa-native-unknown'>? Unknown</span>";
        grid.parentNode.insertBefore(legend, grid);
      }
      for (var ri = 1; ri < grid.rows.length; ri++) {
        var row = grid.rows[ri], cells = row.cells;
        if (!cells || cells.length < 4) continue;
        var reg = (cells[1].textContent || "").trim();
        var nameCell = cells[3];
        var wrap = nameCell.querySelector(".dxwa-native-status");
        // Exclude our own badge text when a MutationObserver/postback re-runs this routine.
        var nameClone = nameCell.cloneNode(true);
        var oldWrap = nameClone.querySelector(".dxwa-native-status");
        if (oldWrap) oldWrap.remove();
        var name = (nameClone.textContent || "").replace(/\s+/g, " ").trim();
        if (!/^WB-\d{2}-/i.test(reg) || !name) continue;
        if (!wrap) {
          wrap = document.createElement("span");
          wrap.className = "dxwa-native-status";
          wrap.setAttribute("data-dxwa-reg", reg);
          nameCell.appendChild(wrap);
        }
        var found = null;
        try { if (window.DX && DX.abpsFind) found = DX.abpsFind(abps.map || {}, reg, name); } catch (e) {}
        var ekyc = found && (String(found.ekyc) === "1" || found.ekyc === true);
        var abpsOk = found && (String(found.abps) === "1" || found.abps === true);
        var sig = (found ? (found.ekyc + "|" + found.abps + "|" + found.aadhaar) : "unknown");
        if (wrap.getAttribute("data-dxwa-status") === sig && wrap.childNodes.length === 2) continue;
        wrap.setAttribute("data-dxwa-status", sig);
        function badge(label, ok, title) {
          var el = document.createElement("span");
          el.className = "dxwa-native-badge " + (!found ? "dxwa-native-unknown" : (ok ? "dxwa-native-good" : "dxwa-native-no"));
          el.textContent = label;
          el.title = title;
          return el;
        }
        wrap.textContent = "";
        wrap.appendChild(badge(!found ? "e-KYC ?" : (ekyc ? "e-KYC ✓" : "e-KYC ✕"), !!ekyc, !found ? "No matching synced record" : (ekyc ? "e-KYC done" : "e-KYC not done")));
        wrap.appendChild(badge(!found ? "ABPS ?" : (abpsOk ? "ABPS ✓" : "ABPS ✕"), !!abpsOk, !found ? "No matching synced record" : (abpsOk ? "ABPS enabled" : "ABPS not enabled")));
      }
    } catch (e) { dbg("native grid badges:", e); }
  }

  var nativeBadgeObserver = null;
  function observePortalGrid() {
    if (nativeBadgeObserver || !document.body) return;
    nativeBadgeObserver = new MutationObserver(function () {
      if (document.getElementById("ctl00_ContentPlaceHolder1_GridView1")) injectPortalGridBadges();
    });
    nativeBadgeObserver.observe(document.body, { childList: true, subtree: true });
  }
  function regOf(g, w) { return w.reg; }
  // GP metadata covering this run (the first worker whose GP has synced data), else null
  function runMeta(r) {
    if (!r || !r.groups || !window.DX || !DX.abpsMetaFor) return null;
    for (var i = 0; i < r.groups.length; i++) {
      var g = r.groups[i];
      for (var j = 0; j < (g.workers || []).length; j++) { var m = DX.abpsMetaFor(abps.meta, regOf(g, g.workers[j])); if (m) return m; }
    }
    return null;
  }
  // effective mode: the remembered choice, but only when this GP actually has data
  function gateMode(r) { return runMeta(r) ? gateSaved() : "all"; }
  function abpsLink() {
    var a = document.createElement("a");
    a.href = location.origin + "/vbgramg/UID/AppABPSRpt.aspx"; a.target = "_blank"; a.rel = "noopener";
    a.textContent = "Open the ABPS report ↗";
    return a;
  }
  function renderGate(r) {
    if (!sel.gk_ekyc || !sel.gk_abps || !sel.gatehint) return;
    var m = runMeta(r), h = sel.gatehint, cls = "";
    var gv = gateSaved(), off = !m || !!(r && r.active);
    sel.gk_ekyc.checked = gv === "ekyc" || gv === "ekyc_abps";
    sel.gk_abps.checked = gv === "abps" || gv === "ekyc_abps";
    sel.gk_ekyc.disabled = sel.gk_abps.disabled = off;
    sel.gatechk.className = "gatechk" + (off ? " off" : "");
    sel.gatehd.textContent = "Entry rule — " + (gv === "all" ? "all workers (nothing ticked)" : GATE_LABEL[gv].replace(/^Only/, "only"));
    h.textContent = "";
    if (!r || !r.groups) {
      h.textContent = "Load a sheet to check eKYC / ABPS data.";
    } else if (!m) {
      cls = "warn";
      h.appendChild(document.createTextNode("No ABPS data for this GP yet, so every worker will be entered. "));
      h.appendChild(abpsLink());
      h.appendChild(document.createTextNode(" and click Sync to enable this rule."));
    } else {
      h.appendChild(document.createTextNode("ABPS data for " + DX.abpsLabel(m) + ": " + m.count + " records, synced " +
        DX.syncedWhen(m) +
        (m.complete === false ? " (partial sync)" : "") + ". "));
      if (DX.abpsStale(m) && gateSaved() !== "all") {
        cls = "warn";
        h.appendChild(document.createTextNode("Older than a week — "));
        h.appendChild(abpsLink());
        h.appendChild(document.createTextNode(" and re-sync. You can still Start."));
      } else cls = "ok";
    }
    h.className = "gatehint" + (cls ? " " + cls : "");
  }
  // Pre-check: mark ineligible workers skipped before the driver ever runs.
  function precheck(r) {
    var mode = gateMode(r);
    r.gate = mode;
    if (mode === "all") return 0;
    // v1.25.1 (Koushik): a list from Gram Setu was already filtered there with the cloud eKYC/ABPS flags —
    // this PC's own ABPS data may be older, so it must not skip anyone.
    if (r.fromCloud) { r.log.push({ t: Date.now(), level: "info", text: "Gram Setu list — eKYC/ABPS pre-check off (already checked in the app)." }); return 0; }
    var m = runMeta(r), n = 0, now = Date.now();
    if (DX.abpsStale(m)) r.log.push({ t: now, level: "warn", text: "ABPS data is " + DX.abpsAgeDays(m) + " day(s) old — proceeding anyway. Re-sync soon." });
    r.groups.forEach(function (g) {
      g.workers.forEach(function (w) {
        if (w.status !== "pending") return;                 // never re-judge done / already-skipped
        var reg = regOf(g, w);
        var c = DX.abpsCheck(abps.map, reg, w.applicant, mode);
        if (c.ok) return;
        w.status = "skipped"; w.skipReason = c.reason; w.at = now; n++;
        r.log.push({ t: now, level: "warn", text: reg + " · " + w.applicant + ": " + c.reason + " — skipped (" + GATE_LABEL[mode] + ")" });
      });
    });
    r.log.push({ t: now, level: n ? "warn" : "info", text: "Pre-check (" + GATE_LABEL[mode] + "): " + n + " worker(s) skipped before entry." });
    return n;
  }

  /* ---------------- per-beneficiary e-KYC / ABPS badges ----------------
     Uses only the synced ABPS dataset. A missing match is shown as Unknown,
     never as a negative status, so unsynced data is not misrepresented. */
  function workerStatusBadges(w) {
    var found = null;
    try {
      if (window.DX && DX.abpsFind && abps && abps.map) {
        found = DX.abpsFind(abps.map, w.reg, w.applicant);
      }
    } catch (e) { found = null; }

    if (!found) {
      return "<span class='dx-status-badges' title='Sync the ABPS Status Report or check whether this beneficiary is present in the synced data.'>" +
        "<span class='dx-badge dx-badge-unknown'>e-KYC ?</span>" +
        "<span class='dx-badge dx-badge-unknown'>ABPS ?</span>" +
        "</span>";
    }

    var ekycOk = String(found.ekyc) === "1" || found.ekyc === true;
    var abpsOk = String(found.abps) === "1" || found.abps === true;
    var ekycText = ekycOk ? "e-KYC ✓" : "e-KYC ✕";
    var abpsText = abpsOk ? "ABPS ✓" : "ABPS ✕";
    var ekycTitle = ekycOk ? "e-KYC done" : (found.aadhaar ? "e-KYC not done" : "Aadhaar not seeded / e-KYC not done");
    var abpsTitle = abpsOk ? "ABPS enabled" : "ABPS not enabled";
    return "<span class='dx-status-badges'>" +
      "<span class='dx-badge " + (ekycOk ? "dx-badge-good" : "dx-badge-no") + "' title='" + esc(ekycTitle) + "'>" + ekycText + "</span>" +
      "<span class='dx-badge " + (abpsOk ? "dx-badge-good" : "dx-badge-no") + "' title='" + esc(abpsTitle) + "'>" + abpsText + "</span>" +
      "</span>";
  }

  function render() {
    maybeShowRate();
    var r = loadRun();
    var active = !!(r && r.active);
    if (wasActive && !active) onRunEnded(r);
    wasActive = active;
    r = loadRun();
    if (!r || !r.groups) {
      sel.summary.textContent = "No sheet loaded.";
      sel.tbody.innerHTML = ""; sel.logbox.innerHTML = "";
      if (sel.prog) sel.prog.hidden = true;
      sel.start.disabled = true; sel.stop.disabled = true; sel.over.disabled = true; sel.exp.disabled = true;
      if (sel.clear) sel.clear.disabled = true;
      if (sel.dl) sel.dl.disabled = false;
      renderGate(null); renderRule(null);
      if (window.KDP) KDP.tiles(sel.tiles, sel.fnote, sel.panel, []);
      return;
    }
    renderGate(r); renderRule(r);
    var c = counts(r);
    // v1.26.0: সংখ্যা এখন টালিতে; summary-তে শুধু list কোথা থেকে আর কত বড়
    sel.summary.textContent = (r.fromCloud ? "☁ Gram Setu list · " : "") + c.groups + " work · " + c.total + " জন";
    if (window.KDP) KDP.tiles(sel.tiles, sel.fnote, sel.panel, [
      { k: "done", n: c.done, l: "Allocated", c: "g" }, { k: "skip", n: c.skip, l: "নিয়মে বাদ", c: "s" },
      { k: "err", n: c.err, l: "ভুল / ফেরত", c: "e" }, { k: "pend", n: c.pend, l: "বাকি", c: "p" }]);

    if (sel.prog) {
      var processed = c.done + c.err + c.skip;
      var pct = c.total ? Math.round(processed / c.total * 100) : 0;
      if (sel.progfill) sel.progfill.style.width = pct + "%";
      if (sel.progtxt) sel.progtxt.innerHTML = progLine(r, c, processed);
      sel.prog.hidden = !c.total;   // v1.26.0: list থাকলেই দেখায়, শুধু চলার সময় নয়
    }

    var html = "", n = 0;
    r.groups.forEach(function (g) {
      g.workers.forEach(function (w) {
        n++;
        var cls = w.status === "done" ? "ok" : w.status === "error" ? "err" : (w.status === "skipped" || w.status === "filled") ? "warn" : "";
        var sy = w.status === "done" ? "✓" : w.status === "error" ? "✕" : w.status === "skipped" ? "⊘" : w.status === "filled" ? "…" : "•";
        html += "<tr class='" + (window.KDP ? KDP.rowClass(w.status) : "") + "'>" +
          "<td class='c'>" + n + "</td>" +
          "<td title='" + esc(g.workCode) + "'>" + esc(shortWork(g.workCode)) + "</td>" +
          "<td><div class='applicant-line'><span class='applicant-name'>" + esc(w.applicant) + "</span>" + workerStatusBadges(w) + "</div>" + (w.status === "skipped" && w.skipReason ? "<div class='why'>⊘ " + esc(w.skipReason) + "</div>" : "") + (w.status === "error" && w.message ? "<div class='why err'>✕ " + esc(w.message) + "</div>" : "") + "</td>" +
          "<td class='c'>" + esc(w.from) + "</td>" +
          "<td class='c'>" + esc(w.days) + "</td>" +
          "<td class='c st-" + cls + "' title='" + esc(w.skipReason || w.message || "") + "'>" + sy + "</td>" +
          "</tr>";
      });
    });
    sel.tbody.innerHTML = html;

    var lg = (r.log || []).slice(-40).reverse().map(function (e) {
      var cl = e.level === "err" ? "l-err" : e.level === "warn" ? "l-warn" : e.level === "ok" ? "l-ok" : "l-info";
      return "<div class='" + cl + "'><span class='lt'>" + fmtTime(e.t) + "</span>" + esc(e.text) + "</div>";
    }).join("");
    sel.logbox.innerHTML = lg;

    persistLog(r);

    sel.start.disabled = r.active || c.pend === 0;
    sel.start.textContent = (c.done || c.err) ? ("▶ Resume (" + c.done + "/" + c.total + " done)") : ("▶ Start (" + c.total + " applicant" + (c.total === 1 ? "" : "s") + ")");
    sel.stop.disabled = !r.active && !autoTimer;   // Stop also cancels the hand-off countdown
    sel.over.disabled = r.active;
    sel.exp.disabled = c.total === 0;
    if (sel.clear) sel.clear.disabled = r.active;
    if (sel.dl) sel.dl.disabled = false;
  }
  // v1.26.0: progress-এর লেখা — কতজন শেষ, এখন কে, আন্দাজে কত সময় বাকি
  function progLine(r, c, processed) {
    var t = "<b>" + processed + "</b> / " + c.total + " জন", sub = "";
    if (r.active) {
      var cur = window.KDP && KDP.now(r), left = window.KDP ? KDP.eta(r, c.pend) : "";
      sub = (cur ? "এখন: " + esc(shortWork(cur.g.workCode)) + " · " + esc(cur.w.applicant) : "চলছে…") + (left ? " · বাকি " + left : "");
    } else if (autoTimer) sub = "নিজে থেকে শুরু হচ্ছে…";
    else if (c.pend) sub = (processed ? "থেমে আছে · " : "") + "বাকি " + c.pend + " জন — ▶ চাপুন";
    else sub = "সব শেষ ✓";
    return t + "<span class='kdp-now'>" + sub + "</span>";
  }
  // v1.26.0: নিয়ম এক লাইনে (বদলাতে ⚙ Advanced)
  function renderRule(r) {
    if (!sel.rule) return;
    var gv = gateMode(r), on = !!(r && r.active);
    var chip = function (ok, txt) { return "<span class='kdp-chip " + (ok ? "y" : "n") + "'>" + txt + (ok ? " ✓" : " ✗") + "</span>"; };
    sel.rule.innerHTML = "<b>নিয়ম</b>" +
      (r && r.fromCloud ? "<span class='kdp-chip y'>Gram Setu-তে দেখা</span>" : chip(gv === "ekyc" || gv === "ekyc_abps", "eKYC") + chip(gv === "abps" || gv === "ekyc_abps", "ABPS")) +
      (on ? "<span class='kdp-lock'>🔒 চলার সময় বদলানো যাবে না</span>" : "");
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (m) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]; }); }
  function shortWork(c) { var p = String(c || "").split("/"); var tail = p[p.length - 1] || String(c || ""); return tail.length > 8 ? "…" + tail.slice(-8) : tail; }

  /* ---------------------- actions ---------------------- */
  function acceptRun(run) {
    var cloud = !!run.fromCloud;
    dbg("parsed sheet", { works: run.groups.length, applicants: counts(run).total, sig: run.sig });
    var prev = loadRun();
    if (prev && prev.sig === run.sig && prev.groups) { run = prev; run.active = false; run.stopRequested = false; status("Same sheet recognised — resuming where it left off.", "ok"); }
    else { status("Loaded " + counts(run).total + " applicant(s) across " + run.groups.length + " work(s). Review, then Start.", "ok"); }
    if (cloud) run.fromCloud = true;   // Gram Setu hand-off: eKYC/ABPS already checked there (v1.25.1)
    if (!run.runId) run.runId = "wa-" + Date.now() + "-" + Math.random().toString(36).slice(2, 6);
    saveRun(run); render();
  }
  // List Builder: type 1/10, tick family members, load straight into the queue (listbuilder.js)
  function openBuilder() {
    var r = loadRun();
    if (r && r.active) { status("A run is in progress — Stop it before building a new list.", "warn"); return; }
    if (!window.GNList) { status("List Builder didn't load — reload the page.", "warn"); return; }
    GNList.open({
      mode: "alloc",
      onLoad: function (rows) {
        var cur = loadRun();
        if (cur && cur.active) { status("A run is in progress — Stop it before loading a new list.", "warn"); return false; }
        acceptRun(parseRows(rows));
        return true;
      }
    });
  }
  /* ---- Work Demand → Work Allocation hand-off (Gram Setu app lists with a Work Code) ----
     The Demand panel leaves the workers whose demand went through in chrome.storage.local
     kdlb_alloc_pending; load them here and, if asked, start after a short countdown. */
  var autoTimer = null, LS_COMBO = "kdlb_combo";
  function comboFor(r) { try { var c = JSON.parse(localStorage.getItem(LS_COMBO) || "null"); return c && r && c.sig === r.sig ? c : null; } catch (e) { return null; } }
  // One sheet per worker: Demand result next to Allocation result, plus a summary sheet.
  function doComboExport(r, combo) {
    if (!window.XLSX) return false;
    var key = function (reg, a) { return String(reg).trim().toUpperCase() + "|" + String(a).trim().toLowerCase(); };
    var alloc = {};
    r.groups.forEach(function (g) { g.workers.forEach(function (w) { alloc[key(w.reg, w.applicant)] = { w: w, code: g.workCode }; }); });
    var ST_D = { done: "Success", error: "Error", skipped: "Skipped" }, ST_A = { done: "Allocated", error: "Error", skipped: "Skipped" };
    var sd = { total: 0, done: 0, error: 0, skipped: 0 }, sa = { total: 0, done: 0, error: 0, skipped: 0 };
    var aoa = [["#", "Reg No", "Applicant", "Work From", "Days", "Work Demand To", "Demand Status", "Demand Result", "Work Code", "Allocation Status", "Allocation Result", "Timestamp"]];
    combo.demand.forEach(function (d, i) {
      sd.total++; if (sd[d.status] != null) sd[d.status]++;
      var a = alloc[key(d.reg, d.applicant)], aw = a && a.w;
      if (aw) { sa.total++; if (sa[aw.status] != null) sa[aw.status]++; }
      aoa.push([i + 1, d.reg, d.applicant, d.from, d.days, d.toDate, ST_D[d.status] || d.status, d.skipReason || d.message || "",
        aw ? a.code : combo.workCode, aw ? (ST_A[aw.status] || aw.status) : "পাঠানো হয়নি (Demand সফল নয়)",
        aw ? (aw.skipReason || aw.message || "") : "", aw ? formatTs(aw.at) : ""]);
    });
    var sum = [["", "মোট", "সফল", "Error", "Skipped"],
      ["Work Demand", sd.total, sd.done, sd.error, sd.skipped],
      ["Work Allocation", sa.total, sa.done, sa.error, sa.skipped],
      [], ["Work Code", combo.workCode]];
    var wb = XLSX.utils.book_new(), ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 4 }, { wch: 24 }, { wch: 24 }, { wch: 11 }, { wch: 5 }, { wch: 13 }, { wch: 13 }, { wch: 30 }, { wch: 28 }, { wch: 16 }, { wch: 30 }, { wch: 19 }];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sum), "Summary");
    XLSX.utils.book_append_sheet(wb, ws, "Demand + Allocation");
    var d = new Date(), name = "Demand-Allocation-report-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
    XLSX.writeFile(wb, name);
    return true;
  }
  // Allocation results back to the Gram Setu app (only for runs that came from it)
  function reportAlloc(r, combo) {
    var find = KDLink.matcher(combo.map), items = [];
    r.groups.forEach(function (g) { g.workers.forEach(function (w) {
      var m = find(w.reg, w.applicant);
      if (m) items.push({ l: m.l, w: m.w, s: w.status, m: w.skipReason || w.message || "", c: g.workCode });
    }); });
    KDLink.reportResults("alloc", items, function (err, o) { dbg("allocation results to Gram Setu", err ? (err.code || err.message) : (o && o.sent)); });
  }
  function cancelAuto() { if (autoTimer) { clearInterval(autoTimer); autoTimer = null; } }
  function pickUpHandoff() {
    try {
      chrome.storage.local.get("kdlb_alloc_pending", function (o) {
        var h = o && o.kdlb_alloc_pending;
        if (!h || !h.rows || !h.rows.length) return;
        if (Date.now() - h.at > 3 * 24 * 3600 * 1000) { chrome.storage.local.remove("kdlb_alloc_pending"); return; }
        var cur = loadRun();
        if (cur && cur.active) { status("Demand থেকে " + h.rows.length + " জন অপেক্ষায় — এই run শেষ হলে page reload করুন।", "warn"); return; }
        chrome.storage.local.remove("kdlb_alloc_pending");
        var hr = parseRows(h.rows); hr.fromCloud = true;
        acceptRun(hr);
        // keep the Demand results: when this run finishes, one Demand + Allocation report is written
        try { var lr = loadRun(); if (lr && h.demand) localStorage.setItem(LS_COMBO, JSON.stringify({ sig: lr.sig, workCode: h.workCode, demand: h.demand, map: h.map || [], at: Date.now() })); } catch (e) {}
        if (!h.auto) { status("Demand থেকে " + h.rows.length + " জন এসেছে (" + h.workCode + ")। দেখে নিয়ে Start চাপুন।", "ok"); return; }
        var left = 5;
        var tick = function () {
          if (left <= 0) { cancelAuto(); doStart(); status("Demand থেকে আসা " + h.rows.length + " জনের Work Allocation শুরু হল।", "ok"); return; }
          status("Demand থেকে " + h.rows.length + " জন এসেছে (" + h.workCode + ")। " + left + " সেকেন্ডে নিজে থেকে Start — থামাতে Stop চাপুন।", "ok");
          left--;
        };
        tick(); autoTimer = setInterval(tick, 1000);
      });
    } catch (e) { dbg("handoff pick-up failed", e && e.message); }
  }
  function builderLabel(n) { if (sel.build) sel.build.textContent = "＋ Build" + (n ? " (" + n + ")" : ""); }
  function onFile(file) {
    var r = loadRun();
    if (r && r.active) { status("A run is in progress — Stop it before loading a new sheet.", "warn"); return; }
    var fr = new FileReader();
    fr.onload = function () {
      try {
        acceptRun(parseWorkbook(fr.result));
      } catch (e) { status("Could not read that file: " + (e && e.message ? e.message : e), "warn"); }
    };
    fr.onerror = function () { status("Could not read that file.", "warn"); };
    fr.readAsArrayBuffer(file);
  }

  // GP key: queue-তে key-এর বাইরের GP-র Job Card থাকলে run শুরু হয় না
  function doStart() {
    // v1.24.0: 🩺 Health Check — দরকারি field না পেলে Start থামে (shared/kd-health.js)
    if (window.KD_HEALTH && !window.KD_HEALTH.gate("allocation", doStartChecked, "Work Allocation")) { status("Health Check: portal-এর কিছু field পাওয়া যায়নি — Start হয়নি।", "warn"); return; }
    if (!window.KD_HEALTH) doStartChecked();
  }
  function doStartChecked() {
    var r0 = loadRun(); if (!r0) return;
    var cards = []; r0.groups.forEach(function (g) { g.workers.forEach(function (w) { cards.push(regOf(g, w)); }); });
    KH_LICENSE.gpCheck(cards, function (bad) { if (bad) { cancelAuto(); status(KH_LICENSE.gpText(bad), "warn"); return; } doStart2(); });
  }
  function doStart2() {
    var r = loadRun(); if (!r) return;
    r.active = true; r.stopRequested = false;
    (r.log = r.log || []).push({ t: Date.now(), level: "info", text: "Run started." });
    var pre = precheck(r);                 // eKYC/ABPS rule — decided without touching the portal
    saveRun(r); wasActive = true; render();
    dbg("start clicked", counts(r), "pre-check skipped", pre);
    post("start");
  }
  function doStop() {
    var r = loadRun(); if (!r) return;
    r.stopRequested = true; r.active = false; saveRun(r);
    post("stop"); render();
    status("Stopping… the current work will not be saved; Resume continues from here.", "warn");
  }
  function doStartOver() {
    var r = loadRun(); if (!r) return;
    r.groups.forEach(function (g) { g.drives = 0; g.workers.forEach(function (w) { w.status = "pending"; w.message = ""; w.at = 0; w.attempts = 0; }); });
    r.active = false; r.stopRequested = false; r.pendingSave = null; r.log = [];
    try { localStorage.removeItem(LS_ALERT); } catch (e) {}
    saveRun(r); render(); status("Reset — all rows pending.", "ok");
  }
  function clearQueue() { try { localStorage.removeItem(LS_RUN); } catch (e) {} try { localStorage.removeItem(LS_ALERT); } catch (e) {} wasActive = false; render(); }
  function doClear() {
    var r = loadRun();
    if (r && r.active) { status("Stop the run before clearing the queue.", "warn"); return; }
    if (!r || !r.groups || !r.groups.length) { status("Nothing to clear.", "ok"); return; }
    var c = counts(r);
    var msg = "Clear the loaded sheet and all " + c.total + " queued row(s)?" + ((c.done || c.err) ? "\n\n" + c.done + " done / " + c.err + " error will be discarded — export first if you need a record." : "");
    if (!confirm(msg)) return;
    dbg("queue cleared by user", c); clearQueue();
    status("Queue cleared. Choose an Excel file to load a new one.", "ok");
  }
  function doExport(runArg) {
    var r = runArg || loadRun(); if (!r || !window.XLSX) return false;
    var aoa = [["Reg No", "Applicant", "Work Code", "Alloc From", "Days", "Status", "Skip Reason", "Result", "Timestamp"]];
    r.groups.forEach(function (g) {
      g.workers.forEach(function (w) {
        aoa.push([w.reg, w.applicant, g.workCode, w.from, w.days,
          (w.status === "done" ? "Allocated" : w.status === "error" ? "Error" : w.status === "skipped" ? "Skipped" : w.status),
          w.skipReason || "", w.message || "", formatTs(w.at)]);
      });
    });
    var ws = XLSX.utils.aoa_to_sheet(aoa), wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Work Allocation");
    var d = new Date(), name = "WorkAllocation-results-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
    dbg("export results", name, (aoa.length - 1) + " rows");
    XLSX.writeFile(wb, name);
    return true;
  }
  function onClickExport() {
    var r = loadRun();
    if (!r || !r.groups || !r.groups.length) { status("Nothing to export yet.", "warn"); return; }
    var combo = comboFor(r);
    if (!(combo ? doComboExport(r, combo) : doExport(r))) { status("Export needs the spreadsheet library — reload the page.", "warn"); return; }
    if (r.active) { status("Results exported. (Queue kept — run still active.)", "ok"); return; }
    clearQueue(); status("Results exported and queue cleared.", "ok");
  }
  function doDownloadLog(cb) {
    if (!window.XLSX) { status("Log download needs the spreadsheet library — reload the page.", "warn"); if (cb) cb(false); return; }
    var r = loadRun();
    persistLog(r, function () {
      var cs = cstore();
      var write = function (runs) {
        var aoa = [["Run", "Timestamp", "Level", "Message"]];
        (runs || []).forEach(function (run) { (run.entries || []).forEach(function (e) { aoa.push([run.runId || "", formatTs(e.t), (e.level || "info"), e.text || ""]); }); });
        if (aoa.length <= 1) { status("No activity log to download yet.", "warn"); if (cb) cb(false); return; }
        var ws = XLSX.utils.aoa_to_sheet(aoa), wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Activity Log");
        var d = new Date(), name = "WorkAllocation-activity-log-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
        dbg("download log", name, (aoa.length - 1) + " lines"); XLSX.writeFile(wb, name); if (cb) cb(true, aoa.length - 1);
      };
      if (!cs) { write(r && r.log ? [{ runId: r.runId || "current", entries: r.log }] : []); return; }
      try { cs.get(CS_LOG, function (o) { write((o && o[CS_LOG]) || []); }); } catch (e) { write([]); }
    });
  }
  function onClickDownloadLog() {
    doDownloadLog(function (ok) {
      if (!ok) return;
      clearLogStore(function () { var r = loadRun(); if (r && !r.active) { r.log = []; saveRun(r); } render(); status("Activity log downloaded and cleared.", "ok"); });
    });
  }

  function onRunEnded(r) {
    if (!r) return;
    var c = counts(r);
    var naturalFinish = c.pend === 0 && (c.done + c.err + c.skip) > 0 && !r.stopRequested;
    dbg("run ended", { done: c.done, error: c.err, skipped: c.skip, pending: c.pend, stopped: !!r.stopRequested, naturalFinish: naturalFinish });
    if (!naturalFinish) return;
    try { localStorage.setItem(LS_RESULTS, JSON.stringify(r)); } catch (e) {}
    var exported = false, combo = comboFor(r);
    try { exported = combo ? doComboExport(r, combo) : doExport(r); } catch (e) { dbg("export failed", e && e.message); }
    if (combo) try { localStorage.removeItem(LS_COMBO); } catch (e) {}
    if (combo && combo.map && combo.map.length && window.KDLink) reportAlloc(r, combo);
    try { localStorage.removeItem(LS_RUN); localStorage.removeItem(LS_ALERT); } catch (e) {}
    wasActive = false;
    status("All " + (c.done + c.err + c.skip) + " record(s) processed — " + c.done + " allocated" + (c.err ? ", " + c.err + " error" : "") + (c.skip ? ", " + c.skip + " skipped" : "") +
      (exported ? " · results exported and the grid was cleared." : " · grid cleared (export failed — check download settings)."), c.err ? "warn" : "ok");
    if (c.done > 0) recordWin();
  }

  /* ---------------------- build panel ---------------------- */
  function buildPanel() {
    try { var stale = document.querySelectorAll("#dxwa-host"); for (var s = 0; s < stale.length; s++) stale[s].parentNode && stale[s].parentNode.removeChild(stale[s]); if (stale.length) dbg("removed", stale.length, "stale panel(s) before build"); } catch (e) {}
    var host = document.createElement("div");
    host.id = "dxwa-host";
    host.style.cssText = "position:fixed;top:70px;right:16px;z-index:2147483647;";
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE + THEME; root.appendChild(css); if (window.KD_applySkin) KD_applySkin(root);
    if (window.KDP) { var kc = document.createElement("style"); kc.textContent = KDP.css; root.appendChild(kc); }   // v1.26.0 clean panel kit
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML;
    // restore the collapsed state BEFORE the panel is inserted, so it never flashes open
    if (minSaved()) {
      var b0 = box.querySelector("#dx_bd"), m0 = box.querySelector("#dx_min");
      if (b0) b0.style.display = "none";
      if (m0) m0.textContent = "+";
    }
    root.appendChild(box);

    ["hd", "min", "bd", "pick", "file", "summary", "prog", "progfill", "progtxt", "tbl", "tbody", "start", "stop", "over", "exp", "dl", "clear", "st", "logbox", "logo", "ver", "gk_ekyc", "gk_abps", "gatechk", "gatehd", "gatehint", "build"]
      .forEach(function (id) { sel[id] = root.getElementById("dx_" + id); });
    ["tiles", "fnote", "rule", "adv", "mbtn", "more"].forEach(function (id) { sel[id] = root.getElementById("dx_" + id); });
    sel.panel = box;

    try {
      if (sel.logo && chrome && chrome.runtime && chrome.runtime.getURL) sel.logo.src = chrome.runtime.getURL("assets/icons/icon48.png");
      if (sel.ver && chrome && chrome.runtime && chrome.runtime.getManifest) sel.ver.textContent = chrome.runtime.getManifest().version;
    } catch (e) {}

    maybeShowRate();

    sel.pick.addEventListener("click", function () { sel.file.click(); });
    sel.build.addEventListener("click", openBuilder);
    if (window.GNList) { GNList.draftCount(builderLabel); GNList.onDraftChange(function (d) { builderLabel(GNList.countOf(d)); }); }
    sel.file.addEventListener("change", function (e) { if (e.target.files && e.target.files[0]) onFile(e.target.files[0]); e.target.value = ""; });
    sel.start.addEventListener("click", doStart);
    sel.stop.addEventListener("click", function () { if (autoTimer) { cancelAuto(); status("নিজে থেকে Start বাতিল। দেখে নিয়ে Start চাপুন।", "warn"); return; } doStop(); });
    sel.over.addEventListener("click", doStartOver);
    sel.exp.addEventListener("click", onClickExport);
    sel.dl.addEventListener("click", onClickDownloadLog);
    sel.clear.addEventListener("click", function () { cancelAuto(); doClear(); });
    [sel.pick, sel.build, sel.over].forEach(function (b) { if (b) b.addEventListener("click", cancelAuto); });
    if (window.KDP) { KDP.adv(sel.adv, "dxwa"); KDP.more(sel.mbtn, sel.more); }
    if (sel.rule) sel.rule.addEventListener("click", function () { if (sel.adv) { sel.adv.open = true; sel.adv.scrollIntoView({ block: "nearest" }); } });
    [sel.gk_ekyc, sel.gk_abps].forEach(function (c) {
      if (c) c.addEventListener("change", function () { gateSave(gateFromTicks(sel.gk_ekyc.checked, sel.gk_abps.checked)); render(); });
    });
    abpsReload();
    observePortalGrid();
    injectPortalGridBadges();
    try { chrome.storage.onChanged.addListener(function (ch, area) { if (area === "local" && (ch.dxAbpsMap || ch.dxAbpsMeta)) abpsReload(); }); } catch (e) {}
    sel.min.addEventListener("click", function () { sel.bd.style.display = sel.bd.style.display === "none" ? "block" : "none"; sel.min.textContent = sel.bd.style.display === "none" ? "+" : "–"; minSave(sel.bd.style.display === "none"); });
    makeDraggable(box, sel.hd);
    render();
    pickUpHandoff();
  }

  function makeDraggable(box, handle) {
    var sx, sy, ox, oy, drag = false; handle.style.cursor = "move";
    handle.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var host = document.getElementById("dxwa-host"); var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; var host = document.getElementById("dxwa-host"); host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
    document.addEventListener("mouseup", function () { drag = false; });
  }

  var HTML =
    "<div class='hd' id='dx_hd'><span class='hdl'><div class='logo' id='dx_logo'>K</div><span class='ttl'><b>Work Allocation</b><small><i>K-Desk</i> Suite · by Koushik</small></span></span><button class='mn' id='dx_min'>–</button></div>" +
    "" +
    "<div class='bd' id='dx_bd'>" +
    "<div class='srcrow'><button class='btn pick' id='dx_pick' title='Excel (.xlsx) sheet load করুন'>📄 Excel</button><button class='btn pick' id='dx_build' title='Village/household লিখে (যেমন 1/10) পরিবারের লোক বাছুন — copy-paste ছাড়া'>＋ Build</button></div>" +
    "<input type='file' id='dx_file' accept='.xlsx,.xls' style='display:none'>" +
    "<div class='summary' id='dx_summary'>No sheet loaded.</div>" +
    "<div class='prog' id='dx_prog' hidden><div class='progbar'><div class='progfill' id='dx_progfill'></div></div><div class='progtxt' id='dx_progtxt'></div></div>" +
    "<div class='kdp-tiles' id='dx_tiles'></div><div class='kdp-fnote' id='dx_fnote' hidden></div>" +
    "<div class='scroll'><table id='dx_tbl'><thead><tr><th>#</th><th>Work</th><th>Applicant</th><th>From</th><th>Days</th><th>St</th></tr></thead><tbody id='dx_tbody'></tbody></table></div>" +
    "<div class='st' id='dx_st'></div>" +
    "<div class='kdp-rule' id='dx_rule' title='চাপলে ⚙ Advanced খুলবে'></div>" +
    "<div class='sec'>Activity</div><div class='logbox' id='dx_logbox'></div>" +
    "<details class='kdp-adv' id='dx_adv'><summary>⚙ Advanced<small>Entry rule · রঙের মানে · গতি</small></summary><div class='kdp-advb'>" +
    "<div class='gate'><div class='gatehd' id='dx_gatehd'>Entry rule</div>" +
      "<div class='gatechk' id='dx_gatechk'>" +
        "<label title='Enter only workers whose eKYC is done'><input type='checkbox' id='dx_gk_ekyc'>eKYC done</label>" +
        "<label title='Enter only workers who are ABPS-enabled'><input type='checkbox' id='dx_gk_abps'>ABPS enabled</label>" +
      "</div>" +
      "<div class='gatehint' id='dx_gatehint'></div></div>" +
    "<div class='badge-legend'><span class='dx-badge dx-badge-good'>Green = Done / Enabled</span><span class='dx-badge dx-badge-no'>Red = Not Done / Not Enabled</span><span class='dx-badge dx-badge-unknown'>Grey = Unknown</span></div>" +
    "<div class='kdp-speed'></div></div></details>" +
    "<div class='kdp-act'><div class='kdp-more' id='dx_more' hidden><button class='btn ghost' id='dx_over'>↺ Start over</button><button class='btn ghost' id='dx_exp'>⭳ Export results</button>" +
      "<button class='btn ghost' id='dx_dl'>📄 Download log</button><button class='btn ghost danger' id='dx_clear'>🗑 Clear queue</button></div>" +
      "<div class='kdp-row'><button class='btn fill' id='dx_start'>▶ Start</button><button class='btn stop' id='dx_stop'>■ Stop</button><button class='btn ghost kdp-mbtn' id='dx_mbtn' title='আরও: Start over, Export, Log, Clear'>⋯</button></div></div>" +
    "<div class='disclaimer'>⚠ Automatic entry-তে ভুল হতে পারে। এই tool শুধু সাহায্য করে, আপনার কাজের বদলি নয়। প্রতিটা row নিজে দেখে নিন, আর allocation portal-এ ঠিকমতো উঠেছে কিনা যাচাই করুন। ব্যবহারের দায়িত্ব আপনার।</div>" +
    "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>v<span id='dx_ver'></span></em></div>" +
    "</div>";

  var THEME = ".panel{font-family:'Segoe UI','Nirmala UI',Noto Sans Bengali,system-ui,sans-serif;border:1px solid rgba(255,255,255,.6);border-left:0;border-radius:16px;box-shadow:0 18px 50px rgba(11,20,55,.28),0 2px 8px rgba(11,20,55,.12)}.hd{position:relative;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);border-bottom:0;padding:12px 12px 12px 14px;user-select:none}.hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}.hdl{gap:10px}.logo{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;flex:none;font:800 19px/1 Georgia,'Times New Roman',serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b);box-shadow:0 3px 10px rgba(245,185,66,.45),inset 0 1px 0 rgba(255,255,255,.6)}.ttl{display:block;min-width:0}.hd .ttl b{display:block;font-size:14.5px;font-weight:700;letter-spacing:.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ttl small{display:block;font-size:11px;color:#c7d2fe;letter-spacing:.3px;white-space:nowrap}.ttl small i{font-style:normal;color:#f5b942;font-weight:600}.mn{width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,.12);font:700 15px/1 system-ui}.mn:hover{background:rgba(255,255,255,.25)}.bd{padding:12px 14px 0;background:linear-gradient(#fbfcff,#fff)}.btn{border-radius:10px;font-family:inherit;font-weight:600;transition:.15s}.btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 4px 12px rgba(15,23,42,.1)}.btn.pick{border:1.5px dashed #c7d2fe;background:#f5f7ff;color:#3730a3}.btn.pick:hover:not(:disabled){background:#eef2ff}.btn.fill{min-height:36px;color:#fff;border:0;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.fill:hover{background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.fill:disabled{opacity:.45;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.stop{min-height:36px;color:#b91c1c;border:1px solid #fecaca;background:#fff5f5}.btn.stop:disabled{opacity:.45;background:#fff5f5;color:#b91c1c}.btn.ghost{background:#f8fafc;color:#0f172a;border:1px solid #e2e8f0}.btn.ghost:hover:not(:disabled){background:#eef2ff}.btn.ghost.danger{background:#fff5f5;color:#b91c1c;border-color:#fecaca}.summary{background:#eef2ff;color:#3730a3;border-radius:10px;padding:7px 10px}.progbar{background:#eef2ff;border-radius:99px}.progfill{border-radius:99px;background:linear-gradient(90deg,#34d399,#10b981,#f5b942)}.progtxt{color:#3730a3}.scroll{border-radius:10px;border-color:#e2e8f0}th{background:#f8fafc;color:#0b1437}.gate,.top{border-radius:10px;background:#fff}.gatehd{color:#64748b;text-transform:uppercase;letter-spacing:.6px}.st{border-radius:8px;background:#f8fafc}.sec{color:#64748b;text-transform:uppercase;letter-spacing:.6px;font-size:11px;font-weight:600;border-top-color:#e2e8f0}.logbox{max-height:140px;background:#0b1437;color:#c7d2fe;border:0;border-radius:10px;padding:8px 10px;font:11px/1.5 Consolas,monospace}.logbox div{border-bottom:1px dotted rgba(199,210,254,.14)}.l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#c7d2fe}.logbox .lt{color:#7c89c9}.disclaimer{border-radius:8px}.foot{display:flex;justify-content:space-between;align-items:center;gap:8px;margin:10px -14px 0;padding:7px 14px;font-size:10.5px;color:#64748b;border-top:1px solid #e2e8f0;background:#f8fafc;text-align:left}.foot b{color:#0b1437;letter-spacing:.4px}.foot em{font-style:normal;color:#e08e0b}";
  var STYLE =
    ".panel{width:360px;font-family:Noto Sans Bengali,Noto Sans,Arial,sans-serif;font-size:13px;color:#0f172a;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #4338ca;border-radius:14px;box-shadow:0 14px 36px rgba(11,20,55,.28);overflow:hidden}" +
    ".hd{background:linear-gradient(115deg,#0b1437,#3730a3);border-bottom:3px solid #f5b942;color:#fff;padding:10px 11px;display:flex;align-items:center;justify-content:space-between}" +".origin-strip{display:flex;align-items:center;gap:6px;padding:6px 10px;background:#f5f7ff;border-bottom:1px solid #c7d2fe;color:#0b1437;font-size:10px;font-weight:700;line-height:1.35}" +".origin-dot{width:7px;height:7px;border-radius:50%;background:#4338ca;flex:0 0 auto}" +".hd b{font-size:12.5px;font-weight:600}" +
    ".hdl{display:flex;align-items:center;gap:7px;min-width:0}" +
    ".logo{width:20px;height:20px;border-radius:4px;flex:0 0 auto;background:#fff}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:22px;height:22px;border-radius:5px;font-size:15px;line-height:1;flex:0 0 auto}" +
    ".bd{padding:10px;max-height:80vh;overflow:auto}" +
    ".btn{padding:8px 9px;border:none;border-radius:9px;font-size:12.5px;font-weight:650;cursor:pointer}" +
    ".btn.pick{width:100%;background:#f5f7ff;color:#3730a3;border:1px solid #3730a3;margin-bottom:8px}" +
    ".btnrow{display:flex;gap:6px;margin-top:6px}.btnrow .btn{flex:1}" +
    ".pickrow{display:flex;gap:6px}.pickrow .btn{flex:1;min-width:0}" +
    ".btn.fill{background:#4338ca;color:#fff}.btn.fill:hover{background:#1e1b6b}.btn.fill:disabled{background:#a5b4fc;cursor:not-allowed}" +
    ".btn.stop{background:#c5221f;color:#fff}.btn.stop:disabled{background:#e6a6a4;cursor:not-allowed}" +
    ".btn.ghost{background:#f5f7ff;color:#334;border:1px solid #d7dce6}.btn.ghost:disabled{color:#aab;cursor:not-allowed}" +
    ".btn.ghost.danger{background:#fdecea;color:#c5221f;border-color:#f3b4b0}.btn.ghost.danger:hover{background:#fbdbd8}.btn.ghost.danger:disabled{background:#f5f7ff;color:#c9a9a8;border-color:#e6d3d2}" +
    ".summary{font-size:11.5px;color:#3730a3;background:#eef2ff;border-radius:7px;padding:6px 8px;margin:8px 0;line-height:1.35}" +
    ".prog{margin:8px 0}.progbar{height:8px;background:#e2e8f0;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#4338ca;transition:width .3s}.progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".scroll{max-height:210px;overflow:auto;border:1px solid #e2e8f0;border-radius:7px}" +
    "table{border-collapse:collapse;width:100%;font-size:11px}" +
    ".applicant-line{display:flex;align-items:center;gap:4px;flex-wrap:wrap;min-width:0}.applicant-name{overflow-wrap:anywhere}" +
    ".dx-status-badges{display:inline-flex;align-items:center;gap:3px;flex-wrap:wrap;vertical-align:middle;margin-top:2px}" +
    ".dx-badge{display:inline-flex;align-items:center;justify-content:center;white-space:nowrap;border-radius:999px;padding:2px 5px;font-size:9px;line-height:1.2;font-weight:700;border:1px solid transparent}" +
    ".dx-badge-good{background:#e1f5e8;color:#137333;border-color:#a8dab5}.dx-badge-no{background:#fce8e6;color:#b3261e;border-color:#f4b9b5}.dx-badge-unknown{background:#f1f3f4;color:#5f6368;border-color:#dadce0}" +
    ".badge-legend{display:flex;gap:4px;flex-wrap:wrap;margin:5px 0 7px}.badge-legend .dx-badge{font-size:8.5px}" +
    "th,td{border-bottom:1px solid #eef0f4;padding:3px 6px;text-align:left}" +
    "th{position:sticky;top:0;background:#f8fafc;color:#3730a3;font-weight:600}" +
    "td.c,th:nth-child(1),th:nth-child(4),th:nth-child(5),th:nth-child(6){text-align:center}" +
    ".st-ok{color:#137333;font-weight:700}.st-err{color:#c5221f;font-weight:700}.st-warn{color:#9a6700;font-weight:700}" +
    ".gate{margin:8px 0 2px;padding:7px 8px;border:1px solid #e2e8f0;border-radius:7px;background:#fbfcff}" +
    ".gatehd{font-size:11px;font-weight:700;color:#3730a3;margin-bottom:4px}" +
    ".gatechk{display:flex;gap:16px;flex-wrap:wrap;padding:2px 0}" +
    ".gatechk label{display:flex;align-items:center;gap:6px;font-size:12.5px;font-weight:600;color:#0f172a;cursor:pointer}" +
    ".gatechk input{margin:0;width:15px;height:15px;accent-color:#3730a3;cursor:pointer}" +
    ".gatechk.off label{color:#8a92a0;cursor:not-allowed}.gatechk.off input{cursor:not-allowed}" +
    ".gatehint{font-size:10.5px;color:#5b6472;margin-top:4px;line-height:1.35}.gatehint.warn{color:#9a6700}.gatehint.ok{color:#137333}" +
    ".gatehint a{color:#3730a3;font-weight:600}" +
    ".why{font-size:10px;color:#9a6700;line-height:1.25;margin-top:1px}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:6px;background:#f5f7ff;min-height:15px;line-height:1.35}" +
    ".st.ok{background:#e7f4ec;color:#137333}.st.warn{background:#fef7e0;color:#9a6700}" +
    ".sec{font-weight:700;color:#3730a3;margin:10px 0 6px;border-top:1px solid #e2e8f0;padding-top:8px;font-size:12px}" +
    ".logbox{max-height:130px;overflow:auto;font-size:10.5px;line-height:1.4;background:#fbfcff;border:1px solid #eef0f4;border-radius:6px;padding:5px 7px}" +
    ".logbox div{padding:1px 0;border-bottom:1px dotted #eef0f4}" +
    ".l-err{color:#c5221f}.l-warn{color:#9a6700}.l-ok{color:#137333}.l-info{color:#5b6472}" +
    ".logbox .lt{display:inline-block;color:#aab2c0;font-variant-numeric:tabular-nums;margin-right:6px}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#8a92a0;line-height:1.35;background:#fbfbfd;border:1px solid #eef0f4;border-radius:6px;padding:5px 7px}" +
    ".foot{margin-top:8px;text-align:center;font-size:10px;color:#8a92a0;line-height:1.35}.foot a.vt{color:#3730a3;text-decoration:none}.foot a.vt:hover{text-decoration:underline}" +
    ".rate{display:flex;align-items:center;justify-content:space-between;gap:6px;background:#fff8e6;border:1px solid #f2d98a;border-radius:7px;padding:6px 8px;margin-bottom:8px;font-size:11px;color:#7a5a00}" +
    ".rate-msg{line-height:1.3}.rate-btns{display:flex;gap:4px;flex:0 0 auto}" +
    ".rlink{background:#3730a3;color:#fff;border:none;border-radius:5px;padding:3px 8px;font-size:11px;font-weight:600;cursor:pointer}.rlink:hover{background:#1e1b6b}" +
    ".rx{background:transparent;border:none;color:#9a6700;font-size:15px;line-height:1;cursor:pointer;padding:0 2px}";

  /* ---------------------- sync with engine ---------------------- */
  window.addEventListener("message", function (ev) { if (!ev.data || ev.data.source !== "DXWA_DRV") return; if (ev.data.type === "sync") render(); });
  setInterval(function () { render(); injectPortalGridBadges(); }, 1500);

  dbg("panel loaded (isolated world) on", location.pathname, "· debug ON — set localStorage dxwa_debug=0 to silence");
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", buildPanel);
  else buildPanel();
})();
});
