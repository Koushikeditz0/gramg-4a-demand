KH_FEATURE("readiness", function () {
/* =====================================================================
   K-Desk Suite by Koushik — Beneficiary Readiness Report   (…/vbgramg/workalloc.aspx)
   Work Allocation grid-এর beneficiary-দের একটা printable report:
   eKYC ✓/✕ আর ABPS ✓/✕ (ABPS Data Sync-এর জমা data থেকে) আর Account আছে কিনা
   (pension_scheme.aspx থেকে, শুধু এই list-এর Job Card-গুলোর জন্য, একটা একটা করে)।
   পুরো GP-র account কখনও টানা হয় না। জমা থাকে শুধু এই Job Card-গুলোর Account No., Bank আর
   IFSC (৭ দিন পরে নিজে মোছে), কোনো server-এ যায় না।
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDRD) return; window.__KDRD = true;

  var P = window.KD_MAP ? window.KD_MAP.prefixId("ctl00_ContentPlaceHolder1_") : "ctl00_ContentPlaceHolder1_";
  var GRID = P + (window.KD_MAP ? window.KD_MAP.id("allocation", "grid", "GridView1") : "GridView1");
  var WORK = P + (window.KD_MAP ? window.KD_MAP.id("allocation", "work", "ddlWork_code") : "ddlWork_code");
  // pension_scheme page-এর ID এখন shared/portal-map.js (page "pension") থেকে; map না থাকলে আগের মান
  var KM = window.KD_MAP, PID = function (k, d) { return KM ? KM.id("pension", k, d) : d; };
  var UP = KM ? KM.prefixName("ctl00$ContentPlaceHolder1$") : "ctl00$ContentPlaceHolder1$";
  var PEN = { village: P + PID("village", "ddlVillage"), reg: P + PID("reg", "ddlReg"), grid: P + PID("grid", "grdData"),
              unVillage: UP + PID("village", "ddlVillage"), unReg: UP + PID("reg", "ddlReg") };
  var PSUF = function (k, d) { return KM ? KM.suffix("pension", k, d) : d; };
  var PROW = { app: PSUF("app", "_lblappNo"), bank: PSUF("bank", "_lblbankDtl"), hf: PSUF("hf", "_HiddenField1") };
  var ACCT_KEY = "kdAcctMap3", ACCT_TTL = 7 * 24 * 60 * 60 * 1000;
  var GAP_MS = 700, RETRIES = 2, NAME_THR = 0.82;
  var JC = /^[A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+/i;

  var abps = { map: {}, meta: {} }, acct = {}, list = [], sel = {}, busy = false, stopReq = false, onlyBad = false;

  /* ---------------------- helpers ---------------------- */
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function norm(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  function idKey(s) { return window.DX && DX.normKey ? DX.normKey(s, "id") : norm(s).toUpperCase(); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function dmy(t) { var d = new Date(t); return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear(); }
  function stamp() { var d = new Date(); return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()); }
  // WB-06-003-006-013/001 (আর যদি পিছনে applicant suffix থাকে, সেটা বাদ)
  function familyCard(reg) { var m = norm(reg).toUpperCase().replace(/\s+/g, "").match(/^([A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+)/); return m ? m[1] : norm(reg); }
  function villageNo(card) { return parseInt(String(card).split("/")[0].split("-")[4], 10) || 0; }

  /* ---------------------- storage ---------------------- */
  function loadAll(cb) {
    try {
      chrome.storage.local.get(["dxAbpsMap", "dxAbpsMeta", ACCT_KEY], function (d) {
        abps.map = (d && d.dxAbpsMap) || {}; abps.meta = (d && d.dxAbpsMeta) || {};
        acct = (d && d[ACCT_KEY]) || {};
        try { chrome.storage.local.remove(["kdAcctMap", "kdAcctMap2"]); } catch (e) {}   // আগের version-এর cache
        var now = Date.now(), k;
        for (k in acct) if (!acct[k] || now - (acct[k].t || 0) > ACCT_TTL) delete acct[k];   // ৭ দিনের পুরনো নিজে মোছে
        cb();
      });
    } catch (e) { cb(); }
  }
  function saveAcct(cb) { var o = {}; o[ACCT_KEY] = acct; try { chrome.storage.local.set(o, cb || function () {}); } catch (e) { if (cb) cb(); } }

  /* ---------------------- beneficiaries from the Work Allocation grid ---------------------- */
  function gridRows() {
    var grid = document.getElementById(GRID), out = [];
    if (!grid || !grid.tBodies || !grid.tBodies[0]) return out;
    var trs = grid.tBodies[0].children;
    for (var i = 0; i < trs.length; i++) {
      var tr = trs[i], cells = tr.children;
      var chk = tr.querySelector && tr.querySelector('input[type="checkbox"][id$="' + (window.KD_MAP ? window.KD_MAP.suffix("allocation", "chk", "_chkAllocate") : "_chkAllocate") + '"]');
      if (!chk || !cells[1] || !cells[3]) continue;
      var reg = norm(cells[1].textContent);
      var nc = cells[3].cloneNode(true);
      [].forEach.call(nc.querySelectorAll(".dxwa-native-status"), function (b) { b.remove(); });
      var name = norm(nc.textContent);
      if (!JC.test(reg) || !name) continue;
      out.push({ reg: reg, name: name, ticked: !!chk.checked });
    }
    return out;
  }
  // grid না থাকলে: Work Allocation panel-এ load করা list
  function queueRows() {
    try {
      var r = JSON.parse(localStorage.getItem("dxwa_run") || "null"), out = [];
      ((r && r.groups) || []).forEach(function (g) { (g.workers || []).forEach(function (w) { if (w.reg) out.push({ reg: w.reg, name: w.applicant || "", ticked: false }); }); });
      return out;
    } catch (e) { return []; }
  }
  function workLabel() {
    var w = document.getElementById(WORK);
    if (!w || w.selectedIndex < 0) return "";
    var t = norm(w.options[w.selectedIndex].text);
    return /select/i.test(t) ? "" : t;
  }

  /* ---------------------- status per beneficiary ---------------------- */
  function abpsOf(b) {
    var f = null;
    try { if (window.DX && DX.abpsFind) f = DX.abpsFind(abps.map, b.reg, b.name); } catch (e) {}
    if (!f) return { ekyc: null, abps: null, aadhaar: null };
    return { ekyc: !!(+f.ekyc), abps: !!(+f.abps), aadhaar: !!(+f.aadhaar) };
  }
  function acctOf(b) {
    var e = acct[idKey(familyCard(b.reg))];
    if (!e) return { state: "unknown" };
    if (e.none) return { state: "no", note: e.none === "Account data নেই" ? "Account update হয়নি" : e.none };
    var best = null, bs = 0;
    (e.rows || []).forEach(function (r) { var s = nameMatch(b.name, r.name); if (s > bs) { bs = s; best = r; } });
    if (!best) {
      var names = (e.rows || []).map(function (r) { return r.name; }).filter(Boolean);
      // এই Job Card-এ অন্যদের account আছে, এর নিজের নেই = Not Updated
      return { state: "no", note: "Account update হয়নি" + (names.length ? " (এই Job Card-এ account আছে: " + names.join(", ") + ")" : "") };
    }
    return best.ac ? { state: "yes", ac: best.ac, bank: best.bank || "", ifsc: best.ifsc || "" } : { state: "no", note: "Account No. খালি" };
  }
  // Pension page-এর নামে applicant no., বন্ধনী বা বাড়তি space থাকতে পারে ("2 - SUDHA RANJAN MOHANTA (40)")
  function cleanName(n) { return String(n || "").replace(/\([^)]*\)/g, " ").replace(/[0-9]+/g, " ").replace(/\b(s\/o|w\/o|d\/o|c\/o)\b.*$/i, " ").replace(/[^A-Za-z\u0980-\u09FF\s]/g, " ").replace(/\s+/g, " ").trim(); }
  function nameMatch(a, b) {
    a = cleanName(a); b = cleanName(b);
    var s = DX.nameScore(a, b, NAME_THR);
    if (s) return s;
    var na = a.toLowerCase().replace(/\s+/g, ""), nb = b.toLowerCase().replace(/\s+/g, "");
    var t = DX.similar(na, nb);                    // "SUDHA RANJAN" = "SUDHARANJAN"
    if (t >= 0.85) return t;
    var ta = a.toLowerCase().split(" "), tb = b.toLowerCase().split(" "), sh = ta.length <= tb.length ? ta : tb, lg = sh === ta ? tb : ta;
    if (sh.length >= 2 && sh.every(function (w) { return lg.indexOf(w) >= 0; })) return 0.83;   // মাঝের নাম বাদ: "Jayanti Barman"
    return 0;
  }
  function evaluate(b) {
    var a = abpsOf(b), c = acctOf(b), why = [];
    if (a.ekyc === null) why.push("ABPS data-য় নেই");
    else {
      if (!a.ekyc) why.push(a.aadhaar ? "eKYC হয়নি" : "Aadhaar seed হয়নি");
      if (!a.abps) why.push("ABPS enable হয়নি");
    }
    if (c.state === "no") why.push(c.note || "Account update হয়নি");
    else if (c.state === "unknown") why.push("Account check হয়নি");
    var ready = a.ekyc === true && a.abps === true && c.state === "yes";
    return { a: a, c: c, why: why, ready: ready };
  }

  /* ---------------------- pension_scheme.aspx lookups (read only) ---------------------- */
  function penUrl() { return location.origin + location.pathname.replace(/[^\/]*$/, "pension_scheme.aspx"); }
  function parseDoc(html) { return new DOMParser().parseFromString(html, "text/html"); }
  function serialize(doc) {
    var f = doc.forms && doc.forms[0], fd = new URLSearchParams();
    if (!f) return fd;
    for (var i = 0; i < f.elements.length; i++) {
      var el = f.elements[i]; if (!el.name) continue;
      var t = String(el.type || "").toLowerCase();
      if (t === "checkbox" || t === "radio") { if (el.checked) fd.append(el.name, el.value); continue; }
      if (t === "submit" || t === "button" || t === "image" || t === "file") continue;
      fd.append(el.name, el.value == null ? "" : el.value);
    }
    return fd;
  }
  function req(body) {
    var opt = { credentials: "include", cache: "no-store" };
    if (body) { opt.method = "POST"; opt.headers = { "Content-Type": "application/x-www-form-urlencoded" }; opt.body = body.toString(); }
    return fetch(penUrl(), opt).then(function (res) {
      return res.text().then(function (t) { if (!res.ok) throw new Error("portal HTTP " + res.status); return parseDoc(t); });
    });
  }
  function checkPage(doc) {
    if (!doc.getElementById(PEN.village)) { var e = new Error("Pension page খুলছে না (login-এর মেয়াদ শেষ?)"); e.fatal = true; throw e; }
    return doc;
  }
  function retry(fn) {
    function go(a) {
      return fn().catch(function (e) {
        if (stopReq || e.fatal || a >= RETRIES) throw e;
        return sleep(1500 * (a + 1)).then(function () { return go(a + 1); });
      });
    }
    return go(0);
  }
  // ASP.NET postback: dropdown বদলানো, প্রতিবার আগের response-এর ViewState দিয়ে
  function choose(doc, id, un, value) {
    var fd = serialize(doc);
    fd.set("__EVENTTARGET", un); fd.set("__EVENTARGUMENT", ""); fd.set(un, value);
    return sleep(GAP_MS).then(function () { return req(fd); }).then(checkPage).then(function (next) {
      var s = next.getElementById(id);
      if (!s || s.value !== value) throw new Error("dropdown বদলায়নি");
      return next;
    });
  }
  function villageOptions(doc) {
    var s = doc.getElementById(PEN.village); if (!s) return [];
    return [].filter.call(s.options, function (o) { return o.value && !/select/i.test(o.text) && o.value !== "0"; })
      .map(function (o) { var m = norm(o.text).match(/[-\/](\d+)\s*$/); return { value: o.value, text: norm(o.text), no: m ? +m[1] : 0 }; });
  }
  function regOptions(doc) {
    var s = doc.getElementById(PEN.reg), out = {};
    if (!s) return out;
    [].forEach.call(s.options, function (o) {
      var c = JC.test(norm(o.value)) ? norm(o.value) : JC.test(norm(o.text)) ? norm(o.text) : "";
      if (c) out[idKey(familyCard(c))] = o.value;
    });
    return out;
  }
  // SmartDesk-এর মতোই: <b>Bank</b> : …<br><b>Branch Name :</b> …<br><b>IFSC Code :</b> …<br><b>AC No.</b> : …
  function parseAccounts(doc) {
    var table = doc.getElementById(PEN.grid), out = [];
    if (!table) return out;
    [].forEach.call(table.querySelectorAll("tr"), function (tr) {
      var nm = tr.querySelector('[id$="' + PROW.app + '"]'), bk = tr.querySelector('[id$="' + PROW.bank + '"]');
      if (!nm || !bk) return;
      var h = doc.createElement("div"); h.innerHTML = String(bk.innerHTML || "").replace(/<br\s*\/?\s*>/gi, "\n");
      var bank = "", ifsc = "", ac = "";
      String(h.textContent || "").split(/\n/).map(norm).forEach(function (line) {
        var m = line.match(/^Bank\s*:?\s*(.*)$/i); if (m) bank = norm(m[1]);
        m = line.match(/^IFSC\s*Code\s*:?\s*(.*)$/i); if (m) ifsc = norm(m[1]).replace(/\s+/g, "");
        m = line.match(/^AC\s*No\.?\s*:?\s*(.*)$/i); if (m) ac = norm(m[1]).replace(/\s+/g, "");
      });
      if (!ac) { var r = norm(h.textContent).match(/AC\s*No\.?\s*:\s*([A-Za-z0-9-]+)/i); if (r) ac = r[1]; }
      out.push({ name: norm(nm.textContent), bank: bank, ifsc: ifsc, ac: ac });
    });
    return out;
  }

  function checkAccounts(force) {
    if (busy) { stopReq = true; setMsg("থামানো হচ্ছে…", "warn"); return; }
    var need = {}, k;
    list.forEach(function (b) { var c = familyCard(b.reg), key = idKey(c); if (force || !acct[key]) need[key] = c; });
    var cards = Object.keys(need);
    if (!cards.length) { setMsg("সব Job Card-এর account আগেই check করা আছে (৭ দিনের মধ্যে)।", "ok"); return; }
    busy = true; stopReq = false; setBusy(true);
    var done = 0, total = cards.length, missing = [];
    var byVillage = {};
    cards.forEach(function (key) { var v = villageNo(need[key]); (byVillage[v] || (byVillage[v] = [])).push(key); });

    setMsg("Pension page খোলা হচ্ছে…", "");
    var doc = null;
    retry(function () { return req(null).then(checkPage); }).then(function (d0) {
      doc = d0;
      var vopts = villageOptions(doc), vnos = Object.keys(byVillage);
      var chain = Promise.resolve();
      vnos.forEach(function (vn) {
        chain = chain.then(function () {
          if (stopReq) return;
          var want = byVillage[vn];
          // আগে নম্বর মেলানো village, না পেলে বাকিগুলো
          var order = vopts.filter(function (o) { return o.no === +vn; }).concat(vopts.filter(function (o) { return o.no !== +vn; }));
          return lookInVillages(order, want);
        });
      });
      return chain;
    }).then(function () {
      finish();
    }, function (e) {
      finish(e);
    });

    function lookInVillages(order, want) {
      var left = want.slice(), i = 0;
      function next() {
        if (stopReq || !left.length) return Promise.resolve();
        if (i >= order.length || i >= 4) {           // ৪টে village-এ না পেলে আর খোঁজা নয়
          left.forEach(function (key) { acct[key] = { t: Date.now(), none: "Pension page-এ Job Card পাওয়া যায়নি" }; missing.push(need[key]); done++; });
          saveAcct(); paint();
          return Promise.resolve();
        }
        var v = order[i++];
        setMsg("Village " + v.text + " খোলা হচ্ছে…", "");
        return retry(function () { return choose(doc, PEN.village, PEN.unVillage, v.value); }).then(function (d) {
          doc = d;
          var opts = regOptions(doc), here = left.filter(function (key) { return opts[key]; });
          left = left.filter(function (key) { return !opts[key]; });
          var c2 = Promise.resolve();
          here.forEach(function (key) {
            c2 = c2.then(function () {
              if (stopReq) return;
              setMsg("Account check " + (done + 1) + "/" + total + " — " + need[key], "");
              return retry(function () { return choose(doc, PEN.reg, PEN.unReg, opts[key]); }).then(function (d2) {
                doc = d2;
                var rows = parseAccounts(doc);
                acct[key] = rows.length ? { t: Date.now(), rows: rows } : { t: Date.now(), none: "Account data নেই" };
                done++; saveAcct(); paint();
              }, function (e) {
                if (e.fatal) throw e;
                done++;                                   // এটা পরে আবার check হবে, cache-এ রাখা হয়নি
              });
            });
          });
          return c2;
        }).then(next);
      }
      return next();
    }

    function finish(err) {
      busy = false; setBusy(false); saveAcct(); paint();
      if (err) setMsg("থেমে গেছে: " + (err.message || err) + ". আবার চাপলে বাকিগুলো check হবে।", "warn");
      else if (stopReq) setMsg("থামানো হয়েছে। " + done + "/" + total + " Job Card check হয়েছে।", "warn");
      else setMsg("Account check শেষ: " + total + " Job Card" + (missing.length ? ", " + missing.length + "টা pension page-এ পাওয়া যায়নি" : "") + "।", "ok");
      stopReq = false;
    }
  }

  /* ---------------------- report window ---------------------- */
  var CSS =
    ":host{all:initial}" +
    ".bar.more[hidden]{display:none!important}.bar.more{padding-top:0!important}.btn.kmore{font-size:16px;line-height:1;padding-left:12px;padding-right:12px}" +
    ".panel{font-family:'Segoe UI','Nirmala UI','Noto Sans Bengali',system-ui,sans-serif;width:min(980px,calc(100vw - 80px));max-height:100vh;display:flex;flex-direction:column;background:linear-gradient(180deg,rgba(238,240,255,.98),rgba(227,230,251,.98));border:1px solid #c9cef3;border-right:0;border-radius:18px 0 0 18px;box-shadow:0 18px 50px rgba(30,27,75,.30);overflow:hidden;color:#1e1b4b;font-size:13px}" +
    ".hd{position:relative;background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);color:#fff;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hd small{display:block;font-size:9.5px;letter-spacing:.9px;text-transform:uppercase;color:#c7d2fe}.hd small i{font-style:normal;color:#f5b942;font-weight:700}.hd b{font-size:15.5px}" +
    ".x{cursor:pointer;border:0;background:rgba(255,255,255,.14);color:#fff;width:30px;height:30px;border-radius:9px;font-size:16px}" +
    ".bar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:10px 14px;border-bottom:1px solid #d4d8f5}" +
    ".btn{cursor:pointer;border-radius:10px;min-height:34px;padding:6px 11px;font:600 12.5px inherit;font-family:inherit;border:1px solid #d4d8f5;background:#f5f6ff;color:#1e1b4b}" +
    ".btn.fill{border:0;color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn:disabled{opacity:.5;cursor:not-allowed}" +
    ".chk{display:flex;align-items:center;gap:5px;font-size:12px;margin-left:auto}" +
    ".sum{display:flex;flex-wrap:wrap;gap:6px;padding:8px 14px 0}.pill{background:#fff;border:1px solid #d4d8f5;border-radius:99px;padding:3px 10px;font-size:12px}.pill b{color:#3730a3}" +
    ".msg{margin:8px 14px 0;padding:7px 10px;border-radius:10px;background:#fff;border-left:4px solid #f5b942;font-size:12px;min-height:16px}.msg.ok{background:#dcfce7}.msg.warn{background:#fef3c7}" +
    ".scroll{flex:1 1 auto;min-height:0;overflow:auto;margin:8px 14px 10px;background:#fff;border:1px solid #d4d8f5;border-radius:10px}" +
    "table{border-collapse:collapse;width:100%;font-size:12px}th{position:sticky;top:0;background:#e3e6fb;color:#1e1b6b;text-align:left;padding:6px 7px}td{padding:5px 7px;border-top:1px solid #eceefb;vertical-align:top}" +
    ".acd{font-size:11.5px;color:#1e1b4b;white-space:nowrap}td.reg{white-space:nowrap}" +
    "tr.bad td:first-child{box-shadow:inset 3px 0 #e11d48}.ok{color:#15803d;font-weight:700}.no{color:#be123c;font-weight:700}.unk{color:#64748b}.why{color:#9a3412;font-size:11.5px}" +
    ".foot{display:flex;justify-content:space-between;padding:7px 14px;font-size:10.5px;color:#5b5f8a;border-top:1px solid #d4d8f5;background:rgba(255,255,255,.55)}.foot b{color:#1e1b4b}.foot em{font-style:normal;color:#c2770a}";

  function mark(v, okTxt, noTxt) { return v === null || v === undefined ? "<span class='unk'>?</span>" : v ? "<span class='ok'>✓ " + okTxt + "</span>" : "<span class='no'>✕ " + noTxt + "</span>"; }
  function acctCell(c) {
    if (c.state === "yes") return "<span class='acd'><span class='ok'>✓</span> " + esc(acLine(c)) + "</span>";
    if (c.state === "no") return "<span class='no'>✕ Not Updated</span>";
    return "<span class='unk'>? check হয়নি</span>";
  }
  // Account No. / Bank / IFSC আলাদা তিন column; না থাকলে প্রথম column-এ Not Updated
  function acctCells(c) {
    if (c.state === "yes") return "<td class='acd'>" + esc(c.ac) + "</td><td>" + esc(c.bank) + "</td><td class='acd'>" + esc(c.ifsc) + "</td>";
    if (c.state === "unknown" && busy) return "<td colspan='3'><span class='skel'></span></td>";   // আসছে…
    return "<td colspan='3' title='" + esc(c.note || "") + "'>" + acctCell(c) + "</td>";
  }
  function acLine(c) { return [c.ac, c.bank, c.ifsc].filter(Boolean).join(" · "); }
  function rowsEval() { return list.map(function (b) { var e = evaluate(b); e.b = b; return e; }); }
  function counts(ev) {
    var n = { all: ev.length, ready: 0, ekyc: 0, abps: 0, ac: 0, unk: 0 };
    ev.forEach(function (e) { if (e.ready) n.ready++; if (e.a.ekyc === false) n.ekyc++; if (e.a.abps === false) n.abps++; if (e.c.state === "no") n.ac++; if (e.c.state === "unknown") n.unk++; });
    return n;
  }
  function gpLabel() {
    for (var i = 0; i < list.length; i++) { var m = DX.abpsMetaFor(abps.meta, list[i].reg); if (m) return { label: DX.abpsLabel(m), when: DX.syncedWhen(m), stale: DX.abpsStale(m) }; }
    return null;
  }

  function paint() {
    if (!sel.tb) return;
    var ev = rowsEval(), n = counts(ev), html = "", i = 0;
    ev.forEach(function (e) {
      if (onlyBad && e.ready) return;
      html += "<tr class='" + (e.ready ? "" : "bad") + "'><td>" + (++i) + "</td><td class='reg'>" + esc(e.b.reg) + "</td><td>" + esc(e.b.name) + "</td><td>" +
        mark(e.a.ekyc, "Done", "No") + "</td><td>" + mark(e.a.abps, "Enabled", "No") + "</td>" + acctCells(e.c) + "</tr>";
    });
    sel.tb.innerHTML = html || "<tr><td colspan='8' class='unk'>কিছু দেখানোর নেই।</td></tr>";
    var g = gpLabel();
    sel.sum.innerHTML =
      "<span class='pill'>মোট <b>" + n.all + "</b></span><span class='pill'>Ready <b>" + n.ready + "</b></span>" +
      "<span class='pill'>eKYC হয়নি <b>" + n.ekyc + "</b></span><span class='pill'>ABPS হয়নি <b>" + n.abps + "</b></span>" +
      "<span class='pill'>Account Not Updated <b>" + n.ac + "</b></span>" + (n.unk ? "<span class='pill'>Account check বাকি <b>" + n.unk + "</b></span>" : "") +
      "<span class='pill'>" + (g ? "ABPS data: " + esc(g.label) + ", " + esc(g.when) + (g.stale ? " ⚠ পুরনো" : "") : "⚠ ABPS data নেই, আগে ABPS Data Sync করুন") + "</span>";
  }
  function setMsg(t, kind) { if (sel.msg) { sel.msg.textContent = t || ""; sel.msg.className = "msg " + (kind || ""); } }
  function setBusy(on) { if (sel.ac) sel.ac.textContent = on ? "■ Stop" : "🏦 Account check"; ["pr", "xl", "re", "cl"].forEach(function (k) { if (sel[k]) sel[k].disabled = on; }); paint(); }

  function dockRight() { return document.getElementById("kdock-host") ? ((window.KDOCK && KDOCK.width ? KDOCK.width() : 58) + "px") : "0"; }
  function toggleReport() { var h = document.getElementById("kdrd-host"); if (h && h.style.display !== "none") closeReport(); else openReport(); }
  function openReport() {
    var g = gridRows(), src = "Work Allocation list";
    var ticked = g.filter(function (r) { return r.ticked; });
    if (ticked.length) { g = ticked; src = "tick করা " + ticked.length + " জন"; }
    if (!g.length) { g = queueRows(); src = "Panel-এ load করা list"; }
    if (!g.length) { alert("K-Desk: Work Allocation-এ কোনো beneficiary পাওয়া যায়নি। আগে Work select করে list খুলুন।"); return; }
    list = g;
    loadAll(function () {
      closeReport();
      var wa = document.getElementById("dxwa-host");   // Work Allocation panel একই জায়গায় বসে, report খোলা থাকলে লুকানো
      if (wa && wa.style.display !== "none") { wa.style.display = "none"; hidWa = true; }
      var host = document.createElement("div"); host.id = "kdrd-host";
      host.style.cssText = "position:fixed;top:0;right:" + dockRight() + ";z-index:2147483645;";
      (document.body || document.documentElement).appendChild(host);
      var root = host.attachShadow({ mode: "open" });
      var st = document.createElement("style"); st.textContent = CSS; root.appendChild(st);
      var wrap = document.createElement("div");
      wrap.innerHTML =
        "<div class='panel'><div class='hd'><span><small><i>K-Desk</i> Suite · Readiness Report</small><b>Beneficiary eKYC / ABPS / Account</b></span><button class='x' id='x'>✕</button></div>" +
        "<div class='bar'><button class='btn' id='pr'>🖨 Print</button><button class='btn' id='xl'>⭳ Excel</button><button class='btn fill' id='ac'>🏦 Account check</button>" +
        "<label class='chk'><input type='checkbox' id='ob'> শুধু যারা ready নয়</label><button class='btn kmore' id='mb' title='আরও: Account আবার check, cache মুছুন'>⋯</button></div>" +
        // v1.27.0 clean panel: কম দরকারি দুটো button "⋯"-এর ভেতরে
        "<div class='bar more' id='mr' hidden><button class='btn' id='re'>↻ Account আবার check</button><button class='btn' id='cl'>🗑 Account cache মুছুন</button></div>" +
        "<div class='sum' id='sum'></div><div class='msg' id='msg'></div>" +
        "<div class='scroll'><table><thead><tr><th>#</th><th>Reg / Job Card No.</th><th>Name</th><th>eKYC</th><th>ABPS</th><th>Account No.</th><th>Bank</th><th>IFSC</th></tr></thead><tbody id='tb'></tbody></table></div>" +
        "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b> · Source: " + esc(src) + (workLabel() ? " · " + esc(workLabel()) : "") + "</span><em>v" + esc(ver()) + "</em></div></div>";
      root.appendChild(wrap);
      ["x", "ac", "pr", "xl", "re", "cl", "ob", "sum", "msg", "tb", "mb", "mr"].forEach(function (id) { sel[id] = root.getElementById(id); });
      sel.mb.onclick = function () { sel.mr.hidden = !sel.mr.hidden; sel.mb.textContent = sel.mr.hidden ? "⋯" : "✕"; };
      [sel.re, sel.cl].forEach(function (b) { b.addEventListener("click", function () { sel.mr.hidden = true; sel.mb.textContent = "⋯"; }); });
      sel.x.onclick = closeReport;
      sel.ac.onclick = function () { checkAccounts(false); };
      sel.re.onclick = function () { if (!busy) checkAccounts(true); };
      sel.cl.onclick = function () { if (busy) return; acct = {}; saveAcct(function () { paint(); setMsg("জমা account data মুছে দেওয়া হয়েছে।", "ok"); }); };
      sel.pr.onclick = printReport;
      sel.xl.onclick = excelReport;
      sel.ob.onchange = function () { onlyBad = sel.ob.checked; paint(); };
      paint();
      var need = list.some(function (b) { return !acct[idKey(familyCard(b.reg))]; });
      if (need) checkAccounts(false);        // শুধু এই list-এর বাকি Job Card-গুলো
      else setMsg("Account data cache থেকে দেখানো হচ্ছে (৭ দিনের মধ্যে check করা)।", "ok");
    });
  }
  var hidWa = false;
  function closeReport() {
    if (busy) stopReq = true;
    var h = document.getElementById("kdrd-host"); if (h) h.remove(); sel = {};
    var wa = document.getElementById("dxwa-host"); if (hidWa && wa) wa.style.display = ""; hidWa = false;
  }
  function ver() { try { return chrome.runtime.getManifest().version; } catch (e) { return ""; } }

  function printReport() {
    var ev = rowsEval().filter(function (e) { return !onlyBad || !e.ready; }), n = counts(rowsEval()), g = gpLabel();
    var yn = function (v, a, b) { return v === null ? "?" : v ? a : b; };
    var rows = ev.map(function (e, i) {
      var ac = e.c.state === "yes" ? "<td>" + esc(e.c.ac) + "</td><td>" + esc(e.c.bank) + "</td><td>" + esc(e.c.ifsc) + "</td>" : "<td colspan='3'>" + (e.c.state === "no" ? "✕ Not Updated" : "?") + "</td>";
      return "<tr" + (e.ready ? "" : " class='bad'") + "><td>" + (i + 1) + "</td><td>" + esc(e.b.reg) + "</td><td>" + esc(e.b.name) + "</td><td>" + yn(e.a.ekyc, "✓", "✕") + "</td><td>" + yn(e.a.abps, "✓", "✕") + "</td>" + ac + "</tr>";
    }).join("");
    var w = window.open("", "_blank");
    if (!w) { setMsg("Print window খোলা যায়নি। Browser-এ popup allow করুন।", "warn"); return; }
    w.document.write("<!doctype html><html><head><meta charset='utf-8'><title>Readiness Report " + dmy(Date.now()) + "</title><style>" +
      "@page{size:A4 portrait;margin:12mm}body{font:12px 'Nirmala UI','Noto Sans Bengali',Arial,sans-serif;color:#000;background:#fff}" +
      "h1{font-size:16px;margin:0 0 2px}.meta{font-size:11.5px;margin-bottom:6px}.sum{font-size:11.5px;margin:6px 0}" +
      "table{border-collapse:collapse;width:100%}th,td{border:1px solid #444;padding:3px 5px;text-align:left;vertical-align:top}th{background:#eee}" +
      "tr.bad td{background:#fff4f4}thead{display:table-header-group}tr{page-break-inside:avoid}.sig{margin-top:28px;display:flex;justify-content:space-between;font-size:11.5px}" +
      "@media print{.np{display:none}}</style></head><body>" +
      "<button class='np' onclick='print()' style='float:right;padding:6px 12px'>Print</button>" +
      "<h1>Beneficiary Readiness Report (eKYC / ABPS / Account)</h1>" +
      "<div class='meta'>" + (g ? "GP: " + esc(g.label) + " · " : "") + (workLabel() ? "Work: " + esc(workLabel()) + " · " : "") + "Date: " + dmy(Date.now()) +
      (g ? " · ABPS data synced " + esc(g.when) : "") + "</div>" +
      "<div class='sum'>মোট " + n.all + " · Ready " + n.ready + " · eKYC হয়নি " + n.ekyc + " · ABPS হয়নি " + n.abps + " · Account Not Updated " + n.ac + (n.unk ? " · Account check বাকি " + n.unk : "") + (onlyBad ? " · (শুধু যারা ready নয়)" : "") + "</div>" +
      "<table><thead><tr><th>#</th><th>Reg / Job Card No.</th><th>Name</th><th>eKYC</th><th>ABPS</th><th>Account No.</th><th>Bank</th><th>IFSC</th></tr></thead><tbody>" + rows + "</tbody></table>" +
      "<div class='sig'><span>Prepared by: ____________________</span><span>Verified by: ____________________</span></div>" +
      "<script>setTimeout(function(){print()},300)<\/script></body></html>");
    w.document.close();
  }
  function excelReport() {
    if (!window.XLSX) { setMsg("Excel library load হয়নি।", "warn"); return; }
    var aoa = [["#", "Reg / Job Card No.", "Name", "eKYC", "ABPS", "Account", "Account No.", "Bank", "IFSC"]];
    rowsEval().filter(function (e) { return !onlyBad || !e.ready; }).forEach(function (e, i) {
      var yn = function (v) { return v === null ? "?" : v ? "Yes" : "No"; };
      aoa.push([i + 1, e.b.reg, e.b.name, yn(e.a.ekyc), yn(e.a.abps), e.c.state === "yes" ? "Updated" : e.c.state === "no" ? "Not Updated" : "?", e.c.ac || "", e.c.bank || "", e.c.ifsc || ""]);
    });
    var ws = XLSX.utils.aoa_to_sheet(aoa);
    var wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Readiness");
    XLSX.writeFile(wb, "Readiness-Report-" + stamp() + ".xlsx");
    setMsg("Excel download হয়েছে (" + (aoa.length - 1) + " জন)।", "ok");
  }

  /* ---------------------- launcher ----------------------
     K-Dock-এর "Readiness Report" icon থেকে খোলে। K-Dock Off থাকলে নিচে বাঁদিকে ছোট একটা button। */
  function placeLauncher() {
    var btn = document.getElementById("kdrd-btn");
    var want = document.getElementById(GRID) && !document.getElementById("kdock-host");
    if (!want) { if (btn) btn.remove(); return; }
    if (btn) return;
    btn = document.createElement("button");
    btn.id = "kdrd-btn"; btn.type = "button"; btn.textContent = "📋 Readiness Report";
    btn.title = "K-Desk Suite: beneficiary-দের eKYC, ABPS আর Account";
    btn.style.cssText = "position:fixed;left:16px;bottom:16px;z-index:2147483644;padding:9px 14px;border:0;border-radius:12px;cursor:pointer;font:600 12.5px 'Segoe UI','Nirmala UI',sans-serif;color:#fff;background:linear-gradient(135deg,#1e1b6b,#3730a3);box-shadow:0 6px 18px rgba(30,27,75,.35);border-bottom:2px solid #f5b942";
    btn.addEventListener("click", function (e) { e.preventDefault(); toggleReport(); });
    (document.body || document.documentElement).appendChild(btn);
  }
  setTimeout(function () { placeLauncher(); setInterval(placeLauncher, 2000); }, 2500);
  window.KD_READINESS = { open: openReport, toggle: toggleReport };
})();
});
