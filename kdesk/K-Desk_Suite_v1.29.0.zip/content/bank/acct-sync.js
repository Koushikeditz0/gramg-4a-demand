KH_FEATURE("acsync", function () {
/* =====================================================================
   K-Desk Suite by Koushik — 🏦 Account Sync  (portal → Gram Setu)
   Pages: …/vbgramg/pension_scheme.aspx and …/vbgramg/EditAppBank.aspx
   Reads each job card's bank account (A/C No, IFSC, Bank) on
   pension_scheme.aspx in the background (fetch, read only — nothing on the
   portal is changed) and sends them to the Gram Setu app
   (kdesk_save_accounts) a few job cards at a time.
   • Only the job cards that still have a worker WITHOUT an account in the
     app are read (kdesk_account_cards), so a second run does only the rest.
   • Nothing is stored in K-Desk except the progress (which job cards were
     already read today) — no account numbers.
   • One request at a time with a gap, so neither the PC nor the portal is loaded.
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDACS) return; window.__KDACS = true;

  var P = window.KD_MAP ? window.KD_MAP.prefixId("ctl00_ContentPlaceHolder1_") : "ctl00_ContentPlaceHolder1_";
  // pension_scheme page-এর ID এখন shared/portal-map.js (page "pension") থেকে; map না থাকলে আগের মান
  var KM = window.KD_MAP, PID = function (k, d) { return KM ? KM.id("pension", k, d) : d; };
  var UP = KM ? KM.prefixName("ctl00$ContentPlaceHolder1$") : "ctl00$ContentPlaceHolder1$";
  var PEN = { village: P + PID("village", "ddlVillage"), reg: P + PID("reg", "ddlReg"), grid: P + PID("grid", "grdData"),
              unVillage: UP + PID("village", "ddlVillage"), unReg: UP + PID("reg", "ddlReg") };
  var PSUF = function (k, d) { return KM ? KM.suffix("pension", k, d) : d; };
  var PROW = { app: PSUF("app", "_lblappNo"), bank: PSUF("bank", "_lblbankDtl"), hf: PSUF("hf", "_HiddenField1") };
  var PROG_KEY = "kdAcSync1", RETRIES = 2, BATCH = 25;
  var SPEEDS = { slow: 1500, normal: 800, fast: 400 };

  var busy = false, stopReq = false, host = null, root = null, speed = "normal";
  var stat = { total: 0, done: 0, rows: 0, saved: 0, updated: 0, same: 0, unmatched: [], noCard: 0, noAcc: 0, t0: 0 };

  /* ---------------- helpers ---------------- */
  function norm(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function bnNum(n) { return String(n).replace(/[0-9]/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); }
  // same as the server's private.base_card: WB-08-005-014-001/008-A → WB-08-005-014-001/8
  function baseCard(s) {
    var c = String(s || "").toUpperCase().replace(/\s+/g, "");
    var m = c.match(/^([A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3})\/0*(\d+)/);
    return m ? m[1] + "/" + m[2] : "";
  }
  function today() { var d = new Date(); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); }
  function gap() { return SPEEDS[speed] || 800; }

  // progress: job cards already read today (so Stop → Start continues). Not account numbers.
  function progGet() {
    return new Promise(function (res) {
      try { chrome.storage.local.get(PROG_KEY, function (o) { var p = (o || {})[PROG_KEY]; res(p && p.day === today() ? p : { day: today(), cards: {} }); }); }
      catch (e) { res({ day: today(), cards: {} }); }
    });
  }
  function progSet(p) { try { var o = {}; o[PROG_KEY] = p; chrome.storage.local.set(o); } catch (e) {} }

  /* ---------------- pension_scheme.aspx (read only) ---------------- */
  function penUrl() { return location.origin + location.pathname.replace(/[^\/]*$/, "pension_scheme.aspx"); }
  function parseDoc(html) { return new DOMParser().parseFromString(html, "text/html"); }
  function serialize(doc) {
    var f = doc.forms && doc.forms[0], fd = new URLSearchParams();
    if (!f) return fd;
    for (var i = 0; i < f.elements.length; i++) {
      var el = f.elements[i]; if (!el.name) continue;
      var t = String(el.type || "").toLowerCase();
      if (t === "checkbox" || t === "radio") { if (el.checked) fd.append(el.name, el.value); continue; }
      if (t === "submit" || t === "button" || t === "image" || t === "file") continue;
      fd.append(el.name, el.value == null ? "" : el.value);
    }
    return fd;
  }
  function req(body) {
    var opt = { credentials: "include", cache: "no-store" };
    if (body) { opt.method = "POST"; opt.headers = { "Content-Type": "application/x-www-form-urlencoded" }; opt.body = body.toString(); }
    return fetch(penUrl(), opt).then(function (res) {
      return res.text().then(function (t) { if (!res.ok) throw new Error("portal HTTP " + res.status); return parseDoc(t); });
    });
  }
  function checkPage(doc) {
    if (!doc.getElementById(PEN.village)) { var e = new Error("Pension page খুলছে না (portal-এ login-এর মেয়াদ শেষ?)"); e.fatal = true; throw e; }
    return doc;
  }
  function retry(fn) {
    function go(a) {
      return fn().catch(function (e) {
        if (stopReq || e.fatal || a >= RETRIES) throw e;
        return sleep(1500 * (a + 1)).then(function () { return go(a + 1); });
      });
    }
    return go(0);
  }
  function choose(doc, id, un, value) {
    var fd = serialize(doc);
    fd.set("__EVENTTARGET", un); fd.set("__EVENTARGUMENT", ""); fd.set(un, value);
    return sleep(gap()).then(function () { return req(fd); }).then(checkPage).then(function (next) {
      var s = next.getElementById(id);
      if (!s || s.value !== value) throw new Error("dropdown বদলায়নি");
      return next;
    });
  }
  function villageOptions(doc) {
    var s = doc.getElementById(PEN.village); if (!s) return [];
    return [].filter.call(s.options, function (o) { return o.value && !/select/i.test(o.text) && o.value !== "0"; })
      .map(function (o) { var m = norm(o.text).match(/[-\/](\d+)\s*$/) || norm(o.value).match(/(\d{3})$/); return { value: o.value, text: norm(o.text), no: m ? +m[1] : 0 }; });
  }
  function regOptions(doc) {
    var s = doc.getElementById(PEN.reg), out = {};
    if (!s) return out;
    [].forEach.call(s.options, function (o) {
      var c = baseCard(o.value) || baseCard(o.text);
      if (c) (out[c] || (out[c] = [])).push(o.value);     // 11 and 11-A are both read
    });
    return out;
  }
  // <b>Bank</b> : …<br><b>Branch Name :</b> …<br><b>IFSC Code :</b> …<br><b>AC No.</b> : …
  function parseAccounts(doc, card) {
    var table = doc.getElementById(PEN.grid), out = [];
    if (!table) return out;
    [].forEach.call(table.querySelectorAll("tr"), function (tr) {
      var nm = tr.querySelector('[id$="' + PROW.app + '"]'), bk = tr.querySelector('[id$="' + PROW.bank + '"]');
      var hf = tr.querySelector('input[id$="' + PROW.hf + '"]');
      if (!nm || !bk) return;
      var h = doc.createElement("div"); h.innerHTML = String(bk.innerHTML || "").replace(/<br\s*\/?\s*>/gi, "\n");
      var bank = "", ifsc = "", ac = "";
      String(h.textContent || "").split(/\n/).map(norm).forEach(function (line) {
        var m = line.match(/^Bank\s*:?\s*(.*)$/i); if (m) bank = norm(m[1]);
        m = line.match(/^IFSC\s*Code\s*:?\s*(.*)$/i); if (m) ifsc = norm(m[1]).replace(/\s+/g, "");
        m = line.match(/^AC\s*No\.?\s*:?\s*(.*)$/i); if (m) ac = norm(m[1]).replace(/\s+/g, "");
      });
      if (!ac) { var r = norm(h.textContent).match(/AC\s*No\.?\s*:\s*([A-Za-z0-9-]+)/i); if (r) ac = r[1]; }
      if (!ifsc) { var r2 = norm(h.textContent).match(/IFSC\s*Code\s*:\s*([A-Za-z0-9]+)/i); if (r2) ifsc = r2[1]; }
      out.push({ jc: card, ap: norm(hf && hf.value), name: norm(nm.textContent), ac: ac, ifsc: ifsc.toUpperCase(), bank: bank });
    });
    return out;
  }

  /* ---------------- the run ---------------- */
  function start() {
    if (busy) { stopReq = true; setMsg("থামানো হচ্ছে… (এখনকার Job Card শেষ করে থামবে)", "warn"); return; }
    if (!window.KDLink || !KDLink.call) { setMsg("Gram Setu link লোড হয়নি। Page reload করুন।", "bad"); return; }
    busy = true; stopReq = false; paintBtn();
    stat = { total: 0, done: 0, rows: 0, saved: 0, updated: 0, same: 0, unmatched: [], noCard: 0, noAcc: 0, t0: Date.now() };
    setMsg("Gram Setu থেকে কোন Job Card-গুলো বাকি দেখা হচ্ছে…", "");
    var prog, pending = [], cards = [];
    progGet().then(function (p) {
      prog = p;
      return KDLink.call("kdesk_account_cards", {}, "🏦 Account Sync — Gram Setu login");
    }).then(function (r) {
      var all = (r && r.cards) || [];
      cards = all.filter(function (x) { return !prog.cards[x.c]; });
      stat.total = cards.length; stat.skipped = all.length - cards.length;
      $("sumGp").textContent = "App-এ " + bnNum(r.workers || 0) + " জন worker, account আছে " + bnNum(r.with_account || 0) + " জনের · বাকি " + bnNum(all.length) + "টা Job Card" +
        (stat.skipped ? " (আজ আগে দেখা " + bnNum(stat.skipped) + "টা বাদ)" : "");
      if (!cards.length) { var e0 = new Error("done"); e0.nothing = true; throw e0; }
      setMsg("Pension page খোলা হচ্ছে…", "");
      return retry(function () { return req(null).then(checkPage); });
    }).then(function (doc) {
      var vopts = villageOptions(doc);
      if (!vopts.length) { var e1 = new Error("Pension page-এ village list পাওয়া যায়নি"); e1.fatal = true; throw e1; }
      var byV = {};
      cards.forEach(function (x) { (byV[x.v] || (byV[x.v] = [])).push(x.c); });
      var chain = Promise.resolve();
      Object.keys(byV).sort(function (a, b) { return a - b; }).forEach(function (vn) {
        chain = chain.then(function () {
          if (stopReq) return;
          var want = byV[vn];
          var order = vopts.filter(function (o) { return o.no === +vn; }).concat(vopts.filter(function (o) { return o.no !== +vn; }));
          return village(order, want);
        });
      });
      return chain;

      function village(order, want) {
        var left = want.slice(), i = 0;
        function next() {
          if (stopReq || !left.length) return Promise.resolve();
          if (i >= order.length || i >= 3) {               // ৩টে village-এ না পেলে বাদ
            left.forEach(function (c) { prog.cards[c] = 1; stat.noCard++; stat.done++; });
            progSet(prog); paint();
            return Promise.resolve();
          }
          var v = order[i++];
          setMsg("Village " + v.text + " খোলা হচ্ছে…", "");
          return retry(function () { return choose(doc, PEN.village, PEN.unVillage, v.value); }).then(function (d) {
            doc = d;
            var opts = regOptions(doc), here = left.filter(function (c) { return opts[c]; });
            left = left.filter(function (c) { return !opts[c]; });
            var c2 = Promise.resolve();
            here.forEach(function (c) {
              c2 = c2.then(function () {
                if (stopReq) return;
                setMsg("পড়া হচ্ছে " + bnNum(stat.done + 1) + "/" + bnNum(stat.total) + " — " + c, "");
                var rows = [];
                var each = opts[c].reduce(function (pr, val) {
                  return pr.then(function () {
                    return retry(function () { return choose(doc, PEN.reg, PEN.unReg, val); }).then(function (d2) {
                      doc = d2; rows = rows.concat(parseAccounts(doc, c).filter(function (x) { return x.ac; }));
                    });
                  });
                }, Promise.resolve());
                return each.then(function () {
                  if (!rows.length) stat.noAcc++;
                  stat.rows += rows.length; pending = pending.concat(rows);
                  prog.cards[c] = 1; stat.done++;
                  if (pending.length >= BATCH) return flush();
                }, function (e) {
                  if (e.fatal) throw e;
                  stat.done++;                               // পরের বার আবার চেষ্টা হবে
                }).then(function () { progSet(prog); paint(); });
              });
            });
            return c2;
          }).then(next);
        }
        return next();
      }
    }).then(function () { return flush(); }).then(function () { finish(); }, function (e) {
      flush().catch(function () {}).then(function () { finish(e); });
    });

    function flush() {
      if (!pending.length) return Promise.resolve();
      var part = pending; pending = [];
      return KDLink.call("kdesk_save_accounts", { p_rows: part }).then(function (r) {
        stat.saved += r.new || 0; stat.updated += r.updated || 0; stat.same += r.same || 0;
        stat.unmatched = stat.unmatched.concat(r.unmatched || []);
        paint();
      }, function (e) { pending = part.concat(pending); throw e; });
    }
  }
  function finish(err) {
    busy = false; paintBtn(); paint();
    if (err && err.nothing) setMsg("✅ সব Job Card-এর account App-এ আছে (অথবা আজ দেখা হয়ে গেছে)। কিছু বাকি নেই।", "ok");
    else if (err) setMsg("থেমে গেছে: " + (err.text || err.message || err) + ". আবার ▶ চাপলে বাকিগুলো থেকে চলবে।", "warn");
    else if (stopReq) setMsg("থামানো হয়েছে। আবার ▶ চাপলে বাকিগুলো থেকে চলবে।", "warn");
    else setMsg("✅ শেষ। নতুন account " + bnNum(stat.saved) + " জনের, বদলেছে " + bnNum(stat.updated) + " জনের।", "ok");
    stopReq = false;
  }

  /* ---------------- panel ---------------- */
  var CSS =
    ":host{all:initial}" +
    ".fab{position:fixed;left:14px;bottom:var(--kdacs-off,14px);z-index:2147483646;cursor:pointer;border:0;border-radius:12px;padding:9px 13px;font:700 13px/1.2 'Segoe UI','Nirmala UI',system-ui,sans-serif;color:#fff;" +
    "background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);box-shadow:0 6px 18px rgba(11,20,55,.3)}" +
    ".box{position:fixed;left:14px;bottom:var(--kdacs-off,14px);z-index:2147483647;max-height:calc(100vh - var(--kdacs-off,14px) - 14px);overflow:auto;width:min(400px,calc(100vw - 28px));border-radius:14px;overflow:hidden;background:#fff;color:#0f172a;" +
    "font:13px/1.4 'Segoe UI','Nirmala UI',system-ui,sans-serif;box-shadow:0 14px 40px rgba(11,20,55,.35)}" +
    ".hd{display:flex;align-items:center;gap:8px;padding:10px 12px;color:#fff;background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3)}" +
    ".k{width:24px;height:24px;border-radius:7px;display:grid;place-items:center;font:800 14px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".hd b{flex:1}.x{cursor:pointer;border:0;background:transparent;color:#c7d2fe;font-size:18px}" +
    ".bd{padding:10px 12px}.sm{color:#475569;font-size:12px}.bar{height:8px;border-radius:6px;background:#e2e8f0;overflow:hidden;margin:8px 0}" +
    ".bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#3730a3,#6366f1)}" +
    ".grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:6px 0}.grid div{background:#f1f5f9;border-radius:8px;padding:6px;text-align:center}" +
    ".grid b{display:block;font-size:15px}.grid small{color:#64748b;font-size:11px}" +
    ".row{display:flex;gap:8px;align-items:center;margin-top:8px}.go{flex:1;cursor:pointer;border:0;border-radius:10px;padding:9px;font:700 13px/1.2 inherit;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".go.stop{background:#fee2e2;color:#991b1b}select{border:1px solid #cbd5e1;border-radius:8px;padding:6px;font:inherit}" +
    ".lk{cursor:pointer;border:0;background:none;color:#3730a3;font:600 12px inherit;text-decoration:underline;padding:0}" +
    ".st{margin-top:8px;padding:7px 9px;border-radius:8px;background:#eef2ff;color:#312e81;font-size:12.5px}.st.ok{background:#dcfce7;color:#166534}.st.warn{background:#fef3c7;color:#92400e}.st.bad{background:#fee2e2;color:#991b1b}";

  function $(id) { return root && root.getElementById(id); }
  function setMsg(m, k) { var s = $("st"); if (s) { s.textContent = m || ""; s.className = "st" + (k ? " " + k : ""); } }
  function paintBtn() { var b = $("go"); if (b) { b.textContent = busy ? "⏹ থামান" : "▶ Account Sync শুরু"; b.className = "go" + (busy ? " stop" : ""); } }
  function paint() {
    if (!root || !$("pct")) return;
    var pct = stat.total ? Math.round(stat.done * 100 / stat.total) : 0;
    $("pct").style.width = pct + "%";
    var left = stat.total - stat.done, per = stat.done ? (Date.now() - stat.t0) / stat.done : gap() * 2 + 600;
    $("prog").textContent = bnNum(stat.done) + "/" + bnNum(stat.total) + " Job Card (" + bnNum(pct) + "%)" +
      (busy && left > 0 ? " · আনুমানিক " + bnNum(Math.ceil(left * per / 60000)) + " মিনিট বাকি" : "");
    $("nNew").textContent = bnNum(stat.saved); $("nUpd").textContent = bnNum(stat.updated); $("nUn").textContent = bnNum(stat.unmatched.length);
    $("dl").style.display = stat.unmatched.length ? "" : "none";
  }
  function downloadUnmatched() {
    var lines = ["Job Card,Applicant No,Name (portal)"].concat(stat.unmatched.map(function (u) { return [u.jc, u.ap || "", '"' + String(u.name || "").replace(/"/g, '""') + '"'].join(","); }));
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv" }));
    a.download = "account-sync-not-matched.csv"; a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
  }
  function openBox() {
    root.innerHTML = "<style>" + CSS + "</style>" +
      "<div class='box'><div class='hd'><span class='k'>K</span><b>🏦 Account Sync → Gram Setu</b><button class='x' id='x' title='ছোট করুন'>–</button></div>" +
      "<div class='bd'><div class='sm'>Portal-এর pension page থেকে প্রতিটা Job Card-এর Account No, IFSC পড়ে Gram Setu app-এ পাঠায়। শুধু যাঁদের account app-এ নেই তাঁদের। Portal-এ কিছু বদলায় না। এই tab খোলা রাখুন।</div>" +
      "<div class='sm' id='sumGp' style='margin-top:6px'></div>" +
      "<div class='bar'><i id='pct'></i></div><div class='sm' id='prog'></div>" +
      "<div class='grid'><div><b id='nNew'>০</b><small>নতুন account</small></div><div><b id='nUpd'>০</b><small>বদলেছে</small></div><div><b id='nUn'>০</b><small>নাম মেলেনি</small></div></div>" +
      "<button class='lk' id='dl' style='display:none'>⬇ নাম-না-মেলা list (CSV)</button>" +
      "<div class='row'><label class='sm'>গতি <select id='speed'><option value='slow'>ধীরে</option><option value='normal' selected>স্বাভাবিক</option><option value='fast'>দ্রুত</option></select></label>" +
      "<button class='go' id='go'></button></div>" +
      "<div class='st' id='st'>▶ চাপলে শুরু হবে। মাঝপথে থামালে পরে বাকিগুলো থেকে চলবে।</div></div></div>";
    $("x").addEventListener("click", showFab);
    $("go").addEventListener("click", start);
    $("dl").addEventListener("click", downloadUnmatched);
    $("speed").value = speed; $("speed").addEventListener("change", function () { speed = this.value; });
    paintBtn(); paint();
  }
  function showFab() {
    root.innerHTML = "<style>" + CSS + "</style><button class='fab' id='fab'>🏦 Account Sync" + (busy ? " · " + bnNum(stat.done) + "/" + bnNum(stat.total) : "") + "</button>";
    $("fab").addEventListener("click", openBox);
  }
  function mount() {
    host = document.createElement("div"); host.id = "kdacs-host"; host.style.cssText = "all:initial";
    root = host.attachShadow({ mode: "open" });
    document.documentElement.appendChild(host);
    showFab();
    // keep the small button's counter fresh while it runs minimised; sit above the
    // Bank A/c Update bar (#kdb-box, full width at the bottom) when it is open
    function place() {
      var kb = document.getElementById("kdb-box"), off = 14;
      if (kb && kb.offsetHeight && getComputedStyle(kb).display !== "none") off = kb.offsetHeight + 10;
      host.style.setProperty("--kdacs-off", off + "px");
      if (host.parentNode !== document.documentElement || host.nextSibling) document.documentElement.appendChild(host);   // stay on top
    }
    place();
    setInterval(function () {
      place();
      if (busy && $("fab")) $("fab").textContent = "🏦 Account Sync · " + bnNum(stat.done) + "/" + bnNum(stat.total);
    }, 1500);
  }
  mount();
})();
});
