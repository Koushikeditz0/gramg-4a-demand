/* bank-bridge.js — K-Desk Suite by Koushik · 🏦 Bank A/c Update (EditAppBank.aspx)
   Isolated world, next to the MAIN-world bank-driver.js:
   1) Guard: PC not activated or "Bank A/c Update" Off on the Dashboard → localStorage
      "kdbank_off" = "1" (and a running job stops); otherwise "0" so the driver starts.
   2) Gram Setu: "☁ Gram Setu" in the driver asks for the accounts the Admin ✔ Verified
      (kdesk_bank_pending); each OK/Fail result goes back (kdesk_bank_report) so the Admin
      panel shows "🏦 Portal updated". Only Job Card, Applicant No, name, A/C and IFSC travel. */
(function () {
  "use strict";
  if (window.__KDBANKBR) return; window.__KDBANKBR = true;

  function setOff(off) {
    try { localStorage.setItem("kdbank_off", off ? "1" : "0"); } catch (e) {}
    if (!off) return;
    try {
      var st = JSON.parse(localStorage.getItem("kdbank_state_v1") || "null");
      if (st && st.running) { st.running = false; localStorage.setItem("kdbank_state_v1", JSON.stringify(st)); }
    } catch (e) {}
  }
  try {
    window.KH_LICENSE.check(function (ok) {
      if (!ok) return setOff(true);
      chrome.storage.local.get(["kh_features", "kh_off"], function (r) { setOff(((r && r.kh_features) || {}).bank === false || !!(r && r.kh_off)); });
    });
  } catch (e) { setOff(true); }

  var SRC_MAIN = "kdbank-main", SRC_BR = "kdbank-bridge";
  function send(msg) { msg.src = SRC_BR; window.postMessage(msg, location.origin); }
  var queue = [], sending = false;
  function flush() {
    if (sending || !queue.length || !window.KDLink) return;
    sending = true;
    var part = queue.splice(0, 200);
    window.KDLink.call("kdesk_bank_report", { p_rows: part }, "🏦 Bank A/c Update → Gram Setu").then(function () {
      sending = false; flush();
    }, function (e) {
      sending = false; queue = part.concat(queue);
      send({ type: "status", text: "Gram Setu-এ result পাঠানো যায়নি (" + (e.text || e.message || e) + ") — পরের result-এর সাথে আবার চেষ্টা হবে" });
    });
  }
  window.addEventListener("message", function (e) {
    var d = e.data; if (e.source !== window || !d || d.src !== SRC_MAIN) return;
    if (!window.KDLink) { send({ type: "status", text: "Gram Setu link লোড হয়নি — page reload করুন" }); return; }
    if (d.type === "load") {
      window.KDLink.call("kdesk_bank_pending", {}, "🏦 Bank A/c Update ← Gram Setu").then(function (rows) {
        rows = Array.isArray(rows) ? rows : [];
        if (!rows.length) { send({ type: "status", text: "☁ Gram Setu: portal-এ update বাকি এমন verified account নেই" }); return; }
        send({ type: "rows", rows: rows });
      }, function (err) {
        send({ type: "status", text: "☁ Gram Setu: " + (err.code === "NOT_LOGGED_IN" ? "login হয়নি" : (err.text || err.message || err)) });
      });
    } else if (d.type === "report" && Array.isArray(d.rows)) {
      queue = queue.concat(d.rows.filter(function (r) { return r && r.id && (r.s === "ok" || r.s === "fail"); }));
      flush();
    }
  });
})();
