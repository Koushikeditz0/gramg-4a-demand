/* K-Desk ↔ Gram Setu Admin bridge (v1.29.0). Runs only on the Gram Setu Admin page.
   - Tells the page K-Desk is here (so its 📚 7 Registers page can show "K-Desk ready").
   - On the page's "make registers" request: takes the Admin's own login token from the page's storage
     (never from the message, so the page cannot name another user) and asks the K-Desk background to check it
     with Gram Setu (role + GP) and open the K-Desk Registers page. No data from the portal is touched here. */
(function () {
  "use strict";
  if (window.__kdGsBridge) return; window.__kdGsBridge = 1;
  var V = chrome.runtime.getManifest().version, O = location.origin;
  function hello() { window.postMessage({ type: "KDESK_HERE", version: V }, O); }
  window.addEventListener("message", function (e) {
    if (e.source !== window || e.origin !== O || !e.data) return;
    var d = e.data;
    if (d.type === "KDESK_PING") return hello();
    if (d.type !== "KDESK_REGISTERS") return;
    var tok = ""; try { tok = (JSON.parse(localStorage.getItem("gramg2.session") || "null") || {}).access_token || ""; } catch (x) {}
    if (!tok) return window.postMessage({ type: "KDESK_REGISTERS_ACK", ok: false, error: "Not logged in to Gram Setu." }, O);
    var req = { fy: String(d.fy || ""), period: String(d.period || "year"), regs: Array.isArray(d.regs) ? d.regs.slice(0, 7).map(String) : [], details: !!d.details };
    try {
      chrome.runtime.sendMessage({ type: "kd-reg-open", token: tok, req: req }, function (r) {
        var err = chrome.runtime.lastError ? "K-Desk did not answer. Reload this page and try again." : null;
        window.postMessage({ type: "KDESK_REGISTERS_ACK", ok: !err && !!(r && r.ok), error: err || (r && r.error) || "" }, O);
      });
    } catch (x) { window.postMessage({ type: "KDESK_REGISTERS_ACK", ok: false, error: "K-Desk was updated. Reload this page." }, O); }
  });
  hello();
})();
