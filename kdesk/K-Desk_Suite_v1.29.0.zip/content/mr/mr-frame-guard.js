// Page-এর নিজের JS জগতে চলে: শুধু extension-এর লুকানো iframe-এর ভিতরে alert/confirm/print আটকায়,
// যাতে automation মাঝপথে আটকে না যায়। তোমার সাধারণ page-এ কিছুই বদলায় না।
(function () {
  try {
    if (window.frameElement && window.frameElement.id === 'mrbp-frame') {
      window.alert = function () {};
      window.confirm = function () { return true; };
      window.print = function () {};
    }
  } catch (e) { /* cross-origin frame */ }
})();
