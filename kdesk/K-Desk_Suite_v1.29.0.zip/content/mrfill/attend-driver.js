/* =====================================================================
   attend-driver.js — K-Desk Suite by Koushik · MR Fill · Fill Attendance only (ENGINE)   …/vbgramg/mustrollattend.aspx

   For each ticked work and each of its muster rolls: open it; if today is its last day (Date To) or later, mark every
   listed worker present on every day EXCEPT the absent days the user chose (day numbers of the
   muster roll: day 1 = its From date), fill an empty Work Start Date, and press Save (the page's
   own promp() checks run; its confirm is answered OK, its alert captured). Muster rolls that
   can't be done are skipped and logged with the reason.

   Work Start Date (txtWrkStartDate): only when the box is EMPTY — the MR's From date, or the date
   the user typed. A date already on the page is never changed.

   The page's grid: worker row i has All{i} (CheckAll ticks c{i}_1..c{i}_{colcnt}) and one box per
   day c{i}_{d}; form1.totrecord = rows, form1.colcnt = days. Workers are never added or removed.
   The "Mark Holiday" boxes (c_p{d}) are not touched.

   v1.3.0 — Present-days target (r.target): after filling, every worker's ticked days are counted
   (locked/disabled day boxes are never clicked and only count if the portal already ticked them).
   If any worker's count ≠ the target, the run PAUSES on that muster roll without saving, leaving it
   filled on screen so the user can correct it by hand and Save; Resume then goes on to the next one.
   v1.3.1: a Test run pauses the same way (nothing is saved either way), and day columns that have
   no tick box in a worker's row are reported as "no box for day …".

   Runs in the PAGE (MAIN) world at document_start; state in localStorage "mrfa_run".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__MRFA_DRV) return;
  window.__MRFA_DRV = true;

  var K = window.MRF_KIT("mrfa"), $ = K.$, byName = K.byName, norm = K.norm, dmyNum = K.dmyNum;

  function absentMap(r, cols) { var m = {}; (r.absent || []).forEach(function (d) { d = d | 0; if (d >= 1 && d <= cols) m[d] = 1; }); return m; }
  function absentList(m) { return Object.keys(m).map(Number).sort(function (a, b) { return a - b; }); }

  // the open muster roll, and why it can't be filled (if it can't)
  function inspect(r) {
    var from = norm(($("txtDatefrm") || {}).value), to = norm(($("txtDateTo") || {}).value);
    var rows = K.formNum("totrecord"), days = K.formNum("colcnt"), sd = $("txtWrkStartDate"), start = norm(sd ? sd.value : "");
    var needStart = !start || start === "0";                       // কিছু লেখা থাকলে কখনো বদলায় না
    var want = r.startMode === "custom" ? norm(r.startDate) : from;
    var text = K.pageText(), why = "";
    var abs = absentMap(r, days);
    if (/No Future Dates/i.test(text) || (dmyNum(to) && dmyNum(to) > K.todayIST())) why = "period not over (ends " + (to || "?") + ")";
    else if (/already\s+(been\s+)?(filled|saved|entered|marked)|attendance\s+(is\s+)?already/i.test(text)) why = "attendance already filled";
    else if (!rows || !byName("All1")) why = "no workers listed on this muster roll";
    else if (!days) why = "the page shows no day columns";
    else if (absentList(abs).length >= days) why = "every day of this muster roll (" + days + " day(s)) is in the absent list";
    else if (needStart && (!sd || sd.disabled)) why = "Work Start Date missing and its box can't be filled — enter it on the portal, then run again";
    else if (needStart && !dmyNum(want)) why = "Work Start Date missing and " + (r.startMode === "custom" ? "the date you gave" : "the muster roll's From date") + " is not readable";
    else if (needStart && dmyNum(from) && dmyNum(want) > dmyNum(from)) why = "the Work Start Date you gave (" + want + ") is after this muster roll's From date " + from;
    else if ($("chk_zeroAtt") && $("chk_zeroAtt").checked) why = "the zero-attendance box is ticked on the page";
    else if (!K.saveButton()) why = "the Save button is not on the page";
    return { from: from, to: to, workers: rows, cols: days, abs: abs, why: why, fillStart: !why && needStart, startVal: want };
  }
  // Work Start Date — portal-এর নিজের date box; readonly না, তবু value সরাসরি বসানো হয় (validdt blur-এ মিলিয়ে নেয়)
  function fillStart(val) {
    var sd = $("txtWrkStartDate"); if (!sd || sd.disabled) return false;
    sd.value = val;
    ["input", "change", "blur"].forEach(function (t) { try { sd.dispatchEvent(new Event(t, { bubbles: true })); } catch (e) {} });
    return norm(sd.value) === val;
  }
  // tick the worker box (the page's CheckAll ticks every day), then untick the absent days
  function fill(rows, cols, abs) {
    for (var i = 1; i <= rows; i++) {
      var all = byName("All" + i); if (!all) continue;
      if (!all.checked) all.click();
      for (var d = 1; d <= cols; d++) { var c = byName("c" + i + "_" + d); if (c && !c.disabled && c.checked !== !abs[d]) c.click(); }
    }
  }
  // right before Save: this work + muster roll, every row exactly as planned
  function check(work, msr, rows, cols, abs, from, counts) {
    var p = [];
    var sd = norm(($("txtWrkStartDate") || {}).value);
    if (!sd || sd === "0") p.push("Work Start Date is empty");
    else if (from && dmyNum(sd) && dmyNum(sd) > dmyNum(from)) p.push("Work Start Date " + sd + " is after the muster roll's From date " + from);
    if (norm(($("ddlWorkCode") || {}).value) !== work) p.push("the work dropdown changed");
    if (norm(($("ddlMsrNo") || {}).value) !== msr) p.push("the muster roll dropdown changed");
    if ($("chk_zeroAtt") && $("chk_zeroAtt").checked) p.push("the zero-attendance box is ticked");
    for (var i = 1; i <= rows; i++) {
      var all = byName("All" + i);
      if (!all) continue;
      if (!all.checked) { p.push("worker row " + i + " is not selected"); continue; }
      var on = 0, locked = [], nobox = [], bad = "";
      for (var d = 1; d <= cols; d++) {
        var c = byName("c" + i + "_" + d); if (!c) { nobox.push(d); continue; }
        if (c.checked) on++;
        if (c.disabled) { locked.push(d); continue; }               // portal-এর বন্ধ ঘর: plan-এর সাথে মেলানো হয় না
        if (!bad && c.checked !== !abs[d]) bad = "row " + i + " day " + d + " is " + (c.checked ? "ticked" : "not ticked");
      }
      if (bad) p.push(bad);
      if (!on) p.push("row " + i + " has no day ticked");
      if (counts) counts.push({ row: i, on: on, locked: locked, nobox: nobox });
    }
    return p;
  }

  function process(r, work, msr) {
    var info = inspect(r); info.work = work; info.msr = msr;
    var abs = absentList(info.abs), present = info.cols - abs.length;
    info.detail = info.cols ? present + " of " + info.cols + " day(s) present" + (abs.length ? "; absent day " + abs.join(", ") : "") : "";
    if (info.why) { K.result(r, info, "Skipped", info.why); K.log(r, "warn", work + " · MR " + msr + ": skipped — " + info.why); K.saveRun(r); return; }
    if (info.fillStart && !fillStart(info.startVal)) {
      K.result(r, info, "Skipped", "Work Start Date missing and could not be filled — enter it on the portal, then run again");
      K.log(r, "warn", work + " · MR " + msr + ": skipped — Work Start Date could not be filled"); K.saveRun(r); return;
    }
    if (info.fillStart) info.detail += "; Work Start Date filled " + info.startVal;
    fill(info.workers, info.cols, info.abs);
    var counts = [];
    var problems = check(work, msr, info.workers, info.cols, info.abs, info.from, counts);
    if (problems.length && K.canDefer(r)) { K.defer(r, info, "safety check before Save failed: " + problems.slice(0, 4).join("; ")); K.saveRun(r); return; }
    if (problems.length) {
      K.result(r, info, "Error", "safety check before Save failed — NOT saved: " + problems.slice(0, 4).join("; "));
      K.log(r, "err", work + " · MR " + msr + ": safety check before Save failed — NOT saved (" + problems.slice(0, 4).join("; ") + ")");
      r.consec = (r.consec || 0) + 1; K.saveRun(r); return;
    }
    var pc = {}; counts.forEach(function (c) { pc[c.on] = 1; });
    info.pres = Object.keys(pc).map(Number).sort(function (a, b) { return a - b; }).join("/");   // present days per worker, e.g. "15" or "14/15"
    var tgt = r.target | 0;
    if (tgt) {
      var off = counts.filter(function (c) { return c.on !== tgt; });
      var lk = {}; counts.forEach(function (c) { c.locked.forEach(function (d) { lk[d] = 1; }); });
      var lockedDays = Object.keys(lk).map(Number).sort(function (a, b) { return a - b; });
      var nb = {}; counts.forEach(function (c) { c.nobox.forEach(function (d) { nb[d] = 1; }); });
      var noBoxDays = Object.keys(nb).map(Number).sort(function (a, b) { return a - b; });
      var seen = {}; counts.forEach(function (c) { seen[c.on] = (seen[c.on] || 0) + 1; });
      info.detail += "; present " + Object.keys(seen).map(function (k) { return k + " day(s)" + (counts.length > 1 ? " ×" + seen[k] : ""); }).join(", ") + " (target " + tgt + ")" +
        (lockedDays.length ? "; locked day " + lockedDays.join(", ") : "") + (noBoxDays.length ? "; no box for day " + noBoxDays.join(", ") : "");
      if (off.length) {
        var why = off.length + " of " + counts.length + " worker(s) not at the target " + tgt + " present day(s): " +
          off.slice(0, 4).map(function (c) { return "row " + c.row + " = " + c.on; }).join(", ") + (off.length > 4 ? " …" : "") +
          " (MR has " + info.cols + " day(s)" + (abs.length ? ", absent day " + abs.join(", ") : "") + (lockedDays.length ? ", locked day " + lockedDays.join(", ") : "") + (noBoxDays.length ? ", no box for day " + noBoxDays.join(", ") : "") + ")";
        if (K.canDefer(r)) { K.defer(r, info, "NOT saved — " + why); K.saveRun(r); return; }   // v1.9.9: আগে বাকিগুলো, শেষে আবার
        K.result(r, info, r.dryRun ? "Would pause (test)" : "Manual", "NOT saved — " + why + ". Paused for you to fix it by hand.");
        r.active = false; r.current = ""; r.paused = { work: work, msr: msr };
        K.log(r, "err", "PAUSED at " + work + " · MR " + msr + " — " + why + ". It is filled on screen but NOT saved: correct the days by hand, press the portal's Save, then press ▶ Resume (this MR will not be touched again).");
        K.saveRun(r); K.restoreDialogs();
        return "paused";
      }
    }
    var what = info.workers + " worker(s), " + info.detail + ", " + info.from + "–" + info.to;
    if (r.dryRun) {
      K.result(r, info, "Would save (test)", what);
      K.log(r, "info", work + " · MR " + msr + ": would save (test run) — " + what);
      K.saveRun(r); return;
    }
    return K.pressSave(r, info, what);
  }

  K.boot(K.makeLoop({ retryOnce: true, process: process }));
})();
