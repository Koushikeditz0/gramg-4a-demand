/* =====================================================================
   attend-panel.js — K-Desk Suite by Koushik · MR Fill · Fill Attendance only (UI)   …/vbgramg/mustrollattend.aspx
   Excel upload (Work Code column → সেই work tick) বা নিজে tick, কোন কোন দিন absent (MR-এর দিন নম্বর: 1 = From date), Work Start Date কোথা থেকে।
   attend-driver.js (MAIN world) প্রতিটা MR ভরে Save করে।
   ===================================================================== */
(function () {
  "use strict";
  if (window.__MRFA_UI) return; window.__MRFA_UI = true;

  var api = null, P = "mrfa_", XL_KEY = "mrfa_xl", xl = null, iay = null;   // iay: Admin job (IAY Tracker) helper   // Excel-এর work list: { name, at, count, codes: { "3208…/IF/IAY/…": 1 } }
  function g(id) { return api && api.root.getElementById(P + id); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function dmyOk(s) {
    var m = /^\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\s*$/.exec(String(s || "")); if (!m) return false;
    var d = new Date(+m[3], +m[2] - 1, +m[1]); return d.getFullYear() === +m[3] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[1];
  }
  function normDmy(s) { var m = /^\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\s*$/.exec(String(s || "")); return m ? pad2(m[1]) + "/" + pad2(m[2]) + "/" + m[3] : ""; }
  // "1, 7" / "1 7" / "3-5" → [1,3,4,5,7]
  function parseDays(s) {
    var out = {}, bad = "";
    String(s || "").split(/[\s,;]+/).filter(Boolean).forEach(function (p) {
      var m = /^(\d{1,2})(?:-(\d{1,2}))?$/.exec(p);
      if (!m) { bad = p; return; }
      var a = +m[1], b = m[2] ? +m[2] : a; if (b < a) { var t = a; a = b; b = t; }
      for (var d = a; d <= b; d++) { if (d >= 1 && d <= 31) out[d] = 1; else bad = p; }
    });
    return { days: Object.keys(out).map(Number).sort(function (x, y) { return x - y; }), bad: bad };
  }
  function opts() {
    var pd = parseDays(g("abs").value);
    var tt = String(g("tgt").value || "").trim(), tn = /^\d{1,2}$/.test(tt) ? +tt : 0;
    return { absent: pd.days, bad: pd.bad, startMode: "from", startDate: "", dry: g("dry").checked,
      target: tn, badTarget: tt && !(tn >= 1 && tn <= 31) ? tt : "" };
  }
  function keep() {
    var q = api.prefs(), o = opts();
    q.absentText = g("abs").value; q.target = g("tgt").value; api.savePrefs(q);
    drawDays(); drawTarget(); api.changed();
  }
  // day chips: as many as the open MR has (colcnt), with the date under each when From date is readable
  function drawDays() {
    var box = g("days"); if (!box) return;
    var cols = parseInt((document.getElementsByName("colcnt")[0] || {}).value, 10) || 16;
    var fm = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(((document.getElementById("txtDatefrm") || {}).value || "").trim());
    var base = fm ? new Date(+fm[3], +fm[2] - 1, +fm[1]) : null, on = {};
    opts().absent.forEach(function (d) { on[d] = 1; });
    var h = "";
    for (var d = 1; d <= Math.max(cols, 14); d++) {
      var dt = base ? new Date(base.getFullYear(), base.getMonth(), base.getDate() + d - 1) : null;
      h += "<button class='day" + (on[d] ? " on" : "") + "' data-d='" + d + "' title='" + (dt ? "Day " + d + " = " + pad2(dt.getDate()) + "/" + pad2(dt.getMonth() + 1) + "/" + dt.getFullYear() : "Day " + d) + "'>" + d +
        (dt ? "<small>" + pad2(dt.getDate()) + "/" + pad2(dt.getMonth() + 1) + "</small>" : "") + "</button>";
    }
    box.innerHTML = h;
  }

  // the MR open on screen: days, locked boxes in row 1, and what the target check would see
  function drawTarget() {
    var el = g("tgtinfo"); if (!el) return;
    var o = opts(), cols = parseInt((document.getElementsByName("colcnt")[0] || {}).value, 10) || 0;
    if (!o.target) { el.innerHTML = "খালি রাখলে দিন গোনা হবে না (আগের মতো চলবে)।"; return; }
    if (!cols || !document.getElementsByName("c1_1")[0]) { el.innerHTML = "প্রতিটা worker-এর present দিন ঠিক <b>" + o.target + "</b> না হলে run থেমে যাবে (Save হবে না)।"; return; }
    var abs = {}, locked = [], on = 0;
    o.absent.forEach(function (d) { abs[d] = 1; });
    for (var d = 1; d <= cols; d++) {
      var c = document.getElementsByName("c1_" + d)[0]; if (!c) continue;
      if (c.disabled) { locked.push(d); if (c.checked) on++; } else if (!abs[d]) on++;
    }
    var ok = on === o.target;
    el.innerHTML = "এই খোলা MR: " + cols + " দিন" + (o.absent.length ? " − absent " + o.absent.length : "") + (locked.length ? " − বন্ধ দিন " + locked.join(", ") : "") +
      " = <b style='color:" + (ok ? "#166534" : "#c5221f") + "'>" + on + " দিন " + (ok ? "✓" : "≠ " + o.target + " → এখানে থামবে") + "</b>";
  }

  /* ---------------------- Excel: Work Code column (যেকোনো sheet) → সেই work গুলো tick ---------------------- */
  var CODE_RE = /^\d{10}\/[A-Z0-9]+\/[A-Z0-9]+\/[A-Z0-9]+$/;
  function key(w) { return String(api.code(w) || "").replace(/\s+/g, "").toUpperCase(); }
  function inXl(w) { return !!(xl && xl.codes && xl.codes[key(w)]); }
  function readExcel(file) {
    var fr = new FileReader();
    fr.onload = function () {
      try {
        var wb = XLSX.read(new Uint8Array(fr.result), { type: "array" }), codes = {}, mrs = {}, nMr = 0;
        wb.SheetNames.forEach(function (sn) {
          var aoa = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, raw: false, defval: "" }), col = -1, mcol = -1, hrow = -1;
          for (var i = 0; i < Math.min(aoa.length, 15) && col < 0; i++) (aoa[i] || []).forEach(function (c, j) { if (col < 0 && /work\s*code/i.test(String(c))) { col = j; hrow = i; } });
          // v1.5.0: optional MR No column on the same header row (MR No / E-MR No / Muster Roll No / MSR No)
          if (hrow >= 0) (aoa[hrow] || []).forEach(function (c, j) { if (mcol < 0 && j !== col && /(^|[^a-z])(e\s*-?\s*)?(mr|msr|muster\s*roll)\s*(no|number|num)\b/i.test(String(c))) mcol = j; });
          aoa.forEach(function (row, ri) {
            if (col >= 0) {
              if (ri <= hrow) return;
              var s = String(row[col] == null ? "" : row[col]).replace(/\s+/g, "").toUpperCase(); if (!CODE_RE.test(s)) return;
              codes[s] = 1;
              var m = mcol >= 0 ? String(row[mcol] == null ? "" : row[mcol]).trim().replace(/\.0+$/, "") : "";
              if (/^\d+$/.test(m)) { var L = mrs[s] = mrs[s] || []; if (L.indexOf(m) < 0) { L.push(m); nMr++; } }
              return;
            }
            row.forEach(function (c) { var s = String(c == null ? "" : c).replace(/\s+/g, "").toUpperCase(); if (CODE_RE.test(s)) codes[s] = 1; });
          });
        });
        var n = Object.keys(codes).length;
        if (!n) { api.status("Excel-এ কোনো Work Code পাওয়া যায়নি (যেমন 3208005012/IF/IAY/5042115)।", "warn"); return; }
        xl = { name: file.name, at: Date.now(), count: n, codes: codes, mrs: mrs, nMr: nMr };
        var o = {}; o[XL_KEY] = xl;
        chrome.storage.local.set(o, function () {
          var list = api.allWorks().filter(inXl);
          drawXl(); api.changed();
          api.status(n + "টা Work Code" + (nMr ? ", " + nMr + "টা MR No" : " (MR No column নেই — প্রতিটা work-এর সব MR দেখবে)") + " নেওয়া হল, এই page-এ " + list.length + "টা work পাওয়া গেছে।", list.length ? "ok" : "warn");
        });
      } catch (e) { var em = e && e.message ? e.message : String(e); api.status(/context invalidated/i.test(em) ? "Extension update/Reload হয়েছে কিন্তু page পুরনো — page refresh (F5) করে আবার Excel দিন।" : "Excel পড়া গেল না: " + em, "warn"); }
    };
    fr.readAsArrayBuffer(file);
  }
  function drawXl() {
    var el = g("xlinfo"); if (!el) return;
    if (!xl || !xl.count) { el.textContent = "Work Code column থাকা Excel দিন।"; return; }
    var works = api.allWorks(), have = works.filter(inXl), onPage = {};
    works.forEach(function (w) { onPage[key(w)] = 1; });
    var missing = Object.keys(xl.codes).filter(function (c) { return !onPage[c]; });
    var withMr = Object.keys(xl.mrs || {}).length;
    el.innerHTML = "<b>" + String(xl.name).replace(/[&<>]/g, "") + "</b>: " + xl.count + "টা code" + (xl.nMr ? ", " + xl.nMr + "টা MR No" : "") + " · page-এ <b>" + have.length + "</b>টা" +
      (xl.nMr && withMr < xl.count ? "<br><span style='color:#5b6472'>" + (xl.count - withMr) + "টা code-এ MR No নেই → সেগুলোর সব MR দেখবে</span>" : "") +
      (missing.length ? "<br><span style='color:#92400e'>" + missing.length + "টা page-এ নেই: " + missing.slice(0, 3).map(function (c) { return c.split("/").slice(-2).join("/"); }).join(", ") + (missing.length > 3 ? " …" : "") + "</span>" : "");
  }

  window.MRF_PANEL({
    ns: "mrfa", mode: "attend", hostId: "mrfa-host", excelOnly: true, compact: true, statusTop: true,
    pickWorks: function () { return xl ? api.allWorks().filter(inXl) : []; },
    statusLine: function (x, esc, tail) {
      var d = x.pres ? x.pres + " দিন" : "", cls, ic, tx;
      if (x.result === "Saved") { cls = "ok"; ic = "✅"; tx = (d ? d + " " : "") + "attendance done"; }
      else if (x.result === "Would save (test)") { cls = "test"; ic = "🧪"; tx = (d ? d + " " : "") + "ঠিক আছে (test, Save হয়নি)"; }
      else if (x.result === "Manual" || x.result === "Would pause (test)") { cls = "man"; ic = "⏸"; tx = (d || "?") + " পেয়েছিল — হাতে ঠিক করার জন্য থেমেছিল"; }
      else if (x.result === "Skipped") {
        cls = "skip"; ic = "⏭";
        tx = /period not over/.test(x.msg) ? "MR শেষ হয়নি" : /already filled/.test(x.msg) ? "আগেই ভরা" : /no workers/.test(x.msg) ? "worker নেই" : /zero-attendance/.test(x.msg) ? "zero attendance tick" : /Work Start Date/.test(x.msg) ? "Work Start Date সমস্যা" : /not in this work's muster roll list/.test(x.msg) ? "এই MR No page-এ নেই" : "skip";
      }
      else { cls = "err"; ic = "❌"; tx = "Save হয়নি — log দেখুন"; }
      return "<div class='sl " + cls + "' title='" + esc(x.msg || x.detail || "") + "'><span class='ic'>" + ic + "</span><span class='wc'>" + esc(tail(x.work)) + "</span>" +
        (x.msr && x.msr !== "—" ? "<span class='mr'>MR " + esc(x.msr) + "</span>" : "") + "<span class='tx'>" + esc(tx) + "</span></div>";
    }, title: "Fill Attendance only", sub: "Muster Roll Attendance",
    ifOnlyDefault: true, logName: "MRFill-Attendance", sheetName: "Attendance log",
    idleHtml: "Excel upload করুন, কোন দিন <b>absent</b> হবে বেছে নিন (না বাছলে সব দিন present), তারপর Start।",
    confirmHead: "এটা portal-এ attendance Save করবে",
    disclaimer: "⚠ Automatic entry-তে ভুল হতে পারে। Save করা attendance wage list-এ যায়। প্রথমে Test run, তারপর একটা ছোট work দিয়ে চালিয়ে portal-এ মিলিয়ে নিন। ব্যবহারের দায়িত্ব আপনার।",
    style: ".panel{width:340px}.bd{padding:7px 9px}.hd{padding:7px 10px}.logo{width:24px;height:24px}.ttl b{font-size:13px}" +
      ".summary{padding:5px 8px;font-size:11.5px;line-height:1.35}.row{margin-top:5px;gap:5px}.c0{margin-top:0}.note.c0{margin:0;flex:1;min-width:0}.lbl2{font-weight:700;color:#3730a3;font-size:11.5px}" +
      ".inp{padding:4px 6px}.inp.num{width:42px;text-align:center}.days{gap:3px;margin-top:5px}.day{width:27px;padding:2px 0;font-size:11px}.day small{font-size:8px}" +
      ".note{margin-top:3px;font-size:10.5px}.btnrow{margin-top:5px;gap:5px}.btn{min-height:30px;padding:5px 8px;font-size:12px}.btn.sm{min-height:24px;padding:3px 6px;font-size:10.5px;border-radius:7px}" +
      ".statbox{max-height:170px;margin-top:6px}.sec{margin:6px 0 4px;padding-top:5px}.logbox{max-height:90px}.prog{margin:5px 0}.st{margin-top:5px;padding:4px 7px}.st:empty{display:none}.disclaimer{margin-top:6px;font-size:9px;padding:4px 6px}.foot{margin-top:5px;padding-top:4px}" +
      ".up{padding:4px 9px;font-size:11.5px}" +
      ".tag{margin-left:auto;font:600 10.5px 'Segoe UI',Arial;color:#166534}" +
      ".up{display:inline-block;padding:6px 10px;border-radius:9px;border:1.5px dashed #a5acec;background:#f5f6ff;color:#3730a3;font-weight:600;font-size:12px;cursor:pointer}.up input{display:none}",
    onRender: function (r) { if (iay) iay.sync(r); },
    tagKey: function () { return xl ? xl.at : 0; },
    workTag: function (w) { return inXl(w) ? "<span class='tag'>Excel ✓</span>" : ""; },
    setupHtml:
      "<div class='row c0'><label class='up'>⭱ Excel upload<input type='file' id='mrfa_file' accept='.xlsx,.xls,.csv'></label><button class='btn ghost sm' id='mrfa_iay' title='Admin panel-এর IAY Tracker থেকে পাঠানো MR Attendance job'>📥 Admin job</button><span class='note c0' id='mrfa_xlinfo'></span></div>" +
      "<div class='row'><span class='lbl2'>Absent</span><input class='inp' id='mrfa_abs' placeholder='দিন নম্বর, যেমন 7 (খালি = সব present)' style='flex:1;min-width:0'>" +
        "<span class='lbl2'>লক্ষ্য</span><input class='inp num' id='mrfa_tgt' inputmode='numeric' placeholder='15' title='প্রতি worker-এর present দিন — না মিললে Pause। খালি = গোনা হবে না'></div>" +
      "<div class='days' id='mrfa_days'></div>" +
      "<div class='note' id='mrfa_tgtinfo'></div>",
    validate: function () {
      var o = opts();
      if (o.bad) return "Absent days-এ \"" + o.bad + "\" বুঝতে পারিনি। শুধু দিনের নম্বর লিখুন, যেমন 1, 7।";
      if (o.badTarget) return "Present দিন (লক্ষ্য)-তে 1 থেকে 31-এর মধ্যে একটা সংখ্যা লিখুন, অথবা খালি রাখুন।";
      return "";
    },
    confirmHtml: function (w) {
      var o = opts();
      return (o.dry ? "<b>Test run</b>: attendance ভরবে কিন্তু <b>Save চাপবে না</b>।<br>" : "") +
        (function () { var k = w.filter(function (x) { return xl && xl.mrs && xl.mrs[key(x)]; }).length; return k ? "<b>" + k + "টা work</b>-এ শুধু Excel-এর MR No চলবে" + (k < w.length ? ", বাকি " + (w.length - k) + "টার সব MR দেখবে" : "") + "।<br>" : ""; })() +
        "<b>" + w.length + "টা work</b>-এর যে MR-গুলোর শেষ দিন (Date To) আজ বা আগে, তাতে সব worker " +
        (o.absent.length ? "<b>দিন " + o.absent.join(", ") + "</b> absent, বাকি সব দিন present" : "<b>প্রতিদিন</b> present") + ", তারপর <b>Save</b>।<br>" +
        (o.target ? "প্রতিটা worker-এর present দিন ঠিক <b>" + o.target + "</b> না হলে সেই MR Save হবে না, run <b>Pause</b> হবে। হাতে ঠিক করে Save করে Resume চাপবেন" + "।<br>" : "") +
        "Work Start Date খালি থাকলে <b>MR-এর From date</b> বসবে।" +
        " যে MR-এর শেষ দিন এখনো আসেনি বা worker নেই, সেগুলো কারণসহ skip হবে।" +
        (o.dry ? "" : "<br><b>Save করা attendance wage list-এ যায়, তাই দিনগুলো মিলিয়ে নিন।</b>");
    },
    makeRun: function (w) {
      var o = opts(), mrMap = {};
      (w || []).forEach(function (x) { var L = xl && xl.mrs && xl.mrs[key(x)]; if (L && L.length) mrMap[x] = L.slice(); });
      return { mrMap: mrMap, absent: o.absent, target: o.target, startMode: o.startMode, startDate: o.startDate, dryRun: o.dry };
    },
    modeText: function (r) {
      return ((r.absent && r.absent.length) ? "absent day " + r.absent.join(", ") : "all days present") + (r.target ? " · target " + r.target + " day(s)" : "");
    },
    onBuilt: function (a) {
      api = a;
      var p = a.prefs();
      if (p.absentText) g("abs").value = p.absentText;
      if (p.target) g("tgt").value = p.target;
      g("tgt").addEventListener("input", keep);
      g("abs").addEventListener("input", keep);
      g("days").addEventListener("click", function (e) {
        var b = e.target.closest && e.target.closest(".day"); if (!b) return; e.preventDefault();
        var d = +b.getAttribute("data-d"), cur = opts().absent, i = cur.indexOf(d);
        if (i >= 0) cur.splice(i, 1); else cur.push(d);
        cur.sort(function (x, y) { return x - y; });
        g("abs").value = cur.join(", "); keep();
      });
      drawDays(); drawTarget();
      g("file").addEventListener("change", function () { var f = g("file").files[0]; if (f) { if (iay) iay.clear(); readExcel(f); } g("file").value = ""; });
      if (window.MRF_IAY) { iay = window.MRF_IAY({ ns: "mrfa", kind: "attend", api: a, readExcel: readExcel }); g("iay").addEventListener("click", iay.open); }
      else g("iay").hidden = true;
      try { chrome.storage.local.get(XL_KEY, function (d) { xl = (d && d[XL_KEY]) || null; drawXl(); api.changed(); }); } catch (e) { drawXl(); }
    }
  });
})();
