/* off-guard.js — K-Desk Suite by Koushik · MR Fill
   Popup-এ কোনো mode Off থাকলে সেই page-এর MAIN-world driver-কে থামিয়ে রাখে:
   localStorage "mrfa_off" / "mrfp_off" = "1" (চালু থাকলে "0"), আর চলমান run বন্ধ, যাতে নিজে থেকে resume না করে। */
(function () {
  "use strict";
  var ns = /msrpayment\.aspx/i.test(location.pathname) ? "mrfp" : "mrfa", mode = ns === "mrfp" ? "pay" : "attend";
  function setOff(off) {
    try { localStorage.setItem(ns + "_off", off ? "1" : "0"); } catch (e) {}
    if (!off) return;
    try {
      var run = JSON.parse(localStorage.getItem(ns + "_run") || "null");
      if (run && run.active) { run.active = false; run.stopRequested = false; run.updatedAt = Date.now(); localStorage.setItem(ns + "_run", JSON.stringify(run)); }
    } catch (e) {}
  }
  try {
    // K-Desk: PC activated না হলে বা Dashboard-এ Off (kh_features.mrattend / mrpay) থাকলে বন্ধ
    var key = mode === "pay" ? "mrpay" : "mrattend";
    window.KH_LICENSE.check(function (ok) {
      if (!ok) return setOff(true);
      chrome.storage.local.get(["kh_features", "kh_off"], function (r) { var f = (r && r.kh_features) || {}; setOff(f[key] === false || !!(r && r.kh_off)); });
      chrome.storage.onChanged.addListener(function (ch) { if (ch.kh_features || ch.kh_off) chrome.storage.local.get(["kh_features", "kh_off"], function (r) { var f = (r && r.kh_features) || {}; setOff(f[key] === false || !!(r && r.kh_off)); }); });
    });
  } catch (e) { setOff(true); }
})();
