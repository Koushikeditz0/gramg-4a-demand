/* =====================================================================
   pay-driver.js — K-Desk Suite by Koushik · MR Fill · Payment only (ENGINE)   …/vbgramg/msrpayment.aspx
   v1.1: MB No comes from the uploaded Excel (Work Code → MB Number, r.mbMap); Wage Per Day is fixed
   to the page's own wage rate (300); only Page No is typed in the panel.

   For each ticked work and each of its muster rolls: open it; fill every worker's Wage Per Day
   that is 0/empty (the wage the user gave, or the page's own wage rate min_wage) and let the
   page's own wage_per_day() work out the amounts; fill Measurement Book No (mb_no_txt) and
   Page No (page_no_txt); press Save (promp(): confirm answered OK, alert captured).
   Page No can go up by 1 after every saved muster roll (user's choice).
   Attendance (P marks, Total Attendance) and the Work start date are the page's own and are
   never changed; "Generate The Pay Slip" stays as the page has it.

   v1.6.0 — Amount target (r.target, Rs per worker): after filling, every worker's Amount Due (APATA)
   is compared with the target. Any mismatch PAUSES the run on that muster roll without saving; it stays
   filled on screen for the user to fix by hand and Save, and Resume goes on with the next one.
   r.mrMap (from the Excel's MR No column) limits a work to those muster rolls (drv-kit loop).

   Runs in the PAGE (MAIN) world at document_start; state in localStorage "mrfp_run".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__MRFP_DRV) return;
  window.__MRFP_DRV = true;

  var K = window.MRF_KIT("mrfp"), $ = K.$, byName = K.byName, norm = K.norm, dmyNum = K.dmyNum;

  function num(v) { var n = parseFloat(String(v == null ? "" : v).trim()); return isNaN(n) ? 0 : n; }
  function txt(id) { var e = $(id); return e ? norm(e.value != null && e.tagName === "INPUT" ? e.value : (e.innerText || e.textContent)) : ""; }
  // dropdown value can be "Work name(3208…/IF/IAY/…)": the code part, upper-case
  function codeOf(w) { var m = /\(([^()]*\/[^()]*)\)\s*$/.exec(String(w || "")); return norm(m ? m[1] : w).toUpperCase(); }
  function r2(n) { return Math.round(n * 100) / 100; }
  // v1.3.0: every worker row on the page, by its own wage_per_day{i} box — not only 1..totrecord
  function wageRows(total) {
    var seen = {}, out = [];
    [].forEach.call(document.querySelectorAll("input[name^='wage_per_day']"), function (e) {
      var m = /^wage_per_day(\d+)$/.exec(e.name || ""); if (m && !seen[m[1]]) { seen[m[1]] = 1; out.push(+m[1]); }
    });
    for (var i = 1; i <= total; i++) if (!seen[i] && byName("wage_per_day" + i)) out.push(i);
    return out.sort(function (a, b) { return a - b; });
  }

  function inspect(r) {
    var from = txt("lblDateFrom"), to = txt("lblDateTo"), rows = K.formNum("totrecord");
    var minWage = num((byName("min_wage") || {}).value) || num(txt("lblWageRate"));
    var wage = minWage || 300;                                   // fixed: the page's own wage rate (300)
    var mb = String((r.mbMap || {})[codeOf(r.works[r.wi])] || "");
    // v1.7.0: Page No from the Excel (this work + MR, else this work), else the panel's Page No
    var pk = codeOf(r.works[r.wi]), pm = r.pageMap || {}, msrNow = norm(($("ddlMsrNo") || {}).value);
    var xp = pm[pk + "|" + msrNow] || pm[pk] || "";
    var page = xp ? String(xp) : String(r.pageNext == null ? r.page : r.pageNext);
    var text = K.pageText(), why = "";
    if (!mb) why = "MB No for this work is not in the uploaded Excel";
    else if (dmyNum(to) && dmyNum(to) > K.todayIST()) why = "period not over (ends " + to + ")";
    else if (/already\s+(been\s+)?(paid|saved|entered)|payment\s+(is\s+)?already/i.test(text)) why = "payment already entered";
    else if (!rows || !byName("wage_per_day1")) why = "no workers listed on this muster roll";
    else if (!txt("txtWrkStDate")) why = "Work start date is empty — fill attendance (with Work Start Date) first";
    else if (!$("mb_no_txt") || !$("page_no_txt")) why = "the Measurement Book No / Page No boxes are not on the page";
    else if (!K.saveButton()) why = "the Save button is not on the page";
    if (!why && !/^\d+$/.test(page)) why = "Page No missing — not in the Excel for this work/MR and none set in the panel";
    return { from: from, to: to, workers: rows, wage: wage, minWage: minWage || wage, mb: mb, page: page, pageXl: !!xp, why: why };
  }

  function fill(info, r) {
    var i, w, kept = 0, rows = wageRows(info.workers);
    info.rows = rows;
    rows.forEach(function (i) {
      w = byName("wage_per_day" + i); if (!w) return;
      if (!(num(w.value) > 0)) w.value = String(info.wage); else if (num(w.value) !== info.wage) kept++;
    });
    // the page's own calculation: Amt Due = Total Attendance × Wage Per Day, Total Cash = Amt Due + TADA + Implements
    rows.forEach(function (i) {
      if (!byName("wage_per_day" + i)) return;
      try { if (typeof window.wage_per_day === "function") window.wage_per_day("wage_per_day" + i, i); else byName("wage_per_day" + i).dispatchEvent(new Event("blur")); } catch (e) {}
    });
    var mb = $("mb_no_txt"), pg = $("page_no_txt");
    mb.value = info.mb; pg.value = info.page;
    [mb, pg].forEach(function (el) { try { el.dispatchEvent(new Event("change", { bubbles: true })); } catch (e) {} });
    return kept;
  }

  function check(work, msr, info, r) {
    var p = [], pd = 0, amt = 0;
    if (norm(($("ddlWorkCode") || {}).value) !== work) p.push("the work dropdown changed");
    if (norm(($("ddlMsrNo") || {}).value) !== msr) p.push("the muster roll dropdown changed");
    if (!txt("txtWrkStDate")) p.push("Work start date is empty");
    if (norm($("mb_no_txt").value) !== info.mb) p.push("Measurement Book No is not " + info.mb);
    if (norm($("page_no_txt").value) !== info.page || isNaN(info.page)) p.push("Page No is not " + info.page);
    var rows = wageRows(info.workers);
    [].forEach.call(document.querySelectorAll("input[name^='wage_per_day']"), function (e) { if (/^wage_per_day\d+$/.test(e.name) && !(num(e.value) > 0)) p.push(e.name + ": Wage Per Day is 0"); });
    for (var k = 0; k < rows.length; k++) {
      var i = rows[k];
      var w = byName("wage_per_day" + i); if (!w) continue;
      var wv = num(w.value), att = num((byName("totAtt" + i) || {}).value), ap = num((byName("APATA" + i) || {}).value), tc = num((byName("TCA" + i) || {}).value);
      if (!(wv > 0)) { p.push("row " + i + ": Wage Per Day is 0"); continue; }
      if (info.minWage && wv > info.minWage) p.push("row " + i + ": Wage Per Day " + wv + " is more than " + info.minWage);
      if (Math.abs(ap - r2(att * wv)) > 0.01) p.push("row " + i + ": amount " + ap + " ≠ " + att + " × " + wv);
      pd += att; amt += tc;
      if (info.amts) info.amts.push({ row: i, att: att, ap: ap });
    }
    info.pd = pd; info.amt = r2(amt);
    return p;
  }

  function process(r, work, msr) {
    var info = inspect(r); info.work = work; info.msr = msr;
    if (info.why) { K.result(r, info, "Skipped", info.why); K.log(r, "warn", work + " · MR " + msr + ": skipped — " + info.why); K.saveRun(r); return; }
    info.amts = [];
    var kept = fill(info, r);
    if (info.rows && info.rows.length > info.workers) { K.log(r, "warn", work + " · MR " + msr + ": the page lists " + info.rows.length + " worker rows but says " + info.workers + " — all " + info.rows.length + " filled and checked"); info.workers = info.rows.length; }
    var problems = check(work, msr, info, r);
    info.detail = "wage " + info.wage + (kept ? " (" + kept + " row(s) kept their own wage)" : "") + "; " + info.pd + " persondays; Rs " + info.amt + "; MB " + info.mb + " page " + info.page;
    if (problems.length && K.canDefer(r)) { K.defer(r, info, "safety check before Save failed: " + problems.slice(0, 4).join("; ")); K.saveRun(r); return; }
    if (problems.length) {
      K.result(r, info, "Error", "safety check before Save failed — NOT saved: " + problems.slice(0, 4).join("; "));
      K.log(r, "err", work + " · MR " + msr + ": safety check before Save failed — NOT saved (" + problems.slice(0, 4).join("; ") + ")");
      r.consec = (r.consec || 0) + 1; K.saveRun(r); return;
    }
    var au = {}; info.amts.forEach(function (a) { au[a.ap] = 1; });
    info.pres = Object.keys(au).map(Number).sort(function (a, b) { return a - b; }).map(function (v) { return "₹" + v; }).join("/") + " · MB " + info.mb + "/" + info.page;
    var tgt = num(r.target);
    if (tgt > 0) {
      var off = info.amts.filter(function (a) { return Math.abs(a.ap - tgt) > 0.01; });
      info.detail += "; amount per worker " + Object.keys(au).join("/") + " (target " + tgt + ")";
      if (off.length && K.canDefer(r)) {
        K.defer(r, info, "NOT saved — " + off.length + " of " + info.amts.length + " worker(s) not at the target amount Rs " + tgt);
        K.saveRun(r); return;
      }
      if (off.length) {
        var why = off.length + " of " + info.amts.length + " worker(s) not at the target amount Rs " + tgt + ": " +
          off.slice(0, 4).map(function (a) { return "row " + a.row + " = Rs " + a.ap + " (" + a.att + " day(s) × " + info.wage + ")"; }).join(", ") + (off.length > 4 ? " …" : "");
        K.result(r, info, r.dryRun ? "Would pause (test)" : "Manual", "NOT saved — " + why + ". Paused for you to fix it by hand.");
        r.active = false; r.current = ""; r.paused = { work: work, msr: msr, page: info.page, pageXl: info.pageXl };
        K.log(r, "err", "PAUSED at " + work + " · MR " + msr + " — " + why + ". It is filled on screen (MB " + info.mb + ", page " + info.page + ") but NOT saved: check it, press the portal's Save, then press ▶ Resume (this MR will not be touched again).");
        K.saveRun(r); K.restoreDialogs();
        return "paused";
      }
    }
    var what = info.workers + " worker(s), " + info.detail + ", " + info.from + "–" + info.to;
    if (r.dryRun) {
      K.result(r, info, "Would save (test)", what);
      K.log(r, "info", work + " · MR " + msr + ": would save (test run) — " + what);
      if (!info.pageXl) bumpPage(r); K.saveRun(r); return;
    }
    return K.pressSave(r, info, what);
  }
  // v1.7.1: one muster roll takes 10 pages of the Measurement Book → +10
  function bumpPage(r) { if (r.pageInc) r.pageNext = String((parseInt(r.pageNext == null ? r.page : r.pageNext, 10) || 0) + 10); }

  K.boot(K.makeLoop({ retryOnce: true, process: process, onSaved: function (r, info, ok) { if (ok && !info.pageXl) bumpPage(r); } }));
})();
