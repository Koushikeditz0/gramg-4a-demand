/* =====================================================================
   pay-panel.js — K-Desk Suite by Koushik · MR Fill · Payment only (UI)   …/vbgramg/msrpayment.aspx
   Excel upload (Work Code → MB Number), Works-এ tick, Page No (default 10, চাইলে প্রতি MR-এ ১ করে বাড়ে)।
   Wage Per Day fixed: page-এর নিজের wage rate (300)। pay-driver.js (MAIN world) প্রতিটা MR ভরে Save করে।
   Excel-এর তথ্য শুধু এই PC-তে (chrome.storage.local "mrfp_mb") থাকে, কোথাও পাঠানো হয় না।
   ===================================================================== */
(function () {
  "use strict";
  if (window.__MRFP_UI) return; window.__MRFP_UI = true;

  var api = null, P = "mrfp_", MB_KEY = "mrfp_mb", mbData = null, iay = null;   // iay: Admin job (IAY Tracker) helper   // { name, at, count, map: { "3208…/IF/IAY/…": "11279" } }
  function g(id) { return api && api.root.getElementById(P + id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function pageWage() { var e = document.getElementsByName("min_wage")[0]; var n = parseFloat(e ? e.value : ""); if (!(n > 0)) { var l = document.getElementById("lblWageRate"); n = parseFloat(l ? l.textContent : ""); } return n > 0 ? n : 300; }
  function key(w) { return String(api.code(w) || "").replace(/\s+/g, "").toUpperCase(); }
  function mbOf(w) { return mbData && mbData.map ? mbData.map[key(w)] || "" : ""; }
  function opts() { var t = g("tgt").value.trim(); return { page: g("pg").value.trim(), pageInc: g("inc").checked, dry: g("dry").checked, target: /^\d+(\.\d+)?$/.test(t) ? +t : 0, badTarget: t && !/^\d+(\.\d+)?$/.test(t) ? t : "" }; }
  function keep() { var q = api.prefs(), o = opts(); q.page = o.page; q.pageInc = o.pageInc; q.target = g("tgt").value; api.savePrefs(q); drawTarget(); api.changed(); }
  // the MR open on screen: what each worker's amount would be at the page rate
  function drawTarget() {
    var el = g("tgtinfo"); if (!el) return;
    var o = opts(), w = pageWage(), boxes = [].filter.call(document.querySelectorAll("input[name^='totAtt']"), function (e) { return /^totAtt\d+$/.test(e.name); });
    if (!o.target) { el.innerHTML = "খালি রাখলে টাকা মেলানো হবে না।" + (o.target === 0 && w ? " (যেমন 15 দিন × " + w + " = " + 15 * w + ")" : ""); return; }
    if (!boxes.length) { el.innerHTML = "প্রতি worker-এর Amount ঠিক <b>₹" + o.target + "</b> না হলে run থেমে যাবে (Save হবে না)।"; return; }
    var am = {}; boxes.forEach(function (e) { am[Math.round(parseFloat(e.value || 0) * w * 100) / 100] = 1; });
    var vals = Object.keys(am).map(Number), ok = vals.length === 1 && Math.abs(vals[0] - o.target) < 0.01;
    el.innerHTML = "এই খোলা MR: " + boxes.length + " জন · " + vals.map(function (v) { return "₹" + v; }).join("/") +
      " <b style='color:" + (ok ? "#166534" : "#c5221f") + "'>" + (ok ? "✓" : "≠ ₹" + o.target + " → এখানে থামবে") + "</b>";
  }

  /* ---------------------- Excel: find the Work Code and MB columns in every sheet ---------------------- */
  function cellStr(v) { var s = String(v == null ? "" : v).trim(); return /^\d+\.0+$/.test(s) ? s.replace(/\.0+$/, "") : s; }
  function readExcel(file) {
    var fr = new FileReader();
    fr.onload = function () {
      try {
        var wb = XLSX.read(new Uint8Array(fr.result), { type: "array" }), map = {}, mrs = {}, nMr = 0, pages = {}, nPg = 0, rows = 0, bad = 0, clash = 0;
        wb.SheetNames.forEach(function (sn) {
          var aoa = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, raw: false, defval: "" });
          var h = -1, cW = -1, cM = -1, cR = -1, cP = -1;
          for (var i = 0; i < Math.min(aoa.length, 15) && h < 0; i++) {
            var row = aoa[i] || [], w = -1, m = -1;
            row.forEach(function (c, j) { var s = String(c).toLowerCase(); if (w < 0 && /work\s*code/.test(s)) w = j; if (m < 0 && /\bmb\b|measurement\s*book/.test(s)) m = j; });
            if (w >= 0 && m >= 0) { h = i; cW = w; cM = m; }
          }
          if (h < 0) return;
          // v1.6.0: optional MR No column (MR No / E-MR No / Muster Roll No / MSR No)
          (aoa[h] || []).forEach(function (c, j) { if (cP < 0 && j !== cW && j !== cM && /^\s*(mb\s*)?page(\s*(no|number|num))?\.?\s*$/i.test(String(c))) cP = j; });
          (aoa[h] || []).forEach(function (c, j) { if (cR < 0 && j !== cW && j !== cM && j !== cP && /(^|[^a-z])(e\s*-?\s*)?(mr|msr|muster\s*roll)\s*(no|number|num)\b/i.test(String(c))) cR = j; });
          for (var r = h + 1; r < aoa.length; r++) {
            var code = cellStr((aoa[r] || [])[cW]).replace(/\s+/g, "").toUpperCase(), mb = cellStr((aoa[r] || [])[cM]);
            if (!code) continue;
            rows++;
            if (!/^[0-9.]+$/.test(mb)) { bad++; continue; }
            if (map[code] && map[code] !== mb) clash++;
            map[code] = mb;
            var mr = cR >= 0 ? cellStr((aoa[r] || [])[cR]) : "";
            if (/^\d+$/.test(mr)) { var L = mrs[code] = mrs[code] || []; if (L.indexOf(mr) < 0) { L.push(mr); nMr++; } }
            var pgv = cP >= 0 ? cellStr((aoa[r] || [])[cP]) : "";
            if (/^\d+$/.test(pgv)) { pages[/^\d+$/.test(mr) ? code + "|" + mr : code] = pgv; nPg++; }
          }
        });
        var n = Object.keys(map).length;
        if (!n) { api.status("Excel-এ \"Work Code\" আর \"MB Number\" column পাওয়া যায়নি।", "warn"); return; }
        mbData = { name: file.name, at: Date.now(), count: n, map: map, mrs: mrs, nMr: nMr, pages: pages, nPg: nPg };
        var o = {}; o[MB_KEY] = mbData;
        chrome.storage.local.set(o, function () {
          api.status(n + "টা work-এর MB No" + (nMr ? ", " + nMr + "টা MR No" : "") + (nPg ? ", " + nPg + "টা Page No" : "") + " নেওয়া হল (" + file.name + ")" + (bad ? ", " + bad + "টা row-এ MB No নেই/ভুল" : "") + (clash ? ", " + clash + "টা work-এর দুটো আলাদা MB No (শেষেরটা নেওয়া হল)" : "") + "।", bad || clash ? "warn" : "ok");
          drawMb(); api.changed();
        });
      } catch (e) { var em = e && e.message ? e.message : String(e); api.status(/context invalidated/i.test(em) ? "Extension update/Reload হয়েছে কিন্তু page পুরনো — page refresh (F5) করে আবার Excel দিন।" : "Excel পড়া গেল না: " + em, "warn"); }
    };
    fr.readAsArrayBuffer(file);
  }
  function drawMb() {
    var el = g("mbinfo"); if (!el) return;
    if (!mbData || !mbData.count) { el.innerHTML = "<span class='bad'>এখনো Excel দেওয়া হয়নি।</span>"; return; }
    var works = api.allWorks(), have = works.filter(function (w) { return !!mbOf(w); }).length;
    el.innerHTML = "<b>" + esc(mbData.name) + "</b>: " + mbData.count + "টা work" + (mbData.nMr ? ", " + mbData.nMr + "টা MR No" : "") + (mbData.nPg ? ", " + mbData.nPg + "টা Page No" : "") + " · page-এ <b>" + have + "</b>টা" +
      (mbData.nPg ? "" : "<br><span style='color:#92400e'>Excel-এ Page No column নেই → নিচের Page No ব্যবহার হবে</span>") +
      (mbData.nMr ? "" : "<br><span style='color:#5b6472'>MR No column নেই → প্রতিটা work-এর সব MR দেখবে</span>");
  }

  window.MRF_PANEL({
    ns: "mrfp", mode: "pay", hostId: "mrfp-host", compact: true, statusTop: true, excelOnly: true,
    pickWorks: function () { return mbData ? api.allWorks().filter(function (w) { return !!mbOf(w); }) : []; },
    // the user saved the paused MR by hand with the page number shown → the next one gets +10
    onResume: function (r, pz) { if (r.pageInc && pz && pz.page != null && !pz.pageXl) { r.pageNext = String((parseInt(pz.page, 10) || 0) + 10); (r.log = r.log || []).push({ t: Date.now(), level: "info", text: "Page No after the hand-saved MR " + pz.msr + ": next is " + r.pageNext + "." }); } },
    statusLine: function (x, esc, tail) {
      var d = x.pres || "", cls, ic, tx;
      if (x.result === "Saved") { cls = "ok"; ic = "✅"; tx = d + " · done"; }
      else if (x.result === "Would save (test)") { cls = "test"; ic = "🧪"; tx = d + " · ঠিক আছে (test)"; }
      else if (x.result === "Manual" || x.result === "Would pause (test)") { cls = "man"; ic = "⏸"; tx = (d || "?") + " — হাতে ঠিক করার জন্য থেমেছিল"; }
      else if (x.result === "Skipped") {
        cls = "skip"; ic = "⏭";
        tx = /period not over/.test(x.msg) ? "MR শেষ হয়নি" : /already/.test(x.msg) ? "আগেই payment হয়েছে" : /MB No/.test(x.msg) ? "Excel-এ MB No নেই" : /Work start date/i.test(x.msg) ? "Work start date খালি" : /no workers/.test(x.msg) ? "worker নেই" : /not in this work's muster roll list/.test(x.msg) ? "এই MR No page-এ নেই" : "skip";
      }
      else { cls = "err"; ic = "❌"; tx = "Save হয়নি — log দেখুন"; }
      return "<div class='sl " + cls + "' title='" + esc(x.msg || x.detail || "") + "'><span class='ic'>" + ic + "</span><span class='wc'>" + esc(tail(x.work)) + "</span>" +
        (x.msr && x.msr !== "—" ? "<span class='mr'>MR " + esc(x.msr) + "</span>" : "") + "<span class='tx'>" + esc(tx) + "</span></div>";
    }, title: "Payment only", sub: "Muster Roll Payment",
    ifOnlyDefault: false, logName: "MRFill-Payment", sheetName: "Payment log",
    idleHtml: "<b>Excel</b> দিন (Work Code, MB NO, Page No, MR no), তারপর Start। Wage Per Day = page-এর rate (" + pageWage() + "), fixed।",
    confirmHead: "এটা portal-এ Muster Roll payment Save করবে (পরে delete হয় না)",
    disclaimer: "⚠ Automatic entry-তে ভুল হতে পারে। Portal বলে: Muster Roll একবার entry হলে delete করা যায় না। প্রথমে Test run, তারপর একটা work দিয়ে চালিয়ে portal-এ মিলিয়ে নিন। ব্যবহারের দায়িত্ব আপনার।",
    style: ".panel{width:340px}.bd{padding:7px 9px}.hd{padding:7px 10px}.logo{width:24px;height:24px}.ttl b{font-size:13px}" +
      ".summary{padding:5px 8px;font-size:11.5px;line-height:1.35}.row{margin-top:5px;gap:5px}.lbl2{font-weight:700;color:#3730a3;font-size:11.5px}" +
      ".inp{padding:4px 6px}.inp.num{width:42px;text-align:center}.sec0{margin:6px 0 3px}.list{max-height:130px}" +
      ".note{margin-top:3px;font-size:10.5px}.btnrow{margin-top:5px;gap:5px}.btn{min-height:30px;padding:5px 8px;font-size:12px}.btn.sm{min-height:24px;padding:3px 6px;font-size:10.5px;border-radius:7px}" +
      ".statbox{max-height:170px;margin-top:6px}.sec{margin:6px 0 4px;padding-top:5px}.logbox{max-height:90px}.prog{margin:5px 0}.st{margin-top:5px;padding:4px 7px}.st:empty{display:none}.disclaimer{margin-top:6px;font-size:9px;padding:4px 6px}.foot{margin-top:5px;padding-top:4px}" +
      ".tag{margin-left:auto;font:600 10.5px 'Segoe UI',Arial;color:#166534}.tag.no{color:#be123c}.bad{color:#be123c}" +
      ".up{display:inline-block;padding:6px 10px;border-radius:9px;border:1.5px dashed #a5acec;background:#f5f6ff;color:#3730a3;font-weight:600;font-size:12px;cursor:pointer}.up input{display:none}",
    onRender: function (r) { if (iay) iay.sync(r); },
    tagKey: function () { return mbData ? mbData.at : 0; },
    workTag: function (w) { if (!mbData) return ""; var m = mbOf(w); return m ? "<span class='tag'>MB " + esc(m) + "</span>" : "<span class='tag no'>MB নেই</span>"; },
    setupHtml:
      "<div class='sec0'><span>MB No (Excel)</span></div>" +
      "<div class='row' style='margin-top:0'><label class='up'>⭱ Excel upload<input type='file' id='mrfp_file' accept='.xlsx,.xls,.csv'></label><button class='btn ghost sm' id='mrfp_iay' title='Admin panel-এর IAY Tracker থেকে পাঠানো MR Payment job (Work Code, MR No, MB No, Page No)'>📥 Admin job</button></div>" +
      "<div class='note' id='mrfp_mbinfo'></div>" +
      "<div class='sec0'><span>Payment details</span></div>" +
      "<div class='row' style='margin-top:0'><span class='lbl2' title='Excel-এ Page No না থাকলে এটা ব্যবহার হবে'>Page No</span><input class='inp num' id='mrfp_pg' inputmode='numeric'>" +
        "<span class='lbl2'>লক্ষ্য ₹</span><input class='inp num' id='mrfp_tgt' inputmode='decimal' placeholder='4500' style='width:62px' title='প্রতি worker-এর Amount Due — না মিললে Pause। খালি = মেলানো হবে না'></div>" +
      "<div class='note' id='mrfp_tgtinfo'></div>" +
      "<div class='row'><label class='chk'><input type='checkbox' id='mrfp_inc'>Excel-এ Page No না থাকলে: প্রতি Save-এর পর +10</label></div>" +
      "<div class='note'>Wage Per Day: page-এর rate, শুধু যেখানে 0 বা খালি। Attendance আর Work start date বদলায় না।</div>",
    validate: function () {
      var o = opts();
      if (!mbData || !mbData.count) return "আগে MB No-র Excel upload করুন।";
      if (!/^\d+$/.test(o.page) && !(mbData.nPg >= mbData.count)) return "Excel-এ সব work-এর Page No নেই — panel-এ Page No লিখুন (শুধু সংখ্যা)।";
      if (o.badTarget) return "লক্ষ্য ₹-এ শুধু সংখ্যা লিখুন (যেমন 4500), অথবা খালি রাখুন।";
      return "";
    },
    confirmHtml: function (w) {
      var o = opts(), miss = w.filter(function (x) { return !mbOf(x); }).length;
      return (o.dry ? "<b>Test run</b>: ভরবে কিন্তু <b>Save চাপবে না</b>।<br>" : "") +
        "<b>" + (w.length - miss) + "টা work</b>-এর প্রতিটা MR-এ MB No <b>Excel থেকে</b>, Wage Per Day <b>" + pageWage() + "</b>, " +
        (mbData.nPg ? "Page No <b>Excel থেকে</b>" + (/^\d+$/.test(o.page) ? " (Excel-এ না থাকলে " + o.page + (o.pageInc ? ", +10 করে" : "") + ")" : "") : "Page No <b>" + o.page + (o.pageInc ? " থেকে শুরু, প্রতি MR-এ +10" : " (সব MR-এ একই)") + "</b>") + ", তারপর <b>Save</b>।" +
        (miss ? "<br><b>" + miss + "টা work-এর MB No Excel-এ নেই</b>, সেগুলো skip হবে।" : "") +
        (function () { var k = w.filter(function (x) { return mbData && mbData.mrs && mbData.mrs[key(x)]; }).length; return k ? "<br><b>" + k + "টা work</b>-এ শুধু Excel-এর MR No চলবে" + (k < w.length ? ", বাকিগুলোর সব MR দেখবে" : "") + "।" : ""; })() +
        (o.target ? "<br>প্রতিটা worker-এর Amount ঠিক <b>₹" + o.target + "</b> না হলে সেই MR Save হবে না, run <b>Pause</b> হবে। হাতে ঠিক করে Save করে Resume চাপবেন।" : "") +
        " যে MR-এর শেষ দিন এখনো আসেনি বা Work start date নেই, সেগুলো কারণসহ skip হবে।" +
        (o.dry ? "" : "<br><b>Save করা MR delete করা যায় না, তাই আগে Test run দিয়ে দেখে নিন।</b>");
    },
    makeRun: function (w) {
      var o = opts(), m = {}, pre = [];
      var mrMap = {};
      w.forEach(function (x) { var v = mbOf(x); if (v) m[key(x)] = v; else pre.push({ work: x, why: "MB No for this work is not in the uploaded Excel" }); var L = mbData.mrs && mbData.mrs[key(x)]; if (v && L && L.length) mrMap[x] = L.slice(); });
      return { mbMap: m, mrMap: mrMap, pageMap: mbData.pages || {}, target: o.target, mbFile: mbData.name, page: o.page, pageNext: o.page, pageInc: o.pageInc, dryRun: o.dry, preSkip: pre };
    },
    modeText: function (r) {
      return "MB" + (r.pageMap && Object.keys(r.pageMap).length ? " + page" : "") + " from " + (r.mbFile || "Excel") + " · page " + (r.pageInc ? (r.pageNext || r.page) + " (+10 each)" : r.page) + (r.target ? " · target ₹" + r.target : "");
    },
    onBuilt: function (a) {
      api = a;
      var p = a.prefs();
      g("pg").value = p.page || "10";
      if (p.pageInc) g("inc").checked = true;
      if (p.target) g("tgt").value = p.target;
      g("tgt").addEventListener("input", keep);
      drawTarget();
      g("pg").addEventListener("input", keep);
      g("inc").addEventListener("change", keep);
      g("file").addEventListener("change", function () { var f = g("file").files[0]; if (f) { if (iay) iay.clear(); readExcel(f); } g("file").value = ""; });
      if (window.MRF_IAY) { iay = window.MRF_IAY({ ns: "mrfp", kind: "pay", api: a, readExcel: readExcel }); g("iay").addEventListener("click", iay.open); }
      else g("iay").hidden = true;
      try { chrome.storage.local.get(MB_KEY, function (d) { mbData = (d && d[MB_KEY]) || null; drawMb(); api.changed(); }); } catch (e) { drawMb(); }
    }
  });
})();
