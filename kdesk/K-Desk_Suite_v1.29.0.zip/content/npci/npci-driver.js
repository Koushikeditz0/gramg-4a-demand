/* =====================================================================
   K-Desk Suite by Koushik — npci-driver.js  —  "Enable ABPS for workers (LIVE check with NPCI)" bulk run (ENGINE)

   Page: …/vbgramg/UID/VUID_NPCI.aspx. For every worker row:
     *Show Aadhaar Number  →  Check with NPCI  →  green = enabled at NPCI
   then "Save Records of this page" when the page has at least one green row,
   then the next page, then the next village (from the village that was open
   when the run started).

   Runs in the PAGE (MAIN) world at document_start so it can hook the page's
   MS-AJAX PageRequestManager (Show / Check / pager are async UpdatePanel
   postbacks) and resume after the FULL reloads caused by Save and by a
   village change. State: portal-origin localStorage "khnp_run", shared with
   the panel (npci-panel.js).

   PRIVACY: the Aadhaar number revealed by "Show" is never read, stored or
   logged. Only the job card, applicant no., names, the portal's message and
   the result are recorded.
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KHNP_DRV) return;
  window.__KHNP_DRV = true;

  var LS_RUN = "khnp_run", LS_ALERT = "khnp_lastAlert";
  // portal-এর ID এখন shared/portal-map.js (page "npci") থেকে; map না থাকলে আগের মান
  var KM = window.KD_MAP, MID = function (k, d) { return KM ? KM.id("npci", k, d) : d; };
  var SUF = function (k, d) { return KM ? KM.suffix("npci", k, d) : d; };
  var PFX = KM ? KM.prefixId("ctl00_ContentPlaceHolder1_") : "ctl00_ContentPlaceHolder1_";
  var UPFX = KM ? KM.prefixName("ctl00$ContentPlaceHolder1$") : "ctl00$ContentPlaceHolder1$";
  var GRID = MID("grid", "gvData");
  var IDS = { village: PFX + MID("village", "DDL_Village"), grid: PFX + GRID, save: PFX + MID("save", "btnProceed2") };
  var UNAME = { village: UPFX + MID("village", "DDL_Village"), grid: UPFX + GRID };
  // row-এর field (suffix-এর শুরুর "_" বাদ দিয়ে, কারণ নিচে pre-এর শেষেই "_" আছে)
  var RS = function (k, d) { return SUF(k, "_" + d).replace(/^_/, ""); };
  var R = { jc: RS("jc", "lbl_jobcardno"), reg: RS("reg", "Reg_No"), app: RS("app", "applicant_no"), name: RS("name", "applicant_name"),
            aname: RS("aname", "txtName_as_per_Aadhar"), show: RS("show", "btn_showuid"), verify: RS("verify", "btn_verifyuid"), msg: RS("msg", "lbl_msg") };
  function reEsc(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
  var ROW_RE = new RegExp(reEsc(GRID) + "_(ctl\\d+)_" + reEsc(R.jc) + "$");
  var PACE = 400;                 // pause between steps
  var BRAKE = 6;                  // stop after this many rows in a row get no answer from the portal
  var SAVE_WAIT = 120000;         // a Save is a full postback; this is only for the alert-capture side

  /* ---------------------- time (the portal breaks Date in the MAIN world) ---------------------- */
  function nowMs() { try { return Math.round((performance.timeOrigin || 0) + performance.now()); } catch (e) { return 0; } }
  var DEBUG = (function () { try { return localStorage.getItem("khnp_debug") === "1"; } catch (e) { return false; } })();
  function dbg() { if (!DEBUG) return; try { console.log.apply(console, ["%c[KH-NPCI/drv]", "color:#137333;font-weight:bold"].concat([].slice.call(arguments))); } catch (e) {} }
  function sleep(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }

  /* ---------------------- adaptive timeout (same scheme as abps.js) ---------------------- */
  var T_FLOOR = 25000, T_CEIL = 180000, T_MULT = 4, rtts = [];
  function noteRtt(ms) { rtts.push(ms); if (rtts.length > 12) rtts.shift(); }
  function typical() { if (!rtts.length) return 8000; var a = rtts.slice().sort(function (x, y) { return x - y; }); return a[Math.min(a.length - 1, Math.floor(a.length * 0.75))]; }
  function timeoutFor() { return Math.min(T_CEIL, Math.max(T_FLOOR, typical() * T_MULT)); }

  /* ---------------------- dialogs: captured, never blocking ---------------------- */
  var origAlert = window.alert, origConfirm = window.confirm, overridden = false;
  function overrideDialogs() {
    if (overridden) return; overridden = true;
    window.alert = function (m) { try { localStorage.setItem(LS_ALERT, JSON.stringify({ t: nowMs(), msg: String(m == null ? "" : m) })); } catch (e) {} };
    window.confirm = function () { return true; };
  }
  function restoreDialogs() { if (!overridden) return; overridden = false; window.alert = origAlert; window.confirm = origConfirm; }
  function takeAlert() { try { var a = JSON.parse(localStorage.getItem(LS_ALERT) || "null"); localStorage.removeItem(LS_ALERT); return a ? a.msg : ""; } catch (e) { return ""; } }

  /* ---------------------- run state ---------------------- */
  function loadRun() { try { return JSON.parse(localStorage.getItem(LS_RUN) || "null"); } catch (e) { return null; } }
  function saveRun(r) { try { r.updatedAt = nowMs(); localStorage.setItem(LS_RUN, JSON.stringify(r)); } catch (e) {} notifyUI(); }
  function notifyUI() { try { window.postMessage({ source: "KHNP_DRV", type: "sync" }, "*"); } catch (e) {} }
  function log(r, level, text) { (r.log = r.log || []).push({ t: nowMs(), level: level, text: text }); if (r.log.length > 3000) r.log = r.log.slice(-3000); }
  function result(r, row, res, msg) {
    (r.results = r.results || []).push({ t: nowMs(), key: row.key, village: row.village, job: row.job, app: row.app, name: row.name, nameAadhaar: row.nameAadhaar, page: row.page, result: res, msg: msg || "" });
    var s = r.stats = r.stats || { checked: 0, saved: 0, failed: 0, errors: 0 };
    if (res === "Saved") s.saved++; else if (res === "Error" || res === "Save failed") s.errors++; else s.failed++;
  }
  function stopping() { var r = loadRun(); return !r || r.stopRequested || !r.active; }
  function stopSignal() { var e = new Error("stopped by user"); e.__stop = true; return e; }

  /* ---------------------- page helpers ---------------------- */
  function $(id) { return document.getElementById(id); }
  function prmReady() { return !!(window.Sys && Sys.WebForms && Sys.WebForms.PageRequestManager && Sys.WebForms.PageRequestManager.getInstance); }
  function prm() { return Sys.WebForms.PageRequestManager.getInstance(); }
  function loggedOut() { return !$(IDS.village) && !$(IDS.grid); }
  function waitFor(cond, timeout, interval) {
    interval = interval || 150;
    return new Promise(function (res, reject) {
      var t0 = nowMs();
      (function tick() {
        if (stopping()) return reject(stopSignal());
        var v; try { v = cond(); } catch (e) { v = false; }
        if (v) return res(v);
        if (nowMs() - t0 > timeout) return res(false);
        setTimeout(tick, interval);
      })();
    });
  }
  // one async UpdatePanel postback started by triggerFn()
  function awaitAsync(triggerFn, timeoutMs) {
    return new Promise(function (resolve, reject) {
      if (!prmReady()) { try { triggerFn(); } catch (e) {} return resolve({ error: "page scripts not ready" }); }
      var p = prm(), done = false, to, sp, t0 = nowMs();
      function cleanup() { try { p.remove_endRequest(end); } catch (e) {} clearTimeout(to); clearInterval(sp); }
      function end(sender, args) {
        if (done) return; done = true; cleanup(); noteRtt(nowMs() - t0);
        var err = null; try { err = args && args.get_error && args.get_error(); } catch (e) {}
        if (err) { try { args.set_errorHandled(true); } catch (e) {} return resolve({ error: err.message || String(err) }); }
        resolve({ ok: true });
      }
      try { p.add_endRequest(end); } catch (e) { return resolve({ error: "cannot hook postback" }); }
      to = setTimeout(function () { if (done) return; done = true; cleanup(); resolve({ timeout: true }); }, timeoutMs);
      sp = setInterval(function () { if (done) return; if (stopping()) { done = true; cleanup(); reject(stopSignal()); } }, 250);
      try { triggerFn(); } catch (e) { if (!done) { done = true; cleanup(); resolve({ error: String(e) }); } }
    });
  }
  function villageText(v) { var s = $(IDS.village); if (!s) return v; for (var i = 0; i < s.options.length; i++) if (s.options[i].value === v) return s.options[i].text; return v; }

  // rows on the current grid page (data rows only — the pager row has no job-card label)
  function readRows() {
    var g = $(IDS.grid); if (!g) return [];
    var out = [], q = g.querySelectorAll("span[id$='_" + R.jc + "']");
    for (var i = 0; i < q.length; i++) {
      var m = q[i].id.match(ROW_RE); if (!m) continue;
      var pre = PFX + GRID + "_" + m[1] + "_", el = function (id) { return $(pre + id); };
      var reg = (el(R.reg) && el(R.reg).value) || q[i].textContent.trim();
      var app = (el(R.app) && el(R.app).value) || (el("lbl_" + R.app) && el("lbl_" + R.app).textContent.trim()) || "";
      out.push({
        pre: pre, key: reg + "|" + app, job: q[i].textContent.trim(), app: app,
        name: (el(R.name) && el(R.name).textContent.trim()) || "",
        nameAadhaar: (el(R.aname) && el(R.aname).textContent.trim()) || ""
      });
    }
    return out;
  }
  // green row = enabled at NPCI; LightSalmon = failed. Judged from the row's own background colour.
  function rowVerdict(row) {
    var lbl = $(row.pre + R.msg), tr = lbl && lbl.closest("tr"), msg = lbl ? lbl.innerText.trim() : "";
    var bg = "", ok = false, bad = false;
    if (tr) {
      bg = (tr.getAttribute("style") || "") + ";" + getComputedStyle(tr).backgroundColor;
      var m = getComputedStyle(tr).backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);
      if (m && (m[4] === undefined || +m[4] > 0)) {
        var R = +m[1], G = +m[2], B = +m[3];
        ok = G > R + 25 && G > B + 10;                 // any green tint
        bad = R > G + 25;                              // salmon / red tint
      }
    }
    if (!ok && /fail|not\s+linked|not\s+seeded|invalid|mismatch|error|not\s+enabled/i.test(msg)) bad = true;
    return { ok: ok && !bad, bad: bad, answered: ok || bad || !!msg, msg: msg, bg: bg };
  }
  function currentPage() {
    var g = $(IDS.grid); if (!g) return 1;
    var last = g.rows[g.rows.length - 1];
    if (!last || !last.querySelector("a[href*='Page$']")) return 1;
    var sp = last.querySelectorAll("span"); for (var i = 0; i < sp.length; i++) { var n = parseInt(sp[i].textContent, 10); if (n) return n; }
    return 1;
  }
  function pagerLink(n) {
    var g = $(IDS.grid); if (!g) return null;
    var a = g.querySelectorAll("a[href*='Page$']"), best = null;
    for (var i = 0; i < a.length; i++) {
      var m = (a[i].getAttribute("href") || "").match(/Page\$(\d+)/); if (!m) continue;
      var k = +m[1]; if (k === n) return a[i];
      if (k > n && (!best || k < best.k)) best = { k: k, a: a[i] };     // "..." links jump ahead
    }
    return best && best.k === n ? best.a : null;
  }
  function firstPageLink(cur) {
    var g = $(IDS.grid); if (!g || cur <= 1) return null;
    var a = g.querySelectorAll("a[href*='Page$']"), best = null;
    for (var i = 0; i < a.length; i++) {
      var m = (a[i].getAttribute("href") || "").match(/Page\$(\d+)/); if (!m) continue;
      var k = +m[1]; if (k < cur && (!best || k < best.k)) best = { k: k, a: a[i] };
    }
    return best ? best.a : null;
  }
  // Fire the dropdown's own onchange (non-strict page code). Calling __doPostBack from here throws:
  // MS-AJAX's PageRequestManager reads arguments.callee.caller, which strict-mode callers forbid.
  // The change may be an async UpdatePanel postback or a full reload — wait for either.
  async function selectVillage(v) {
    var s = $(IDS.village); if (!s) return { error: "village list not found" };
    var res = await awaitAsync(function () { s.value = v; s.dispatchEvent(new Event("change", { bubbles: true })); }, timeoutFor());
    if (res.ok) await waitFor(function () { return !(prmReady() && prm().get_isInAsyncPostBack()); }, 10000);
    return res;                                        // a full reload simply never gets here
  }

  /* ---------------------- one row: Show → Check ---------------------- */
  async function doRow(r, row) {
    var show = $(row.pre + R.show), check = $(row.pre + R.verify);
    if (!show || !check) return { error: "row controls not found" };
    takeAlert();
    if (check.disabled) {
      var a = await awaitAsync(function () { $(row.pre + R.show).click(); }, timeoutFor());
      if (a.timeout) return { timeout: true, msg: "No answer from the portal after Show Aadhaar (" + Math.round(timeoutFor() / 1000) + "s)" };
      if (a.error) return { error: "Show Aadhaar: " + a.error };
      var c2 = await waitFor(function () { var c = $(row.pre + R.verify); return c && !c.disabled; }, 4000);
      // Show always enables "Check with NPCI" when the portal answers. If it didn't and the portal said
      // nothing, the request was lost (network / session) — an Error to retry, not a final answer.
      if (!c2) {
        var al = takeAlert(), lm = $(row.pre + R.msg), said = (lm && lm.innerText.trim()) || al;
        return said ? { failed: true, msg: "Aadhaar could not be shown: " + said } : { error: "No answer from the portal after Show Aadhaar (connection?)" };
      }
      await sleep(PACE);
    }
    var b = await awaitAsync(function () { $(row.pre + R.verify).click(); }, timeoutFor());
    if (b.timeout) return { timeout: true, msg: "No answer from NPCI check (" + Math.round(timeoutFor() / 1000) + "s)" };
    if (b.error) return { error: "Check with NPCI: " + b.error };
    await waitFor(function () { return rowVerdict(row).answered; }, 3000);
    var v = rowVerdict(row), al2 = takeAlert();
    if (v.ok) return { ok: true, msg: v.msg || "Verified at NPCI" };
    return { failed: true, msg: v.msg || al2 || "Not verified at NPCI (row did not turn green)" };
  }

  /* ---------------------- after a Save reload ---------------------- */
  function resolveSave(r) {
    var s = r.saving; r.saving = null;
    var alertMsg = takeAlert();
    var still = {}; readRows().forEach(function (x) { still[x.key] = 1; });
    var okErr = /error|fail|not\s+saved|unable|invalid/i.test(alertMsg);
    (s.rows || []).forEach(function (row) {
      if (okErr) result(r, row, "Save failed", alertMsg);
      else result(r, row, "Saved", alertMsg || (still[row.key] ? "Saved (row still listed — please verify)" : "Saved"));
    });
    log(r, okErr ? "err" : "ok", "Village " + s.villageText + " page " + s.page + ": Save — " + (alertMsg || "done") + " (" + (s.rows || []).length + " enabled)");
    saveRun(r);
  }

  /* ---------------------- main loop ---------------------- */
  async function runLoop() {
    var r = loadRun(); if (!r || !r.active) { restoreDialogs(); return; }
    overrideDialogs();
    try { await waitFor(function () { return document.readyState !== "loading" && prmReady() && ($(IDS.village) || loggedOut()); }, 30000); } catch (e) {}
    r = loadRun(); if (!r || !r.active) { restoreDialogs(); return; }
    if (r.saving) { resolveSave(r); r = loadRun(); }
    // Green rows checked before a reload lose their green state on the new page, and Save only takes
    // the rows verified on the page being saved — so check them again.
    else if (r.pendingOk && r.pendingOk.length) {
      r.pendingOk.forEach(function (x) { if (r.done) delete r.done[x.key]; if (r.stats && r.stats.checked) r.stats.checked--; });
      log(r, "info", "Re-checking " + r.pendingOk.length + " green row(s) from before the page reloaded, so they are saved correctly.");
      r.pendingOk = []; saveRun(r);
    }

    while (true) {
      r = loadRun(); if (!r) { restoreDialogs(); return; }
      if (r.stopRequested || !r.active) { if (r.active || r.stopRequested) { r.active = false; r.stopRequested = false; log(r, "warn", "Stopped by user."); saveRun(r); } restoreDialogs(); return; }
      if (loggedOut()) { r.active = false; log(r, "err", "The portal page closed or the session expired — log in again and press Resume."); saveRun(r); restoreDialogs(); return; }

      var target = (r.villages || [])[r.vi];
      if (!target) { r.active = false; r.finishedAt = nowMs(); log(r, "ok", "Finished all villages."); saveRun(r); restoreDialogs(); return; }

      // 1. right village?
      if (String($(IDS.village).value) !== target.value) {
        log(r, "info", "Opening village " + target.text + " (" + (r.vi + 1) + "/" + r.villages.length + ")…");
        r.page = 1; r.toFirstPage = true; saveRun(r);
        var sv0 = await selectVillage(target.value);
        if (sv0.ok) { await sleep(PACE); continue; }              // async update: carry on in this page
        r = loadRun(); r.active = false; log(r, "err", "Could not open village " + target.text + ": " + (sv0.error || "no answer from the portal") + ". Press Resume to try again."); saveRun(r); restoreDialogs(); return;
      }

      // 2. rows on this page — but a village always starts from page 1: the portal keeps the grid's
      //    page index when the village changes, so village 2 could otherwise open on page 4.
      var pg = currentPage();
      if (r.toFirstPage) {
        var fp = pg > 1 ? firstPageLink(pg) : null;
        if (fp) {
          var fres = await awaitAsync(function () { fp.click(); }, timeoutFor());
          if (fres.timeout || fres.error) { r = loadRun(); r.active = false; log(r, "err", "Could not go back to page 1: " + (fres.error || "no answer") + ". Press Resume."); saveRun(r); restoreDialogs(); return; }
          await sleep(PACE); continue;
        }
        r = loadRun(); r.toFirstPage = false; saveRun(r);
      }
      var rows = readRows(), done = r.done || (r.done = {});
      r.page = pg;
      var todo = rows.filter(function (x) { return !done[x.key]; });
      if (todo.length) {
        var row = todo[0];
        row.village = target.text; row.page = pg;
        r.current = row.job + " #" + row.app; saveRun(r);
        var res;
        try { res = await doRow(r, row); } catch (e) { if (e && e.__stop) continue; res = { error: String(e && e.message || e) }; }
        r = loadRun(); if (!r) return;
        var info = { village: row.village, job: row.job, app: row.app, name: row.name, nameAadhaar: row.nameAadhaar, page: pg, key: row.key };
        r.done = r.done || {}; r.done[row.key] = 1;
        r.stats = r.stats || { checked: 0, saved: 0, failed: 0, errors: 0 }; r.stats.checked++;
        if (res.ok) {
          (r.pendingOk = r.pendingOk || []).push(info);
          r.consec = 0; log(r, "ok", row.job + " #" + row.app + " " + row.name + ": verified at NPCI (green) — will be saved with this page");
        } else if (res.failed) {
          r.consec = 0; result(r, info, "Not enabled", res.msg); log(r, "warn", row.job + " #" + row.app + " " + row.name + ": " + res.msg);
        } else {
          r.consec = (r.consec || 0) + 1; result(r, info, "Error", res.msg || res.error); log(r, "err", row.job + " #" + row.app + " " + row.name + ": " + (res.msg || res.error));
          if (r.consec >= BRAKE) { r.active = false; log(r, "err", "Stopped: the portal did not answer " + BRAKE + " rows in a row. Check the connection, then Resume."); saveRun(r); restoreDialogs(); return; }
        }
        saveRun(r);                                   // keep r.current until the next row: no blinking line
        await sleep(PACE);
        continue;
      }

      // 3. page finished: Save if anything turned green
      var okHere = (r.pendingOk || []).filter(function (x) { return x.village === target.text; });
      if (okHere.length) {
        if (r.dryRun) {
          okHere.forEach(function (x) { result(r, x, "Verified (dry run, not saved)", "Dry run — Save not pressed"); });
          r.pendingOk = []; log(r, "warn", "Dry run: " + okHere.length + " green row(s) on page " + pg + " NOT saved."); saveRun(r);
        } else {
          r.pendingOk = (r.pendingOk || []).filter(function (x) { return x.village !== target.text; });
          r.saving = { rows: okHere, page: pg, villageText: target.text };
          log(r, "info", "Saving page " + pg + " of " + target.text + " (" + okHere.length + " green row(s))…");
          saveRun(r);
          takeAlert();
          var sv = $(IDS.save);
          if (!sv) { r.saving = null; okHere.forEach(function (x) { result(r, x, "Save failed", "Save button not found"); }); saveRun(r); continue; }
          try { sv.click(); } catch (e) {}
          // Save validates (group "Demand") before posting; if the page's own validation blocks it, say so now
          await sleep(1500);
          if (window.Page_IsValid === false) {
            r = loadRun(); var sv2 = r.saving; r.saving = null;
            var why = [].map.call(document.querySelectorAll("span[id*='RFV'],span[id*='Validator']"), function (x) { return x.style.display !== "none" && x.style.visibility !== "hidden" ? x.textContent.trim() : ""; }).filter(Boolean).join(" ");
            sv2.rows.forEach(function (x) { result(r, x, "Save failed", "Blocked by the page's validation" + (why ? ": " + why : "")); });
            r.active = false; log(r, "err", "The portal's own form check blocked Save" + (why ? " (" + why + ")" : "") + ". Run stopped — please check the page."); saveRun(r); restoreDialogs(); return;
          }
          // full postback: the next page load resolves r.saving. If the page doesn't navigate, report it.
          await sleep(SAVE_WAIT);
          r = loadRun();
          if (r && r.saving) { var al = takeAlert(); var s = r.saving; r.saving = null; s.rows.forEach(function (x) { result(r, x, "Save failed", al || "The page did not save (no reload)"); }); log(r, "err", "Save did not complete on page " + pg + (al ? ": " + al : "") + "."); saveRun(r); }
          continue;
        }
      }

      // 4. next page, else next village
      var nx = pagerLink(pg + 1);
      if (nx) {
        log(r, "info", target.text + ": page " + (pg + 1) + "…"); saveRun(r);
        var pres = await awaitAsync(function () { nx.click(); }, timeoutFor());
        if (pres.timeout || pres.error) { r = loadRun(); r.consec = (r.consec || 0) + 1; log(r, "err", "Could not open page " + (pg + 1) + ": " + (pres.error || "no answer")); saveRun(r);
          if (r.consec >= BRAKE) { r.active = false; saveRun(r); restoreDialogs(); return; } }
        await sleep(PACE);
        continue;
      }
      r = loadRun();
      log(r, "ok", target.text + ": done (" + rows.length + " row(s) on the last page).");
      r.vi++; r.page = 1; saveRun(r);
      var nextV = r.villages[r.vi];
      if (!nextV) continue;                                       // → "Finished" on the next turn
      continue;                                                   // step 1 opens the next village
    }
  }

  var busy = false;
  function kick() {
    if (busy) return;
    var r = loadRun(); if (!r || !r.active) return;
    busy = true;
    Promise.resolve().then(runLoop).then(function () { busy = false; }, function (e) { busy = false; dbg("loop error", e); });
  }

  /* ---------------------- boot ---------------------- */
  (function boot() {
    var r = loadRun();
    if (r && r.active) overrideDialogs();
    dbg("engine loaded on", location.pathname, r && r.active ? "· run ACTIVE, resuming" : "· idle");
    window.addEventListener("message", function (ev) {
      if (!ev.data || ev.data.source !== "KHNP_UI") return;
      if (ev.data.type === "start") { overrideDialogs(); kick(); }
      else if (ev.data.type === "stop") { var rr = loadRun(); if (rr) { rr.stopRequested = true; saveRun(rr); } }
    });
    setInterval(function () { var rr = loadRun(); if (rr && rr.active && !rr.stopRequested) kick(); }, 1000);
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", kick); else kick();
  })();
})();
