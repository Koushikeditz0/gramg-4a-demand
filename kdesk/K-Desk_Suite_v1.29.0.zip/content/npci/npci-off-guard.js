/* npci-off-guard.js — K-Desk Suite by Koushik
   Dashboard-এ "ABPS Enable (NPCI)" Off থাকলে বা PC activated না থাকলে চলমান run থামিয়ে দেয়,
   যাতে MAIN-world driver নিজে থেকে resume না করে। */
(function () {
  "use strict";
  function stopRun() {
    try {
      var run = JSON.parse(localStorage.getItem("khnp_run") || "null");
      if (run && run.active) { run.active = false; run.stopRequested = false; run.updatedAt = Date.now(); localStorage.setItem("khnp_run", JSON.stringify(run)); }
    } catch (e) {}
  }
  try {
    window.KH_LICENSE.check(function (ok) {
      if (!ok) return stopRun();                                // NPCI-র Dashboard toggle নেই (v1.7.1), তাই শুধু license দেখে
      chrome.storage.local.get("kh_off", function (r) { if (r && r.kh_off) stopRun(); });   // K-Desk OFF
    });
  } catch (e) { stopRun(); }
})();
