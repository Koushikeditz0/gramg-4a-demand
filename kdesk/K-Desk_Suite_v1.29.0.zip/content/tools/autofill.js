/* autofill.js — K-Desk Suite by Koushik · Field Autofill
   Portal-এর যেকোনো field বেছে একটা default value রাখলে পরের বার ওই page খুললে নিজে ভরে যায়
   (যেমন Block, Panchayat, পদবি, মোবাইল নম্বর)। Dashboard → "🎯 Field বাছুন" চাপুন, তারপর page-এ
   field-এ click করুন। Default শুধু এই PC-র extension storage-এ থাকে (kdAutofillRules), কোথাও যায় না।

   Isolated world-এ চলে: native value-setter একই DOM node-এ কাজ করে, তাই portal-এর নিজের onchange চলে।
   Loop থেকে বাঁচার নিয়ম: field-এ আগেই সেই value থাকলে কখনো লেখে না (অনেক dropdown-এ onchange =
   __doPostBack; বারবার লিখলে postback → reload → আবার লেখা, অনন্তকাল)। প্রথম বারের পরে শুধু ফাঁকা
   field ভরে, আপনার টাইপ করা জিনিস বদলায় না। Dashboard toggle: "autofill" (না থাকলে On)। */
KH_FEATURE("autofill", function () {
(function () {
  "use strict";
  if (window.__KDAF) return; window.__KDAF = true;

  var RULES_KEY = "kdAutofillRules";      // chrome.storage.local (শুধু এই PC)
  var HOST_ID = "kdaf-host";
  var TOP = (function () { try { return window.top === window; } catch (e) { return true; } })();

  var rules = [];            // rules for THIS page only
  var enabled = true;
  var firstPassDone = false; // first pass overrides; later passes only fill empties

  /* ---------------------- small helpers ---------------------- */
  // নিয়ম page-এর path ধরে রাখা (portal-এর সব server-এ একই page একই নিয়ম পায়)
  function pageKey() { return String(location.pathname || "").toLowerCase(); }
  // escapes ' too: the markup below uses single-quoted attributes, and option
  // values/labels come from the portal page
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]; }); }
  function cssEsc(s) {
    try { if (window.CSS && CSS.escape) return CSS.escape(s); } catch (e) {}
    return String(s).replace(/([^\w-])/g, "\\$1");
  }
  function ver() { try { return chrome.runtime.getManifest().version; } catch (e) { return ""; } }

  // same contract as the drivers' setNative: native setter + input/change
  function setNative(el, val) {
    if (!el) return false;
    try {
      var proto = el.tagName === "SELECT" ? HTMLSelectElement.prototype
        : el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, val);
    } catch (e) { try { el.value = val; } catch (e2) { return false; } }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  var FILLABLE = ["text", "number", "tel", "email", "url", "search", "date", "password", "checkbox", "radio"];
  function isFillable(el) {
    if (!el || el.nodeType !== 1) return false;
    var tag = (el.tagName || "").toLowerCase();
    if (tag === "select" || tag === "textarea") return true;
    if (tag !== "input") return false;
    return FILLABLE.indexOf(String(el.type || "text").toLowerCase()) !== -1;
  }
  function kindOf(el) {
    var tag = (el.tagName || "").toLowerCase();
    if (tag === "select") return "select";
    if (tag === "textarea") return "textarea";
    var t = String(el.type || "text").toLowerCase();
    if (t === "checkbox") return "checkbox";
    if (t === "radio") return "radio";
    return "text";
  }
  function isBool(kind) { return kind === "checkbox" || kind === "radio"; }
  function truthy(v) { return v === true || v === 1 || v === "1" || v === "true"; }

  /* ---------------------- selector strategy ----------------------
     ASP.NET top-level ids (ctl00_ContentPlaceHolder1_DDL_Village) are stable, but
     GridView row ids carry a shifting row index (…_gvData_ctl02_dt_from). Ranked:
       1. #id            when the id has no row index
       2. [name="…"]     the UniqueID, when no usable id
       3. [id$="_suffix"] for row-indexed ids (the technique the drivers use)
       4. a short nth-of-type path from the nearest stable ancestor            */
  function rowIndexed(s) { return /_ctl\d+_/.test(s) || /\$ctl\d+\$/.test(s) || s.indexOf("[id$=") === 0; }

  function cssPath(el) {
    var parts = [], node = el, depth = 0;
    while (node && node.nodeType === 1 && depth < 6) {
      if (node.id && !rowIndexed(node.id)) { parts.unshift("#" + cssEsc(node.id)); break; }
      var p = node.parentNode, idx = 1;
      if (p && p.children) {
        for (var i = 0; i < p.children.length; i++) {
          if (p.children[i] === node) break;
          if (p.children[i].tagName === node.tagName) idx++;
        }
      }
      parts.unshift(node.tagName.toLowerCase() + ":nth-of-type(" + idx + ")");
      node = node.parentNode; depth++;
    }
    return parts.join(" > ");
  }

  function selectorFor(el) {
    var id = el.id || "";
    if (id && !rowIndexed(id)) return "#" + cssEsc(id);
    if (el.name && !rowIndexed(el.name)) return '[name="' + String(el.name).replace(/"/g, '\\"') + '"]';
    if (id) {
      var m = id.match(/_ctl\d+_(.+)$/);
      if (m) return '[id$="_' + m[1] + '"]';
      return "#" + cssEsc(id);
    }
    return cssPath(el);
  }

  function labelFor(el) {
    var t = "";
    try {
      if (el.id) { var l = document.querySelector('label[for="' + String(el.id).replace(/"/g, '\\"') + '"]'); if (l) t = l.textContent; }
      if (!t && el.closest) { var td = el.closest("td"); if (td && td.previousElementSibling) t = td.previousElementSibling.textContent; }
      if (!t) t = el.placeholder || el.title || "";
      if (!t && el.id) t = String(el.id).split("_").pop();
    } catch (e) {}
    t = String(t || "").replace(/\s+/g, " ").trim();
    if (!t) t = "field";
    return t.length > 40 ? t.slice(0, 40) + "…" : t;
  }

  /* ---------------------- storage ---------------------- */
  function readAll(cb) {
    try {
      chrome.storage.local.get(RULES_KEY, function (r) { cb((r && r[RULES_KEY]) || [], true); });
    } catch (e) { cb([], true); }
  }
  function writeAll(all, cb) {
    try { chrome.storage.local.set(bundle(all), cb || function () {}); } catch (e) { if (cb) cb(); }
  }
  function bundle(all) { var o = {}; o[RULES_KEY] = all; return o; }

  function refresh() {
    readAll(function (all, on) {
      enabled = on;
      var pk = pageKey();
      rules = all.filter(function (x) { return x && String(x.page || "").toLowerCase() === pk; });
      applyRules("refresh");
    });
  }

  /* ---------------------- the fill engine ---------------------- */
  function applyRules() {
    if (!enabled || !rules.length) return;
    var laterPass = firstPassDone, did = false;
    for (var i = 0; i < rules.length; i++) {
      var r = rules[i];
      if (!r || r.enabled === false || !r.sel) continue;
      var el = null;
      try { el = document.querySelector(r.sel); } catch (e) { continue; }
      if (!el || el.disabled || el.readOnly) continue;

      if (isBool(r.kind)) {
        var want = truthy(r.value);
        if (el.checked === want) continue;   // loop guard
        if (laterPass) continue;             // never fight the user after the first pass
        try { el.click(); did = true; } catch (e) {}
        continue;
      }
      if (String(el.value) === String(r.value)) continue;                 // loop guard (critical)
      if (laterPass && String(el.value).trim() !== "") continue;          // don't clobber typing
      setNative(el, r.value); did = true;
    }
    firstPassDone = true;
  }

  /* ---------------------- K-Desk UI ---------------------- */
  var AF_STYLE =
    ".hl{position:fixed;pointer-events:none;border:2px solid #3730a3;background:rgba(55,48,163,.12);border-radius:3px;box-shadow:0 0 0 2px rgba(55,48,163,.18);transition:all .04s linear;display:none}" +
    ".bar{position:fixed;top:14px;left:50%;transform:translateX(-50%);pointer-events:none;display:flex;align-items:center;gap:10px;" +
      "background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);color:#fff;font-family:Segoe UI,Arial,sans-serif;font-size:12.5px;padding:8px 14px;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.28)}" +
    ".hdl{display:flex;align-items:center;gap:7px;min-width:0}" +
    ".logo{width:22px;height:22px;border-radius:7px;flex:0 0 auto;display:grid;place-items:center;font:800 13px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".bar b{font-size:12.5px;font-weight:600}" +
    ".ov{position:fixed;inset:0;background:rgba(15,20,30,.45);display:flex;align-items:center;justify-content:center;pointer-events:auto}" +
    ".panel{width:360px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;color:#1a1a1a;background:#fff;border:1px solid #3730a3;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.28);overflow:hidden}" +
    ".hd{background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);color:#fff;padding:8px 10px;display:flex;align-items:center;justify-content:space-between}" +
    ".hd b{font-size:12.5px;font-weight:600}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:22px;height:22px;border-radius:5px;font-size:15px;line-height:1;flex:0 0 auto}" +
    ".bd{padding:10px;max-height:80vh;overflow:auto}" +
    ".lbl{font-size:11.5px;color:#3730a3;font-weight:600;margin-bottom:3px}" +
    ".selx{font-size:10px;color:#8a92a0;word-break:break-all;margin-bottom:8px}" +
    ".in{width:100%;padding:7px 8px;border:1px solid #c7cfdd;border-radius:7px;font-size:13px;font-family:inherit;box-sizing:border-box}" +
    ".in:focus{outline:none;border-color:#3730a3;box-shadow:0 0 0 2px rgba(55,48,163,.15)}" +
    ".chkrow{display:flex;align-items:center;gap:8px;font-size:12.5px}" +
    ".btn{padding:8px 9px;border:none;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer}" +
    ".btnrow{display:flex;gap:6px;margin-top:10px}.btnrow .btn{flex:1}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.fill:hover{filter:brightness(1.05)}" +
    ".btn.ghost{background:#f2f4f8;color:#334;border:1px solid #d7dce6}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:6px;background:#f2f4f8;line-height:1.35}" +
    ".st.warn{background:#fef7e0;color:#9a6700}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#8a92a0;line-height:1.35;background:#fbfbfd;border:1px solid #eef0f4;border-radius:6px;padding:5px 7px}" +
    ".foot{margin-top:8px;padding-top:6px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;font-size:10.5px;color:#64748b}.foot b{color:#0b1437}.foot em{font-style:normal;color:#e08e0b}" +
    ".toast{position:fixed;left:18px;bottom:18px;pointer-events:none;background:#137333;color:#fff;padding:10px 14px;border-radius:8px;" +
      "font:600 12.5px Segoe UI,Arial,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.28)}";

  function brandHead(title) {
    return "<div class='hd'><span class='hdl'><span class='logo'>K</span><b>" + esc(title) + "</b></span></div>";
  }
  function brandFoot() {
    return "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>v" + esc(ver()) + "</em></div>";
  }

  /* ---------------------- picker ---------------------- */
  var pick = null;

  function stopPicker() {
    if (!pick) return;
    try { document.removeEventListener("mousemove", pick.move, true); } catch (e) {}
    try { document.removeEventListener("click", pick.click, true); } catch (e) {}
    try { document.removeEventListener("keydown", pick.key, true); } catch (e) {}
    try { pick.host.parentNode && pick.host.parentNode.removeChild(pick.host); } catch (e) {}
    pick = null;
  }

  function toast(msg) {
    try {
      var h = document.createElement("div");
      h.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
      (document.body || document.documentElement).appendChild(h);
      var r = h.attachShadow({ mode: "open" });
      var s = document.createElement("style"); s.textContent = AF_STYLE; r.appendChild(s);
      var t = document.createElement("div"); t.className = "toast"; t.textContent = msg; r.appendChild(t);
      setTimeout(function () { try { h.parentNode.removeChild(h); } catch (e) {} }, 3500);
    } catch (e) {}
  }

  function startPicker() {
    if (pick) return;
    var host = document.createElement("div");
    host.id = HOST_ID;
    host.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var st = document.createElement("style"); st.textContent = AF_STYLE; root.appendChild(st);

    var hl = document.createElement("div"); hl.className = "hl"; root.appendChild(hl);
    if (TOP) {   // one hint bar only, even on framed pages
      var bar = document.createElement("div"); bar.className = "bar";
      bar.innerHTML = "<span class='hdl'><span class='logo'>K</span><b>K-Desk · Field Autofill</b></span>" +
        "<span>যে field-এর default রাখবেন তাতে click করুন · বাতিল করতে <b>Esc</b></span>";
      root.appendChild(bar);
    }

    // Events inside our shadow root retarget to the host at document level, so this
    // tells "our own UI" from "the page". Without it the capture handler below would
    // swallow clicks on our own Save/Cancel buttons and the dialog would look frozen.
    function fromUs(e) { try { return e.target === host || (host.contains && host.contains(e.target)); } catch (x) { return false; } }
    function dialogOpen() { return !!root.querySelector(".ov"); }
    function closeDialog() { var ov = root.querySelector(".ov"); if (ov) { try { root.removeChild(ov); } catch (x) {} } host.style.pointerEvents = "none"; }

    function move(e) {
      if (dialogOpen() || fromUs(e)) { hl.style.display = "none"; return; }
      var el = e.target;
      if (!isFillable(el)) { hl.style.display = "none"; return; }
      var r = el.getBoundingClientRect();
      hl.style.display = "block";
      hl.style.left = (r.left - 2) + "px"; hl.style.top = (r.top - 2) + "px";
      hl.style.width = r.width + "px"; hl.style.height = r.height + "px";
    }
    function click(e) {
      if (fromUs(e)) return;            // let our own dialog work
      e.preventDefault(); e.stopPropagation();
      if (typeof e.stopImmediatePropagation === "function") e.stopImmediatePropagation();
      if (dialogOpen()) return;         // modal: swallow page clicks, but don't re-pick
      var el = e.target;
      if (!isFillable(el)) return;      // ignore non-fields, stay in picker mode
      hl.style.display = "none";
      askValue(root, el);
    }
    function key(e) {
      if (e.key !== "Escape" && e.keyCode !== 27) return;
      e.preventDefault();
      if (dialogOpen()) { closeDialog(); return; }   // first Esc closes the dialog
      stopPicker();                                   // second Esc leaves picker mode
    }

    document.addEventListener("mousemove", move, true);
    document.addEventListener("click", click, true);
    document.addEventListener("keydown", key, true);
    pick = { host: host, root: root, move: move, click: click, key: key };
  }

  // the branded "set a default" modal
  function askValue(root, el) {
    var kind = kindOf(el), sel = selectorFor(el), label = labelFor(el);
    var flagged = rowIndexed(sel);

    var field;
    if (kind === "select") {
      var opts = "";
      for (var i = 0; i < el.options.length; i++) {
        var o = el.options[i];
        opts += "<option value='" + esc(o.value) + "'" + (o.value === el.value ? " selected" : "") + ">" + esc(o.textContent) + "</option>";
      }
      field = "<select class='in' id='af_v'>" + opts + "</select>";
    } else if (isBool(kind)) {
      field = "<label class='chkrow'><input type='checkbox' id='af_v'" + (el.checked ? " checked" : "") + "> এই box default-এ tick থাকবে</label>";
    } else if (kind === "textarea") {
      field = "<textarea class='in' id='af_v' rows='3'>" + esc(el.value || "") + "</textarea>";
    } else {
      field = "<input class='in' id='af_v' type='text' value='" + esc(el.value || "") + "'>";
    }

    var ov = document.createElement("div"); ov.className = "ov";
    var box = document.createElement("div"); box.className = "panel";
    box.innerHTML =
      brandHead("K-Desk · Field Autofill") +
      "<div class='bd'>" +
        "<div class='lbl'>" + esc(label) + "</div>" +
        "<div class='selx'>" + esc(sel) + "</div>" +
        field +
        (flagged ? "<div class='st warn'>এটা table-এর কোনো row-এর field মনে হচ্ছে। Table reload হলে row নম্বর বদলায়, তাই এই default সবসময় নাও বসতে পারে।</div>" : "") +
        "<div class='btnrow'><button class='btn fill' id='af_save'>Default রাখুন</button><button class='btn ghost' id='af_cancel'>বাতিল</button></div>" +
        "<div class='disclaimer'>⚠ রাখা default portal-এর form-এ নিজে ভরে যাবে। Save করার আগে form একবার দেখে নিন। Dashboard থেকে যেকোনো default মুছতে পারবেন।</div>" +
        brandFoot() +
      "</div>";
    ov.appendChild(box); root.appendChild(ov);
    if (pick) pick.host.style.pointerEvents = "auto";

    var vEl = box.querySelector("#af_v");
    try { vEl.focus(); } catch (e) {}

    function close() { try { root.removeChild(ov); } catch (e) {} if (pick) pick.host.style.pointerEvents = "none"; }
    box.querySelector("#af_cancel").addEventListener("click", function (e) { e.preventDefault(); close(); stopPicker(); });
    box.querySelector("#af_save").addEventListener("click", function (e) {
      e.preventDefault();
      var value = isBool(kind) ? (vEl.checked ? "1" : "0") : String(vEl.value);
      var rule = {
        id: "r" + Date.now() + "_" + Math.random().toString(36).slice(2, 7),
        page: pageKey(), sel: sel, kind: kind, label: label,
        value: value, enabled: true, flagged: flagged, createdAt: Date.now()
      };
      readAll(function (all) {
        // one rule per field per page — replace any existing one
        var next = all.filter(function (x) { return !(x && x.sel === rule.sel && String(x.page).toLowerCase() === rule.page); });
        next.push(rule);
        writeAll(next, function () {
          close(); stopPicker();
          refresh();
          toast("“" + label + "”-এর default রাখা হয়েছে");
        });
      });
    });
  }

  /* ---------------------- lifecycle ---------------------- */
  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (msg && msg.type === "KD_AF_PICK") { startPicker(); try { sendResponse({ ok: true }); } catch (e) {} }
      return false;
    });
  } catch (e) {}

  try {
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local") return;
      if (ch[RULES_KEY]) { firstPassDone = false; refresh(); }
    });
  } catch (e) {}

  // ASP.NET re-renders constantly, so keep re-applying (debounced). Never disconnects.
  var timer = null;
  try {
    new MutationObserver(function () {
      if (timer) return;
      timer = setTimeout(function () { timer = null; applyRules(); }, 150);
    }).observe(document.documentElement || document.body, { childList: true, subtree: true });
  } catch (e) {}

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", refresh);
  else refresh();
})();
});
