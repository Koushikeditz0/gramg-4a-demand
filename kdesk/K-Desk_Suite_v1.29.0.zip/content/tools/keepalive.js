/* keepalive.js — K-Desk Suite by Koushik · Login ধরে রাখা (Stay logged in)
   Portal কিছুক্ষণ কিছু না করলে logout করে দেয়, অনেক সময় bulk run-এর মাঝখানে। Portal-এর একটা tab
   খোলা থাকলে প্রতি ৪ মিনিটে portal-এর MENU page-এ (login-এর পরে যে page আসে) একটা হালকা request
   (HEAD) পাঠিয়ে session জিইয়ে রাখে। যে page-এ কাজ চলছে সেটায় কখনো নয়, কারণ কিছু page fresh খুললে
   server-এ কাজের অবস্থা মুছে যায়।
   • একই site-এর যত tab-ই খোলা থাকুক, ৪ মিনিটে একবারই (localStorage দিয়ে ভাগ করা)।
   • ৮ ঘণ্টা কেউ portal ব্যবহার না করলে নিজে থেমে যায়, যাতে ফাঁকা PC-তে logout হয়।
   • কখনো login করে না: session আগেই শেষ হলে থেমে যায়।
   • Request শুধু portal-এর নিজের server-এ যায়, অন্য কোথাও নয়।
   Dashboard toggle: "keepalive" (না থাকলে On)। */
KH_FEATURE("keepalive", function () {
(function () {
  "use strict";
  if (window.__KDKEEP) return; window.__KDKEEP = true;
  if (window.top !== window) return;                                          // tab-প্রতি একবার, frame-এ নয়
  if (!/^vbgramg(de|web)\d*\.dord\.gov\.in$/i.test(location.hostname)) return; // শুধু login করা data-entry site
  if (/login|logout|signout/i.test(location.pathname)) return;

  var EVERY = 4 * 60 * 1000, IDLE_MAX = 8 * 60 * 60 * 1000;
  var K_AT = "kd_keep_at", K_ACT = "kd_keep_act", K_MENU = "kd_keep_menu", K_GET = "kd_keep_get";
  var MENU_RE = /(indexframe\d*|home\w*|menu\w*)\.aspx$/i;                     // GP login-এ …/indexframe2.aspx
  function remember(path) { if (path && MENU_RE.test(path)) { try { localStorage.setItem(K_MENU, path); } catch (e) {} } }
  remember(location.pathname);
  // menu থেকে খোলা page-এর referrer-এ menu-র ঠিকানা থাকে
  try { var ref = document.referrer ? new URL(document.referrer) : null; if (ref && ref.origin === location.origin) remember(ref.pathname); } catch (e) {}
  function menuUrl() { try { var p = localStorage.getItem(K_MENU); return p ? location.origin + p : ""; } catch (e) { return ""; } }

  var dead = false, lastMark = 0;
  // Block (PO) login HEAD-এ 404 দেয়, তখন সাধারণ GET (site অনুযায়ী মনে রাখা)
  var useGet = (function () { try { return localStorage.getItem(K_GET) === "1"; } catch (e) { return false; } })();
  function num(k) { try { return +localStorage.getItem(k) || 0; } catch (e) { return 0; } }
  function put(k, v) { try { localStorage.setItem(k, String(v)); } catch (e) {} }

  // কেউ portal ব্যবহার করছে: মিনিটে বড়জোর একবার লেখা
  function mark() { var t = Date.now(); if (t - lastMark > 60000) { lastMark = t; put(K_ACT, t); } }
  ["mousedown", "keydown", "wheel", "touchstart"].forEach(function (ev) { window.addEventListener(ev, mark, { passive: true, capture: true }); });
  mark();

  // চলমান bulk run-ও "ব্যবহার" ধরা হয়, যাতে রাতভর run-এর মাঝে logout না হয়
  function runActive() {
    return ["dxwd_run", "dxwa_run", "khnp_run", "mrfa_run", "mrfp_run"].some(function (k) {
      try { var r = JSON.parse(localStorage.getItem(k) || "null"); return !!(r && r.active); } catch (e) { return false; }
    });
  }

  function ping() {
    if (dead) return;
    var now = Date.now();
    if (runActive()) put(K_ACT, now);
    if (now - num(K_ACT) > IDLE_MAX) return;               // ঘণ্টার পর ঘণ্টা কেউ নেই: logout হতে দিন
    if (now - num(K_AT) < EVERY - 15000) return;           // অন্য tab এইমাত্র করেছে
    var url = menuUrl(); if (!url) return;                  // এই site-এ menu page এখনো দেখা হয়নি
    put(K_AT, now);
    var full = useGet;
    fetch(url, { method: full ? "GET" : "HEAD", credentials: "include", cache: "no-store" }).then(function (r) {
      if (/login|sessionexp|timeout/i.test(r.url) && r.url !== url) { dead = true; return; }   // আগেই logout হয়ে গেছে
      if (!full && !r.ok) { useGet = true; put(K_GET, "1"); put(K_AT, 0); return; }         // HEAD চলে না: পরের মিনিট থেকে GET
      if (full) return r.text().then(function (t) { if (/Session\s*Expired|Illegal\s*Operation/i.test(t.slice(0, 20000))) dead = true; });
    }).catch(function () {});
  }
  setInterval(ping, 60000);                                 // পিছনের tab-এও ১ মিনিটের timer চলে
})();
});
