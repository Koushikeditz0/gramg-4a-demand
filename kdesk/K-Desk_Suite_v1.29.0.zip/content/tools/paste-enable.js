/* paste-enable.js — K-Desk Suite by Koushik · Copy / Paste চালু
   Portal-এর কিছু field-এ paste, copy, cut আর right-click বন্ধ করা থাকে (onpaste="return false",
   capture listener ইত্যাদি)। এটা শুধু page-এর নিজের বাধাগুলো থামায় আর ওই inline attribute মুছে দেয়,
   যাতে Reg No, তারিখ, OTP সহজে paste করা যায়। Clipboard-এর কিছু পড়ে না, রাখে না, কোথাও পাঠায় না।
   document_start-এ চলে, যাতে আমাদের capture listener page-এর আগে বসে। শুধু *.dord.gov.in-এ।
   Dashboard toggle: "paste" (না থাকলে On); PC activated না হলে কিছু করে না। */
(function () {
  "use strict";
  if (window.__KDPASTE) return; window.__KDPASTE = true;
  var enabled = false;      // licence আর toggle দেখে তারপর চালু হয়
  var EVENTS = ["paste", "copy", "cut", "contextmenu", "drop", "dragstart", "selectstart", "beforecopy", "beforecut", "beforepaste"];

  // Capture-phase, আগে বসানো: page-এর blocker-এর আগে চলে তাকে থামায়, browser-এর আসল paste/copy চলতে দেয়।
  function stopper(e) { if (!enabled) return; try { e.stopImmediatePropagation(); } catch (x) {} }
  EVENTS.forEach(function (t) {
    try { window.addEventListener(t, stopper, true); } catch (e) {}
    try { document.addEventListener(t, stopper, true); } catch (e) {}
  });

  // নতুন field এলেই inline blocker attribute মুছে ফেলা
  var ATTRS = ["onpaste", "oncopy", "oncut", "oncontextmenu", "ondrop", "ondragstart", "onselectstart"];
  function clean(root) {
    if (!enabled) return;
    try {
      var els = (root || document).querySelectorAll("input,textarea,[onpaste],[oncopy],[oncut],[oncontextmenu],[onselectstart]");
      for (var i = 0; i < els.length; i++) {
        for (var j = 0; j < ATTRS.length; j++) {
          if (els[i].hasAttribute && els[i].hasAttribute(ATTRS[j])) { try { els[i][ATTRS[j]] = null; } catch (e) {} els[i].removeAttribute(ATTRS[j]); }
        }
      }
    } catch (e) {}
  }
  function sweep() { clean(document); }
  document.addEventListener("DOMContentLoaded", sweep);
  try {
    new MutationObserver(function (muts) {
      if (!enabled) return;
      for (var i = 0; i < muts.length; i++) {
        var a = muts[i].addedNodes; if (!a) continue;
        for (var j = 0; j < a.length; j++) if (a[j] && a[j].nodeType === 1) clean(a[j]);
      }
    }).observe(document.documentElement || document, { childList: true, subtree: true });
  } catch (e) {}

  function apply(features) { enabled = !features || features.paste !== false; if (enabled && document.readyState !== "loading") sweep(); }
  try {
    window.KH_LICENSE.check(function (ok) {
      if (!ok) return;
      chrome.storage.local.get(["kh_features", "kh_off"], function (r) { apply(r && r.kh_off ? { paste: false } : r && r.kh_features); });
      chrome.storage.onChanged.addListener(function (ch, area) { if (area === "local" && (ch.kh_features || ch.kh_off)) chrome.storage.local.get(["kh_features", "kh_off"], function (r) { apply(r && r.kh_off ? { paste: false } : r && r.kh_features); }); });
    });
  } catch (e) {}
})();
