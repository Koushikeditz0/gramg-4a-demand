/* pwreveal.js — K-Desk Suite by Koushik · Password দেখানো
   Portal-এর password box-এ কী টাইপ করছেন দেখা যায় না, ভুল হলে বারবার login ফেল হয়।
   প্রতিটি password box-এর পাশে ছোট 👁 বোতাম বসায়: চাপলে লেখা দেখায়, আবার চাপলে লুকায়।
   Form submit (বা Enter) হওয়ার আগে আবার লুকিয়ে দেয়। Password পড়ে না, রাখে না, কোথাও পাঠায় না;
   শুধু box-এর type বদলায়। Dashboard toggle: "pwreveal" (না থাকলে On)। */
KH_FEATURE("pwreveal", function () {
(function () {
  "use strict";
  if (window.__KDPW) return; window.__KDPW = true;
  var ATTR = "data-kd-pw", SIZE = 24, tracked = [], layer = null, root = null, raf = 0;

  function ensureLayer() {
    if (layer && layer.isConnected) return true;
    if (!document.body) return false;
    layer = document.createElement("div");
    layer.id = "kdpw-layer";
    layer.style.cssText = "position:fixed;left:0;top:0;width:0;height:0;z-index:2147483645;pointer-events:none;";
    document.body.appendChild(layer);
    root = layer.attachShadow({ mode: "open" });
    var css = document.createElement("style");
    css.textContent = "button{position:fixed;width:" + SIZE + "px;height:" + SIZE + "px;padding:0;margin:0;border:1px solid #c7d2fe;" +
      "border-radius:7px;background:#fff;color:#3730a3;font:13px/1 'Segoe UI',Arial,sans-serif;cursor:pointer;pointer-events:auto;" +
      "box-shadow:0 1px 3px rgba(11,20,55,.2);display:flex;align-items:center;justify-content:center}" +
      "button:hover{border-color:#e08e0b}button.on{background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b);border-color:#e08e0b}";
    root.appendChild(css);
    tracked = [];
    return true;
  }
  function isPw(el) { return el.getAttribute(ATTR) === "1" || String(el.type).toLowerCase() === "password"; }
  function setShown(t, show) {
    try { t.input.type = show ? "text" : "password"; } catch (e) {}
    if (show) t.input.setAttribute(ATTR, "1"); else t.input.removeAttribute(ATTR);
    t.btn.textContent = show ? "🙈" : "👁";
    t.btn.title = show ? "Password লুকান (K-Desk)" : "Password দেখুন (K-Desk)";
    t.btn.className = show ? "on" : "";
  }
  function track(input) {
    for (var i = 0; i < tracked.length; i++) if (tracked[i].input === input) return;
    var b = document.createElement("button");
    b.type = "button"; b.setAttribute("aria-label", "Password দেখুন");
    var t = { input: input, btn: b };
    b.addEventListener("mousedown", function (e) { e.preventDefault(); });          // focus box-এই থাকুক
    b.addEventListener("click", function (e) {
      e.preventDefault(); e.stopPropagation();
      setShown(t, input.getAttribute(ATTR) !== "1");
      try { input.focus(); } catch (x) {}
    });
    root.appendChild(b); tracked.push(t); setShown(t, false);
  }
  function scan() {
    if (!ensureLayer()) return;
    var q = document.querySelectorAll('input[type="password"],input[' + ATTR + '="1"]');
    for (var i = 0; i < q.length; i++) track(q[i]);
    place();
  }
  // বোতাম box-এর ঠিক ডানে (জায়গা না থাকলে box-এর ভেতরে ডান ধারে)
  function place() {
    raf = 0;
    var W = window.innerWidth, H = window.innerHeight;
    tracked = tracked.filter(function (t) {
      if (!t.input.isConnected) { t.btn.remove(); return false; }
      if (!isPw(t.input)) { t.btn.style.display = "none"; return true; }
      var r = t.input.getBoundingClientRect(), cs = getComputedStyle(t.input);
      var visible = r.width > 20 && r.height > 8 && cs.visibility !== "hidden" && cs.display !== "none" &&
        r.bottom > 0 && r.top < H && r.right > 0 && r.left < W && !t.input.disabled;
      if (!visible) { t.btn.style.display = "none"; return true; }
      var left = r.right + 4; if (left + SIZE > W - 2) left = r.right - SIZE - 4;
      t.btn.style.display = "flex";
      t.btn.style.left = Math.round(left) + "px";
      t.btn.style.top = Math.round(r.top + (r.height - SIZE) / 2) + "px";
      return true;
    });
  }
  function soon() { if (!raf) raf = requestAnimationFrame(place); }
  // পাঠানোর আগে আবার লুকানো, যাতে browser-এর password manager সাধারণ password box দেখে
  function maskAll() { tracked.forEach(function (t) { if (t.input.getAttribute(ATTR) === "1") setShown(t, false); }); }

  var tm = null;
  try {
    new MutationObserver(function () { if (tm) return; tm = setTimeout(function () { tm = null; scan(); }, 300); })
      .observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}
  window.addEventListener("scroll", soon, true);
  window.addEventListener("resize", soon);
  document.addEventListener("submit", maskAll, true);
  document.addEventListener("keydown", function (e) { if (e.key === "Enter" && e.target && e.target.getAttribute && e.target.getAttribute(ATTR) === "1") maskAll(); }, true);
  document.addEventListener("click", function (e) {             // ASP.NET login বোতাম অনেক সময় form submit নয়, script দিয়ে পাঠায়
    var b = e.target && e.target.closest && e.target.closest("input[type=submit],input[type=button],input[type=image],button");
    if (b && !(layer && layer.contains(b))) maskAll();
  }, true);
  window.addEventListener("pagehide", maskAll);
  setInterval(function () { if (tracked.length) place(); }, 600);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scan); else scan();
})();
});
