KH_FEATURE("wlcaste", function () {
/* caste-register.js — K-Desk Suite by Koushik
   For ⚖ WL Caste Breakup: when the Registration Application Register is open, Job Card → Caste is saved
   into K-Desk's caste store (kh_caste_map_v2), the same store the on-page Caste Breakup uses.
   If the old Caste Breakup feature is On it already does this, so this file then does nothing. */
(function () {
  'use strict';
  if (window.__KDWCB_REG__) return; window.__KDWCB_REG__ = true;
  var K = window.KDWCBKIT; if (!K) return;
  function pageText() { try { return (document.body && document.body.innerText) || ''; } catch (e) { return ''; } }
  function toast(msg) {
    var t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;right:76px;bottom:18px;z-index:2147483647;color:#fff;background:#137333;padding:10px 14px;border-radius:8px;font:600 13px "Segoe UI","Nirmala UI",Arial;box-shadow:0 3px 12px #0004;max-width:420px';
    document.body.appendChild(t); setTimeout(function () { t.remove(); }, 6000);
  }
  function cacheRegister() {
    var reg = K.rawUnion(document);
    var cardIdx = K.colIndex(reg, /job\s*card\s*(no|number)/i), casteIdx = K.colIndex(reg, /caste/i);
    if (cardIdx < 0 || casteIdx < 0) return false;
    var map = {};
    reg.rows.forEach(function (r) {
      var id = K.normId(r[cardIdx]); if (!id || !K.JC_RE.test(r[cardIdx] || '')) return;
      var c = K.cellStr(r[casteIdx]); if (c && !map[id]) map[id] = c;
    });
    var n = Object.keys(map).length; if (!n) return false;
    chrome.storage.local.get(K.KEY, function (d) {
      var cur = (d && d[K.KEY]) || {}; for (var k in map) cur[k] = map[k];
      var o = {}; o[K.KEY] = cur; o[K.META_KEY] = { count: Object.keys(cur).length, savedAt: Date.now() };
      chrome.storage.local.set(o, function () { toast('⚖ Caste register জমা হয়েছে — এই page থেকে ' + n + 'টি Job Card (মোট ' + Object.keys(cur).length + ')।'); });
    });
    return true;
  }
  function isRegister() {
    var titled = (document.title || '') + '\n' + pageText() + '\n' + location.href;
    return (/Registration Application Register/i.test(titled) || /panchregpeople/i.test(location.href)) && K.hasJobCardRow(document);
  }
  function go() {
    var done = false, obs = null;
    function tryIt() { if (done || !isRegister()) return; if (cacheRegister()) { done = true; if (obs) { obs.disconnect(); obs = null; } } }
    tryIt();
    if (!done) {
      obs = new MutationObserver(tryIt);
      obs.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(function () { if (obs) { obs.disconnect(); obs = null; } }, 90000);
    }
  }
  // the old Caste Breakup feature (toggle "caste") already saves the register when it is On
  try { chrome.storage.local.get('kh_features', function (r) { var f = (r && r.kh_features) || {}; if (f.caste === false) go(); }); } catch (e) {}
})();
});
