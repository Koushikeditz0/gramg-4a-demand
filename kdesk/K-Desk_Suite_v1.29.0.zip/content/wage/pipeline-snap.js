KH_FEATURE("pipe", function () {
/* =====================================================================
   pipeline-snap.js — K-Desk Suite by Koushik · 💸 Payment pipeline → Gram Setu (isolated world)
   Only READS two portal pages and tells Gram Setu (SQL v217) what is waiting there, so the
   Admin panel's 💸 Pipeline tab can show where the money is stuck:
     • Generate Wagelist (SendMSRtoPO.aspx): works listed = MR filled, no wage list yet
       (+ how many workers held each work back in the last ⚙ Generate run);
       wage lists made by the last Generate run (work code, WL no., amount).
     • Send Wagelist For Payment (sendforpay.aspx): wage lists in the "Wagelist No." list for the
       chosen Financial Year (+ amount of the one on screen / read by 🧪 Test run);
       wage lists the last Send run really sent.
   Nothing on the portal is clicked or changed. Nothing is sent unless K-Desk is already logged in to
   Gram Setu (no login box pops up). No names, bank or Aadhaar data are sent.
   Dashboard toggle: "pipe".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDPIPE) return;
  var path = location.pathname.toLowerCase();
  var ON_GEN = /\/sendmsrtopo\.aspx$/.test(path), ON_SEND = /\/sendforpay\.aspx$/.test(path);
  if (!ON_GEN && !ON_SEND) return;
  try { if (window.top !== window) return; } catch (e) { return; }
  window.__KDPIPE = true;

  // portal-এর ID এখন shared/portal-map.js (page "wagegen" আর "sendpay") থেকে; map না থাকলে আগের মান
  var KM = window.KD_MAP, MI = function (pg, k, d) { return KM ? KM.id(pg, k, d) : d; };
  var P = KM ? KM.prefixId("ctl00_ContentPlaceHolder1_") : "ctl00_ContentPlaceHolder1_", SS = "kdpipe_sent_", TITLE = "💸 Pipeline → Gram Setu";
  var REPEAT = 30 * 60000;                    // same list again → send again only after 30 minutes
  function $(id) { return document.getElementById(id); }
  function norm(s) { return String(s == null ? "" : s).replace(/ /g, " ").replace(/\s+/g, " ").trim(); }
  function lsJson(k) { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch (e) { return null; } }
  function link() { return !!(window.KDLink && window.KDLink.call && window.KDLink.signedIn); }
  function hash(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return String(h); }
  function done(key, sig, every) {
    try { var o = JSON.parse(sessionStorage.getItem(SS + key) || localStorage.getItem(SS + key) || "null"); return !!(o && o.s === sig && Date.now() - o.t < every); } catch (e) { return false; }
  }
  function mark(key, sig, persist) {
    var v = JSON.stringify({ s: sig, t: Date.now() });
    try { sessionStorage.setItem(SS + key, v); if (persist) localStorage.setItem(SS + key, v); } catch (e) {}
  }
  var busy = false;
  // send only when already logged in to Gram Setu; a missing v217 SQL / network error is quiet (console only)
  async function send(key, sig, fn, args, persist, every) {
    if (busy || !link() || done(key, sig, every || REPEAT)) return;
    busy = true;
    try {
      if (!(await window.KDLink.signedIn())) return;
      await window.KDLink.call(fn, args, TITLE);
      mark(key, sig, persist);
    } catch (e) { try { console.warn("[K-Desk pipeline]", fn, (e && (e.text || e.message)) || e); } catch (x) {} }
    finally { busy = false; }
  }
  function amt(s) { var n = parseFloat(String(s || "").replace(/[₹,\s]/g, "")); return isFinite(n) ? n : null; }

  /* ---------------------- Generate Wagelist page ---------------------- */
  function genRows() {
    var t = $(P + MI("wagegen", "list", "wagelist_msr")); if (!t) return [];
    return [].filter.call(t.rows, function (r) { return r.querySelector("input[type=checkbox]") && r.cells.length >= 4; }).map(function (r) {
      return { code: norm(r.cells[2].textContent).toUpperCase(), name: norm(r.cells[3].textContent).slice(0, 160) };
    }).filter(function (x) { return /^\d{10}\//.test(x.code); });
  }
  function genTick() {
    var run = lsJson("kdwg_run");
    if (run && run.active) return;                                     // a Generate run is going on: wait for it
    var recent = run && run.finishedAt && Date.now() - run.finishedAt < 3 * 864e5 ? run : null;
    // wage lists made by the last run
    if (recent) {
      var made = (recent.results || []).filter(function (x) { return x.result === "generated" && /WL\d+/i.test(x.wl || ""); }).map(function (x) {
        return { wl: String(x.wl).toUpperCase(), code: x.code || "", date: x.wlDate || "", n: x.workers != null ? +x.workers || null : null, amt: amt(x.amount), stage: "generated" };
      });
      if (made.length) send("wg_" + recent.finishedAt, String(made.length), "kdesk_pipeline_wls", { p_rows: made }, true, 365 * 864e5);
    }
    // the works list on screen (after Proceed). Empty list counts only when the page has its dates (Proceed pressed).
    var rows = genRows();
    if (!rows.length && !norm(($(P + MI("wagegen", "from", "wgfromdt")) || {}).value)) return;
    var held = {};
    if (recent) (recent.results || []).forEach(function (x) { if (x.code) held[String(x.code).toUpperCase()] = x.result === "held" ? (x.held || []).length : 0; });
    var items = rows.map(function (x) { return { code: x.code, name: x.name, held: held[x.code] || 0 }; });
    var ag = $(P + MI("wagegen", "agency", "exe_agency")), scope = ag && ag.selectedIndex >= 0 ? norm(ag.options[ag.selectedIndex].text) : "";
    if (/select/i.test(scope)) scope = "";
    send("gen_" + hash(scope), hash(JSON.stringify(items)), "kdesk_pipeline_snap", { p_kind: "wl_gen", p_scope: scope, p_items: items });
  }

  /* ---------------------- Send Wagelist For Payment page ---------------------- */
  function sendTick() {
    var run = lsJson("kdsp_run");
    if (run && run.active) return;                                     // a Send run is going on: wait for it
    var fySel = $(P + MI("sendpay", "fy", "ddlfin")), fy = fySel ? norm(fySel.value) : "";
    // what the last run read (🧪 test: amounts) or really sent
    var amtOf = {};
    if (run && run.finishedAt && Date.now() - run.finishedAt < 7 * 864e5) {
      var sent = [];
      (run.results || []).forEach(function (x) {
        var a = 0, any = false; (x.agencies || []).forEach(function (g) { var v = amt(g.amount); if (v != null) { a += v; any = true; } });
        var wl = String(x.wl || "").toUpperCase(); if (!/WL\d+/.test(wl)) return;
        if (any) amtOf[wl] = a;
        if (x.result === "sent") sent.push({ wl: wl, fy: x.fy || "", amt: any ? a : null, stage: "sent" });
      });
      if (sent.length) send("sp_" + run.finishedAt, String(sent.length), "kdesk_pipeline_wls", { p_rows: sent }, true, 365 * 864e5);
    }
    if (!/^\d{4}\s*-\s*\d{4}$/.test(fy)) return;                       // no Financial Year chosen yet
    var wlSel = $(P + MI("sendpay", "wl", "ddl_sel")); if (!wlSel) return;
    var list = [].filter.call(wlSel.options, function (o) { return o.value && !/^(select|0|-1)$/i.test(o.value) && !/select/i.test(o.text); })
      .map(function (o) { return String(o.value).toUpperCase(); }).filter(function (v) { return /WL\d+/.test(v); });
    // amount of the wage list on screen
    var cur = String(wlSel.value || "").toUpperCase();
    if (list.indexOf(cur) >= 0) {
      var a = 0, any = false;
      [].forEach.call(document.querySelectorAll("[id*='GridView1_'][id$='txt_chk_amt']"), function (e) { var v = amt(e.tagName === "INPUT" ? e.value : e.textContent); if (v != null) { a += v; any = true; } });
      if (any) amtOf[cur] = a;
    }
    var items = list.map(function (wl) { return amtOf[wl] != null ? { wl: wl, amt: amtOf[wl] } : { wl: wl }; });
    send("sp_" + fy, hash(JSON.stringify(items)), "kdesk_pipeline_snap", { p_kind: "send_pay", p_scope: fy.replace(/\s+/g, ""), p_items: items });
  }

  // the page changes by postbacks (some partial): look again every few seconds for a while
  var tick = ON_GEN ? genTick : sendTick, n = 0;
  setTimeout(tick, 2500);
  var iv = setInterval(function () { if (++n > 150) { clearInterval(iv); return; } tick(); }, 4000);
})();
});
