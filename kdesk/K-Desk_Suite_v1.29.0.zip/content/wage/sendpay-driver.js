/* =====================================================================
   sendpay-driver.js — K-Desk Suite by Koushik · Send Wage List for Payment (MAIN world, document_start)
   The portal answers "Send Wagelist For Payment" with a browser alert ("Record Update sucessfully", or a reason).
   An alert stops the page until someone clicks OK, so while a K-Desk run is going (localStorage kdsp_run.active)
   the alert's text is kept in localStorage kdsp_alerts for the panel instead of being shown.
   With no run going, alerts are left exactly as they are. (No Date here: the portal replaces it in this world.)
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDSP_DRV) return; window.__KDSP_DRV = true;
  function running() { try { var r = JSON.parse(localStorage.getItem("kdsp_run") || "null"); return !!(r && r.active); } catch (e) { return false; } }
  var native = window.alert;
  window.alert = function (m) {
    if (!running()) return native.apply(window, arguments);
    try {
      var q = JSON.parse(localStorage.getItem("kdsp_alerts") || "[]");
      q.push(String(m == null ? "" : m)); localStorage.setItem("kdsp_alerts", JSON.stringify(q.slice(-20)));
    } catch (e) {}
  };
})();
