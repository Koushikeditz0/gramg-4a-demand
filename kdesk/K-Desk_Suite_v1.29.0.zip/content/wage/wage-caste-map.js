KH_FEATURE("caste", function () {
/* K-Desk Suite by Koushik — Wage List Caste Breakup
   নিজে থেকে চলে, report-এর format SmartDesk-এর মতো:
   1) Registration Application Register page খুললেই (কোনো button চাপতে হয় না) পুরো list
      load হলে Job Card → Caste নিজে থেকে extension storage-এ জমা হয়। অন্য GP-র register
      খুললে আগের data মোছে না, যোগ হয়।
   2) Wage List পুরো load হলে ("Download In Excel" বা job card row দেখা দিলে) নিজে থেকেই
      Muster Roll অনুযায়ী General / SC / ST report খোলে (SmartDesk format, head code সহ)।
      বন্ধ করলে "⚖ Caste breakup" button দিয়ে আবার খোলা যায়।
   3) Page-এ লেখা wage list total-এর সঙ্গে হিসেব মিলিয়ে দেখায়।
   প্রতিটি frame-এ চলে, নিজেই বোঝে কোন page। সব data শুধু browser-এ থাকে; Aadhaar/bank column পড়া হয় না। */
(function () {
  'use strict';
  if (window.__KH_WAGE_CASTE__) return;
  window.__KH_WAGE_CASTE__ = true;


  // একই page-এ অন্য extension (GramG Ninja / SmartDesk) চালু থাকলে তাদের একই রকম popup/button লুকিয়ে রাখা,
  // যাতে শুধু Helper-এর report দেখা যায়
  (function hideOthers() {
    try {
      if (document.getElementById('kh-hide-other-caste')) return;
      var st = document.createElement('style'); st.id = 'kh-hide-other-caste';
      st.textContent = '#dxwbk-ov,#dxwbk-btn,#dxwbk-toast,#vbg-report-box,#vbg-generate,#vbg-load-caste,#vbg-report-toast{display:none!important}';
      (document.head || document.documentElement).appendChild(st);
    } catch (e) {}
  })();

  var KEY = 'kh_caste_map_v2';      // { normKey(jobCard): "SC" | "ST" | raw caste text }
  var META_KEY = 'kh_caste_meta_v2'; // { count, savedAt }
  var STALE_MS = 7 * 24 * 60 * 60 * 1000;
  var JC_RE = /[A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+/i;
  var IS_WAGE = false;

  function txt(el) { return (el ? (el.innerText || el.textContent || '') : '').replace(/\s+/g, ' ').trim(); }
  function pageText() { try { return (document.body && document.body.innerText) || ''; } catch (e) { return ''; } }
  function hasJobCardRow() { try { return Array.prototype.some.call(document.querySelectorAll('tr'), function (tr) { return JC_RE.test(tr.innerText || ''); }); } catch (e) { return false; } }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function money(n) { return '₹' + Number(n || 0).toLocaleString('en-IN'); }
  function fmt(n) { return Number(n || 0).toLocaleString('en-IN'); }

  /* ---------- page-এর table পড়ার পদ্ধতি (cleanTable / normKey) ---------- */
  // Job Card key: বড় হাতের অক্ষর, space বাদ, সংখ্যার আগের 0 বাদ (WB-06-003 আর WB-6-3 একই ধরা হয়)
  function normId(v) { return String(v == null ? '' : v).toUpperCase().replace(/\s+/g, '').replace(/\d+/g, function (m) { return String(parseInt(m, 10)); }); }
  function cellStr(v) { return v == null ? '' : String(v).trim(); }
  function nonEmpty(r) { var c = 0; for (var i = 0; i < r.length; i++) if (cellStr(r[i]) !== '') c++; return c; }
  function firstText(r) { for (var i = 0; i < r.length; i++) { var v = cellStr(r[i]); if (v) return v; } return ''; }
  function isSerialRow(r) {
    var nums = []; for (var i = 0; i < r.length; i++) { var v = cellStr(r[i]); if (v) nums.push(v); }
    if (nums.length < Math.max(3, r.length - 2)) return false;
    for (var j = 0; j < nums.length; j++) if (String(j + 1) !== nums[j]) return false;
    return true;
  }
  function labelScore(r) { var lab = 0, tot = 0; for (var i = 0; i < r.length; i++) { var v = cellStr(r[i]); if (!v) continue; tot++; if (!/^[\d.,\/\-]+$/.test(v)) lab++; } return tot ? lab / tot : 0; }
  var JUNK_FIRST = /^(sub ?total|total\b|rupees\b.*only|signature|report completed|payment by|bank name|wage list|state\s*[:：]|district\s*[:：]|block\s*[:：]|financial year|mustroll period|wage list agency|view wage list|signout|home$)/i;
  // সব row-কে একটা grid বানায়: সবচেয়ে বেশি দেখা চওড়াই আসল data, প্রথম label row header
  function cleanTable(rowsIn) {
    var all = rowsIn.map(function (r) { return r.slice(); });
    if (!all.length) return { headers: [], rows: [] };
    var freq = {}; all.forEach(function (r) { if (r.length >= 2) freq[r.length] = (freq[r.length] || 0) + 1; });
    var W = 0, best = -1; Object.keys(freq).forEach(function (k) { if (freq[k] > best) { best = freq[k]; W = +k; } });
    if (!W) W = all[0].length;
    var hcand = null;
    for (var i = 0; i < all.length; i++) { var hr = all[i]; if (hr.length < 3 || isSerialRow(hr) || labelScore(hr) < 0.7) continue; if (hr.length > (hcand ? hcand.length : 0)) hcand = hr; }
    if (hcand && hcand.length > W) W = hcand.length;
    var header = null, headerIdx = -1;
    for (var j = 0; j < all.length; j++) { if (all[j].length === W && !isSerialRow(all[j]) && labelScore(all[j]) >= 0.7) { header = all[j].slice(); headerIdx = j; break; } }
    var dataRows = [];
    for (var r0 = 0; r0 < all.length; r0++) {
      if (r0 === headerIdx) continue;
      var row = all[r0];
      if (!nonEmpty(row) || row.length !== W || isSerialRow(row) || JUNK_FIRST.test(firstText(row))) continue;
      if (header && row.join('') === header.join('')) continue;   // বারবার আসা header
      dataRows.push(row);
    }
    var H = header ? header.slice() : [];
    for (var h = H.length; h < W; h++) H.push('col' + (h + 1));
    return { headers: H.slice(0, W).map(function (x, idx) { return cellStr(x) || ('col' + (idx + 1)); }), rows: dataRows };
  }
  // Page-এর সব leaf <tr> (nested table থাকা layout row বাদ) একসাথে — wage list কয়েকটা table-এ ভাগ থাকলেও সব row আসে
  function rawUnion() {
    var rows = [];
    Array.prototype.forEach.call(document.querySelectorAll('tr'), function (tr) {
      if (tr.querySelector('table')) return;
      if (tr.closest && tr.closest('#kh-wc-box')) return;          // নিজের report বাদ
      var vals = [];
      for (var i = 0; i < tr.children.length; i++) { var c = tr.children[i]; if (c.tagName === 'TD' || c.tagName === 'TH') vals.push(txt(c)); }
      if (vals.length) rows.push(vals);
    });
    return cleanTable(rows);
  }
  function colIndex(t, re) { for (var i = 0; i < t.headers.length; i++) if (re.test(String(t.headers[i] || ''))) return i; return -1; }
  function bucket(c) { var s = String(c == null ? '' : c).trim().toUpperCase(); if (s === 'SC') return 'SC'; if (s === 'ST') return 'ST'; return 'OTH'; }
  // Wage list-এর নিজের total: কয়েকটা bank/PO block থাকলে সব "Sub Total" যোগ, নইলে সবচেয়ে বড় "total"
  function statedTotal() {
    var t = pageText(), m, subs = [], reSub = /sub\s*total[^0-9]{0,15}([0-9][0-9,]*(?:\.\d+)?)/gi;
    while ((m = reSub.exec(t))) subs.push(parseFloat(m[1].replace(/,/g, '')) || 0);
    if (subs.length > 1) return Math.round(subs.reduce(function (a, b) { return a + b; }, 0) * 100) / 100;
    var mx = 0, re = /total[^0-9]{0,15}([0-9][0-9,]*)/gi;
    while ((m = re.exec(t))) { var n = parseFloat(m[1].replace(/,/g, '')) || 0; if (n > mx) mx = n; }
    return mx;
  }

  /* ---------- style ---------- */
  var CSS = '' +
    '#kh-wc-box{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:max-content;max-width:94vw;max-height:80vh;z-index:2147483645;background:#fff;border:1px solid #cbd5e1;border-radius:12px;box-shadow:0 14px 40px #0b143755;font:12px "Segoe UI","Nirmala UI",Arial,sans-serif;color:#0f172a;display:flex;flex-direction:column;overflow:hidden}' +
    '#kh-wc-box .kh-head{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:6px 10px;font-size:13px;gap:16px;display:flex;justify-content:space-between;align-items:center}' +
    '#kh-wc-box .kh-head:after{content:"";position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}' +
    '#kh-wc-close{background:transparent;border:0;color:#fff;font-size:18px;line-height:1;cursor:pointer;padding:0}' +
    '#kh-wc-box .kh-controls{padding:5px 10px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #e2e8f0}' +
    '#kh-wc-copy{margin-left:auto;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b);color:#1a1300;border:0;border-radius:6px;padding:4px 10px;font:700 12px "Segoe UI",Arial;cursor:pointer}' +
    '#kh-wc-box .kh-msg{margin:5px 10px 0;padding:3px 8px;border-radius:6px;font-size:11.5px}' +
    '#kh-wc-box .kh-ok{color:#137333;background:#e7f4ea;border:1px solid #b6dcc0}' +
    '#kh-wc-box .kh-bad{color:#9a5a12;background:#fdf0e3;border:1px solid #f4d9b8}' +
    '#kh-wc-box .kh-body{padding:10px 12px;font-size:13px;line-height:1.55;max-width:560px}' +
    '#kh-wc-box .kh-scroll{overflow:auto;flex:1 1 auto;min-height:0;margin:6px 10px 0}' +
    '#kh-wc-table{border-collapse:collapse;width:max-content;font-size:11.5px}' +
    '#kh-wc-table th,#kh-wc-table td{border:1px solid #94a3b8;padding:3px 6px;text-align:center;white-space:nowrap}' +
    '#kh-wc-table th{background:#eef2fb;white-space:normal;max-width:120px;font-size:10.5px;line-height:1.25;position:sticky;top:0}' + '#kh-wc-table thead tr:nth-child(2) th{top:var(--kh-h1,22px)}' + '#kh-wc-table td.kh-warn,#kh-wc-table td:last-child{white-space:normal;max-width:240px;text-align:left}' +
    '#kh-wc-table td.kh-warn{color:#b3261e;font-weight:600}' +
    '#kh-wc-box .kh-note{padding:4px 10px;font-size:11px;gap:16px;margin-top:6px;color:#64748b;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between}' +
    '#kh-wc-box .kh-note em{font-style:normal;color:#e08e0b}' +
    '#kh-wc-btn{position:fixed;right:18px;bottom:18px;z-index:2147483640;border:0;border-radius:10px;padding:10px 14px;font:600 13px "Segoe UI","Nirmala UI",Arial,sans-serif;box-shadow:0 3px 12px #0004;cursor:pointer;color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}' +
    '#kh-wc-box{background:linear-gradient(180deg,#eef0ff,#e3e6fb);border-color:#c9cef3;max-width:calc(100vw - 96px);left:calc(50% - 29px)}#kh-wc-box .kh-controls,#kh-wc-box .kh-note{border-color:#d4d8f5}#kh-wc-table td{background:#fff}#kh-wc-table th{background:#e3e6fb}' +
    '#kh-wc-toast{position:fixed;right:18px;bottom:18px;z-index:2147483647;color:#fff;padding:10px 14px;border-radius:8px;font:600 13px "Segoe UI","Nirmala UI",Arial;box-shadow:0 3px 12px #0004;max-width:420px}';
  function addStyle() {
    if (document.getElementById('kh-wc-style')) return;
    var st = document.createElement('style'); st.id = 'kh-wc-style'; st.textContent = CSS;
    (document.head || document.documentElement).appendChild(st);
  }
  function toast(msg, ok) {
    addStyle();
    var t = document.getElementById('kh-wc-toast'); if (t) t.remove();
    t = document.createElement('div'); t.id = 'kh-wc-toast'; t.textContent = msg;
    t.style.background = ok === false ? '#b3261e' : '#137333';
    document.body.appendChild(t); setTimeout(function () { if (t) t.remove(); }, 5000);
  }
  function verText() { try { return 'v' + chrome.runtime.getManifest().version; } catch (e) { return ''; } }
  function openBox(title) {
    addStyle();
    var bt = document.getElementById('kh-wc-btn'); if (bt) bt.style.display = 'none';
    var box = document.getElementById('kh-wc-box');
    if (!box) { box = document.createElement('div'); box.id = 'kh-wc-box'; document.body.appendChild(box); }
    box.innerHTML = '<div class="kh-head"><b>' + esc(title) + '</b><button id="kh-wc-close" title="বন্ধ করুন">×</button></div>';
    box.querySelector('#kh-wc-close').onclick = closeBox;
    return box;
  }
  function closeBox() { var b = document.getElementById('kh-wc-box'); if (b) b.remove(); if (IS_WAGE) showButton(); }
  function footer() { return '<div class="kh-note"><span>Muster Roll-wise • Unskilled only • Skilled columns পরে update হবে</span><span>✦ Crafted by <b>KOUSHIK</b> <em>' + esc(verText()) + '</em></span></div>'; }

  /* ---------- Register page: নিজে থেকেই caste জমা ---------- */
  function cacheRegister() {
    try {
      var reg = rawUnion();
      var cardIdx = colIndex(reg, /job\s*card\s*(no|number)/i), casteIdx = colIndex(reg, /caste/i);
      if (cardIdx < 0 || casteIdx < 0) return false;
      var map = {};
      reg.rows.forEach(function (r) {
        var id = normId(r[cardIdx]); if (!id || !JC_RE.test(r[cardIdx] || '')) return;
        var c = cellStr(r[casteIdx]);
        if (c && !map[id]) map[id] = c;
      });
      var n = Object.keys(map).length; if (!n) return false;
      chrome.storage.local.get(KEY, function (d) {
        var cur = (d && d[KEY]) || {}; for (var k in map) cur[k] = map[k];
        var total = Object.keys(cur).length, meta = { count: total, savedAt: Date.now() };
        var o = {}; o[KEY] = cur; o[META_KEY] = meta;
        chrome.storage.local.set(o, function () {
          toast('Caste register জমা হয়েছে — এই page থেকে ' + fmt(n) + 'টি Job Card (মোট ' + fmt(total) + ')।');
        });
      });
      return true;
    } catch (e) { return false; }
  }

  /* ---------- Wage list: SmartDesk format report ---------- */
  function showButton() {
    addStyle();
    var b = document.getElementById('kh-wc-btn');
    if (!b) { b = document.createElement('button'); b.id = 'kh-wc-btn'; b.type = 'button'; b.textContent = '⚖ Caste breakup'; document.body.appendChild(b); }
    b.onclick = doBreakup; b.style.display = '';
  }
  function needRegister(missing) {
    var box = openBox('Caste register দরকার');
    var d = document.createElement('div'); d.className = 'kh-body';
    d.innerHTML = (missing
      ? '<b>' + fmt(missing) + 'টি Job Card</b> জমা থাকা register-এ নেই।'
      : 'এখনও কোনো caste register জমা নেই।') +
      '<br>এই GP-র <b>Registration Application Register</b> একবার খুলুন (Analytics &amp; Reports → Registration Application Register)। পুরো list load হলে নিজে থেকেই জমা হবে, কোনো button চাপতে হবে না। তারপর এই page-এ <b>⚖ Caste breakup</b> চাপুন।';
    box.appendChild(d); box.insertAdjacentHTML('beforeend', footer());
  }
  function getInfo() {
    var T = pageText();
    var wl = ((T.match(/Wage\s*List\s*No\.?\s*:\s*-\s*([A-Za-z0-9]+)/i) || [])[1]) || ((T.match(/\b(\d{6,}WL\d{2,})\b/i) || [])[1]) || '';
    var dt = ((T.match(/Wage\s*List\s*Date\.?\s*:\s*-\s*(\d{2}\/\d{2}\/\d{4})/i) || [])[1]) || '';
    return { wl: wl, date: dt };
  }
  function doBreakup() {
    var wage = rawUnion();
    var cardIdx = colIndex(wage, /job\s*card/i);
    var mrIdx = colIndex(wage, /must\s*roll|muster\s*roll|msr\s*no/i);
    var amtIdx = colIndex(wage, /amount\s*of\s*wage/i); if (amtIdx < 0) amtIdx = colIndex(wage, /amount/i);
    if (cardIdx < 0 || amtIdx < 0 || mrIdx < 0) {
      var b0 = openBox('Wage list caste breakup');
      b0.insertAdjacentHTML('beforeend', '<div class="kh-body">এই page-এ wage list-এর table (Job Card, Mustroll No., Amount) পাওয়া যায়নি। Page পুরো load হলে আবার চেষ্টা করুন।</div>' + footer());
      return;
    }
    chrome.storage.local.get([KEY, META_KEY], function (d) {
      var map = (d && d[KEY]) || {}, meta = (d && d[META_KEY]) || null;
      if (!Object.keys(map).length) { needRegister(0); return; }
      var groups = {}, rowCount = 0, total = 0, missingCards = [];
      wage.rows.forEach(function (r) {
        var amtRaw = String(r[amtIdx] == null ? '' : r[amtIdx]).replace(/[^\d.\-]/g, '');
        if (amtRaw === '' || isNaN(parseFloat(amtRaw))) return;      // header / ফাঁকা / non-data row
        if (!JC_RE.test(r[cardIdx] || '')) return;
        var amt = parseFloat(amtRaw) || 0, mr = cellStr(r[mrIdx]) || '—';
        var caste = map[normId(r[cardIdx])];
        var g = groups[mr] || (groups[mr] = { mr: mr, g: 0, sc: 0, st: 0, unknown: 0, unknownJobs: [] });
        if (caste == null) {
          g.unknown += amt; if (g.unknownJobs.indexOf(r[cardIdx]) < 0) g.unknownJobs.push(r[cardIdx]);
          if (missingCards.indexOf(r[cardIdx]) < 0) missingCards.push(r[cardIdx]);
        } else {
          var b = bucket(caste);
          if (b === 'SC') g.sc += amt; else if (b === 'ST') g.st += amt; else g.g += amt;
        }
        total += amt; rowCount++;
      });
      if (!rowCount) { needRegister(0); return; }
      var data = Object.keys(groups).map(function (k) { return groups[k]; })
        .sort(function (a, b) { return (Number(a.mr) || 0) - (Number(b.mr) || 0) || String(a.mr).localeCompare(String(b.mr)); });
      render(data, getInfo(), rowCount, Object.keys(map).length, total, missingCards, meta);
    });
  }

  function render(data, info, rowCount, mapCount, total, missingCards, meta) {
    var box = openBox('VB-G RAM G — Unskilled Report');
    var stated = statedTotal(), msgs = '';
    if (stated > 0) {
      msgs += Math.round(stated) === Math.round(total)
        ? '<div class="kh-msg kh-ok">✓ মোট ' + money(total) + ' — page-এর wage list total-এর সঙ্গে মিলেছে।</div>'
        : '<div class="kh-msg kh-bad">⚠ হিসেবের মোট ' + money(total) + ', কিন্তু page-এ লেখা total ' + money(stated) + '। Page পুরো reload করে আবার চেষ্টা করুন।</div>';
    }
    if (missingCards.length) msgs += '<div class="kh-msg kh-bad">⚠ ' + fmt(missingCards.length) + 'টি Job Card-এর caste জমা register-এ নেই, তাদের টাকা কোনো category-তে ধরা হয়নি (Remarks দেখুন)। এই GP-র Registration Application Register একবার খুললেই ঠিক হবে।</div>';
    if (meta && meta.savedAt && Date.now() - meta.savedAt > STALE_MS) msgs += '<div class="kh-msg kh-bad">জমা থাকা caste register ' + Math.floor((Date.now() - meta.savedAt) / 86400000) + ' দিন পুরনো। নতুন Job Card থাকলে register একবার খুলে নিন।</div>';

    var body = data.map(function (x, i) {
      var remarks = x.unknown ? 'Unmatched Job Card: ' + x.unknownJobs.join(', ') : '';
      return '<tr><td>' + (i + 1) + '</td><td>' + esc(x.mr) + '</td><td>' + esc(info.date) + '</td>' +
        '<td>' + (x.g ? esc(info.wl) : '—') + '</td><td>' + money(x.g) + '</td><td>—</td><td>₹0</td>' +
        '<td>' + (x.sc ? esc(info.wl) : '—') + '</td><td>' + money(x.sc) + '</td><td>—</td><td>₹0</td>' +
        '<td>' + (x.st ? esc(info.wl) : '—') + '</td><td>' + money(x.st) + '</td><td>—</td><td>₹0</td>' +
        '<td' + (remarks ? ' class="kh-warn"' : '') + '>' + esc(remarks) + '</td></tr>';
    }).join('');

    box.insertAdjacentHTML('beforeend',
      '<div class="kh-controls">' +
        '<span>Wage List: <b>' + esc(info.wl || '—') + '</b></span>' +
        '<span>Wage List Date: <b>' + esc(info.date || '—') + '</b></span>' +
        '<span>Wage rows: <b>' + rowCount + '</b></span>' +
        '<span>Caste mappings: <b>' + mapCount + '</b></span>' +
        '<button id="kh-wc-copy">Copy Report</button>' +
      '</div>' + msgs +
      '<div class="kh-scroll"><table id="kh-wc-table"><thead>' +
        '<tr><th rowspan="2">Sl. No.</th><th rowspan="2">Muster Roll Number</th><th rowspan="2">Wage List Date</th>' +
        '<th colspan="4">General Category (40-2505-02-101-00-011-3102)</th>' +
        '<th colspan="4">SC Category (40-2505-02-789-00-011-3102)</th>' +
        '<th colspan="4">ST Category (40-2505-02-796-00-011-3102)</th><th rowspan="2">Remarks</th></tr>' +
        '<tr><th>Unskilled Wagelist No.</th><th>Amount of Unskilled Wage to be paid (in Rs.)</th>' +
        '<th>Semi-Skilled and Skilled Wagelist No.</th><th>Amount of Semi-Skilled and Skilled wage to be paid (in Rs.)</th>' +
        '<th>Unskilled Wagelist No.</th><th>Amount of Unskilled Wage to be paid (in Rs.)</th>' +
        '<th>Semi-Skilled and Skilled Wagelist No.</th><th>Amount of Semi-Skilled and Skilled wage to be paid (in Rs.)</th>' +
        '<th>Unskilled Wagelist No.</th><th>Amount of Unskilled to be paid (in Rs.)</th>' +
        '<th>Semi-Skilled and Skilled Wagelist No.</th><th>Amount of Semi-Skilled and Skilled wage to be paid (in Rs.)</th></tr>' +
      '</thead><tbody>' + body + '</tbody></table></div>' + footer());
    box.querySelector('#kh-wc-copy').onclick = copyReport;
    // দ্বিতীয় header row প্রথমটার ঠিক নিচে আটকে থাকবে (scroll করলে)
    try { var t = box.querySelector('#kh-wc-table'); t.style.setProperty('--kh-h1', t.tHead.rows[0].cells[0].offsetHeight ? (t.tHead.rows[0].offsetHeight + 'px') : '22px'); } catch (e) {}
  }

  function copyReport() {
    var table = document.getElementById('kh-wc-table'); if (!table) return;
    // শুধু tbody-র data row, header নয়
    var text = Array.prototype.map.call(table.querySelectorAll('tbody tr'), function (tr) {
      return Array.prototype.map.call(tr.children, function (c) { return txt(c); }).join('\t');
    }).join('\n');
    function fallback() {
      var ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch (e) {} ta.remove();
      toast(ok ? 'Report copy হয়েছে — Excel-এ paste করুন।' : 'Copy হয়নি। আবার চেষ্টা করুন।', ok);
    }
    try { navigator.clipboard.writeText(text).then(function () { toast('Report copy হয়েছে — Excel-এ paste করুন।'); }, fallback); }
    catch (e) { fallback(); }
  }

  /* ---------- কোন page, কখন চালাবে ---------- */
  // Report সত্যি render হলে তবেই ("Download In Excel" বা job card row) — আধা-load page বা ভুল frame-এ নয়
  function reportReady() { return /Download\s*In\s*Excel/i.test(pageText()) || hasJobCardRow(); }
  function skilledList() { var m = location.search.match(/[?&]flag=([^&]+)/i); return !!(m && !/^UNSK$/i.test(m[1])); }
  function classifyAndFire() {
    var t = pageText(), titled = (document.title || '') + '\n' + t + '\n' + location.href;
    if ((/Registration Application Register/i.test(titled) || /panchregpeople/i.test(location.href)) && hasJobCardRow()) return cacheRegister();
    if (/Wage\s*List/i.test(t) && /Wage\s*List\s*No/i.test(t) && hasJobCardRow()) {
      if (skilledList()) return true;            // Skilled/Semi-skilled list: এই report শুধু Unskilled-এর জন্য
      IS_WAGE = true; doBreakup(); return true;
    }
    return false;
  }
  // v1.2.2-এ button দিয়ে জমা করা caste data নতুন key-তে নিয়ে আসা (একবারই)
  try {
    chrome.storage.local.get(['kh_jobcard_caste_map_v1', KEY], function (d) {
      var old = d && d.kh_jobcard_caste_map_v1; if (!old) return;
      var cur = d[KEY] || {}; for (var k in old) { var id = normId(k); if (!cur[id]) cur[id] = old[k]; }
      var o = {}; o[KEY] = cur; o[META_KEY] = { count: Object.keys(cur).length, savedAt: Date.now() };
      chrome.storage.local.set(o, function () { chrome.storage.local.remove('kh_jobcard_caste_map_v1'); });
    });
  } catch (e) { }

  var fired = false, obs = null;
  function tryFire() { if (fired || !reportReady()) return; if (classifyAndFire()) { fired = true; if (obs) { obs.disconnect(); obs = null; } } }
  try {
    tryFire();
    if (!fired) {
      obs = new MutationObserver(tryFire);
      obs.observe(document.documentElement || document.body, { childList: true, subtree: true, characterData: true });
      setTimeout(function () { if (obs) { obs.disconnect(); obs = null; } }, 90000);   // 90 সেকেন্ড পরে দেখা বন্ধ
    }
  } catch (e) { }
})();
});
