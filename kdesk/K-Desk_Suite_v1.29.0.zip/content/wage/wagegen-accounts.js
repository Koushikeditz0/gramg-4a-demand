/* =====================================================================
   K-Desk Suite by Koushik — Generate Wagelist → Account copy চাই
   (…/vbgramg/SendMSRtoPO.aspx)
   When a work is held back because "Accounts of the Following Records are
   not freezed", the portal shows a table (GridView1): Job Card, Applicant
   no., Name, Account No., Account Freezed. K-Desk adds one button under it
   that sends those workers (Job Card + Applicant No + name only) to the
   Gram Setu app as "📷 Account copy চাই" requests for the GP's
   supervisors (KDLink.askAccounts). Nothing on the page is pressed.
   ===================================================================== */
KH_FEATURE("wls", function () {
(function () {
  "use strict";
  if (window.__KDWGA) return;
  window.__KDWGA = true;

  var JC = /^[A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+$/i, BAR_ID = "kdwga-bar";
  function txt(el) { return el ? String(el.textContent || "").replace(/ /g, " ").replace(/\s+/g, " ").trim() : ""; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function bnNum(n) { return String(n).replace(/[0-9]/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); }

  // The not-frozen table: id ends in GridView1, or any table whose header has "Account Freezed".
  function findTable() {
    var t = document.querySelector('table[id$="GridView1"]');
    if (t && /freez/i.test(txt(t.rows[0]))) return t;
    var all = document.querySelectorAll("table");
    for (var i = 0; i < all.length; i++) {
      var r0 = all[i].rows && all[i].rows[0];
      if (r0 && /account\s*freez/i.test(txt(r0)) && /job\s*card/i.test(txt(r0))) return all[i];
    }
    return null;
  }

  function readRows(t) {
    var head = [].map.call(t.rows[0].cells, function (c) { return txt(c).toLowerCase(); });
    var col = function (re, def) { for (var i = 0; i < head.length; i++) if (re.test(head[i])) return i; return def; };
    var cJ = col(/job\s*card/, 1), cA = col(/applicant\s*no/, 2), cN = col(/applicant\s*name|name/, 3), cAc = col(/account\s*no/, 4), cF = col(/freez/, 5);
    var out = [], seen = {};
    for (var i = 1; i < t.rows.length; i++) {
      var c = t.rows[i].cells; if (!c || c.length <= cJ) continue;
      var jc = txt(c[cJ]).toUpperCase(); if (!JC.test(jc)) continue;
      var ap = (txt(c[cA]).match(/\d+/) || [""])[0], name = txt(c[cN]), acc = txt(c[cAc]).replace(/\s+/g, ""), frz = txt(c[cF]).toUpperCase();
      if (/^(F|Y|FREEZ|FROZEN)/.test(frz)) continue;            // already frozen → not needed
      var k = jc + "|" + ap + "|" + name.toLowerCase(); if (seen[k]) continue; seen[k] = 1;
      out.push({ jc: jc, ap: ap, name: name, noAcc: !acc,
        info: (ap ? "#" + ap + " · " : "") + (acc ? "A/C …" + acc.slice(-4) + " · freeze হয়নি" : "A/C নেই") });
    }
    return out;
  }

  function workLabel() {
    // the ticked work (if any) in the works grid, for the note
    var cb = document.querySelector('table[id$="wagelist_msr"] input[type=checkbox]:checked');
    var tr = cb && cb.closest("tr"); if (!tr) return "";
    var m = txt(tr).match(/\d{10}\/[A-Z]+\/[A-Z]+\/\d+/); return m ? m[0] : "";
  }

  function render() {
    var t = findTable(), old = document.getElementById(BAR_ID);
    if (!t) { if (old) old.remove(); return; }
    var rows = readRows(t), sig = rows.map(function (r) { return r.jc + r.ap; }).join(",");
    if (old && old.getAttribute("data-sig") === sig && old.previousElementSibling === t) return;
    if (old) old.remove();
    if (!rows.length) return;
    var noAcc = rows.filter(function (r) { return r.noAcc; }).length;
    var bar = document.createElement("div"); bar.id = BAR_ID; bar.setAttribute("data-sig", sig);
    bar.style.cssText = "margin:8px 0 4px;padding:9px 12px;border-radius:12px;display:flex;flex-wrap:wrap;gap:10px;align-items:center;" +
      "background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);color:#fff;font:13px/1.35 'Segoe UI','Nirmala UI',system-ui,sans-serif;box-shadow:0 6px 18px rgba(11,20,55,.25)";
    bar.innerHTML =
      "<span style='width:26px;height:26px;border-radius:8px;display:grid;place-items:center;font:800 15px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)'>K</span>" +
      "<span style='flex:1;min-width:200px'><b>" + bnNum(rows.length) + " জনের জন্য wage list আটকে আছে</b><br><small style='color:#c7d2fe'>" +
      (noAcc ? bnNum(noAcc) + " জনের A/C নেই · " : "") + bnNum(rows.length - noAcc) + " জনের account freeze হয়নি</small></span>" +
      "<button type='button' style='cursor:pointer;border:0;border-radius:10px;padding:8px 12px;font:700 12.5px/1.2 inherit;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)'>📷 Account copy চাই → Gram Setu</button>";
    bar.querySelector("button").addEventListener("click", function (e) {
      e.preventDefault(); e.stopPropagation();
      if (!window.KDLink || !window.KDLink.askAccounts) { alert("K-Desk: Gram Setu link লোড হয়নি। Page reload করুন।"); return; }
      var w = workLabel();
      window.KDLink.askAccounts({ rows: readRows(t), source: "Wage List আটকে আছে (account)" + (w ? " · " + w : "") });
    });
    t.parentNode.insertBefore(bar, t.nextSibling);
  }

  render();
  // ASP.NET partial postbacks can replace the grid; re-check now and then (cheap).
  setInterval(render, 2000);
})();
});
