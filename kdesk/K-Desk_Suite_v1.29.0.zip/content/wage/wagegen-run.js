/* =====================================================================
   wagegen-run.js — K-Desk Suite by Koushik · Generate Wage List auto run (isolated world)
   GP login → "Generate Wagelist for Payment" (…/vbgramg/SendMSRtoPO.aspx).
   The portal makes one wage list per ticked work on "View Wagelist", or refuses it with
   "Accounts of the Following Records are not freezed …" and a table (GridView1) of the workers holding it back.
   This presses View Wagelist for every listed work (or only the ticked ones, or only the IAY works), one at a time:
     • generated  → the portal opens View Wage List (view_wagelist.aspx): wage list no., date, amount are logged,
                    then the page's own Home link → the menu's own Generate Wagelist link → GP → Proceed → next work;
     • held back  → the GridView1 table is logged (job card, applicant no., name, account no., freeze status);
     • any other message, or no answer, is logged too.
   Works are found by work code, never by row (a generated work leaves the list and the rows move up).
   Run state: the portal's localStorage "kdwg_run" (survives page loads), mirrored to chrome.storage.local "kdwgLastRun".
   Only the page's own controls are used: Agency drop-down, Proceed, a work's tick box, View Wagelist, Home, menu link.
   At the end the Excel log downloads by itself; everyone who held back a wage list can be sent to Gram Setu
   as "📷 Account copy চাই" (KDLink.askAccounts, same as wagegen-accounts.js).
   Dashboard toggle: "wlgen".
   ===================================================================== */
(function () {
  "use strict";
  if (window.__KDWG) return; window.__KDWG = true;

  var P = (window.KD_MAP ? window.KD_MAP.prefixId("ctl00_ContentPlaceHolder1_") : "ctl00_ContentPlaceHolder1_"), LS = "kdwg_run", MIRROR = "kdwgLastRun", HOST_ID = "kdwg-host", MIN_KEY = "kdwg_min", POS_KEY = "kdwg_pos";
  var STALE = 5 * 60000, WAIT = 150000, JC = /^[A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+$/;
  var path = location.pathname.toLowerCase();
  var ON_GEN = /\/sendmsrtopo\.aspx$/.test(path), ON_VIEW = /\/view_wagelist\.aspx$/.test(path), ON_MENU = /\/indexframe2\.aspx$/.test(path);
  if (!ON_GEN && !ON_VIEW && !ON_MENU) return;
  // only the top page (the portal sometimes loads pages inside frames; one runner is enough)
  try { if (window.top !== window && !ON_GEN) return; } catch (e) {}

  function $(id) { return document.getElementById(id); }
  function norm(s) { return String(s == null ? "" : s).replace(/ /g, " ").replace(/\s+/g, " ").trim(); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function bn(n) { return String(n).replace(/[0-9]/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function hm(t) { var d = new Date(t); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); }
  function stamp(t) { var d = new Date(t); return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + " " + hm(t); }
  function load() { try { return JSON.parse(localStorage.getItem(LS) || "null"); } catch (e) { return null; } }
  function save(r) {
    try { r.at = Date.now(); localStorage.setItem(LS, JSON.stringify(r)); } catch (e) {}
    try { var o = {}; o[MIRROR] = r; chrome.storage.local.set(o); } catch (e) {}
  }
  function note(r, text, level) { (r.log = r.log || []).push({ t: Date.now(), level: level || "info", text: text }); if (r.log.length > 600) r.log.splice(0, r.log.length - 600); }
  function short(code) { return String(code || "").replace(/^\d{10}\//, "…/"); }
  function isIay(w) { return /\/IAY\//i.test(w.code || ""); }
  var MODE_TXT = { all: "সব work", ticked: "tick দেওয়া work", iay: "শুধু IAY work" };

  /* ---------------------- reading the Generate Wagelist page ---------------------- */
  function agency() { return $(P + "exe_agency"); }
  // works grid: Sno · Panchayat · Work Code · Work Name · Select
  function listRows() {
    var t = $(P + "wagelist_msr"); if (!t) return [];
    return [].filter.call(t.rows, function (r) { return r.querySelector("input[type=checkbox]") && r.cells.length >= 4; }).map(function (r) {
      return { code: norm(r.cells[2].textContent), name: norm(r.cells[3].textContent), box: r.querySelector("input[type=checkbox]") };
    }).filter(function (x) { return /\d{10}\//.test(x.code); });
  }
  function msg(doc) { return norm(((doc || document).getElementById(P + "lblmsg") || {}).textContent); }
  // held-back table: header has "Job Card" and "Account Freezed"
  function heldBack(doc) {
    var t = [].filter.call((doc || document).querySelectorAll("table"), function (x) {
      var h = x.rows && x.rows[0]; return h && /account\s*freez/i.test(h.textContent) && /job\s*card/i.test(h.textContent);
    })[0];
    if (!t) return null;
    var head = [].map.call(t.rows[0].cells, function (c) { return norm(c.textContent).toLowerCase(); });
    var ix = function (re) { for (var i = 0; i < head.length; i++) if (re.test(head[i])) return i; return -1; };
    var cJ = ix(/job\s*card/), cA = ix(/applicant\s*no/), cN = ix(/applicant\s*name/), cAc = ix(/account\s*no/), cF = ix(/freez/);
    var out = [];
    [].slice.call(t.rows, 1).forEach(function (tr) {
      var c = function (i) { return i >= 0 && tr.cells[i] ? norm(tr.cells[i].textContent) : ""; };
      var jc = c(cJ).toUpperCase(); if (!JC.test(jc)) return;
      out.push({ jc: jc, ap: (c(cA).match(/\d+/) || [""])[0], name: c(cN), ac: c(cAc).replace(/\s+/g, ""), fz: c(cF).toUpperCase() });
    });
    return out;
  }
  function problem(h) { return !/\d/.test(h.ac || "") ? "No account" : /^(F|Y)/.test(h.fz) ? "Frozen" : "Account not frozen"; }

  /* ---------------------- the run, step by step ---------------------- */
  function counts(r) {
    var gen = 0, held = 0, other = 0, amt = 0, noAc = {}, unf = {};
    (r.results || []).forEach(function (x) {
      if (x.result === "generated") { gen++; amt += Number(x.amount) || 0; }
      else if (x.result === "held") { held++; (x.held || []).forEach(function (h) { var k = h.jc + "|" + h.ap, p = problem(h); if (p === "No account") noAc[k] = h; else if (p === "Account not frozen") unf[k] = h; }); }
      else if (x.result !== "skipped") other++;
    });
    return { gen: gen, held: held, other: other, amt: amt, nNo: Object.keys(noAc).length, nUnf: Object.keys(unf).length };
  }
  function summaryText(r) { var c = counts(r); return c.gen + " generated" + (c.amt ? " (₹" + c.amt + ")" : "") + " · " + c.held + " held back (" + c.nNo + " no A/C, " + c.nUnf + " not frozen)" + (c.other ? " · " + c.other + " other" : ""); }
  function finish(r, why) {
    r.active = false; r.phase = ""; r.cur = null;
    if (!why) { r.finishedAt = Date.now(); note(r, "শেষ: " + summaryText(r) + ".", "ok"); }
    else note(r, why, "warn");
    save(r); render();
    var checks = !why && r.fast && (r.results || []).some(function (x) { return x.result === "check"; });
    if (!why && ON_GEN && !r.logSaved && !checks) { r.logSaved = 1; save(r); setTimeout(function () { download(true); }, 600); }
    // fast mode: the page still shows the works made into wage lists — Proceed once to refresh the list
    if (!why && ON_GEN && r.fast && r.results.some(function (x) { return x.result === "generated" || x.result === "check"; })) {
      if (r.results.some(function (x) { return x.result === "check"; })) { r.verify = 1; save(r); }
      setTimeout(function () { var g = $(P + "go"); if (g) g.click(); }, 2500);
    }
  }
  function record(r, res) {
    res.code = r.cur; res.name = ((r.works || []).filter(function (w) { return w.code === r.cur; })[0] || {}).name || ""; res.t = Date.now();
    r.results.push(res); r.done[r.cur] = 1; r.phase = ""; r.cur = null; r.tries = 0;
    var lvl = res.result === "generated" ? "ok" : res.result === "held" ? "warn" : res.result === "skipped" ? "info" : "err";
    note(r, short(res.code) + ": " + (res.result === "generated" ? "wage list " + res.wl + (res.amount ? " · ₹" + res.amount : "") :
      res.result === "held" ? bn(res.held.length) + " জনের account-এর জন্য আটকে আছে" : res.msg || res.result), lvl);
  }
  // pick the works for a run from the listed rows
  function pickWorks(mode, rows) {
    var list = rows;
    if (mode === "ticked") list = rows.filter(function (x) { return x.box.checked; });
    else if (mode === "iay") list = rows.filter(isIay);
    return list.map(function (x) { return { code: x.code, name: x.name }; });
  }

  // Generate Wagelist page: read the answer to the last View Wagelist, then get the page ready and send the next work
  // fast mode: works whose answer couldn't be read are checked against the refreshed list (gone = wage list made)
  function verifyChecks(r) {
    var rows = listRows(); if (!rows.length && !norm(($(P + "wgfromdt") || {}).value)) return;
    var listed = {}; rows.forEach(function (x) { listed[x.code] = 1; });
    var n = 0;
    r.results.forEach(function (x) {
      if (x.result !== "check") return; n++;
      if (listed[x.code]) { x.result = "not generated"; x.msg = "List-এ এখনও আছে — wage list হয়নি, আবার চালান"; }
      else { x.result = "generated"; x.msg = "List থেকে চলে গেছে — wage list হয়েছে (No: View Wage List-এ দেখুন)"; }
    });
    r.verify = 0; note(r, n + "টা অনিশ্চিত work list-এর সাথে মিলিয়ে দেখা হল।", "ok"); save(r);
    if (n) { r.logSaved = 1; download(true); }
  }
  function stepGen() {
    var r = load();
    if (r && !r.active && r.finishedAt && r.verify) { verifyChecks(r); render(); return; }
    if (!r || !r.active) { render(); return; }
    if (Date.now() - (r.at || 0) > STALE) { finish(r, "Paused: page ৫ মিনিটের বেশি সাড়া দেয়নি (login শেষ?)। ▶ Resume চাপুন।"); return; }
    if (r.phase === "wait" && r.cur && r.fast) {
      // the page reloaded while a background View Wagelist was out: its answer is lost
      record(r, { result: "check", msg: "Page reload হয়ে গেছে, উত্তর পাওয়া যায়নি — portal-এ দেখে নিন wage list হয়েছে কিনা" }); save(r);
    }
    if (r.phase === "wait" && r.cur) {
      var m = msg(), held = heldBack();
      if (/select\s*work/i.test(m)) {
        if ((r.tries = (r.tries || 0) + 1) < 2) { note(r, short(r.cur) + ": tick portal-এ পৌঁছায়নি, আবার চেষ্টা।", "warn"); r.phase = ""; r.retry = r.cur; r.cur = null; }
        else record(r, { result: "error", msg: "Portal দুবার 'Select Work' বলেছে" });
      } else if (held && held.length) record(r, { result: "held", held: held, msg: m });
      else if (m) record(r, { result: "message", msg: m });
      else record(r, { result: "no answer", msg: "Portal কোনো message দেয়নি" });
      save(r);
    }
    if (r.stop) { finish(r, "Stopped। ▶ Resume চাপলে পরের work থেকে চলবে।"); return; }
    var ag = agency(); if (!ag) { finish(r, "এটা GP-র Generate Wagelist page নয়।"); return; }
    if (ag.value !== r.gp.value) {
      if ((r.picks = (r.picks || 0) + 1) > 3) { finish(r, "Agency-তে " + r.gp.name + " বাছা গেল না।"); return; }
      if (![].some.call(ag.options, function (o) { return o.value === r.gp.value; })) { finish(r, r.gp.name + " Agency list-এ নেই।"); return; }
      r.phase = "pick"; save(r); ag.value = r.gp.value; ag.dispatchEvent(new Event("change", { bubbles: true })); return;
    }
    var rows = listRows();
    if (!rows.length) {
      if (!norm(($(P + "wgfromdt") || {}).value) || !norm(($(P + "wgtodt") || {}).value)) { finish(r, "GP বাছার পরে From/To date আসেনি।"); return; }
      if ((r.loads = (r.loads || 0) + 1) > 3) { finish(r, r.works ? "Proceed চাপার পরেও কোনো work আসেনি।" : "এই date-এ wage list করার মতো কোনো work নেই।"); return; }
      r.phase = "load"; save(r); var go = $(P + "go"); if (go) go.click(); else finish(r, "Proceed button পাওয়া যায়নি।"); return;
    }
    r.picks = 0; r.loads = 0;
    if (!r.works) {                                              // started on an empty page: take the list now
      r.works = pickWorks(r.mode, rows);
      r.from = norm(($(P + "wgfromdt") || {}).value); r.to = norm(($(P + "wgtodt") || {}).value);
      note(r, r.works.length + "টা work (" + MODE_TXT[r.mode] + "), " + r.from + " – " + r.to + "।"); save(r);
      if (!r.works.length) { finish(r, r.mode === "iay" ? "List-এ কোনো IAY work নেই।" : "কোনো work নেই।"); return; }
    }
    var by = {}; rows.forEach(function (x) { by[x.code] = x; });
    var next = null;
    if (r.retry && !r.done[r.retry]) next = r.retry;
    for (var i = 0; !next && i < r.works.length; i++) {
      var w = r.works[i]; if (r.done[w.code]) continue;
      if (!by[w.code]) { r.cur = w.code; record(r, { result: "skipped", msg: "List-এ আর নেই (আগেই হয়ে গেছে, বা date-এর বাইরে)" }); continue; }
      next = w.code;
    }
    r.retry = null;
    if (!next) { finish(r); return; }
    rows.forEach(function (x) { if (x.box.checked) x.box.checked = false; });
    by[next].box.click();
    var ticked = rows.filter(function (x) { return x.box.checked; });
    if (ticked.length !== 1 || ticked[0].code !== next) { finish(r, short(next) + " একা tick করা গেল না।"); return; }
    var btn = $(P + "btn_go"); if (!btn) { finish(r, "View Wagelist button পাওয়া যায়নি।"); return; }
    r.phase = "wait"; r.cur = next; r.curAt = Date.now(); save(r); render();
    if (r.fast) { by[next].box.checked = false; fastSend(next, by[next], btn); return; }
    btn.click();
    setTimeout(function () {                                     // no page load within WAIT: log and go on
      var x = load(); if (!x || !x.active || x.phase !== "wait" || x.cur !== next) return;
      record(x, { result: "no answer", msg: Math.round(WAIT / 1000) + " সেকেন্ডে portal সাড়া দেয়নি" }); save(x); stepGen();
    }, WAIT);
  }

  /* ---------------------- fast mode: View Wagelist in the background ----------------------
     Same as Ctrl+click on View Wagelist (the portal answers in a new tab and this page stays): the page's own form,
     with only this work ticked and the View Wagelist button, is posted in the background. This page never changes,
     so there is no Home → menu → Generate Wagelist → Proceed between works. Works already done are never sent again. */
  function formBody(box, btn) {
    var form = btn.form || document.forms[0], fd = new FormData(form), body = new URLSearchParams();
    fd.forEach(function (v, k) {
      if (typeof v !== "string") return;
      var el = form.elements[k];
      if (el && el.type === "checkbox" && el.closest && el.closest("#" + P + "wagelist_msr")) return;   // no other work's tick
      body.append(k, v);
    });
    body.set("__EVENTTARGET", ""); body.set("__EVENTARGUMENT", "");
    body.append(box.name, box.value || "on");
    body.append(btn.name, btn.value);
    return { url: form.action || location.href, body: body };
  }
  function fastSend(code, row, btn) {
    var f = formBody(row.box, btn), ctl = new AbortController(), timer = setTimeout(function () { ctl.abort(); }, WAIT);
    fetch(f.url, { method: "POST", body: f.body, credentials: "include", signal: ctl.signal, headers: { "Content-Type": "application/x-www-form-urlencoded" } })
      .then(function (res) { return res.text().then(function (h) { return { url: res.url, html: h, ok: res.ok, status: res.status }; }); })
      .then(function (x) {
        clearTimeout(timer);
        var r = load(); if (!r || r.cur !== code) return;
        var doc = new DOMParser().parseFromString(x.html, "text/html");
        var raw = docText(doc);
        var view = /view_wagelist\.aspx/i.test(x.url) || /Wage\s*List\s*No/i.test(raw);
        // a page that only moves on by script to View Wage List
        var jump = !view && /(location\.href|window\.open|location\.replace)[^;]*view_wagelist\.aspx/i.exec(x.html);
        if (jump) {
          var u = /['"]([^'"]*view_wagelist\.aspx[^'"]*)['"]/i.exec(jump[0]);
          if (u) return fetch(new URL(u[1], f.url).href, { credentials: "include" }).then(function (y) { return y.text(); }).then(function (h2) {
            var d2 = new DOMParser().parseFromString(h2, "text/html"); fastDone(code, viewResult(docText(d2), d2));
          });
        }
        if (view) { fastDone(code, viewResult(raw, doc)); return; }
        var m = msg(doc), held = heldBack(doc);
        if (!x.ok) fastDone(code, { result: "error", msg: "Portal error " + x.status });
        else if (/select\s*work/i.test(m)) fastDone(code, { result: "error", msg: "Portal বলেছে 'Select Work'" });
        else if (held && held.length) fastDone(code, { result: "held", held: held, msg: m });
        else if (/login|session/i.test(x.url) && !/sendmsrtopo/i.test(x.url)) fastDone(code, { result: "error", msg: "Login শেষ হয়ে গেছে মনে হচ্ছে" }, true);
        else fastDone(code, { result: m ? "message" : "no answer", msg: m || "Portal কোনো message দেয়নি" });
      })
      .catch(function (e) {
        clearTimeout(timer);
        fastDone(code, { result: "check", msg: (e && e.name === "AbortError" ? Math.round(WAIT / 1000) + " সেকেন্ডে উত্তর আসেনি" : "উত্তর পড়া যায়নি (" + (e && e.message || e) + ")") + " — শেষে list মিলিয়ে দেখবে" });
      });
  }
  function fastDone(code, res, stopNow) {
    var r = load(); if (!r || !r.active || r.cur !== code) return;
    record(r, res);
    if (stopNow) { finish(r, "Login শেষ হয়ে গেছে মনে হচ্ছে। আবার login করে Generate Wagelist খুলে ▶ Resume চাপুন।"); return; }
    save(r); render();
    setTimeout(stepGen, 300);
  }
  // a parsed page's text with a space between table cells (textContent alone runs "Sub Total" and "4500" together)
  function docText(doc) {
    if (!doc || !doc.body) return "";
    [].forEach.call(doc.body.querySelectorAll("td,th,br,p,div,span"), function (el) { el.appendChild(doc.createTextNode(" ")); });
    return norm(doc.body.textContent);
  }
  function viewResult(raw, doc) {
    var wl = /Wage\s*List\s*No\.?\s*:?\s*-?\s*([0-9A-Z]*WL\d+)/i.exec(raw), wd = /Wage\s*List\s*Date\.?\s*:?\s*-?\s*(\d{1,2}\/\d{1,2}\/\d{4})/i.exec(raw);
    var subs = (raw.match(/Sub\s*Total\s*:?\s*\d[\d,]*/gi) || []).map(function (x) { return +x.replace(/^[^\d]*/, "").replace(/,/g, ""); });
    var gt = /Grand\s*Total\s*:?\s*(\d[\d,]*)/i.exec(raw);
    var workers = [].filter.call(doc.querySelectorAll("td"), function (td) { return JC.test(norm(td.textContent)); }).length;
    return { result: wl ? "generated" : "message", wl: wl ? wl[1] : "", wlDate: wd ? wd[1] : "", workers: workers,
      amount: gt ? +gt[1].replace(/,/g, "") : subs.reduce(function (a, b) { return a + b; }, 0), msg: wl ? "" : "View Wage List খুলেছে, কিন্তু Wage List No পাওয়া যায়নি" };
  }
  // View Wage List (page mode): the wage list was made — log it, then the page's Home link
  function stepView() {
    var r = load(); if (!r || !r.active || r.phase !== "wait" || !r.cur) return;
    if (Date.now() - (r.at || 0) > STALE) { finish(r, "Paused: page ৫ মিনিটের বেশি সাড়া দেয়নি। Generate Wagelist খুলে ▶ Resume চাপুন।"); return; }
    var raw = norm(document.body ? document.body.innerText || document.body.textContent : "");
    var wl = /Wage\s*List\s*No\.?\s*:?\s*-?\s*([0-9A-Z]*WL\d+)/i.exec(raw), wd = /Wage\s*List\s*Date\.?\s*:?\s*-?\s*(\d{1,2}\/\d{1,2}\/\d{4})/i.exec(raw);
    var subs = (raw.match(/Sub\s*Total\s*:?\s*\d[\d,]*/gi) || []).map(function (x) { return +x.replace(/^[^\d]*/, "").replace(/,/g, ""); });
    var gt = /Grand\s*Total\s*:?\s*(\d[\d,]*)/i.exec(raw);
    var workers = [].filter.call(document.querySelectorAll("td"), function (td) { return JC.test(norm(td.textContent)); }).length;
    record(r, { result: wl ? "generated" : "message", wl: wl ? wl[1] : "", wlDate: wd ? wd[1] : "", workers: workers,
      amount: gt ? +gt[1].replace(/,/g, "") : subs.reduce(function (a, b) { return a + b; }, 0), msg: wl ? "" : "View Wage List খুলেছে, কিন্তু Wage List No পাওয়া যায়নি" });
    if (r.stop) { finish(r, "Wage list page-এ থামানো হল। Generate Wagelist খুলে ▶ Resume চাপুন।"); return; }
    var home = [].filter.call(document.querySelectorAll("a[href]"), function (a) { try { return /\/indexframe2\.aspx$/i.test(new URL(a.getAttribute("href"), location.href).pathname); } catch (e) { return false; } })[0];
    if (!home) { finish(r, "Wage list page-এ Home link নেই। Menu থেকে Generate Wagelist খুলে ▶ Resume চাপুন।"); return; }
    r.phase = "back"; save(r);
    setTimeout(function () { home.click(); }, 1200);
  }
  // the menu: its own link to Generate Wagelist
  function stepMenu() {
    var r = load(); if (!r || !r.active || r.phase !== "back") return;
    if (Date.now() - (r.at || 0) > STALE) { finish(r, "Paused: page ৫ মিনিটের বেশি সাড়া দেয়নি। Generate Wagelist খুলে ▶ Resume চাপুন।"); return; }
    var a = [].filter.call(document.querySelectorAll("a[href]"), function (x) { try { return /\/sendmsrtopo\.aspx$/i.test(new URL(x.getAttribute("href"), location.href).pathname); } catch (e) { return false; } })[0];
    if (!a) { finish(r, "Menu-তে Generate Wagelist link পাওয়া যায়নি। নিজে খুলে ▶ Resume চাপুন।"); return; }
    r.phase = "menu"; save(r);
    setTimeout(function () { a.click(); }, 800);
  }

  /* ---------------------- start / stop ---------------------- */
  var confirming = null;                                         // "all" | "ticked" | "iay" while the confirm box is open
  function askStart(mode) {
    // v1.24.0: 🩺 Health Check — দরকারি field না পেলে Start থামে (shared/kd-health.js)
    if (window.KD_HEALTH && !window.KD_HEALTH.gate("wagegen", function () { askStartChecked(mode); }, "Generate Wagelist")) { status("Health Check: portal-এর কিছু field পাওয়া যায়নি — Start হয়নি।", "warn"); return; }
    if (!window.KD_HEALTH) askStartChecked(mode);
  }
  function askStartChecked(mode) {
    var r = load();
    if (r && r.active) return;
    var ag = agency(); if (!ag) { status("এটা GP-র Generate Wagelist page নয়।", "warn"); return; }
    var o = ag.options[ag.selectedIndex];
    if (!o || !/\d{6,}/.test(o.value)) {
      var gps = [].filter.call(ag.options, function (x) { return /\d{6,}/.test(x.value); });
      if (gps.length !== 1) { status(gps.length ? "আগে Agency-তে Panchayat বাছুন।" : "Agency list-এ কোনো Gram Panchayat নেই।", "warn"); return; }
    }
    var rows = listRows();
    if (mode === "all" && rows.some(function (x) { return x.box.checked; })) mode = "ticked";
    if (rows.length && !pickWorks(mode, rows).length) { status(mode === "iay" ? "List-এ কোনো IAY work নেই।" : "কোনো work নেই।", "warn"); return; }
    confirming = mode; render();
  }
  function doStart() {
    var mode = confirming; confirming = null; if (!mode) return;
    var ag = agency(); if (!ag) return;
    var o = ag.options[ag.selectedIndex];
    if (!o || !/\d{6,}/.test(o.value)) o = [].filter.call(ag.options, function (x) { return /\d{6,}/.test(x.value); })[0];
    if (!o) return;
    var rows = listRows(), fy = $(P + "ddlstFinyear");
    var r = { v: 1, runId: "kdwg-" + Date.now(), active: true, stop: false, startedAt: Date.now(), mode: mode,
      gp: { value: o.value, name: norm(o.text).replace(/^Gram Panchayat-/i, "") },
      fy: fy && fy.selectedIndex >= 0 ? norm(fy.options[fy.selectedIndex].text) : "",
      from: norm(($(P + "wgfromdt") || {}).value), to: norm(($(P + "wgtodt") || {}).value),
      works: rows.length ? pickWorks(mode, rows) : null, done: {}, results: [], phase: "", cur: null, log: [], fast: fastPref() };
    note(r, r.works ? "শুরু: " + r.gp.name + ", " + r.works.length + "টা work (" + MODE_TXT[mode] + "), " + r.from + " – " + r.to + "।" : "শুরু: " + r.gp.name + " — GP বেছে Proceed চাপছে (" + MODE_TXT[mode] + ")।");
    if (!r.fast) note(r, "পুরোনো পদ্ধতি: প্রতিটা wage list-এর পরে Home → menu দিয়ে ফিরবে।");
    save(r); stepGen();
  }
  function fastPref() { try { return localStorage.getItem("kdwg_fast") !== "0"; } catch (e) { return true; } }
  function resume() {
    var r = load(); if (!r || r.active || r.finishedAt) return;
    r.active = true; r.stop = false; r.phase = ""; r.cur = null; r.picks = 0; r.loads = 0; r.fast = fastPref();
    note(r, "Resumed."); save(r); stepGen();
  }
  function stopRun() { var r = load(); if (!r || !r.active) return; r.stop = true; note(r, "Stop চাপা হয়েছে: হাতের work শেষ হলে থামবে।", "warn"); save(r); render(); }
  function newRun() {
    var r = load(); if (r && r.active) { status("আগে Stop করুন।", "warn"); return; }
    if (r && !r.logSaved && !window.confirm("আগের run-এর log মুছে দেবেন? দরকার হলে আগে ⭳ Log download করুন।")) return;
    try { localStorage.removeItem(LS); } catch (e) {}
    status("মুছে দেওয়া হয়েছে।", "ok"); render();
  }

  /* ---------------------- Excel log ---------------------- */
  function download(auto) {
    var r = load(); if (!r || !r.results || !r.results.length) { if (!auto) status("Log খালি।", "warn"); return; }
    if (!window.XLSX) { status("Spreadsheet library load হয়নি — page reload করুন।", "warn"); return; }
    var A = [["Work Code", "Work Name", "Result", "Wage List No.", "Wage List Date", "Workers", "Amount (₹)", "Held back by", "Portal message", "Time"]];
    var H = [["Work Code", "Work Name", "Job Card No.", "Applicant no.", "Applicant Name", "Account No.", "Account Freezed", "Problem"]];
    var W = {};
    r.results.forEach(function (x) {
      A.push([x.code, x.name, x.result, x.wl || "", x.wlDate || "", x.workers || "", x.amount || "", x.held ? x.held.length : "", x.msg || "", stamp(x.t)]);
      (x.held || []).forEach(function (h) {
        H.push([x.code, x.name, h.jc, h.ap, h.name, h.ac, h.fz, problem(h)]);
        var k = h.jc + "|" + h.ap; (W[k] = W[k] || { h: h, works: [] }).works.push(x.code);
      });
    });
    var WK = [["Job Card No.", "Applicant no.", "Applicant Name", "Account No.", "Account Freezed", "Problem", "Works held back", "Work Codes"]];
    Object.keys(W).map(function (k) { return W[k]; }).sort(function (a, b) { return a.h.jc < b.h.jc ? -1 : a.h.jc > b.h.jc ? 1 : 0; })
      .forEach(function (w) { WK.push([w.h.jc, w.h.ap, w.h.name, w.h.ac, w.h.fz, problem(w.h), w.works.length, w.works.join(", ")]); });
    var wb = XLSX.utils.book_new(), add = function (aoa, name, cols) { var ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = cols.map(function (w) { return { wch: w }; }); XLSX.utils.book_append_sheet(wb, ws, name); };
    add(A, "By work", [34, 50, 11, 26, 12, 8, 11, 11, 60, 17]);
    add(H, "Held back", [34, 40, 24, 9, 24, 20, 9, 18]);
    add(WK, "Workers", [24, 9, 24, 20, 9, 18, 8, 60]);
    var d = new Date(), name = "Wagelist-" + (r.mode === "iay" ? "IAY-" : "") + String(r.gp.name || "GP").replace(/[^\w-]+/g, "_") + "-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()) + ".xlsx";
    XLSX.writeFile(wb, name); status("Saved " + name + "।", "ok");
  }

  /* ---------------------- held-back workers → Gram Setu ---------------------- */
  function runPeople(r) {
    var by = {};
    ((r && r.results) || []).forEach(function (x) {
      if (x.result !== "held") return;
      (x.held || []).forEach(function (h) {
        var p = problem(h); if (p === "Frozen") return;
        var k = h.jc + "|" + h.ap; if (by[k]) return;
        by[k] = { jc: h.jc, ap: h.ap, name: h.name, noAcc: p === "No account",
          info: (h.ap ? "#" + h.ap + " · " : "") + (p === "No account" ? "A/C নেই" : "A/C …" + String(h.ac).replace(/\D/g, "").slice(-4) + " · freeze হয়নি") };
      });
    });
    return Object.keys(by).sort().map(function (k) { return by[k]; });
  }
  function askAccounts() {
    var r = load(), rows = runPeople(r);
    if (!rows.length) { status("কাউকে পাঠানোর নেই।", "warn"); return; }
    if (!window.KDLink || !window.KDLink.askAccounts) { status("Gram Setu link load হয়নি — page reload করুন।", "warn"); return; }
    window.KDLink.askAccounts({ rows: rows, source: "Wage List আটকে আছে (account) · " + (r.mode === "iay" ? "IAY " : "") + "auto run " + stamp(r.startedAt) });
  }

  /* ---------------------- panel ---------------------- */
  var sel = {};
  function status(m, kind) { if (!sel.st) return; sel.st.textContent = m || ""; sel.st.className = "st" + (kind ? " " + kind : ""); sel.st.hidden = !m; }
  function render() {
    if (!sel.sum) return;
    var r = load(), active = !!(r && r.active), paused = !!(r && !active && !r.finishedAt);
    var rows = listRows();
    if (!r) {
      var t = rows.filter(function (x) { return x.box.checked; }).length, ni = rows.filter(isIay).length;
      sel.sum.innerHTML = rows.length ? "<b>" + bn(rows.length) + "</b>টা work list-এ" + (ni ? " (IAY <b>" + bn(ni) + "</b>টা)" : "") + (t ? " · <b>" + bn(t) + "</b>টায় tick (শুধু সেগুলো চলবে)" : "") + "।<br>Start চাপলে একটা একটা করে <b>View Wagelist</b> চাপবে।"
        : "Start চাপলে Panchayat বেছে <b>Proceed</b> চাপবে, তারপর প্রতিটা work-এ <b>View Wagelist</b>।";
      sel.prog.hidden = true;
    } else {
      var c = counts(r), N = (r.works || []).length, D = Object.keys(r.done || {}).length;
      sel.sum.innerHTML = (r.finishedAt ? "✓ শেষ · " : active ? "চলছে · " : "Paused · ") + "<b>" + D + "/" + N + "</b> work · " + esc(r.gp.name) + " · " + esc(MODE_TXT[r.mode] || "") +
        "<br>Generated <b>" + c.gen + "</b>" + (c.amt ? " (₹" + c.amt + ")" : "") + " · আটকে <b>" + c.held + "</b>" + (c.other ? " · অন্য <b>" + c.other + "</b>" : "") +
        "<br>A/C নেই <b>" + c.nNo + "</b> জন · freeze হয়নি <b>" + c.nUnf + "</b> জন" +
        (active && r.cur ? "<br><span class='cur'>এখন: " + esc(short(r.cur)) + "</span>" : "");
      var pct = N ? Math.round(100 * D / N) : 0;
      sel.prog.hidden = false; sel.fill.style.width = pct + "%"; sel.ptxt.textContent = D + "/" + N + " (" + pct + "%)";
    }
    var idle = !r || !!r.finishedAt;
    sel.starts.hidden = !idle || !!confirming; sel.res.hidden = !paused; sel.fastrow.hidden = active;
    sel.cfm.hidden = !confirming;
    if (confirming) {
      var n = rows.length ? pickWorks(confirming, rows).length : 0;
      sel.cfmtxt.innerHTML = (n ? "<b>" + bn(n) + "</b>টা work (" + MODE_TXT[confirming] + ")" : "Proceed-এর পরে যা আসবে (" + MODE_TXT[confirming] + ")") +
        "-এ একটা একটা করে <b>View Wagelist</b> চাপবে।<br>যে work ready, সেটা portal-এ <b>সত্যিকারের wage list</b> হয়ে যাবে। Account-এর জন্য আটকালে তার table log-এ থাকবে।";
    }
    sel.stop.disabled = !active || !!(r && r.stop);
    sel.dl.disabled = !(r && r.results && r.results.length);
    sel.newr.disabled = active || !r;
    var ppl = active ? [] : runPeople(r);
    sel.ask.hidden = !ppl.length; sel.ask.textContent = "📷 Account copy চাই → Gram Setu (" + bn(ppl.length) + " জন)";
    var L = (r && r.log) || [], h = "";
    for (var k = L.length - 1, m = 0; k >= 0 && m < 200; k--, m++) h += "<div class='l-" + esc(L[k].level) + "'><span class='lt'>" + hm(L[k].t) + "</span>" + esc(L[k].text) + "</div>";
    sel.logbox.innerHTML = h || "<div class='l-info'>এখনো কিছু হয়নি।</div>";
  }
  var STYLE =
    ".panel{width:370px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:13px;color:#1e1b4b;background:linear-gradient(180deg,#f3f4ff,#e8eafc);border:1px solid #c9cef3;border-radius:16px;box-shadow:0 18px 50px rgba(30,27,75,.30);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:10px 12px;display:flex;align-items:center;justify-content:space-between;cursor:move}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hdl{display:flex;align-items:center;gap:9px;min-width:0}.ttl b{display:block;font-size:14px}.ttl small{display:block;font-size:10px;color:#c7d2fe;letter-spacing:.6px;text-transform:uppercase}.ttl small i{font-style:normal;color:#f5b942;font-weight:600;text-transform:none}" +
    ".logo{width:28px;height:28px;border-radius:8px;flex:0 0 auto;display:grid;place-items:center;font:800 15px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:24px;height:24px;border-radius:6px;font-size:15px;line-height:1}" +
    ".bd{padding:10px 12px;max-height:80vh;overflow:auto}" +
    ".summary{font-size:12px;background:#fff;border:1px solid #d4d8f5;border-left:4px solid #f5b942;border-radius:10px;padding:8px 10px;line-height:1.45}.summary .cur{color:#5b6472}" +
    ".prog{margin:8px 0}.progbar{height:8px;background:#d4d8f5;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#e08e0b;transition:width .3s}.progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".btn{padding:8px 9px;border:none;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;min-height:34px}.btnrow{display:flex;gap:6px;margin-top:7px}.btnrow .btn{flex:1}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.iay{color:#fff;background:linear-gradient(135deg,#0f766e,#0d9488)}" +
    ".btn.stop{background:#c5221f;color:#fff}.btn.stop:disabled{background:#e6a6a4;cursor:not-allowed}" +
    ".btn.ghost{background:#f5f6ff;color:#1e1b4b;border:1px solid #d4d8f5}.btn.ghost:disabled{color:#aab;cursor:not-allowed}.btn.ghost.danger{background:#fff1f2;color:#be123c;border-color:#fecdd3}.btn.ghost.danger:disabled{background:#f5f6ff;color:#c9a9a8}" +
    ".cfm{margin:8px 0;padding:8px;border:1px solid #f2d98a;background:#fef7e0;border-radius:9px;font-size:11.5px;color:#5a4300;line-height:1.45}.cfmh{font-weight:700;color:#9a6700;margin-bottom:4px}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:7px;background:#f5f6ff;line-height:1.35}.st.ok{background:#dcfce7;color:#166534}.st.warn{background:#fef3c7;color:#92400e}" +
    ".sec{font-weight:700;color:#3730a3;margin:10px 0 6px;border-top:1px solid #d4d8f5;padding-top:8px;font-size:12px}" +
    ".logbox{max-height:170px;overflow:auto;font-size:10.5px;line-height:1.4;background:#0b1437;color:#cbd5e1;border-radius:8px;padding:6px 8px}.logbox div{padding:1px 0;border-bottom:1px dotted #1e2a5a}" +
    ".l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#cbd5e1}.lt{display:inline-block;color:#aab2c0;margin-right:6px}" +
    ".hint{font-size:11px;color:#5b6472;margin-top:7px;line-height:1.4}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#7a8090;line-height:1.35;background:#f5f6ff;border:1px solid #d4d8f5;border-radius:7px;padding:5px 7px}" +
    ".opt{display:flex;gap:6px;align-items:flex-start;font-size:11.5px;margin-top:8px;cursor:pointer;line-height:1.35}.opt input{margin:2px 0 0;accent-color:#3730a3}.foot{margin-top:8px;padding-top:6px;border-top:1px solid #d4d8f5;display:flex;justify-content:space-between;font-size:10.5px;color:#5b5f8a}.foot b{color:#1e1b4b}.foot em{font-style:normal;color:#c2770a}[hidden]{display:none!important}";
  var HTML =
    "<div class='hd' id='kw_hd'><span class='hdl'><span class='logo'>K</span><span class='ttl'><b>Generate Wage List · Auto</b><small><i>K-Desk</i> Suite · একটা একটা work</small></span></span><button class='mn' id='kw_min'>–</button></div>" +
    "<div class='bd' id='kw_bd'>" +
    "<div class='summary' id='kw_sum'></div>" +
    "<div class='prog' id='kw_prog' hidden><div class='progbar'><div class='progfill' id='kw_fill'></div></div><div class='progtxt' id='kw_ptxt'></div></div>" +
    "<label class='opt' id='kw_fastrow'><input type='checkbox' id='kw_fast'> ⚡ দ্রুত: View Wagelist পেছনে (Ctrl+click-এর মতো), page বদলাবে না</label>" +
    "<div class='btnrow' id='kw_starts'><button class='btn fill' id='kw_all'>▶ Start (সব work)</button><button class='btn iay' id='kw_iay'>🏠 শুধু IAY</button></div>" +
    "<div class='btnrow' id='kw_res' hidden><button class='btn fill' id='kw_resume'>▶ Resume</button></div>" +
    "<div class='cfm' id='kw_cfm' hidden><div class='cfmh'>⚠ সত্যি wage list তৈরি হবে</div><div id='kw_cfmtxt'></div>" +
      "<div class='btnrow'><button class='btn fill' id='kw_yes'>হ্যাঁ, শুরু করুন</button><button class='btn ghost' id='kw_no'>বাতিল</button></div></div>" +
    "<div class='btnrow'><button class='btn stop' id='kw_stop'>■ Stop</button><button class='btn ghost' id='kw_dl'>⭳ Log (Excel)</button></div>" +
    "<div class='btnrow'><button class='btn fill' id='kw_ask' hidden></button></div>" +
    "<div class='btnrow'><button class='btn ghost danger' id='kw_new'>↺ New run (clear)</button></div>" +
    "<div class='st' id='kw_st' hidden></div>" +
    "<div class='sec'>Activity</div><div class='logbox' id='kw_logbox'></div>" +
    "<div class='hint'>কিছু work-এ tick দিয়ে <b>Start</b> চাপলে শুধু সেগুলো চলবে। <b>🏠 শুধু IAY</b> চাপলে শুধু যে work code-এ <b>/IAY/</b> আছে সেগুলো। ⚡ দ্রুত চালু থাকলে page একই থাকে; বন্ধ করলে প্রতিটা wage list-এর পরে Home → menu দিয়ে ফেরে।</div>" +
    "<div class='disclaimer'>⚠ এটা portal-এ সত্যিকারের wage list তৈরি করে। শেষে log দেখে portal-এ মিলিয়ে নিন। যেকোনো সময় ■ Stop চাপা যায়।</div>" +
    "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>K-Desk v<span id='kw_ver'></span></em></div>" +
    "</div>";

  function build() {
    if ($(HOST_ID)) return;
    var host = document.createElement("div"); host.id = HOST_ID;
    var kdW = 58; try { if (localStorage.getItem("kd_wide") === "1" && localStorage.getItem("kd_collapsed") !== "1") kdW = 200; } catch (e) {}
    host.style.cssText = "position:fixed;top:0;right:" + kdW + "px;left:auto;z-index:2147483646;";
    var pos = null; try { pos = JSON.parse(localStorage.getItem(POS_KEY) || "null"); } catch (e) {}
    if (pos && pos.l >= 0 && pos.t >= 0 && pos.l < window.innerWidth - 60 && pos.t < window.innerHeight - 40) { host.style.left = pos.l + "px"; host.style.top = pos.t + "px"; host.style.right = "auto"; }
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE; root.appendChild(css);
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML; root.appendChild(box);
    ["hd", "min", "bd", "ver", "sum", "prog", "fill", "ptxt", "starts", "all", "iay", "res", "resume", "cfm", "cfmtxt", "yes", "no", "stop", "dl", "ask", "new", "st", "logbox", "fast", "fastrow"]
      .forEach(function (id) { sel[id === "new" ? "newr" : id] = root.getElementById("kw_" + id); });
    try { sel.ver.textContent = chrome.runtime.getManifest().version; } catch (e) {}
    try { if (localStorage.getItem(MIN_KEY) === "1") { sel.bd.style.display = "none"; sel.min.textContent = "+"; } } catch (e) {}
    sel.fast.checked = fastPref();
    sel.fast.addEventListener("change", function () { try { localStorage.setItem("kdwg_fast", sel.fast.checked ? "1" : "0"); } catch (e) {} });
    sel.all.addEventListener("click", function () { askStart("all"); });
    sel.iay.addEventListener("click", function () { askStart("iay"); });
    sel.yes.addEventListener("click", doStart);
    sel.no.addEventListener("click", function () { confirming = null; render(); });
    sel.resume.addEventListener("click", resume);
    sel.stop.addEventListener("click", stopRun);
    sel.dl.addEventListener("click", function () { download(false); });
    sel.ask.addEventListener("click", askAccounts);
    sel.newr.addEventListener("click", newRun);
    sel.min.addEventListener("click", function () { var hide = sel.bd.style.display !== "none"; sel.bd.style.display = hide ? "none" : "block"; sel.min.textContent = hide ? "+" : "–"; try { localStorage.setItem(MIN_KEY, hide ? "1" : "0"); } catch (e) {} });
    var sx, sy, ox, oy, drag = false;
    sel.hd.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
    document.addEventListener("mouseup", function () {
      if (!drag) return; drag = false;
      var rr = host.getBoundingClientRect(); try { localStorage.setItem(POS_KEY, JSON.stringify({ l: Math.max(0, Math.round(rr.left)), t: Math.max(0, Math.round(rr.top)) })); } catch (e) {}
    });
    render(); setInterval(render, 1500);
  }

  if (window.__KDWG_TEST) window.__KDWG_TEST({ heldBack: heldBack, problem: problem, counts: counts, listRows: listRows, pickWorks: pickWorks, runPeople: runPeople });
  function boot() {
    if (ON_GEN) { if (agency()) build(); setTimeout(stepGen, 700); }
    else if (ON_VIEW) setTimeout(stepView, 900);
    else if (ON_MENU) setTimeout(stepMenu, 900);
  }
  function start() {
    // on the wage list page and the menu it only carries a run that is going
    if (!ON_GEN) { var r = load(); if (!r || !r.active) return; }
    if (window.KH_FEATURE) window.KH_FEATURE("wlgen", boot); else boot();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
