KH_FEATURE("wls", function () {
/* =====================================================================
   K-Desk Suite by Koushik — Wage List Status   (…/vbgramg/view_wagelist.aspx)
   Beside every Job seeker Name: eKYC ✓/✗ and ABPS ✓/✗ from the synced
   eKYC/ABPS data (abps.js), plus — where the NPCI ABPS-enable run already
   checked the worker — the portal's reason and the next step. Export the
   open wage list, or build a whole-GP "payment readiness" report across
   every wage list in the dropdown (read in the background; the page itself
   never changes). The Aadhaar No. column is never read.
   ===================================================================== */
(function () {
  "use strict";
  if (window.__DXWLS) return;
  // View Wagelist-এর dropdown ID এখন shared/portal-map.js (page "wlview") থেকে; map না থাকলে আগের মান
  var WLID = window.KD_MAP ? window.KD_MAP.id("wlview", "wl", "ddl_sel") : "ddl_sel";
  var FYID = window.KD_MAP ? window.KD_MAP.id("wlview", "fy", "ddlFinYr") : "ddlFinYr";
  var SEL = document.getElementById(WLID) || document.querySelector('select[id$="' + WLID + '"]');
  var JC = /^WB-\d{2}-\d{3}-\d{3}-\d{3}\/\d+$/;
  if (!SEL && !hasWorkers(document)) return;
  window.__DXWLS = true;


  // একই page-এ অন্য extension (GramG Ninja / SmartDesk) চালু থাকলে তাদের একই রকম popup/button লুকিয়ে রাখা,
  // যাতে শুধু Helper-এর report দেখা যায়
  (function hideOthers() {
    try {
      if (document.getElementById('kh-hide-other-wls')) return;
      var st = document.createElement('style'); st.id = 'kh-hide-other-wls';
      st.textContent = '#dxwls-host,.gn-wls,#smartdesk-wage-status-panel,#smartdesk-wage-status-run,.smartdesk-wage-chip{display:none!important}';
      (document.head || document.documentElement).appendChild(st);
    } catch (e) {}
  })();

  var MIN_KEY = "khwls_min", HOST_ID = "khwls-host";
  var abps = { map: {}, meta: {} }, npci = {}, sel = {}, onlyBad = false, busy = false, current = [];

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function txt(el) { return el ? String(el.innerText != null ? el.innerText : el.textContent || "").replace(/\s+/g, " ").trim() : ""; }
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function dmy(t) { var d = new Date(t); return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear(); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function status(t, kind) { if (sel.st) { sel.st.textContent = t || ""; sel.st.className = "st" + (kind ? " " + kind : ""); } }

  /* ---------------------- extract workers from a wage-list page (live or fetched) ---------------------- */
  function hasWorkers(doc) { return [].some.call(doc.querySelectorAll("td"), function (td) { return JC.test(txt(td)); }); }
  function headerMap(table, jc) {
    var h = null;
    for (var i = 0; i < table.rows.length; i++) if (/job\s*card/i.test(txt(table.rows[i])) && /seeker/i.test(txt(table.rows[i]))) { h = table.rows[i]; break; }
    var m = { jc: jc, name: jc + 1, bank: jc + 2, acct: jc + 4, slip: jc + 5, work: jc + 6, msr: jc + 7, att: jc + 9, amt: -1 };
    if (h) {
      var find = function (re) { for (var k = 0; k < h.cells.length; k++) if (re.test(txt(h.cells[k]))) return k; return -1; };
      var set = function (key, re) { var k = find(re); if (k >= 0) m[key] = k; };
      set("jc", /job\s*card/i); set("name", /seeker/i); set("bank", /as\s*per\s*bank|bank\s*\/\s*post/i); set("acct", /account/i);
      set("slip", /wage\s*slip/i); set("work", /work\s*code/i); set("msr", /must?\s*roll\s*no/i); set("att", /attendance/i); set("amt", /amount/i);
    }
    return m;
  }
  // smallest elements whose text matches re (no child that also matches)
  function leaves(doc, re) {
    return [].filter.call(doc.querySelectorAll("th,td,span,div,b,strong,font,p"), function (e) {
      return re.test(e.textContent || "") && ![].some.call(e.children, function (c) { return re.test(c.textContent || ""); });
    });
  }
  function before(a, b) { return !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING); }
  // the "Wage List No.:-… / Agency No.:-… / Date.:-…" block that precedes a worker table, plus the bank line above it
  function blockInfo(doc) {
    var banks = leaves(doc, /Bank\s*Name\s*:|Post\s*Office\s*Name\s*:/i).map(function (e) {
      var line = e; while (line.parentElement && !/Branch\s*Name/i.test(line.textContent || "") && line.parentElement !== doc.body) line = line.parentElement;
      var t = (line.textContent || "").replace(/\s+/g, " ");
      var bn = (t.match(/(?:Bank|Post\s*Office)\s*Name\s*:\s*(.+?)(?=\s*(?:Branch|IFSC|$))/i) || [])[1] || "";
      var br = (t.match(/Branch\s*Name\s*:\s*(.+?)(?=\s*(?:IFSC|Bank|$))/i) || [])[1] || "";
      return { el: e, name: (bn + (br ? " · " + br : "")).trim() };
    });
    return leaves(doc, /Wage\s*List\s*No\.?\s*:-/i).map(function (e) {
      var box = e.closest("table") || e.parentElement, t = (box.textContent || "").replace(/\s+/g, " ");
      var g = function (re) { var x = t.match(re); return x ? x[1].trim() : ""; };
      var bank = ""; banks.forEach(function (bk) { if (before(bk.el, e)) bank = bk.name; });
      return { el: e, wl: g(/Wage\s*List\s*No\.?\s*:-\s*(\d+WL\d+)/i), agency: g(/Agency\s*No\.?\s*:-\s*(\d+WL\d+(?:-[A-Z0-9]+)*?)(?=Wage|Mus|\s|$)/i), date: g(/Wage\s*List\s*Date\.?\s*:-\s*([\d\/]+)/i), bank: bank };
    });
  }
  function extractWorkers(doc, fallbackWl) {
    var blocks = blockInfo(doc), out = [], maps = new Map();
    [].forEach.call(doc.querySelectorAll("tr"), function (tr) {
      if (tr.querySelector("tr")) return;
      var jc = -1; for (var i = 0; i < tr.cells.length; i++) if (JC.test(txt(tr.cells[i]))) { jc = i; break; }
      if (jc < 0) return;
      var table = tr.closest("table"); if (!maps.has(table)) maps.set(table, headerMap(table, jc));
      var m = maps.get(table), c = function (k) { var i = m[k]; if (k === "amt" && i < 0) i = tr.cells.length - 1; return i >= 0 && tr.cells[i] ? txt(tr.cells[i]) : ""; };
      var blk = null; for (var b = 0; b < blocks.length; b++) if (blocks[b].el.compareDocumentPosition(tr) & Node.DOCUMENT_POSITION_FOLLOWING) blk = blocks[b];
      out.push({ row: doc === document ? tr : null, nameCell: doc === document ? tr.cells[m.name] : null,
        wl: (blk && blk.wl) || fallbackWl || "", date: (blk && blk.date) || "", bank: (blk && blk.bank) || "",
        sno: txt(tr.cells[0]), job: c("jc"), name: c("name"), bankName: c("bank"), acct: c("acct"), slip: c("slip"),
        work: c("work"), msr: c("msr"), att: c("att"), amt: c("amt") });
    });
    return out;
  }

  /* ---------------------- status per worker ---------------------- */
  function npciFor(job, name) {
    var list = npci[DX.normKey(job, "id")]; if (!list) return null;
    var best = null, bs = 0;
    list.forEach(function (x) { var s = DX.nameScore(name, x.name, 0.82); if (s > bs) { bs = s; best = x; } });
    return best;
  }
  function nextStep(w) {
    var m = String((w.np && w.np.msg) || "");
    if (w.np && w.np.result === "Saved") return "Enabled for DBT (NPCI run " + dmy(w.np.t) + ")";
    if (/disabled.*(mapper|bank)/i.test(m)) return "Visit the bank branch to re-seed Aadhaar in the NPCI mapper";
    if (/not\s+linked|not\s+seeded/i.test(m)) return "Seed Aadhaar with NPCI at the bank branch (account-holder's bank)";
    if (!w.found) return "Not in ABPS data — re-sync the Aadhaar/ABPS report";
    if (!w.ekyc) return w.aadhaar ? "Complete eKYC" : "Seed Aadhaar, then complete eKYC";
    if (!w.abps) return w.np ? (m || "Check the NPCI result") : "Enable ABPS (NPCI page: Check with NPCI, then Save)";
    return "";
  }
  function assess(list) {
    list.forEach(function (w) {
      var a = DX.abpsFind(abps.map, w.job, w.name);
      w.found = !!a; w.ekyc = !!(a && a.ekyc); w.abps = !!(a && a.abps); w.aadhaar = !!(a && a.aadhaar);
      w.np = npciFor(w.job, w.name);
      w.ready = w.found && w.ekyc && w.abps;
      w.next = nextStep(w);
    });
    return list;
  }

  /* ---------------------- on the page ---------------------- */
  var CHIP = "display:inline-block;margin-left:5px;padding:1px 6px;border-radius:10px;font:700 10px/1.5 Segoe UI,Arial,sans-serif;vertical-align:middle;white-space:nowrap;";
  function chip(label, ok, title) {
    var s = document.createElement("span");
    s.className = "kh-wls";
    s.textContent = label + (ok === null ? " ?" : ok ? " ✓" : " ✗");
    s.style.cssText = CHIP + (ok === null ? "background:#eef0f4;color:#5b6472" : ok ? "background:#e7f4ec;color:#137333" : "background:#fdecea;color:#c5221f");
    s.title = title;
    return s;
  }
  function paint() {
    [].forEach.call(document.querySelectorAll(".kh-wls"), function (e) { e.remove(); });
    current.forEach(function (w) {
      if (!w.nameCell) return;
      var tip = "K-Desk Suite · " + (w.found ? "eKYC " + (w.ekyc ? "done" : "not done") + ", ABPS " + (w.abps ? "enabled" : "not enabled") : "not in the synced ABPS data") +
        (w.np ? "\nNPCI check: " + (w.np.result || "") + (w.np.msg ? " — " + w.np.msg : "") : "") + (w.next ? "\nNext step: " + w.next : "");
      if (!w.found) w.nameCell.appendChild(chip("ABPS data", null, tip));
      else { w.nameCell.appendChild(chip("eKYC", w.ekyc, tip)); w.nameCell.appendChild(chip("ABPS", w.abps, tip)); }
      var first = w.row.cells[0];
      first.style.setProperty("border-left", w.ready ? "" : "4px solid " + (w.found ? "#c5221f" : "#8a92a0"), w.ready ? "" : "important");
      w.row.style.display = onlyBad && w.ready ? "none" : "";
    });
  }
  function counts(list) {
    var c = { n: list.length, ekyc: 0, abps: 0, bad: 0, nf: 0 };
    list.forEach(function (w) { if (w.ekyc) c.ekyc++; if (w.abps) c.abps++; if (!w.ready) c.bad++; if (!w.found) c.nf++; });
    return c;
  }
  function render() {
    if (!sel.sum) return;
    var c = counts(current), wl = SEL ? SEL.value : "";
    sel.sum.innerHTML = current.length
      ? "Wage list <b>" + esc(wl && wl !== "select" ? "…" + wl.slice(-8) : "") + "</b>: <b>" + c.n + "</b> worker" + (c.n === 1 ? "" : "s") +
        " · eKYC ✓ <b>" + c.ekyc + "</b> · ABPS ✓ <b>" + c.abps + "</b><br><b class='bad'>" + c.bad + " not ready</b>" + (c.nf ? " · " + c.nf + " not in ABPS data" : "")
      : "Page-এ একটা wage list বাছুন, প্রতিটি worker-এর status দেখাবে।";
    var m = current[0] ? DX.abpsMetaFor(abps.meta, current[0].job) : null, base = location.origin + "/vbgramg/UID/AppABPSRpt.aspx";
    if (!Object.keys(abps.map).length) sel.fresh.innerHTML = "<span class='warn'>No eKYC/ABPS data synced yet.</span> <a href='" + esc(base) + "' target='_blank' rel='noopener'>Open the ABPS report ↗</a> and Sync.";
    else if (m) sel.fresh.innerHTML = "ABPS data " + esc(DX.abpsLabel(m)) + " · synced " + esc(DX.syncedWhen(m)) + (DX.abpsStale(m) ? " · <span class='warn'>older than a week</span> <a href='" + esc(base) + "' target='_blank' rel='noopener'>re-sync ↗</a>" : "");
    else sel.fresh.innerHTML = "<span class='warn'>No ABPS data for this Panchayat.</span> <a href='" + esc(base) + "' target='_blank' rel='noopener'>Sync it ↗</a>";
    var n = SEL ? [].filter.call(SEL.options, function (o) { return o.value && !/select/i.test(o.value); }).length : 0;
    sel.gp.textContent = "⭳ Whole-GP report (" + n + " wage list" + (n === 1 ? "" : "s") + ")";
    sel.gp.disabled = busy || !n; sel.dl.disabled = busy || !current.length;
  }

  /* ---------------------- Excel ---------------------- */
  var COLS = ["Wage List No", "Wage List Date", "Bank / Agency", "S.No", "Job Card No", "Job seeker Name", "Name as per Bank", "Account No", "Wage Slip",
    "Work Code", "MSR No", "Attendance", "Amount", "eKYC", "ABPS", "In ABPS data", "NPCI result", "NPCI reason", "Next step"];
  function rowOf(w) {
    var yn = function (v) { return w.found ? (v ? "Yes" : "No") : ""; };
    return [w.wl, w.date, w.bank, w.sno, w.job, w.name, w.bankName, w.acct, w.slip, w.work, w.msr, w.att, w.amt,
      yn(w.ekyc), yn(w.abps), w.found ? "Yes" : "No", w.np ? w.np.result : "", w.np ? w.np.msg : "", w.next];
  }
  function sheet(list) {
    var ws = XLSX.utils.aoa_to_sheet([COLS].concat(list.map(rowOf)));
    ws["!cols"] = [18, 12, 22, 6, 24, 24, 24, 16, 18, 34, 8, 10, 9, 6, 6, 9, 14, 50, 50].map(function (w) { return { wch: w }; });
    return ws;
  }
  function save(wb, name) { XLSX.writeFile(wb, name); }
  function stamp() { var d = new Date(); return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + "-" + pad2(d.getHours()) + pad2(d.getMinutes()); }
  function exportThis() {
    if (!window.XLSX) { status("The spreadsheet library isn't loaded — reload the page.", "warn"); return; }
    var wb = XLSX.utils.book_new(), wl = SEL ? SEL.value : "wage-list";
    XLSX.utils.book_append_sheet(wb, sheet(current), "Workers");
    var bad = current.filter(function (w) { return !w.ready; });
    if (bad.length) XLSX.utils.book_append_sheet(wb, sheet(bad), "Not ready");
    save(wb, "WageList-" + wl + "-status-" + stamp() + ".xlsx");
    status("Saved — " + current.length + " worker(s), " + bad.length + " not ready.", "ok");
  }

  /* ---------------------- whole-GP report: every wage list, read in the background ---------------------- */
  var rtts = [];
  function typical() { if (!rtts.length) return 6000; var a = rtts.slice().sort(function (x, y) { return x - y; }); return a[Math.min(a.length - 1, Math.floor(a.length * 0.75))]; }
  function timeoutFor(att) { return Math.min(240000, Math.round(Math.max(25000, typical() * 4) * Math.pow(1.6, att || 0))); }
  async function fetchList(wl, att) {
    var form = document.forms[0], fd = new FormData(form);
    fd.set("__EVENTTARGET", SEL.name || WLID); fd.set("__EVENTARGUMENT", ""); fd.set(SEL.name || WLID, wl);
    var body = new URLSearchParams(); fd.forEach(function (v, k) { if (typeof v === "string") body.append(k, v); });
    var ac = new AbortController(), to = setTimeout(function () { ac.abort(); }, timeoutFor(att)), t0 = Date.now();
    try {
      var res = await fetch(form.action || location.href, { method: "POST", body: body, credentials: "include", signal: ac.signal,
        headers: { "Content-Type": "application/x-www-form-urlencoded" } });
      if (!res.ok) throw new Error("the portal answered " + res.status);
      var html = await res.text(); rtts.push(Date.now() - t0); if (rtts.length > 8) rtts.shift();
      var doc = new DOMParser().parseFromString(html, "text/html");
      if (!doc.getElementById(WLID) && !doc.querySelector('select[id$="' + WLID + '"]')) throw new Error("session expired — log in again");
      return extractWorkers(doc, wl);
    } finally { clearTimeout(to); }
  }
  async function gpReport() {
    if (busy) return;
    var lists = [].filter.call(SEL.options, function (o) { return o.value && !/select/i.test(o.value); }).map(function (o) { return o.value; });
    if (!lists.length) return;
    busy = true; render(); sel.prog.hidden = false;
    var all = [], per = [], failed = [];
    for (var i = 0; i < lists.length; i++) {
      var wl = lists[i], got = null;
      sel.fill.style.width = Math.round(100 * i / lists.length) + "%";
      sel.ptxt.textContent = "Wage list " + (i + 1) + "/" + lists.length + " — " + wl;
      for (var att = 0; att < 3 && !got; att++) {
        try { got = await fetchList(wl, att); } catch (e) {
          if (/session expired/.test(e.message)) { failed.push(wl + " (" + e.message + ")"); att = 3; break; }
          if (att < 2) { status("Wage list " + wl + ": " + (e.name === "AbortError" ? "slow portal" : e.message) + " — retrying…", "warn"); await sleep(1500 * (att + 1)); }
          else failed.push(wl);
        }
      }
      if (got) { assess(got); all = all.concat(got); per.push(wl + ": " + got.length); status("Wage list " + (i + 1) + "/" + lists.length + " — " + wl + ", " + got.length + " worker(s)", ""); }
    }
    sel.fill.style.width = "100%"; sel.ptxt.textContent = lists.length + " of " + lists.length + " wage lists read";
    busy = false; render();
    if (!all.length) { status("Nothing read" + (failed.length ? " — " + failed.join(", ") : "") + ".", "warn"); return; }
    var bad = all.filter(function (w) { return !w.ready; }).sort(function (a, b) { return a.job < b.job ? -1 : a.job > b.job ? 1 : 0; });
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet(all), "All workers");
    XLSX.utils.book_append_sheet(wb, sheet(bad), "Not ready");
    save(wb, "GP-payment-readiness-" + stamp() + ".xlsx");
    status("Saved the GP report — " + all.length + " worker rows across " + per.length + " wage list(s), " + bad.length + " not ready." +
      (failed.length ? " Could not read: " + failed.join(", ") + "." : ""), failed.length ? "warn" : "ok");
  }


  /* ---------------------- WL Export: ticked wage lists of a Financial Year → PDF (print) / Excel ----------------------
     The year's wage lists come from the page's own list (or one background postback of the year dropdown); each ticked
     wage list is read in the background (the ddl_sel postback). PDF = the portal's own wage list tables, one wage list per
     A4 landscape page, in a print window (Save as PDF). Excel = every worker with eKYC/ABPS + a Not ready sheet.
     The page itself never changes. */
  var FY = document.getElementById(FYID) || document.querySelector('select[id$="' + FYID + '"]') ||
    [].filter.call(document.querySelectorAll("select"), function (s) { return s !== SEL && [].some.call(s.options, function (o) { return /^\d{4}-\d{4}$/.test(o.value); }); })[0] || null;
  var ex = { fy: "", state: null, wls: [], ticks: {}, q: "", loading: false };
  function wlSelOf(doc) { return doc.getElementById(WLID) || doc.querySelector('select[id$="' + WLID + '"]'); }
  function wlOptions(s) { return s ? [].filter.call(s.options, function (o) { return /WL/i.test(o.value); }).map(function (o) { return o.value; }) : []; }
  function years() { return FY ? [].filter.call(FY.options, function (o) { return /\d{4}-\d{4}/.test(o.value); }).map(function (o) { return o.value; }) : []; }
  // one background postback, as if dropdown `name` had been changed to `value` on page `state` (hidden fields + dropdowns only)
  async function postback(state, name, value, att) {
    var form = state.forms[0], body = new URLSearchParams();
    [].forEach.call(form.querySelectorAll("input[type=hidden],select"), function (e) { if (e.name) body.set(e.name, e.value); });
    body.set("__EVENTTARGET", name); body.set("__EVENTARGUMENT", ""); body.set(name, value);
    var ac = new AbortController(), to = setTimeout(function () { ac.abort(); }, timeoutFor(att)), t0 = Date.now();
    try {
      var res = await fetch(new URL(form.getAttribute("action") || location.href, location.href).href, { method: "POST", body: body, credentials: "include", signal: ac.signal,
        headers: { "Content-Type": "application/x-www-form-urlencoded" } });
      if (!res.ok) throw new Error("the portal answered " + res.status);
      var html = await res.text(); rtts.push(Date.now() - t0); if (rtts.length > 8) rtts.shift();
      var doc = new DOMParser().parseFromString(html, "text/html");
      if (!wlSelOf(doc)) throw new Error("session expired — log in again");
      return doc;
    } finally { clearTimeout(to); }
  }
  async function postbackRetry(state, name, value, what) {
    for (var att = 0; att < 3; att++) {
      try { return await postback(state, name, value, att); } catch (e) {
        if (/session expired/.test(e.message) || att === 2) throw e;
        status(what + ": " + (e.name === "AbortError" ? "portal ধীর" : e.message) + " — আবার চেষ্টা…", "warn"); await sleep(1500 * (att + 1));
      }
    }
  }
  async function loadYear(fy) {
    ex.fy = fy; ex.wls = []; ex.state = null; ex.ticks = {}; renderEx();
    if (!fy) return;
    if ((!FY || FY.value === fy) && wlOptions(SEL).length) { ex.state = document; ex.wls = wlOptions(SEL); renderEx(); return; }
    ex.loading = true; renderEx();
    try {
      var doc = await postbackRetry(document, FY.name || FYID, fy, fy + "-এর wage list");
      if (ex.fy !== fy) return;
      ex.state = doc; ex.wls = wlOptions(wlSelOf(doc));
    } catch (e) { status(fy + "-এর wage list পড়া গেল না: " + e.message, "warn"); }
    finally { if (ex.fy === fy) { ex.loading = false; renderEx(); } }
  }
  function shownWls() {
    var q = String(ex.q || "").trim(); if (!q) return ex.wls;
    var parts = q.split(/[\s,;]+/).filter(Boolean);
    return ex.wls.filter(function (w) { return parts.some(function (p) { return w.toUpperCase().indexOf(p.toUpperCase()) >= 0; }); });
  }
  function tickedWls() { return ex.wls.filter(function (w) { return ex.ticks[w]; }); }
  var exSig = "";
  function renderEx() {
    if (!sel.exl) return;
    var ys = years();
    if (sel.exfy.options.length !== ys.length + 1) sel.exfy.innerHTML = "<option value=''>Financial Year বাছুন</option>" + ys.map(function (y) { return "<option>" + esc(y) + "</option>"; }).join("");
    if (sel.exfy.value !== ex.fy) sel.exfy.value = ex.fy;
    sel.exfy.hidden = !FY;
    var list = shownWls(), sig = ex.fy + "|" + ex.loading + "|" + list.join(",") + "|" + JSON.stringify(ex.ticks) + "|" + busy;
    if (sig !== exSig) {
      exSig = sig;
      sel.exl.innerHTML = ex.loading ? "<div class='empty'>" + esc(ex.fy) + "-এর wage list পড়ছে…</div>"
        : !ex.fy ? "<div class='empty'>উপরে Financial Year বাছুন।</div>"
        : !list.length ? "<div class='empty'>কোনো wage list নেই।</div>"
        : list.map(function (w) { return "<label class='wl'><input type='checkbox' data-w='" + esc(w) + "'" + (ex.ticks[w] ? " checked" : "") + (busy ? " disabled" : "") + "><span>" + esc(w) + "</span></label>"; }).join("");
    }
    var n = tickedWls().length;
    sel.excnt.textContent = n + " / " + ex.wls.length + " ticked";
    sel.expdf.disabled = sel.exxl.disabled = busy || ex.loading || !n;
  }
  // read the ticked wage lists one by one in the background: [{ wl, doc }]
  async function readTicked(what) {
    var list = tickedWls(), out = [], failed = [];
    busy = true; render(); renderEx(); sel.prog.hidden = false;
    try {
      for (var i = 0; i < list.length; i++) {
        sel.fill.style.width = Math.round(100 * i / list.length) + "%";
        sel.ptxt.textContent = what + " — wage list " + (i + 1) + "/" + list.length + " · " + list[i];
        try {
          var doc = ex.state === document && SEL.value === list[i] ? document : await postbackRetry(ex.state || document, (wlSelOf(ex.state || document) || SEL).name || WLID, list[i], "Wage list " + list[i]);
          out.push({ wl: list[i], doc: doc });
        } catch (e) { failed.push(list[i] + (/session/.test(e.message) ? " (login শেষ)" : "")); if (/session/.test(e.message)) break; }
      }
      sel.fill.style.width = "100%"; sel.ptxt.textContent = out.length + " / " + list.length + " wage list পড়া হল";
    } finally { busy = false; render(); renderEx(); }
    return { got: out, failed: failed };
  }
  // the portal's own wage list tables from a page: the outermost tables holding the wage list header or workers
  function printable(doc) {
    var keep = [].filter.call(doc.querySelectorAll("table"), function (t) {
      var x = t.textContent || ""; return /Wage\s*List\s*No/i.test(x) || [].some.call(t.querySelectorAll("td"), function (td) { return JC.test(txt(td)); });
    }).filter(function (t, i, all) { return !all.some(function (o) { return o !== t && o.contains(t); }); });
    return keep.map(function (t) {
      var c = t.cloneNode(true);
      [].forEach.call(c.querySelectorAll("script,input,select,button,img,.kh-wls"), function (e) { e.remove(); });
      [].forEach.call(c.querySelectorAll("tr"), function (r) { r.style.display = ""; });
      return c.outerHTML;
    }).join("");
  }
  async function exportPdf() {
    if (busy) return;
    var w = window.open("", "_blank");
    if (!w) { status("Popup block হয়েছে — address bar-এ popup allow করে আবার চাপুন।", "warn"); return; }
    w.document.write("<title>Wage lists…</title><p style='font:14px Segoe UI,Arial'>K-Desk: wage list পড়ছে, একটু অপেক্ষা করুন…</p>");
    var r = await readTicked("PDF");
    if (!r.got.length) { w.close(); status("কিছু পড়া গেল না" + (r.failed.length ? ": " + r.failed.join(", ") : "") + "।", "warn"); return; }
    var pages = r.got.map(function (x, i) { return "<section class='wlp'" + (i ? " style='page-break-before:always'" : "") + ">" + printable(x.doc) + "</section>"; }).join("");
    var title = "Wage lists " + ex.fy + " (" + r.got.length + ")";
    w.document.open();
    w.document.write("<!doctype html><html><head><meta charset='utf-8'><title>" + esc(title) + "</title><style>" +
      "@page{size:A4 landscape;margin:8mm}body{font:10px Arial,sans-serif;color:#000;margin:0}" +
      "table{border-collapse:collapse;width:100%!important;font-size:9.5px}td,th{padding:2px 3px;vertical-align:top}" +
      "tr{page-break-inside:avoid}.bar{position:sticky;top:0;background:#1e1b6b;color:#fff;padding:8px 12px;font:13px Segoe UI,Arial}" +
      ".bar button{margin-left:10px;padding:6px 14px;border:0;border-radius:6px;background:#f5b942;font-weight:700;cursor:pointer}" +
      "@media print{.bar{display:none}}</style></head><body>" +
      "<div class='bar'>K-Desk · " + esc(title) + (r.failed.length ? " · পড়া যায়নি: " + esc(r.failed.join(", ")) : "") +
      "<button onclick='window.print()'>🖨 Print / Save as PDF</button></div>" + pages + "</body></html>");
    w.document.close();
    setTimeout(function () { try { w.focus(); w.print(); } catch (e) {} }, 700);
    status("PDF window খোলা হয়েছে — " + r.got.length + "টা wage list। Print-এ 'Save as PDF' বাছুন।" + (r.failed.length ? " পড়া যায়নি: " + r.failed.join(", ") : ""), r.failed.length ? "warn" : "ok");
  }
  async function exportXl() {
    if (busy) return;
    if (!window.XLSX) { status("Spreadsheet library load হয়নি — page reload করুন।", "warn"); return; }
    var r = await readTicked("Excel");
    var all = [];
    r.got.forEach(function (x) { all = all.concat(assess(extractWorkers(x.doc, x.wl))); });
    if (!all.length) { status("কোনো worker পাওয়া যায়নি" + (r.failed.length ? " (পড়া যায়নি: " + r.failed.join(", ") + ")" : "") + "।", "warn"); return; }
    var bad = all.filter(function (w) { return !w.ready; });
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet(all), "Workers");
    XLSX.utils.book_append_sheet(wb, sheet(bad), "Not ready");
    var name = "WL-Export-" + ex.fy + "-" + stamp() + ".xlsx";
    save(wb, name);
    status("Saved " + name + " — " + r.got.length + "টা wage list, " + all.length + " worker, " + bad.length + " not ready." + (r.failed.length ? " পড়া যায়নি: " + r.failed.join(", ") : ""), r.failed.length ? "warn" : "ok");
  }

  /* ---------------------- panel ---------------------- */
  var STYLE =
    ".panel{width:320px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:13px;color:#0f172a;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 10px 30px rgba(11,20,55,.3);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:8px 10px;display:flex;align-items:center;justify-content:space-between}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hd b{font-size:12.5px;font-weight:700}.hdl{display:flex;align-items:center;gap:8px;min-width:0}" +
    ".logo{width:24px;height:24px;border-radius:7px;flex:0 0 auto;display:grid;place-items:center;font:800 14px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:22px;height:22px;border-radius:5px;font-size:15px;line-height:1;flex:0 0 auto}" +
    ".bd{padding:10px;max-height:80vh;overflow:auto}" +
    ".summary{font-size:12px;color:#1e1b6b;background:#eef2ff;border-radius:7px;padding:7px 9px;line-height:1.5}.summary .bad{color:#c5221f}" +
    ".fresh{margin-top:6px;font-size:11px;color:#5b6472;line-height:1.4}.fresh a{color:#3730a3;font-weight:600}.warn{color:#9a6700;font-weight:600}" +
    ".chk{display:flex;align-items:center;gap:7px;margin-top:8px;font-size:12px;font-weight:600;cursor:pointer}.chk input{margin:0;width:15px;height:15px;accent-color:#3730a3}" +
    ".btn{padding:8px 9px;border:none;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;width:100%;margin-top:6px}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.fill:hover{filter:brightness(1.05)}.btn.fill:disabled{background:#f3e3bd;color:#8a7a55;cursor:not-allowed}" +
    ".btn.ghost{background:#f2f4f8;color:#334;border:1px solid #d7dce6}.btn.ghost:disabled{color:#aab;cursor:not-allowed}" +
    ".prog{margin:8px 0 0}.progbar{height:8px;background:#e6e9f0;border-radius:5px;overflow:hidden}.progfill{height:100%;width:0;background:#e08e0b;transition:width .3s}" +
    ".progtxt{margin-top:4px;font-size:11px;text-align:center;color:#3730a3;font-weight:600}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:6px;background:#f2f4f8;min-height:15px;line-height:1.35}" +
    ".st.ok{background:#e7f4ec;color:#137333}.st.warn{background:#fef7e0;color:#9a6700}" +
    ".hint{margin-top:8px;font-size:10.5px;color:#5b6472;line-height:1.35}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#8a92a0;line-height:1.35;background:#fbfbfd;border:1px solid #eef0f4;border-radius:6px;padding:5px 7px}" +
    ".foot{margin-top:8px;padding-top:6px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;font-size:10.5px;color:#64748b}.foot b{color:#0b1437}.foot em{font-style:normal;color:#e08e0b}" +
    ".sec{font-weight:700;color:#3730a3;margin:10px 0 4px;border-top:1px solid #e2e8f0;padding-top:8px;font-size:12px;display:flex;justify-content:space-between;align-items:center}.sec small{font-weight:400;color:#64748b}" +
    ".row{display:flex;gap:6px;margin-top:6px;align-items:center}.inp{flex:1;min-width:0;border:1px solid #c9d3e6;border-radius:7px;padding:5px 7px;font:12px 'Segoe UI',Arial,sans-serif;background:#fff}" +
    ".lk{background:none;border:none;color:#3730a3;cursor:pointer;font-size:11.5px;padding:0;text-decoration:underline}" +
    ".exl{max-height:150px;overflow:auto;border:1px solid #e2e8f0;border-radius:7px;padding:3px 7px;margin-top:6px;background:#fff}.wl{display:flex;gap:6px;align-items:center;font:11.5px Consolas,monospace;padding:2px 0;cursor:pointer}.wl input{margin:0;accent-color:#3730a3}.empty{font-size:11px;color:#64748b;padding:4px 0}" +
    ".row .btn{margin-top:0}" +
    "[hidden]{display:none!important}";
  var HTML =
    "<div class='hd' id='w_hd'><span class='hdl'><span class='logo'>K</span><span class='ttl'><b>Wage List Status</b><small><i>K-Desk</i> Suite · Wage List</small></span></span><button class='mn' id='w_min'>–</button></div>" +
    "<div class='bd' id='w_bd'>" +
    "<div class='summary' id='w_sum'></div><div class='fresh' id='w_fresh'></div>" +
    "<label class='chk'><input type='checkbox' id='w_only'>শুধু যারা ready নয় তাদের দেখাও</label>" +
    "<button class='btn ghost' id='w_dl'>⭳ এই wage list Excel-এ</button>" +
    "<button class='btn fill' id='w_gp'>⭳ Whole-GP report</button>" +
    "<div class='sec'><span>⭳ WL Export (PDF / Excel)</span><small id='w_excnt'></small></div>" +
    "<div class='row'><select class='inp' id='w_exfy'></select></div>" +
    "<div class='row'><input class='inp' id='w_exq' placeholder='Wage list No খুঁজুন (শেষের সংখ্যাও চলবে)'></div>" +
    "<div class='row'><button class='lk' id='w_exall'>Tick all</button><button class='lk' id='w_exnone'>Untick all</button></div>" +
    "<div class='exl' id='w_exl'></div>" +
    "<div class='row'><button class='btn fill' id='w_expdf'>🖨 PDF (সব একসাথে)</button><button class='btn ghost' id='w_exxl'>⭳ Excel</button></div>" +
    "<div class='prog' id='w_prog' hidden><div class='progbar'><div class='progfill' id='w_fill'></div></div><div class='progtxt' id='w_ptxt'></div></div>" +
    "<div class='st' id='w_st'></div>" +
    "<div class='hint'>প্রতিটি Job seeker Name-এর পাশের eKYC / ABPS চিহ্ন আসে আপনার sync করা ABPS data থেকে; mouse রাখলে পরের ধাপ দেখায়। <b>Not ready</b> = eKYC বা ABPS বাকি, DBT payment fail হতে পারে। <b>Whole-GP report</b> dropdown-এর সব wage list পিছনে পড়ে একটা Excel বানায়, এই page বদলায় না।</div>" +
    "<div class='disclaimer'>⚠ শেষ ABPS sync অনুযায়ী status; নতুন তথ্যের জন্য ABPS report আবার sync করুন।</div>" +
    "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>v<span id='w_ver'></span></em></div>" +
    "</div>";
  function build() {
    var host = document.createElement("div"); host.id = HOST_ID;
    host.style.cssText = "position:fixed;top:70px;right:16px;z-index:2147483644;";
    document.body.appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE; root.appendChild(css); if (window.KD_applySkin) KD_applySkin(root);
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML; root.appendChild(box);
    ["hd", "min", "bd", "ver", "sum", "fresh", "only", "dl", "gp", "prog", "fill", "ptxt", "st", "exfy", "exq", "exall", "exnone", "exl", "excnt", "expdf", "exxl"].forEach(function (id) { sel[id] = root.getElementById("w_" + id); });
    try { sel.ver.textContent = chrome.runtime.getManifest().version; } catch (e) {}
    var mini = false; try { mini = localStorage.getItem(MIN_KEY) === "1"; } catch (e) {}
    if (mini) { sel.bd.style.display = "none"; sel.min.textContent = "+"; }
    sel.min.addEventListener("click", function () { var h = sel.bd.style.display !== "none"; sel.bd.style.display = h ? "none" : "block"; sel.min.textContent = h ? "+" : "–"; try { localStorage.setItem(MIN_KEY, h ? "1" : "0"); } catch (e) {} });
    sel.only.addEventListener("change", function () { onlyBad = sel.only.checked; paint(); });
    sel.dl.addEventListener("click", exportThis);
    sel.gp.addEventListener("click", gpReport);
    sel.exfy.addEventListener("change", function () { if (!busy) loadYear(sel.exfy.value); });
    sel.exq.addEventListener("input", function () { ex.q = sel.exq.value; renderEx(); });
    sel.exall.addEventListener("click", function () { shownWls().forEach(function (w) { ex.ticks[w] = true; }); renderEx(); });
    sel.exnone.addEventListener("click", function () { ex.ticks = {}; renderEx(); });
    sel.exl.addEventListener("change", function (e) { var w = e.target && e.target.getAttribute("data-w"); if (!w) return; if (e.target.checked) ex.ticks[w] = true; else delete ex.ticks[w]; renderEx(); });
    sel.expdf.addEventListener("click", exportPdf);
    sel.exxl.addEventListener("click", exportXl);
    var sx, sy, ox, oy, drag = false; sel.hd.style.cursor = "move";
    sel.hd.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
    document.addEventListener("mouseup", function () { drag = false; });
  }

  /* ---------------------- boot ---------------------- */
  function load(cb) {
    DX.abpsLoad(function (map, meta) {
      abps.map = map || {}; abps.meta = meta || {};
      try {
        chrome.storage.local.get("khnpLastRun", function (d) {
          npci = {};
          ((d && d.khnpLastRun && d.khnpLastRun.results) || []).forEach(function (x) { var k = DX.normKey(x.job || String(x.key || "").split("|")[0], "id"); (npci[k] = npci[k] || []).push(x); });
          cb();
        });
      } catch (e) { cb(); }
    });
  }
  function refresh() { current = assess(extractWorkers(document, SEL ? SEL.value : "")); paint(); render(); renderEx(); }
  function boot() {
    if (!window.DX || !DX.abpsFind) return;
    build();
    load(refresh);
    if (SEL) { var ys = years(); loadYear(!FY ? "current" : /\d{4}-\d{4}/.test(FY.value) ? FY.value : ys.length ? ys[ys.length - 1] : ""); }
    try { chrome.storage.onChanged.addListener(function (ch, area) { if (area === "local" && (ch.dxAbpsMap || ch.dxAbpsMeta || ch.khnpLastRun)) load(refresh); }); } catch (e) {}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
});
