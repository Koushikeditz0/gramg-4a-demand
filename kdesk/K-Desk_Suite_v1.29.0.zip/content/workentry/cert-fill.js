/* =====================================================================
   cert-fill.js — K-Desk Suite by Koushik · Work Entry Certificate Auto-Fill (isolated world)
   Work Entry (work_entry.aspx) / Edit Work Entry (work_entry_edit.aspx): the 8 certificate blocks.
   • Signer details (Name, Designation, Department, Mobile, Email) typed once in the panel → every block.
   • PDFs: pick a folder (file name carries the block number 1–8, or a keyword like "dpr", "split"),
     or one 8-page PDF (page 1 → block 1 … page 8 → block 8).
   • The portal takes ~900 KB a file: a bigger scan is re-rendered (pdf.js) and re-encoded as JPEG (jsPDF),
     stepping down resolution/quality until it fits. Files that already fit are not touched.
   • DPR and Convergence radios → Yes. The operator checks the form and presses the portal's own Save.
   Signer stored in chrome.storage.local "kdcert_signer". Dashboard toggle: "cert".
   ===================================================================== */
(function () {
  "use strict";
  var P = window.KD_MAP ? window.KD_MAP.prefixId("ctl00_ContentPlaceHolder1_") : "ctl00_ContentPlaceHolder1_";
  var CID = function (k, d) { return window.KD_MAP ? window.KD_MAP.id("cert", k, d) : d; };
  if (!document.getElementById(P + CID("c1file", "File_pre_estimation_file_name"))) return;
  if (window.__KDCERT) return; window.__KDCERT = true;

  var BLOCKS = [
    { num: 1, title: "Pre-estimation / Feasibility", file: "File_pre_estimation_file_name", f: ["txtpre_estimation_person_name", "txtpre_estimation_designation", "txtpre_estimation_department", "txtpre_estimation_mobile", "txtpre_estimation_emailid"], keys: ["pre", "estimation", "feasib", "utility"] },
    { num: 2, title: "No duplication (BDO)", file: "File_double_wrks_file_name", f: ["txtdouble_wrks_person_name", "txtdouble_wrks_designation", "txtdouble_wrks_department", "txtdouble_wrks_mobile", "txtdouble_wrks_emailid"], keys: ["duplicat", "double", "count"] },
    { num: 3, title: "Non-splitting (BDO)", file: "File_spliting_wrk_fie_name", f: ["non_spliting_person_name", "txtnon_spliting_wrk_designation", "txtnon_spliting_wrks_department", "txtnon_spliting_wrks_Mobile", "txtnon_spliting_wrk_Email"], keys: ["split"] },
    { num: 4, title: "Permissible category (BDO)", file: "File_permissible_wrk", f: ["txtpermissible_wrk_person_name", "txtpermissible_wrk_designation", "txtpermissible_wrk_department", "txtpermissible_wrk_mobile", "txtpermissible_wrk_emailid"], keys: ["permiss"] },
    { num: 5, title: "Beneficiary selection (BDO)", file: "File_beneficiary_file_name", f: ["txtbeneficiary_person_name", "txtbeneficiary_designation", "txtbeneficiary_department", "txtbeneficiary_mobile", "txtbeneficiary_emailid"], keys: ["benefic", "para"] },
    { num: 6, title: "DPR preparation", file: "File_dpr_prep_file_name", f: ["txtdpr_prep_person_name", "txtdpr_prep_designation", "txtdpr_prep_department", "txtdpr_prep_mobile", "txtdpr_prep_emailid"], keys: ["dpr"], radio: "rdodpr_preparation" },
    { num: 7, title: "Convergence clearance", file: "File_conv_dept_file_name", f: ["txtconv_dept_person_name", "txtconv_dept_designation", "txtconv_dept", "txtconv_dept_mobile", "txtconv_dept_emailid"], keys: ["converg"], radio: "rdoConvergenece" },
    { num: 8, title: "Non-negotiables (BDO)", file: "File_non_negotiables_file_name", f: ["txtnon_negotiables_person_name", "txtnon_negotiables_designation", "txtnon_negotiables_department", "txtnon_negotiables_mobile", "txtnon_negotiables_emailid"], keys: ["negoti"] }
  ];
  // portal-এর ID এখন shared/portal-map.js (page "cert": c1file, c1name … c8email, c6radio, c7radio) থেকে;
  // map না থাকলে উপরের আগের মান। radio-র map ID-তে শেষের "_0" থাকে।
  BLOCKS.forEach(function (b) {
    var n = "c" + b.num;
    b.file = CID(n + "file", b.file);
    b.f = b.f.map(function (id, i) { return CID(n + ["name", "desig", "dept", "mob", "email"][i], id); });
    if (b.radio) b.radio = CID(n + "radio", b.radio + "_0").replace(/_0$/, "");
  });
  var N = BLOCKS.length, SKEYS = ["name", "desig", "dept", "mob", "email"], SLABEL = ["Name", "Designation", "Department", "Mobile", "Email"];
  var LIMIT = 900 * 1024, TARGET = 870 * 1024, SCALES = [2.0, 1.5, 1.15, 0.9], QUALS = [0.72, 0.6, 0.5, 0.42];
  var HOST_ID = "kdcert-host", MIN_KEY = "kdcert_min", POS_KEY = "kdcert_pos", SKEY = "kdcert_signer";
  var signer = { name: "", desig: "", dept: "", mob: "", email: "" };
  var map = {}, before = {}, picked = 0, busy = false, sel = {};

  function $(id) { return document.getElementById(id); }
  function el(id) { return $(P + id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function size(b) { return b >= 1048576 ? (b / 1048576).toFixed(2) + " MB" : b >= 1024 ? Math.round(b / 1024) + " KB" : b + " B"; }
  function base(f) { var n = f.name || ""; return n.slice(Math.max(n.lastIndexOf("/"), n.lastIndexOf("\\")) + 1); }
  function libs() { return !!(window.pdfjsLib && window.jspdf && window.jspdf.jsPDF); }
  try { if (window.pdfjsLib) window.pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("vendor/pdf.worker.min.js"); } catch (e) {}

  /* ---------------------- form ---------------------- */
  function setVal(e, v) {
    if (!e) return;
    try { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(e, v); } catch (x) { e.value = v; }
    e.dispatchEvent(new Event("input", { bubbles: true })); e.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function attach(e, file) {
    if (!e || !file) return false;
    try { var dt = new DataTransfer(); dt.items.add(file); e.files = dt.files; e.dispatchEvent(new Event("input", { bubbles: true })); e.dispatchEvent(new Event("change", { bubbles: true })); return e.files.length === 1; }
    catch (x) { return false; }
  }
  function yes(name) { var r = $(P + name + "_0"); if (!r) return; if (!r.checked) { r.checked = true; r.click(); } r.dispatchEvent(new Event("change", { bubbles: true })); }

  /* ---------------------- file → block ---------------------- */
  function seqOf(f) {
    var nm = base(f).toLowerCase().replace(/\.pdf$/, "").replace(/of[\s_.-]*\d+/g, " "), g = nm.match(/\d+/g), last = null;
    (g || []).forEach(function (x) { var v = parseInt(x, 10); if (v >= 1 && v <= N) last = v; });
    return last;
  }
  function matchFiles(files) {
    map = {}; before = {};
    var used = {}, seq = files.map(seqOf);
    BLOCKS.forEach(function (b) { for (var i = 0; i < files.length; i++) if (!used[i] && seq[i] === b.num) { map[b.num] = files[i]; used[i] = 1; break; } });
    BLOCKS.forEach(function (b) {
      if (map[b.num]) return;
      for (var i = 0; i < files.length; i++) {
        if (used[i]) continue; var nm = base(files[i]).toLowerCase();
        if (b.keys.some(function (k) { return nm.indexOf(k) >= 0; })) { map[b.num] = files[i]; used[i] = 1; return; }
      }
    });
  }

  /* ---------------------- compression ---------------------- */
  function buildPdf(cvs, dims, q) {
    var J = window.jspdf.jsPDF, doc = null;
    cvs.forEach(function (cv, i) {
      var w = dims[i].w, h = dims[i].h, o = w > h ? "l" : "p";
      if (!i) doc = new J({ unit: "pt", format: [w, h], orientation: o, compress: true }); else doc.addPage([w, h], o);
      doc.addImage(cv.toDataURL("image/jpeg", q), "JPEG", 0, 0, w, h, undefined, "FAST");
    });
    return doc.output("blob");
  }
  async function renderPage(pdf, p, sc) {
    var page = await pdf.getPage(p), v1 = page.getViewport({ scale: 1 }), vp = page.getViewport({ scale: sc });
    var cv = document.createElement("canvas"); cv.width = Math.max(1, Math.ceil(vp.width)); cv.height = Math.max(1, Math.ceil(vp.height));
    var ctx = cv.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cv.width, cv.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    return { cv: cv, dim: { w: v1.width, h: v1.height } };
  }
  function free(cvs) { cvs.forEach(function (c) { c.width = c.height = 0; }); }
  // pages [from..to] of an open pdf → the best-quality File that fits (null if none fits)
  async function squeeze(pdf, from, to, name, keepIfFits) {
    var best = null;
    for (var si = 0; si < SCALES.length; si++) {
      var cvs = [], dims = [];
      for (var p = from; p <= to; p++) { var r = await renderPage(pdf, p, SCALES[si]); cvs.push(r.cv); dims.push(r.dim); }
      for (var qi = 0; qi < QUALS.length; qi++) {
        var blob = buildPdf(cvs, dims, QUALS[qi]);
        if ((keepIfFits && !si && !qi && blob.size <= LIMIT) || blob.size <= TARGET) { free(cvs); return new File([blob], name, { type: "application/pdf" }); }
        if (!best || blob.size < best.size) best = blob;
      }
      free(cvs);
    }
    return best && best.size <= LIMIT ? new File([best], name, { type: "application/pdf" }) : null;
  }
  async function openPdf(file) { return window.pdfjsLib.getDocument({ data: await file.arrayBuffer(), disableAutoFetch: true, disableStream: true }).promise; }
  async function compressBig() {
    var big = BLOCKS.filter(function (b) { return map[b.num] && map[b.num].size > LIMIT; });
    if (!big.length || !libs()) return;
    for (var i = 0; i < big.length; i++) {
      var b = big[i], f = map[b.num];
      status("Compress হচ্ছে: Certificate " + b.num + " (" + base(f) + ", " + size(f.size) + ") · " + (i + 1) + "/" + big.length, "warn");
      try {
        var pdf = await openPdf(f), c = await squeeze(pdf, 1, pdf.numPages, base(f), false);
        try { pdf.destroy(); } catch (e) {}
        if (c && c.size <= LIMIT && c.size < f.size) { before[b.num] = f.size; map[b.num] = c; }
      } catch (e) { /* stays too big */ }
      renderRows();
    }
  }
  async function splitEight(file) {
    if (!libs()) { status("PDF library এখনো load হয়নি — page reload করো।", "warn"); return; }
    map = {}; before = {}; busy = true; renderAll();
    status(base(file) + " পড়া হচ্ছে…", "warn");
    var pdf;
    try { pdf = await openPdf(file); } catch (e) { busy = false; status("PDF খোলা গেল না (খারাপ বা password দেওয়া)।", "warn"); renderAll(); return; }
    if (pdf.numPages !== N) { try { pdf.destroy(); } catch (e) {} busy = false; status("এই PDF-এ " + pdf.numPages + " পাতা — ঠিক " + N + " পাতা লাগবে (পাতা 1 = Certificate 1 … পাতা 8 = Certificate 8)।", "warn"); renderAll(); return; }
    var stem = base(file).replace(/\.pdf$/i, "");
    for (var p = 1; p <= N; p++) {
      status("পাতা " + p + "/" + N + " আলাদা করা হচ্ছে…", "warn");
      try { var f = await squeeze(pdf, p, p, stem + "-" + p + ".pdf", true); if (f) map[p] = f; } catch (e) {}
      renderRows();
    }
    try { pdf.destroy(); } catch (e) {}
    picked = N; busy = false; finalStatus(); renderAll();
  }
  async function pickFolder(files) {
    files = [].filter.call(files || [], function (f) { return /\.pdf$/i.test(base(f)); });
    if (!files.length) { status("এই folder-এ কোনো PDF নেই।", "warn"); return; }
    picked = files.length; matchFiles(files); busy = true; renderAll();
    await compressBig();
    busy = false; finalStatus(); renderAll();
  }

  /* ---------------------- fill ---------------------- */
  function over() { return BLOCKS.filter(function (b) { return map[b.num] && map[b.num].size > LIMIT; }).map(function (b) { return b.num; }); }
  function finalStatus() {
    var o = over(), n = Object.keys(map).length, c = Object.keys(before).length;
    if (o.length) status("Compress করার পরেও " + size(LIMIT) + "-এর বেশি: Certificate " + o.join(", ") + "। Fill বন্ধ — ওই scan ছোট/পরিষ্কার করে আবার বাছো।", "warn");
    else status(picked + "টা PDF · " + n + "/" + N + " Certificate মিলেছে" + (c ? " · " + c + "টা compress করা হয়েছে" : "") + "। নিচে মিলিয়ে দেখে ✍ Fill চাপো।", n === N ? "ok" : "warn");
  }
  function fill() {
    // 🩺 Health Check: portal-এর field না মিললে Fill হবে না (দুবার "তবু চালাই" চাপলে চলবে)
    if (window.KD_HEALTH && !window.KD_HEALTH.gate("cert", fillChecked, "Certificate Auto-Fill")) { status("Health Check: portal-এর কিছু field পাওয়া যায়নি — Fill হয়নি।", "warn"); return; }
    if (!window.KD_HEALTH) fillChecked();
  }
  function fillChecked() {
    if (!SKEYS.some(function (k) { return signer[k]; })) { status("আগে সই-কারীর details লেখো (✏ Signer)।", "warn"); sel.sdet.open = true; return; }
    if (over().length) { finalStatus(); return; }
    var files = 0, miss = [];
    BLOCKS.forEach(function (b) {
      b.f.forEach(function (id, i) { setVal(el(id), String(signer[SKEYS[i]] || "").replace(/\s+/g, " ").trim()); });
      if (b.radio) yes(b.radio);
      if (map[b.num] && attach(el(b.file), map[b.num])) files++; else miss.push(b.num);
    });
    if (miss.length) status("৮টা Certificate-এ details বসানো হয়েছে, " + files + "টা PDF attach হয়েছে। Certificate " + miss.join(", ") + "-এর PDF নেই — ফাইলের নামে নম্বর (1–8) দিয়ে আবার বাছো।", "warn");
    else status("✓ হয়ে গেছে: ৮টা Certificate-এ details + ৮টা PDF, DPR আর Convergence = Yes। Form দেখে নিয়ে portal-এর Save চাপো।", "ok");
  }

  /* ---------------------- panel ---------------------- */
  function status(t, lv) { if (!sel.st) return; sel.st.hidden = !t; sel.st.className = "st " + (lv || ""); sel.st.textContent = t || ""; }
  function renderRows() {
    if (!sel.rows) return;
    sel.rows.innerHTML = BLOCKS.map(function (b) {
      var f = map[b.num], st, cls;
      if (!f) { st = "PDF নেই"; cls = "miss"; }
      else if (f.size > LIMIT) { st = size(f.size) + " · খুব বড়"; cls = "big"; }
      else if (before[b.num]) { st = size(before[b.num]) + " → " + size(f.size) + " ✓"; cls = "ok"; }
      else { st = size(f.size) + " ✓"; cls = "ok"; }
      return "<div class='row " + cls + "'><span class='n'>" + b.num + "</span><span class='t'><b>" + esc(b.title) + (b.radio ? " · Yes" : "") + "</b><small>" + (f ? esc(base(f)) : "—") + "</small></span><span class='s'>" + st + "</span></div>";
    }).join("");
  }
  function renderWho() {
    var bits = [signer.name, signer.desig, signer.dept].filter(Boolean).join(", ");
    sel.who.innerHTML = bits ? "সই করবেন: <b>" + esc(bits) + "</b>" : "<span class='warnt'>সই-কারীর details এখনো লেখা হয়নি</span>";
  }
  // shadow DOM-এ document.activeElement = host, তাই টাইপ করার সময় box আবার লেখা হত আর শেষের space মুছে যেত — এখন শুধু load-এর সময় বসানো হয়
  function renderSigner() { renderWho(); SKEYS.forEach(function (k) { if (sel["s_" + k]) sel["s_" + k].value = signer[k] || ""; }); }
  function renderAll() {
    renderRows(); renderWho();
    var any = Object.keys(map).length > 0;
    sel.map.hidden = !any && !busy;
    sel.fill.disabled = busy || !any || over().length > 0;
    sel.folder.disabled = sel.one.disabled = busy;
  }
  var STYLE =
    ".panel{width:360px;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif;font-size:13px;color:#1e1b4b;background:linear-gradient(180deg,#f3f4ff,#e8eafc);border:1px solid #c9cef3;border-radius:16px;box-shadow:0 18px 50px rgba(30,27,75,.30);overflow:hidden}" +
    ".hd{position:relative;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);padding:10px 12px;display:flex;align-items:center;justify-content:space-between;cursor:move}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".hdl{display:flex;align-items:center;gap:9px;min-width:0}.ttl b{display:block;font-size:14px}.ttl small{display:block;font-size:10px;color:#c7d2fe;letter-spacing:.6px;text-transform:uppercase}.ttl small i{font-style:normal;color:#f5b942;font-weight:600;text-transform:none}" +
    ".logo{width:28px;height:28px;border-radius:8px;flex:0 0 auto;display:grid;place-items:center;font:800 15px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:24px;height:24px;border-radius:6px;font-size:15px;line-height:1}" +
    ".bd{padding:10px 12px;max-height:80vh;overflow:auto}" +
    ".who{font-size:12px;background:#fff;border:1px solid #d4d8f5;border-left:4px solid #f5b942;border-radius:10px;padding:7px 10px;line-height:1.4}.warnt{color:#b45309;font-weight:600}" +
    "details{margin-top:6px}summary{cursor:pointer;font-size:12px;color:#3730a3;font-weight:600}" +
    ".sg{display:grid;grid-template-columns:86px 1fr;gap:4px 6px;margin-top:6px;align-items:center;font-size:11.5px}.sg input{padding:5px 7px;border:1px solid #c9cef3;border-radius:7px;font:inherit;font-size:12px}" +
    ".btn{padding:8px 9px;border:none;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;min-height:34px}.btnrow{display:flex;gap:6px;margin-top:8px}.btnrow .btn{flex:1}" +
    ".btn.fill{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}.btn.fill:disabled{opacity:.5;cursor:not-allowed}" +
    ".btn.ghost{background:#f5f6ff;color:#1e1b4b;border:1px solid #d4d8f5}.btn.ghost:disabled{color:#aab;cursor:not-allowed}" +
    ".map{margin-top:8px;background:#fff;border:1px solid #d4d8f5;border-radius:10px;padding:4px 6px}" +
    ".row{display:flex;align-items:center;gap:7px;padding:4px 2px;border-bottom:1px dotted #e0e3f7;font-size:11.5px}.row:last-child{border-bottom:none}" +
    ".row .n{width:20px;height:20px;border-radius:50%;display:grid;place-items:center;font-weight:700;font-size:11px;color:#fff;background:#9ca3af;flex:none}" +
    ".row.ok .n{background:#10b981}.row.big .n{background:#dc2626}.row .t{flex:1;min-width:0}.row .t b{display:block;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
    ".row .t small{display:block;color:#6b7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.row .s{font-size:10.5px;white-space:nowrap;color:#166534}.row.big .s{color:#dc2626;font-weight:600}.row.miss .s{color:#9a6700}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:7px;background:#f5f6ff;line-height:1.4}.st.ok{background:#dcfce7;color:#166534}.st.warn{background:#fef3c7;color:#92400e}" +
    ".hint{font-size:11px;color:#5b6472;margin-top:8px;line-height:1.4}" +
    ".foot{margin-top:8px;padding-top:6px;border-top:1px solid #d4d8f5;display:flex;justify-content:space-between;font-size:10.5px;color:#5b5f8a}.foot b{color:#1e1b4b}.foot em{font-style:normal;color:#c2770a}[hidden]{display:none!important}";
  var HTML =
    "<div class='hd' id='kc_hd'><span class='hdl'><span class='logo'>K</span><span class='ttl'><b>Certificate Auto-Fill</b><small><i>K-Desk</i> Suite · ৮টা certificate · PDF compress</small></span></span><button class='mn' id='kc_min'>–</button></div>" +
    "<div class='bd' id='kc_bd'>" +
    "<div class='who' id='kc_who'></div>" +
    "<details id='kc_sdet'><summary>⚙ Signer details (একবার লিখলেই মনে থাকে)</summary><div class='sg'>" +
      SKEYS.map(function (k, i) { return "<label for='kc_s_" + k + "'>" + SLABEL[i] + "</label><input id='kc_s_" + k + "' " + (k === "mob" ? "inputmode='numeric' maxlength='10'" : k === "email" ? "type='email'" : "") + ">"; }).join("") +
    "</div></details>" +
    "<div class='btnrow'><button class='btn ghost' id='kc_folder'>📁 Folder বাছো</button><button class='btn ghost' id='kc_one'>📄 ৮ পাতার একটা PDF</button></div>" +
    "<input type='file' id='kc_fin' webkitdirectory multiple hidden><input type='file' id='kc_oin' accept='.pdf,application/pdf' hidden>" +
    "<div class='map' id='kc_map' hidden><div id='kc_rows'></div></div>" +
    "<div class='btnrow'><button class='btn fill' id='kc_fill' disabled>✍ Fill (৮টা Certificate)</button></div>" +
    "<div class='st' id='kc_st' hidden></div>" +
    "<details class='kguide'><summary>ⓘ নির্দেশনা</summary><div class='hint'>Folder-এ ফাইলের নামে 1–8 নম্বর থাকলেই হবে (যেমন <b>1.pdf</b>, <b>cert-05.pdf</b>), বা নাম দিয়ে (dpr, split, permissible…)। ৮ পাতার PDF দিলে পাতা 1 → Certificate 1 … পাতা 8 → Certificate 8। " + size(LIMIT) + "-এর বড় ফাইল নিজে থেকে compress হয়, ছোটগুলো যেমন আছে তেমন থাকে। Fill-এর পরে form দেখে নিয়ে portal-এর <b>Save</b> নিজে চাপো।</div></details>" +
    "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>K-Desk v<span id='kc_ver'></span></em></div>" +
    "</div>";

  function build() {
    if ($(HOST_ID)) return;
    var host = document.createElement("div"); host.id = HOST_ID;
    var kdW = 58; try { if (localStorage.getItem("kd_wide") === "1" && localStorage.getItem("kd_collapsed") !== "1") kdW = 200; } catch (e) {}
    host.style.cssText = "position:fixed;top:0;right:" + kdW + "px;left:auto;z-index:2147483646;";
    var pos = null; try { pos = JSON.parse(localStorage.getItem(POS_KEY) || "null"); } catch (e) {}
    if (pos && pos.l >= 0 && pos.t >= 0 && pos.l < window.innerWidth - 60 && pos.t < window.innerHeight - 40) { host.style.left = pos.l + "px"; host.style.top = pos.t + "px"; host.style.right = "auto"; }
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE; root.appendChild(css);
    var box = document.createElement("div"); box.className = "panel"; box.innerHTML = HTML; root.appendChild(box);
    ["hd", "min", "bd", "ver", "who", "sdet", "folder", "one", "fin", "oin", "map", "rows", "fill", "st"].forEach(function (id) { sel[id] = root.getElementById("kc_" + id); });
    SKEYS.forEach(function (k) {
      var inp = sel["s_" + k] = root.getElementById("kc_s_" + k);
      inp.addEventListener("input", function () { signer[k] = inp.value; renderWho(); try { var o = {}; o[SKEY] = signer; chrome.storage.local.set(o); } catch (e) {} });
    });
    try { sel.ver.textContent = chrome.runtime.getManifest().version; } catch (e) {}
    try { if (localStorage.getItem(MIN_KEY) === "1") { sel.bd.style.display = "none"; sel.min.textContent = "+"; } } catch (e) {}
    sel.folder.addEventListener("click", function () { sel.fin.value = ""; sel.fin.click(); });
    sel.one.addEventListener("click", function () { sel.oin.value = ""; sel.oin.click(); });
    sel.fin.addEventListener("change", function () { pickFolder(sel.fin.files).catch(function (e) { busy = false; status("Error: " + e.message, "warn"); renderAll(); }); });
    sel.oin.addEventListener("change", function () { if (sel.oin.files[0]) splitEight(sel.oin.files[0]).catch(function (e) { busy = false; status("Error: " + e.message, "warn"); renderAll(); }); });
    sel.fill.addEventListener("click", fill);
    sel.min.addEventListener("click", function () { var hide = sel.bd.style.display !== "none"; sel.bd.style.display = hide ? "none" : "block"; sel.min.textContent = hide ? "+" : "–"; try { localStorage.setItem(MIN_KEY, hide ? "1" : "0"); } catch (e) {} });
    var sx, sy, ox, oy, drag = false;
    sel.hd.addEventListener("mousedown", function (e) { if (e.target === sel.min) return; drag = true; sx = e.clientX; sy = e.clientY; var rr = host.getBoundingClientRect(); ox = rr.left; oy = rr.top; host.style.right = "auto"; e.preventDefault(); });
    document.addEventListener("mousemove", function (e) { if (!drag) return; host.style.left = (ox + e.clientX - sx) + "px"; host.style.top = (oy + e.clientY - sy) + "px"; });
    document.addEventListener("mouseup", function () {
      if (!drag) return; drag = false;
      var rr = host.getBoundingClientRect(); try { localStorage.setItem(POS_KEY, JSON.stringify({ l: Math.max(0, Math.round(rr.left)), t: Math.max(0, Math.round(rr.top)) })); } catch (e) {}
    });
    try {
      chrome.storage.local.get(SKEY, function (r) { if (r && r[SKEY]) signer = Object.assign(signer, r[SKEY]); renderSigner(); renderAll(); if (!SKEYS.some(function (k) { return signer[k]; })) sel.sdet.open = true; });
    } catch (e) { renderAll(); }
    renderAll();
  }
  function start() { if (window.KH_FEATURE) window.KH_FEATURE("cert", build); else build(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
