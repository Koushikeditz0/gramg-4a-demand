/* Demand & Allocation Helper by Koushik — shared core (key normalisation + eKYC/ABPS eligibility helpers). */
window.DX = (function () {
  "use strict";
  function pad2(n) { n = String(n); return n.length < 2 ? "0" + n : n; }
  function normDate(v, fmt) {
    v = String(v == null ? "" : v).trim(); if (!v) return "";
    var iso = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/); if (iso) return iso[1] + "-" + pad2(+iso[2]) + "-" + pad2(+iso[3]);
    var m = v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/); if (!m) return v.toLowerCase();
    var a = +m[1], b = +m[2], y = +m[3]; if (y < 100) y += 2000; var day, mon;
    if (fmt === "dmy") { day = a; mon = b; }
    else if (fmt === "mdy") { day = b; mon = a; }
    else { if (a > 12) { day = a; mon = b; } else if (b > 12) { day = b; mon = a; } else { day = a; mon = b; } }
    return y + "-" + pad2(mon) + "-" + pad2(day);
  }
  function normName0(v) { return String(v == null ? "" : v).toLowerCase().replace(/\*/g, "").replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim(); }
  function tokenSort(s) { return s.split(" ").filter(Boolean).sort().join(" "); }
  function normKey(v, mode, opts) {
    opts = opts || {};
    if (mode === "id") return String(v == null ? "" : v).toUpperCase().replace(/\s+/g, "").replace(/\d+/g, function (m) { return String(parseInt(m, 10)); });
    if (mode === "date") return normDate(v, opts.dateFormat || "auto");
    if (mode === "name") return normName0(v);
    return String(v == null ? "" : v).trim().toLowerCase();
  }
  function levenshtein(a, b) {
    a = a || ""; b = b || ""; var m = a.length, n = b.length; if (!m) return n; if (!n) return m;
    var prev = [], cur = [], i, j; for (j = 0; j <= n; j++) prev[j] = j;
    for (i = 1; i <= m; i++) { cur[0] = i; for (j = 1; j <= n; j++) { var cost = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1; cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost); } var t = prev; prev = cur; cur = t; }
    return prev[n];
  }
  function similar(a, b) { a = a || ""; b = b || ""; if (!a && !b) return 1; var mx = Math.max(a.length, b.length); if (!mx) return 1; return 1 - levenshtein(a, b) / mx; }
  function nameScore(a, b, thr) {
    var na = normName0(a), nb = normName0(b); if (na === nb) return 1;
    var sa = tokenSort(na), sb = tokenSort(nb); if (sa === sb) return 0.99;
    var s = Math.max(similar(na, nb), similar(sa, sb)); return s >= thr ? s : 0;
  }
  var ABPS_STALE_MS = 7 * 24 * 60 * 60 * 1000;
  function abpsGp(card) { var a = String(card || "").split("/")[0].split("-"); return a.length >= 4 ? a.slice(0, 4).join("-") : ""; }
  // Match Work Allocation Registration No. against the ABPS export. Some portal exports
  // put Applicant No. after a slash in Job Card No. (…-001/001); others store the base
  // Job Card No. and Applicant No. in separate columns. Try exact key first, then base-card
  // and record-level fallback. Always require a strong applicant-name match to avoid
  // assigning one family member's status to another.
  function abpsFind(map, reg, name) {
    map = map || {};
    var rawReg = String(reg == null ? "" : reg).trim();
    var normReg = normKey(rawReg, "id");
    var list = map[normReg];
    var baseRaw = rawReg.split("/")[0];
    var baseKey = normKey(baseRaw, "id");
    var applicant = rawReg.indexOf("/") >= 0 ? normKey(rawReg.split("/").slice(1).join("/"), "id") : "";
    var candidates = [];
    if (list && list.length) candidates = candidates.concat(list);
    // Search keys by base Job Card No. where export omitted the applicant suffix.
    if (baseKey !== normReg) {
      var baseList = map[baseKey];
      if (baseList && baseList.length) candidates = candidates.concat(baseList);
    }
    // Robust fallback for differently formatted keys or separate Applicant No. columns.
    if (!candidates.length) {
      Object.keys(map).forEach(function (k) {
        (map[k] || []).forEach(function (a) {
          var card = String(a.card || k).trim();
          var cardBase = normKey(card.split("/")[0], "id");
          var cardApp = card.indexOf("/") >= 0 ? normKey(card.split("/ ").join("/").split("/").slice(1).join("/"), "id") : normKey(a.app || "", "id");
          if (cardBase === baseKey && (!applicant || !cardApp || applicant === cardApp)) candidates.push(a);
        });
      });
    }
    var best = null, bs = 0;
    for (var i = 0; i < candidates.length; i++) {
      var sc = nameScore(name, candidates[i].name, 0.82);
      if (sc > bs) { bs = sc; best = candidates[i]; }
    }
    return best;
  }
  function abpsCheck(map, reg, name, mode) {
    if (!mode || mode === "all") return { ok: true, reason: "", found: null };
    var best = abpsFind(map, reg, name);
    if (!best) return { ok: false, reason: "not in ABPS data", found: false };
    var needE = mode === "ekyc" || mode === "ekyc_abps", needA = mode === "abps" || mode === "ekyc_abps", why = [];
    // name the root cause when Aadhaar isn't even seeded
    if (needE && !best.ekyc) why.push(best.aadhaar ? "eKYC not done" : "Aadhaar not seeded");
    if (needA && !best.abps) why.push("ABPS not enabled");
    return why.length ? { ok: false, reason: why.join(" + "), found: true } : { ok: true, reason: "", found: true };
  }
  function abpsMetaFor(meta, reg) { return (meta && meta[abpsGp(normKey(reg, "id"))]) || null; }
  // "Dasghara-II (WB-06-003-006)" — never the normalised lookup key, which means nothing to a person
  function abpsLabel(m, key) { if (!m) return key || ""; return m.name ? m.name + (m.code ? " (" + m.code + ")" : "") : (m.code || key || ""); }
  function abpsStale(m) { return !m || !m.savedAt || (Date.now() - m.savedAt) > ABPS_STALE_MS; }
  function abpsAgeDays(m) { return m && m.savedAt ? Math.floor((Date.now() - m.savedAt) / 86400000) : null; }
  // "today at 14:32" · "yesterday at 09:05" · "3 days ago (24/09/2026 14:32)" — calendar days, local time
  function syncedWhen(ts) {
    ts = (ts && ts.savedAt) || ts; if (!ts) return "";
    var d = new Date(ts), p = function (n) { return (n < 10 ? "0" : "") + n; };
    var hm = p(d.getHours()) + ":" + p(d.getMinutes());
    var day = function (x) { return new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime(); };
    var n = Math.round((day(new Date()) - day(d)) / 86400000);
    if (n <= 0) return "today at " + hm;
    if (n === 1) return "yesterday at " + hm;
    return n + " days ago (" + p(d.getDate()) + "/" + p(d.getMonth() + 1) + "/" + d.getFullYear() + " " + hm + ")";
  }
  // CSV/table view of the dataset. Uses the portal's own job-card format (a.card), not the
  // normalised lookup key, so an operator can cross-check rows against the portal.
  var ABPS_HEADERS = ["Job Card No", "Applicant No", "Applicant Name", "Aadhaar Seeded", "Authentication Done", "ABPS Enabled", "eKYC Done"];
  function abpsLoad(cb) {
    try { chrome.storage.local.get(["dxAbpsMap", "dxAbpsMeta"], function (d) { cb((d && d.dxAbpsMap) || {}, (d && d.dxAbpsMeta) || {}); }); }
    catch (e) { cb({}, {}); }
  }

  function q(v) { v = (v == null ? "" : String(v)); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }

  function toCSV(headers, rows) {
    var lines = [];
    if (headers && headers.length) lines.push(headers.map(q).join(","));
    rows.forEach(function (r) { lines.push(r.map(q).join(",")); });
    return "﻿" + lines.join("\r\n"); // BOM so Excel reads UTF-8
  }

  function download(filename, text, mime) {
    var blob = new Blob([text], { type: mime || "text/plain;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a"); a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1500);
  }

  function abpsTable(map) {
    var yn = function (v) { return v ? "Yes" : "No"; }, rows = [];
    Object.keys(map || {}).forEach(function (k) {
      (map[k] || []).forEach(function (a) { rows.push([a.card || k, a.app, a.name, yn(a.aadhaar), yn(a.auth), yn(a.abps), yn(a.ekyc)]); });
    });
    return { headers: ABPS_HEADERS.slice(), rows: rows };
  }


  return {
    toCSV: toCSV, download: download, abpsTable: abpsTable,
    normKey: normKey, similar: similar, nameScore: nameScore,
    abpsCheck: abpsCheck, abpsFind: abpsFind, abpsMetaFor: abpsMetaFor, abpsStale: abpsStale,
    abpsAgeDays: abpsAgeDays, syncedWhen: syncedWhen, abpsGp: abpsGp, abpsLoad: abpsLoad, abpsLabel: abpsLabel
  };
})();
