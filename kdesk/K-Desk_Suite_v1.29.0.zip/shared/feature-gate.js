/* feature-gate.js — Dashboard-এর On/Off toggle আর PC activation lock মেনে feature চালায়।
   PC activated না হলে কোনো feature চলবে না; activated হলে Off করা feature বাদ। */
// v1.7.1: ABPS Data Sync আর NPCI সবসময় চালু (Dashboard-এ toggle নেই), আগে Off করা থাকলেও
var KH_ALWAYS = { abps: 1, npci: 1 };
window.KH_FEATURE = window.KH_FEATURE || function (name, run) {
  try {
    window.KH_LICENSE.check(function (ok) {
      if (!ok) return;
      chrome.storage.local.get(["kh_features", "kh_off"], function (r) {
        if (r && r.kh_off) return;                              // Dashboard-এর মূল K-Desk On/Off = OFF
        var f = (r && r.kh_features) || {}; if (f[name] === false && !KH_ALWAYS[name]) return; run();
      });
    });
  } catch (e) {}
};
