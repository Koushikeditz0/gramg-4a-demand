/* K-Desk Suite by Koushik — Gram Setu link
   Loads the lists that supervisors submitted in Koushik's own "Gram Setu"
   app (his own Supabase project) straight into the Work Demand queue, instead of exporting an
   Excel from the admin panel and choosing it here.
   The login is a limited "kdesk" account: it can only read the submitted lists of its own GP
   and lock them. Only the session token is kept (chrome.storage.local "kdlb_sess"), never the PIN.
   Nothing is sent back to the app except "these lists were loaded / lock them".
   Used by the Demand panel: KDLink.open({ onRows: function (rows) { … return true; } }). */
(function () {
  "use strict";
  if (window.KDLink) return;

  var SB_URL = "https://wbzybizfpdalpukfzefk.supabase.co";
  var SB_KEY = "sb_publishable_fCY9paYMNTyepXdI7YRhkw_2u85P7bn";   // public key, protected by RLS + server functions
  var EMAIL_DOMAIN = "@users.gramg.invalid";
  var SESS_KEY = "kdlb_sess", PREF_KEY = "kdlb_pref";

  var BN = {
    NETWORK: "Gram Setu server-এ পৌঁছানো গেল না। Internet দেখে আবার চেষ্টা করুন।",
    NOT_AUTHORIZED: "এই account K-Desk-এর জন্য নয়। Admin panel-এ যে kdesk login বানানো হয়েছে সেটা দিন।",
    SESSION_REVOKED: "Login শেষ হয়ে গেছে (অন্য device-এ login বা admin বন্ধ করেছে)। আবার login করুন।",
    NOT_LOGGED_IN: "আগে login করুন।",
    USER_DISABLED: "এই account বন্ধ করা আছে।",
    LIST_NOT_FOUND: "List পাওয়া যায়নি (হয়তো reopen বা শেষ করা হয়েছে)। ⟳ চেপে আবার দেখুন।",
    BAD_INPUT: "অন্তত একটা list বাছুন (সর্বোচ্চ ২০০)।"
  };
  function errText(e) { return (e && BN[e.code]) || ("Server error: " + ((e && e.message) || e)); }
  function ApiError(code, msg, status, network) { var e = new Error(msg || code); e.code = code; e.status = status; e.network = !!network; return e; }

  /* ---------------- storage ---------------- */
  function stGet(k) { return new Promise(function (res) { try { chrome.storage.local.get(k, function (o) { res((o || {})[k] || null); }); } catch (e) { res(null); } }); }
  function stSet(k, v) { return new Promise(function (res) { try { var o = {}; o[k] = v; chrome.storage.local.set(o, res); } catch (e) { res(); } }); }
  function stDel(k) { return new Promise(function (res) { try { chrome.storage.local.remove(k, res); } catch (e) { res(); } }); }

  /* ---------------- Supabase (documented HTTP API, same calls as the app's sb-client.js) ---------------- */
  var sess = null;
  function request(path, body, token) {
    var h = { apikey: SB_KEY, "Content-Type": "application/json" };
    if (token) h.Authorization = "Bearer " + token;
    var ctrl = new AbortController(), t = setTimeout(function () { ctrl.abort(); }, 25000);
    return fetch(SB_URL + path, { method: "POST", headers: h, cache: "no-store", body: JSON.stringify(body || {}), signal: ctrl.signal })
      .then(function (res) {
        clearTimeout(t);
        return res.text().then(function (txt) {
          var d = null; try { d = txt ? JSON.parse(txt) : null; } catch (e) { d = txt; }
          if (!res.ok) {
            var msg = (d && (d.message || d.msg || d.error_description || d.error)) || ("HTTP " + res.status);
            var code = (d && (d.error_code || d.code)) || String(res.status);
            if (typeof msg === "string" && /^[A-Z][A-Z0-9_]{2,40}$/.test(msg)) code = msg;
            throw ApiError(code, msg, res.status);
          }
          return d;
        });
      }, function () { clearTimeout(t); throw ApiError("NETWORK", BN.NETWORK, 0, true); });
  }
  function keep(d) {
    sess = { access_token: d.access_token, refresh_token: d.refresh_token,
             expires_at: d.expires_at || Math.floor(Date.now() / 1000) + (d.expires_in || 3600),
             username: sess && sess.username, gp: sess && sess.gp, name: sess && sess.name };
    return stSet(SESS_KEY, sess);
  }
  function dropSession() { sess = null; return stDel(SESS_KEY); }
  function fresh() {
    if (!sess) return Promise.reject(ApiError("NOT_LOGGED_IN"));
    if (sess.expires_at - Date.now() / 1000 > 90) return Promise.resolve();
    return request("/auth/v1/token?grant_type=refresh_token", { refresh_token: sess.refresh_token }).then(keep, function (e) {
      if (!e.network) { dropSession(); e.code = "SESSION_REVOKED"; }
      throw e;
    });
  }
  function rpc(fn, args) {
    return fresh().then(function () { return request("/rest/v1/rpc/" + fn, args, sess.access_token); }).catch(function (e) {
      if (["SESSION_REVOKED", "NOT_LOGGED_IN", "USER_DISABLED"].indexOf(e.code) >= 0 || (e.status === 401 && !e.network)) {
        dropSession(); if (e.status === 401 && !BN[e.code]) e.code = "SESSION_REVOKED";
      }
      throw e;
    });
  }
  function login(username, pin) {
    username = String(username || "").trim().toLowerCase(); pin = String(pin || "").trim();
    if (!/^[a-z0-9_.-]{3,32}$/.test(username)) return Promise.reject(ApiError("X", "Username সঠিক নয়।"));
    if (pin.length < 6) return Promise.reject(ApiError("X", "PIN কমপক্ষে ৬ সংখ্যার।"));
    sess = null;
    return request("/auth/v1/token?grant_type=password", { email: username + EMAIL_DOMAIN, password: pin })
      .then(keep, function (e) { if (e.network) throw e; throw ApiError("X", "Username/PIN ভুল অথবা account বন্ধ।"); })
      .then(function () { return rpc("register_session", { p_user_agent: ("K-Desk " + navigator.userAgent).slice(0, 300) }); })
      .then(function () { return rpc("get_my_context", {}); })
      .then(function (ctx) {
        if (!ctx || ctx.role !== "kdesk") {
          return logout().then(function () { throw ApiError("NOT_AUTHORIZED"); });
        }
        sess.username = ctx.username; sess.name = ctx.full_name; sess.gp = ctx.gp_name;
        return stSet(SESS_KEY, sess);
      });
  }
  function logout() {
    var s = sess; if (!s) return dropSession();
    return request("/rest/v1/rpc/logout_session", {}, s.access_token).catch(function () {})
      .then(function () { return request("/auth/v1/logout?scope=local", {}, s.access_token).catch(function () {}); })
      .then(dropSession);
  }

  /* ---------------- rows for the Demand panel (pure; mirrors the admin "K-Desk export") ---------------- */
  // codeFor(apiRow) -> Work Code for that worker ("" = Demand only). map ties each queued row back to
  // its list and worker, so the Demand / Allocation results can be written back to the app.
  function buildRows(apiRows, fromDMY, days, codeFor) {
    var seen = {}, out = [], skipped = [], dupes = 0;
    (apiRows || []).forEach(function (r) {
      if (seen[r.worker_id]) { dupes++; return; }
      seen[r.worker_id] = 1;
      if (r.worker_active === false || !r.eligible) { skipped.push(r); return; }
      out.push(r);
    });
    out.sort(function (a, b) {
      return a.village_no - b.village_no || a.household_no - b.household_no ||
        (a.job_card_no < b.job_card_no ? -1 : a.job_card_no > b.job_card_no ? 1 : 0) || a.applicant_no - b.applicant_no;
    });
    return {
      // the supervisor's own date in Gram Setu (From + Working days, SQL v189/v209) wins; lists without one use the box
      rows: out.map(function (r) {
        var own = r.from_date && r.work_days ? isoToDMY(String(r.from_date).slice(0, 10)) : "";
        return { "Reg No": r.job_card_no, "Applicant": r.applicant_name, "Work From": own || fromDMY, "No of Days": String(own ? r.work_days : days) };
      }),
      map: out.map(function (r) { return { reg: r.job_card_no, app: r.applicant_name, l: r.list_id, w: r.worker_id, c: (codeFor && codeFor(r)) || "" }; }),
      skipped: skipped, dupes: dupes
    };
  }

  /* ---------------- UI ---------------- */
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function bnNum(n) { return String(n).replace(/[0-9]/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); }
  function fmtDate(iso) {
    if (!iso) return ""; var d = new Date(iso); if (isNaN(d)) return "";
    var p = function (x) { return (x < 10 ? "0" : "") + x; };
    return p(d.getDate()) + "/" + p(d.getMonth() + 1) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
  }
  function isoToDMY(v) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || ""); return m ? m[3] + "/" + m[2] + "/" + m[1] : ""; }
  function todayISO() { var d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); }

  var CSS =
    ":host{all:initial}" +
    ".ov{position:fixed;inset:0;background:rgba(11,20,55,.45);z-index:2147483600;display:flex;align-items:center;justify-content:center;font-family:'Segoe UI','Nirmala UI',Noto Sans Bengali,system-ui,sans-serif;font-size:13px;color:#0f172a}" +
    ".card{width:min(560px,94vw);max-height:88vh;display:flex;flex-direction:column;background:#fff;border-radius:16px;box-shadow:0 24px 60px rgba(11,20,55,.35);overflow:hidden}" +
    ".hd{position:relative;display:flex;align-items:center;gap:10px;padding:12px 14px;color:#fff;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%)}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".logo{width:32px;height:32px;border-radius:10px;display:grid;place-items:center;font:800 17px/1 Georgia,serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b)}" +
    ".ttl{flex:1;min-width:0}.ttl b{display:block;font-size:14.5px}.ttl small{display:block;font-size:11px;color:#c7d2fe;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
    ".x{cursor:pointer;border:0;border-radius:8px;width:28px;height:28px;background:rgba(255,255,255,.14);color:#fff;font:700 15px/1 system-ui}" +
    ".bd{padding:12px 14px;overflow:auto}" +
    "label.f{display:block;font-size:11.5px;font-weight:600;color:#475569;margin:8px 0 3px}" +
    "input[type=text],input[type=password],input[type=date],input[type=number]{box-sizing:border-box;width:100%;padding:8px 9px;border:1px solid #cbd5e1;border-radius:9px;font:inherit}" +
    ".row{display:flex;gap:8px;align-items:flex-end}.row>div{flex:1}" +
    ".btn{cursor:pointer;border:0;border-radius:10px;padding:9px 12px;font:600 12.5px/1.2 inherit;font-family:inherit}" +
    ".fill{color:#fff;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.fill:disabled{opacity:.45;cursor:not-allowed}" +
    ".ghost{background:#f8fafc;color:#0f172a;border:1px solid #e2e8f0}" +
    ".lists{border:1px solid #e2e8f0;border-radius:10px;max-height:300px;overflow:auto;margin-top:6px}" +
    ".it{display:flex;gap:9px;align-items:flex-start;padding:8px 10px;border-bottom:1px solid #f1f5f9;cursor:pointer}.it:last-child{border-bottom:0}.it:hover{background:#f5f7ff}" +
    ".it input{margin-top:3px}.it b{font-size:13px}.meta{font-size:11px;color:#64748b;margin-top:2px}" +
    ".tag{display:inline-block;font-size:10.5px;font-weight:700;border-radius:99px;padding:1px 7px;margin-left:5px}" +
    ".t-sub{background:#ecfdf5;color:#047857}.t-lock{background:#fef3c7;color:#92400e}.t-exp{background:#eef2ff;color:#3730a3}" +
    ".empty{padding:16px;text-align:center;color:#64748b}" +
    ".st{margin-top:10px;padding:7px 10px;border-radius:9px;background:#f8fafc;font-size:12px;min-height:16px}.st.err{background:#fff5f5;color:#b91c1c}.st.ok{background:#ecfdf5;color:#047857}.st.warn{background:#fffbeb;color:#92400e}" +
    ".ft{display:flex;gap:8px;justify-content:space-between;align-items:center;padding:10px 14px;border-top:1px solid #e2e8f0;background:#f8fafc}" +
    ".who{font-size:11px;color:#64748b}.chk{font-size:12px;display:flex;gap:6px;align-items:center;margin-top:10px}" +
    ".note{font-size:11px;color:#64748b;margin-top:8px;line-height:1.45}";

  var host = null, root = null, opts = null, lists = [], afterLogin = null, shellTitle = "☁ Gram Setu থেকে আনো";

  function close() { if (host) { host.remove(); host = null; root = null; } }
  function $(id) { return root && root.getElementById(id); }
  function setStatus(msg, kind) { var s = $("st"); if (s) { s.textContent = msg || ""; s.className = "st" + (kind ? " " + kind : ""); } }

  function shell(sub, body, foot) {
    root.innerHTML = "<style>" + CSS + "</style>" +
      "<div class='ov' id='ov'><div class='card'>" +
      "<div class='hd'><div class='logo'>K</div><div class='ttl'><b>" + esc(shellTitle) + "</b><small>" + esc(sub) + "</small></div><button class='x' id='x' title='বন্ধ'>✕</button></div>" +
      "<div class='bd'>" + body + "<div class='st' id='st'></div></div>" +
      "<div class='ft'>" + foot + "</div></div></div>";
    $("x").addEventListener("click", close);
    $("ov").addEventListener("mousedown", function (e) { if (e.target === $("ov")) close(); });
  }

  function showLogin(msg) {
    shell("Gram Setu · আপনার নিজের server",
      "<div class='note'>Admin panel-এ বানানো <b>kdesk</b> account দিয়ে একবার login করুন। PIN সেভ হবে না, শুধু login থাকবে।</div>" +
      "<label class='f'>Username</label><input type='text' id='u' autocomplete='off' spellcheck='false'>" +
      "<label class='f'>PIN</label><input type='password' id='p' inputmode='numeric' autocomplete='off'>",
      "<span class='who'>✦ K-Desk Suite</span><button class='btn fill' id='go'>Login</button>");
    var go = function () {
      $("go").disabled = true; setStatus("Login হচ্ছে…");
      login($("u").value, $("p").value).then(function () { (afterLogin || showLists)(); }, function (e) {
        $("go").disabled = false; setStatus(e.code === "X" ? e.message : errText(e), "err");
      });
    };
    $("go").addEventListener("click", go);
    $("p").addEventListener("keydown", function (e) { if (e.key === "Enter") go(); });
    stGet(PREF_KEY).then(function (p) { if (p && p.username && $("u")) { $("u").value = p.username; $("p").focus(); } else if ($("u")) $("u").focus(); });
    if (msg) setStatus(msg, "warn");
  }

  function showLists() {
    stSet(PREF_KEY, { username: sess.username });
    shell((sess.gp || "") + " · " + (sess.name || sess.username),
      "<div class='row'><div><label class='f'>Work From (যে list-এ তারিখ নেই তার জন্য)</label><input type='date' id='from'></div>" +
      "<div style='flex:0 0 110px'><label class='f'>Days</label><input type='number' id='days' min='1' max='366' value='14'></div>" +
      "<div style='flex:0 0 auto'><button class='btn ghost' id='rf' title='আবার আনো'>⟳</button></div></div>" +
      "<label class='f'>Work Code (Work Allocation-এর জন্য; যে list-এ app-এ Work Code দেওয়া আছে সেটা নিজে থেকেই নেওয়া হবে)</label>" +
      "<input type='text' id='wcode' spellcheck='false' autocomplete='off' placeholder='যেমন 3206003006/IF/93393042892327'>" +
      "<label class='chk'><input type='checkbox' id='auto' checked>Demand শেষ হলে সফল worker-দের নিয়ে Work Allocation নিজে থেকে চালাও</label>" +
      "<label class='f'>জমা পড়া list (যেগুলো নেবেন সেগুলোতে টিক দিন)</label>" +
      "<div class='lists' id='lists'><div class='empty'>আনছি…</div></div>" +
      "<label class='chk'><input type='checkbox' id='lock' checked>Load হলে list lock করো (Supervisor আর বদলাতে পারবে না)</label>" +
      "<div class='note'>একই worker দুটো list-এ থাকলে একবারই নেওয়া হবে। App-এ যারা inactive বা eKYC/ABPS-এ যোগ্য নয় তারা বাদ যাবে (app-এর export-এর মতো)।</div>",
      "<button class='btn ghost' id='out'>Logout</button><button class='btn fill' id='load' disabled>⭳ Queue-তে নাও</button>");
    stGet(PREF_KEY).then(function (p) {
      $("from").value = (p && p.from && p.from >= todayISO()) ? p.from : todayISO();
      if (p && p.days) $("days").value = p.days;
      if (p && p.auto === false) $("auto").checked = false;
      syncAuto();
    });
    $("wcode").addEventListener("input", syncAuto);
    $("rf").addEventListener("click", function () { fetchLists(); });
    $("out").addEventListener("click", function () { logout().then(function () { showLogin(); }); });
    $("load").addEventListener("click", doLoad);
    fetchLists();
  }

  // Allocation runs only when a Work Code is given
  function listCodes(ids) { var m = {}; lists.forEach(function (l) { if (ids.indexOf(l.list_id) >= 0 && l.work_code) m[l.list_id] = l.work_code; }); return m; }
  function syncAuto() {
    var a = $("auto"), w = $("wcode"); if (!a || !w) return;
    a.disabled = !w.value.trim() && !Object.keys(listCodes(picked())).length; a.parentNode.style.opacity = a.disabled ? ".5" : "1";
  }
  function hasDate(l) { return !!(l && l.from_date && l.work_days); }
  function allDated(ids) { return ids.length > 0 && ids.every(function (id) { return lists.some(function (l) { return l.list_id === id && hasDate(l); }); }); }
  function picked() {
    var ids = []; [].forEach.call(root.querySelectorAll(".it input:checked"), function (c) { ids.push(c.value); }); return ids;
  }
  function updateLoadBtn() {
    var ids = picked(), n = 0;
    lists.forEach(function (l) { if (ids.indexOf(l.list_id) >= 0) n += +l.eligible || 0; });
    var b = $("load"); if (!b) return;
    b.disabled = !ids.length;
    b.textContent = ids.length ? "⭳ Queue-তে নাও (" + bnNum(ids.length) + " list, ~" + bnNum(n) + " জন)" : "⭳ Queue-তে নাও";
    var codes = listCodes(ids), w = $("wcode");
    if (w) w.placeholder = Object.keys(codes).length === ids.length && ids.length ? "বাছা সব list-এর নিজের Work Code আছে" : "যেমন 3206003006/IF/93393042892327";
    syncAuto();
  }

  function fetchLists(keepStatus) {
    var box = $("lists"); if (!box) return;
    box.innerHTML = "<div class='empty'>আনছি…</div>"; if (keepStatus !== true) setStatus("");
    rpc("kdesk_lists", {}).then(function (rows) {
      lists = rows || [];
      if (!lists.length) { box.innerHTML = "<div class='empty'>এখনো কোনো list জমা পড়েনি।</div>"; updateLoadBtn(); return; }
      box.innerHTML = lists.map(function (l, i) {
        var tags = l.submit_state === "locked" ? "<span class='tag t-lock'>🔒 Locked</span>" : "<span class='tag t-sub'>✓ জমা</span>";
        if (l.export_count) tags += "<span class='tag t-exp'>আগে নেওয়া " + bnNum(l.export_count) + " বার</span>";
        return "<label class='it'><input type='checkbox' value='" + esc(l.list_id) + "'" + (l.export_count ? "" : " checked") + ">" +
          "<div><b>" + esc(l.work_name || "(নাম নেই)") + "</b>" + tags +
          "<div class='meta'>" + esc(l.full_name || l.username) + " · " + bnNum(l.eligible) + "/" + bnNum(l.workers) + " জন যোগ্য" +
          (l.submitted_at ? " · জমা " + esc(fmtDate(l.submitted_at)) : "") +
          ((l.supervisors && l.supervisors.length) ? " · Supervisor: " + esc(l.supervisors.join(", ")) : "") +
          (l.work_code ? "<div class='meta'>Work Code: <b>" + esc(l.work_code) + "</b></div>" : "") +
          "<div class='meta'>তারিখ: " + (hasDate(l) ? "<b>" + esc(isoToDMY(String(l.from_date).slice(0, 10))) + "</b> · " + bnNum(l.work_days) + " দিন (Supervisor-এর দেওয়া)"
                                                    : "দেওয়া নেই, উপরের Work From/Days নেবে") + "</div>" + "</div></div></label>";
      }).join("");
      [].forEach.call(box.querySelectorAll("input"), function (c) { c.addEventListener("change", updateLoadBtn); });
      updateLoadBtn();
    }, function (e) {
      if (!sess) { showLogin(errText(e)); return; }
      box.innerHTML = "<div class='empty'>আনা গেল না।</div>"; setStatus(errText(e), "err");
    });
  }

  function doLoad() {
    var ids = picked(), fromISO = $("from").value, from = isoToDMY(fromISO), days = parseInt($("days").value, 10), doLock = $("lock").checked;
    var workCode = $("wcode").value.replace(/\s+/g, ""), codes = listCodes(ids), anyCode = !!workCode || Object.keys(codes).length > 0;
    var auto = anyCode && $("auto").checked;
    if (!ids.length) { setStatus("আগে list বাছুন।", "err"); return; }
    var dated = allDated(ids);
    if (!from && !dated) { setStatus("Work From তারিখ দিন।", "err"); return; }
    if (!(days >= 1 && days <= 366) && !dated) { setStatus("Days ঠিক দিন (১ থেকে ৩৬৬)।", "err"); return; }
    if (workCode && !/^[^\/]+\/[A-Za-z]{2,3}\/[^\/]+/.test(workCode)) { setStatus("Work Code-এর format মিলছে না (যেমন 3206003006/IF/93393042892327)।", "err"); return; }
    stSet(PREF_KEY, { username: sess.username, from: fromISO, days: days, auto: $("auto").checked });
    $("load").disabled = true; setStatus("Worker আনছি…");
    var built;
    rpc("kdesk_list_rows", { p_list_ids: ids }).then(function (apiRows) {
      built = buildRows(apiRows, from, days, function (r) { return r.work_code || codes[r.list_id] || workCode; });
      if (!built.rows.length) throw ApiError("X", "এই list-গুলোতে নেওয়ার মতো কোনো worker নেই।");
      var main = workCode || codes[Object.keys(codes)[0]] || "";
      var ok = opts && opts.onRows ? opts.onRows(built.rows, { workCode: main, autoAlloc: auto, map: built.map }) : false;
      if (ok === false) throw ApiError("X", "Queue-তে নেওয়া গেল না (হয়তো একটা run চলছে, আগে Stop করুন)।");
      return doLock ? rpc("kdesk_lock_lists", { p_list_ids: ids }).catch(function () { return { lockFailed: true }; }) : null;
    }).then(function (lk) {
      var msg = "✅ " + bnNum(built.rows.length) + " জন queue-তে এসেছে।" + (dated ? " তারিখ: প্রতিটা list-এর নিজের।" : "");
      if (built.dupes) msg += " " + bnNum(built.dupes) + " জন একাধিক list-এ ছিল, একবারই নেওয়া হয়েছে।";
      if (built.skipped.length) msg += " ⚠ " + bnNum(built.skipped.length) + " জন বাদ (inactive বা অযোগ্য): " +
        built.skipped.slice(0, 6).map(function (r) { return r.job_card_no + " " + r.applicant_name; }).join("; ") + (built.skipped.length > 6 ? " …" : "");
      if (lk && lk.lockFailed) msg += " (List lock করা যায়নি, app-এ দেখে নিন।)";
      else if (lk) msg += " List lock হয়েছে।";
      if (anyCode) msg += auto ? " Demand শেষ হলে সফল worker-রা নিজে থেকেই Work Allocation-এ যাবে (" + (Object.keys(codes).length ? "list-এর Work Code" : workCode) + ")।"
                                : " Demand শেষ হলে Work Allocation page খুললেই সফল worker-রা queue-তে থাকবে।";
      setStatus(msg, built.skipped.length ? "warn" : "ok");
      fetchLists(true);
      if (!built.skipped.length) setTimeout(close, 1800);
    }).catch(function (e) {
      updateLoadBtn();
      if (!sess) { showLogin(errText(e)); return; }
      setStatus(e.code === "X" ? e.message : errText(e), "err");
    });
  }

  function open(o) {
    opts = o || {};
    close(); afterLogin = showLists; shellTitle = "☁ Gram Setu থেকে আনো";
    host = document.createElement("div"); host.id = "kdlb-host";
    root = host.attachShadow({ mode: "open" });
    document.documentElement.appendChild(host);
    stGet(SESS_KEY).then(function (s) { sess = s; if (sess && sess.refresh_token) showLists(); else showLogin(); });
  }

  /* ---------------- ABPS Sync -> Gram Setu ----------------
     After an ABPS Sync, send ONLY the four yes/no flags per worker (Job Card + Applicant No,
     name only to match when the report has no Applicant No) to the Gram Setu app
     (kdesk_sync_flags updates existing workers of the kdesk login's GP and logs every change).
     cb(err, { sent, matched, changed }) — err.code "NOT_LOGGED_IN" when K-Desk has no Gram Setu login. */
  /* fin (v1.23.0, SQL v222): { villages: [13, 14 …], complete: true|false }. Every batch then carries one run id and,
     at the end, kdesk_sync_finish makes workers the portal no longer lists inactive (soft, the server has the
     safety limits). out.missing = { status, missing, deactivated, restored, note }. Old server (no v222) → flags only. */
  function newRunId() {
    try { if (crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
    var b = new Uint8Array(16); crypto.getRandomValues(b); b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128;
    var h = Array.prototype.map.call(b, function (x) { return (x < 16 ? "0" : "") + x.toString(16); }).join("");
    return h.slice(0, 8) + "-" + h.slice(8, 12) + "-" + h.slice(12, 16) + "-" + h.slice(16, 20) + "-" + h.slice(20);
  }
  function noFn(e) { return e && (e.code === "PGRST202" || /Could not find the function/i.test(e.message || "")); }
  function syncFlags(rows, cb, fin) {
    stGet(SESS_KEY).then(function (s) {
      sess = s;
      if (!sess || !sess.refresh_token) { cb(ApiError("NOT_LOGGED_IN")); return; }
      var out = { sent: 0, matched: 0, changed: 0, restored: 0 }, B = 3000, i = 0;
      var run = fin ? newRunId() : null;
      function done() {
        if (!run) { cb(null, out); return; }
        rpc("kdesk_sync_finish", { p_run: run, p_villages: fin.villages || [], p_complete: !!fin.complete }).then(function (r) {
          out.missing = r || null; cb(null, out);
        }, function (e) { out.missing = { status: "error", note: errText(e) }; cb(null, out); });
      }
      (function next() {
        if (i >= rows.length) { done(); return; }
        var part = rows.slice(i, i + B);
        var args = { p_rows: part }; if (run) args.p_run = run;
        rpc("kdesk_sync_flags", args).then(function (r) {
          i += B;
          out.sent += part.length; out.matched += (r && r.matched) || 0; out.changed += (r && r.changed) || 0; out.restored += (r && r.restored) || 0; next();
        }, function (e) {
          // server without SQL v222: same batch again the old way, no inactive marking
          if (run && i === 0 && noFn(e)) { run = null; out.oldServer = true; next(); return; }
          e.text = errText(e); cb(e, out);
        });
      })();
    });
  }

  /* ---------------- Demand / Allocation results -> Gram Setu ----------------
     kind "demand" | "alloc"; items [{ l: list_id, w: worker_id, s: "done"|"error"|"skipped", m: message, c: work code }].
     Only workers of lists this login loaded; the app shows them to the Admin and the list's Supervisor. */
  function reportResults(kind, items, cb) {
    cb = cb || function () {};
    // rows that came from an IAY Tracker job (l = "iay:<job id>", w = work code) go to that job instead
    var iay = {}, rest = [];
    (items || []).forEach(function (x) {
      var m = x && /^iay:(\d+)$/.exec(String(x.l || ""));
      if (m) (iay[m[1]] = iay[m[1]] || []).push({ key: x.w, s: x.s, m: x.m }); else rest.push(x);
    });
    var ids = Object.keys(iay);
    if (ids.length) {
      var left = ids.length, sentI = 0, firstErr = null;
      ids.forEach(function (id) {
        iayReport(id, kind, iay[id], function (err, o) {
          if (err && !firstErr) firstErr = err; sentI += (o && o.sent) || 0;
          if (--left === 0) { if (!rest.length) cb(firstErr, { sent: sentI }); else reportResults(kind, rest, cb); }
        });
      });
      return;
    }
    items = rest;
    var rows = (items || []).filter(function (x) { return x && x.l && x.w && /^(done|error|skipped)$/.test(x.s); })
      .map(function (x) { return { l: x.l, w: x.w, k: kind, s: x.s, m: String(x.m || "").slice(0, 300), c: x.c || "" }; });
    if (!rows.length) { cb(null, { sent: 0 }); return; }
    stGet(SESS_KEY).then(function (s) {
      sess = s;
      if (!sess || !sess.refresh_token) { cb(ApiError("NOT_LOGGED_IN")); return; }
      var out = { sent: 0 }, B = 2000, i = 0;
      (function next() {
        if (i >= rows.length) { cb(null, out); return; }
        var part = rows.slice(i, i + B); i += B;
        rpc("kdesk_report_results", { p_rows: part }).then(function () { out.sent += part.length; next(); },
          function (e) { e.text = errText(e); cb(e, out); });
      })();
    });
  }
  // Match run workers (Reg No + Applicant name) back to the rows loaded from the app; each map entry is used once.
  function matcher(map) {
    var by = {};
    (map || []).forEach(function (m) { var k = String(m.reg).trim().toUpperCase() + "|" + String(m.app).trim().toLowerCase(); (by[k] = by[k] || []).push(m); });
    return function (reg, app) { var q = by[String(reg).trim().toUpperCase() + "|" + String(app).trim().toLowerCase()]; return q && q.length ? q.shift() : null; };
  }


  /* ---------------- Account copy requests -> Gram Setu ----------------
     From the portal's Wage List page: workers whose bank account is not frozen are sent as
     "📷 Account copy চাই" requests to every supervisor of the kdesk login's GP
     (kdesk_add_account_requests, SQL v184). Only Job Card + name leave the page.
     KDLink.askAccounts({ rows: [{ jc, ap, name, info }], source: "Wage List …" }) */
  var accRows = [], accSource = "";
  function openAccounts(o) {
    o = o || {};
    accRows = (o.rows || []).filter(function (r) { return r && r.jc; });
    accSource = String(o.source || "Wage List");
    close(); afterLogin = showAccounts; shellTitle = "📷 Account copy চাই → Gram Setu";
    host = document.createElement("div"); host.id = "kdlb-host";
    root = host.attachShadow({ mode: "open" });
    document.documentElement.appendChild(host);
    stGet(SESS_KEY).then(function (s) { sess = s; if (sess && sess.refresh_token) showAccounts(); else showLogin(); });
  }
  function accPicked() {
    var out = []; [].forEach.call(root.querySelectorAll(".it input:checked"), function (c) { var r = accRows[+c.value]; if (r) out.push(r); }); return out;
  }
  function showAccounts() {
    stSet(PREF_KEY, { username: sess.username });
    var items = accRows.map(function (r, i) {
      return "<label class='it'><input type='checkbox' value='" + i + "' checked><div><b>" + esc(r.name || "—") + "</b>" +
        "<div class='meta'>" + esc(r.jc) + (r.info ? " · " + esc(r.info) : "") + "</div></div></label>";
    }).join("");
    shell((sess.gp || "") + " · " + (sess.name || sess.username),
      "<div class='note'>এই worker-দের account <b>নেই বা freeze হয়নি</b>। পাঠালে Gram Setu app-এ এই GP-র <b>সব supervisor</b>-এর কাছে " +
      "<b>📷 Account copy চাই</b> দেখাবে। শুধু Job Card, Applicant No আর নাম যাবে।</div>" +
      "<div class='chk'><input type='checkbox' id='all' checked><label for='all'>সব বাছুন (" + bnNum(accRows.length) + " জন)</label></div>" +
      "<div class='lists' id='box'>" + (items || "<div class='empty'>কোনো worker নেই।</div>") + "</div>" +
      "<label class='f'>Note (supervisor দেখবে)</label><input type='text' id='nt' maxlength='200'>",
      "<button class='btn ghost' id='out'>Logout</button><button class='btn fill' id='send'>📷 পাঠাও</button>");
    $("nt").value = accSource.slice(0, 200);
    var upd = function () { var n = accPicked().length; $("send").disabled = !n; $("send").textContent = "📷 " + bnNum(n) + " জনকে পাঠাও"; };
    $("all").addEventListener("change", function () { var v = $("all").checked; [].forEach.call(root.querySelectorAll(".it input"), function (c) { c.checked = v; }); upd(); });
    [].forEach.call(root.querySelectorAll(".it input"), function (c) { c.addEventListener("change", upd); });
    $("out").addEventListener("click", function () { logout().then(function () { showLogin(); }); });
    $("send").addEventListener("click", sendAccounts);
    upd();
  }
  function sendAccounts() {
    var picked = accPicked(); if (!picked.length) return;
    var note = $("nt").value, B = 3000, i = 0, res = { added: 0, already: 0, not_found: [], unclear: [] };
    $("send").disabled = true; setStatus("পাঠানো হচ্ছে…");
    (function next() {
      if (i >= picked.length) { done(); return; }
      var part = picked.slice(i, i + B).map(function (r) { return { jc: r.jc, ap: r.ap ? String(r.ap) : "", name: r.name || "" }; }); i += B;
      rpc("kdesk_add_account_requests", { p_rows: part, p_note: note }).then(function (r) {
        r = r || {}; res.added += r.added || 0; res.already += r.already || 0;
        res.not_found = res.not_found.concat(r.not_found || []); res.unclear = res.unclear.concat(r.unclear || []); next();
      }, function (e) {
        $("send").disabled = false;
        if (/kdesk_add_account_requests|PGRST202|404/.test((e.code || "") + " " + (e.message || "")))
          setStatus("Gram Setu-এ এখনো v184 SQL চালানো হয়নি (kdesk_add_account_requests নেই)।", "err");
        else if (!sess) showLogin(errText(e));
        else setStatus(errText(e), "err");
      });
    })();
    function done() {
      var miss = res.not_found.concat(res.unclear).map(function (r) { return r.jc + " " + (r.name || ""); });
      var msg = "✓ নতুন request: " + bnNum(res.added) + " জন" + (res.already ? " · আগে থেকেই চাওয়া আছে: " + bnNum(res.already) : "") +
        (miss.length ? " · App-এ মেলেনি " + bnNum(miss.length) + " জন: " + miss.slice(0, 8).join("; ") + (miss.length > 8 ? " …" : "") : "");
      setStatus(msg, miss.length ? "warn" : "ok");
      $("send").textContent = "✓ পাঠানো হয়েছে";
    }
  }


  /* ---------------- generic call for other K-Desk pages (Bank A/c Update) ----------------
     KDLink.call(fn, args, title) -> Promise. When there is no Gram Setu login yet it shows the
     login box first (title on top), then makes the call. */
  function call(fn, args, title) {
    return stGet(SESS_KEY).then(function (s) {
      sess = s;
      if (sess && sess.refresh_token) return rpc(fn, args || {});
      return new Promise(function (res, rej) {
        close(); shellTitle = title || "☁ Gram Setu"; opts = {};
        afterLogin = function () { close(); rpc(fn, args || {}).then(res, rej); };
        host = document.createElement("div"); host.id = "kdlb-host";
        root = host.attachShadow({ mode: "open" });
        document.documentElement.appendChild(host);
        showLogin();
        var x = $("x"); if (x) x.addEventListener("click", function () { rej(ApiError("NOT_LOGGED_IN")); });
      });
    }).catch(function (e) {
      if (!e.text) e.text = (e.code === "PGRST202" || /Could not find the function/i.test(e.message || "")) ?
        "Gram Setu-এ এখনো v184 SQL চালানো হয়নি।" : errText(e);
      throw e;
    });
  }

  /* ---------------- IAY Tracker jobs (admin panel → K-Desk) ----------------
     The IAY Tracker makes a job (Demand + Allocation / MR Attendance / MR Payment) for this login's GP.
     KDLink.openJobs({ kind: "demand"|"attend"|"pay", onJob: function (job) { … return true | "error text"; } })
     shows the waiting jobs; the picked one is marked running and handed to the panel. Nothing is
     done on the portal here — the panel still needs Start. Results: KDLink.iayReport(id, stage, rows, cb)
     with rows [{ key: work code (demand/alloc) or "work code|MR No", s: done|error|skipped, m }]. */
  var JOB_NAME = { demand: "Demand + Allocation", attend: "MR Attendance", pay: "MR Payment" };
  var jobOpts = null, jobs = [];
  function openJobs(o) {
    jobOpts = o || {};
    close(); afterLogin = showJobs; shellTitle = "📥 Admin job · IAY Tracker";
    host = document.createElement("div"); host.id = "kdlb-host";
    root = host.attachShadow({ mode: "open" });
    document.documentElement.appendChild(host);
    stGet(SESS_KEY).then(function (s) { sess = s; if (sess && sess.refresh_token) showJobs(); else showLogin(); });
  }
  function showJobs() {
    stSet(PREF_KEY, { username: sess.username });
    shell((sess.gp || "") + " · " + JOB_NAME[jobOpts.kind],
      "<div class='note'>Admin panel-এর IAY Tracker থেকে পাঠানো <b>" + esc(JOB_NAME[jobOpts.kind]) + "</b> job। একটা বাছুন — panel-এ load হবে, " +
      "portal-এ কিছু হবে না যতক্ষণ না আপনি <b>Start</b> চাপেন। শেষ হলে প্রতিটা row-এর ফল Tracker-এ ফিরে যাবে।</div>" +
      "<div class='lists' id='lists'><div class='empty'>আনছি…</div></div>",
      "<button class='btn ghost' id='out'>Logout</button><span><button class='btn ghost' id='rf' title='আবার আনো'>⟳</button> <button class='btn fill' id='load' disabled>⭳ Panel-এ নাও</button></span>");
    $("out").addEventListener("click", function () { logout().then(function () { showLogin(); }); });
    $("rf").addEventListener("click", fetchJobs);
    $("load").addEventListener("click", takeJob);
    fetchJobs();
  }
  function fetchJobs() {
    var box = $("lists"); if (!box) return;
    box.innerHTML = "<div class='empty'>আনছি…</div>"; setStatus("");
    rpc("kdesk_iay_jobs", { p_kind: jobOpts.kind }).then(function (rows) {
      jobs = rows || [];
      if (!jobs.length) { box.innerHTML = "<div class='empty'>এখন কোনো job নেই। Admin panel → IAY Tracker → list খুলে 📤 K-Desk চাপুন।</div>"; $("load").disabled = true; return; }
      box.innerHTML = jobs.map(function (j, i) {
        var tag = j.status === "running" ? "<span class='tag t-lock'>▶ চলছে " + bnNum(j.ok + j.failed + j.skipped) + "/" + bnNum(j.total) + "</span>" : "<span class='tag t-sub'>⏳ নতুন</span>";
        return "<label class='it'><input type='radio' name='job' value='" + i + "'" + (i ? "" : " checked") + ">" +
          "<div><b>#" + j.id + " · " + esc(j.title) + "</b>" + tag +
          "<div class='meta'>" + bnNum(j.total) + " row · বানানো " + esc(fmtDate(j.created_at)) + (j.picked_at ? " · প্রথম নেওয়া " + esc(fmtDate(j.picked_at)) : "") + "</div></div></label>";
      }).join("");
      $("load").disabled = false;
    }, function (e) {
      if (!sess) { showLogin(errText(e)); return; }
      box.innerHTML = "<div class='empty'>আনা গেল না।</div>";
      setStatus(/kdesk_iay_jobs|PGRST202/.test((e.code || "") + " " + (e.message || "")) ? "Server-এ এখনো v199 SQL নেই।" : errText(e), "err");
    });
  }
  function takeJob() {
    var c = root.querySelector(".it input:checked"), j = c && jobs[+c.value]; if (!j) return;
    $("load").disabled = true; setStatus("Job আনছি…");
    rpc("kdesk_iay_job_take", { p_id: j.id }).then(function (job) {
      var ok = jobOpts.onJob ? jobOpts.onJob(job) : false;
      if (ok !== true) throw ApiError("X", typeof ok === "string" ? ok : "Panel-এ নেওয়া গেল না (হয়তো একটা run চলছে, আগে Stop করুন)।");
      setStatus("✅ Job #" + job.id + " panel-এ এসেছে (" + bnNum(job.items.length) + " row)। দেখে নিয়ে Start চাপুন।", "ok");
      setTimeout(close, 1600);
    }).catch(function (e) {
      $("load").disabled = false;
      if (!sess) { showLogin(errText(e)); return; }
      setStatus(e.code === "X" ? e.message : e.code === "JOB_NOT_FOUND" ? "Job আর নেই (cancel বা শেষ হয়েছে)। ⟳ চাপুন।" : errText(e), "err");
    });
  }
  function iayReport(id, stage, rows, cb) {
    cb = cb || function () {};
    rows = (rows || []).filter(function (x) { return x && x.key && /^(done|error|skipped)$/.test(x.s); })
      .map(function (x) { return { key: String(x.key), s: x.s, m: String(x.m || "").slice(0, 300) }; });
    if (!rows.length) { cb(null, { sent: 0 }); return; }
    stGet(SESS_KEY).then(function (s) {
      sess = s;
      if (!sess || !sess.refresh_token) { cb(ApiError("NOT_LOGGED_IN")); return; }
      var out = { sent: 0 }, B = 2000, i = 0;
      (function next() {
        if (i >= rows.length) { cb(null, out); return; }
        var part = rows.slice(i, i + B); i += B;
        rpc("kdesk_iay_report", { p_id: +id, p_stage: stage, p_rows: part }).then(function (r) { out.sent += part.length; out.job = r; next(); },
          function (e) { e.text = errText(e); cb(e, out); });
      })();
    });
  }

  // signed in to Gram Setu already? (no login dialog)
  function signedIn() { return stGet(SESS_KEY).then(function (s) { return !!(s && s.refresh_token); }); }
  window.KDLink = { signedIn: signedIn, open: open, askAccounts: openAccounts, call: call, buildRows: buildRows, syncFlags: syncFlags, reportResults: reportResults, matcher: matcher, openJobs: openJobs, iayReport: iayReport, _isoToDMY: isoToDMY };
})();
