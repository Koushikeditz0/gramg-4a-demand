/* kd-panel.js — K-Desk Suite by Koushik · Clean panel kit (v1.26.0)
   সব panel-কে একই পরিষ্কার ছাঁচে আনার ছোট kit। শুধু চেহারা আর ছোট সাহায্য — কোনো portal কাজ নেই।
     KDP.css                  — panel-এর STYLE + THEME + skin-এর পরে যোগ করার CSS
     KDP.tiles(box, note, panel, items)
                              — count টালি; টালিতে চাপলে table-এ শুধু সেই ধরনের row (tr.r-<k>)
     KDP.adv(details, key)    — "⚙ Advanced" ভাঁজ; খোলা/বন্ধ এই PC-তে মনে রাখে
     KDP.more(btn, box)       — "⋯" চাপলে কম দরকারি button-গুলো দেখায়/লুকায়
     KDP.now(run) / KDP.eta(run) — এখন কে চলছে, আর আন্দাজে কত সময় বাকি
   প্রথমে Demand + Allocation (v1.26.0), পরের version-এ বাকি panel। */
(function () {
  "use strict";
  if (window.KDP) return;

  var KEYS = ["done", "skip", "err", "pend"];
  var CSS =
    /* list কোথা থেকে: এক সারিতে ছোট chip */
    ".srcrow{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:5px;margin-bottom:8px}" +
    ".srcrow .btn.pick{width:auto;margin:0!important;min-height:32px!important;padding:6px 2px!important;font-size:11px!important;letter-spacing:-.1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
    ".summary:empty,.st:empty{display:none}" +
    /* count টালি */
    ".kdp-tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:8px 0 4px}.kdp-tiles:empty{display:none}" +
    ".kdp-t{all:unset;box-sizing:border-box;cursor:pointer;border-radius:11px;padding:6px 8px;border:1px solid;background:#fff;transition:.12s;text-align:left}" +
    ".kdp-t b{display:block;font:700 17px/1.15 'Segoe UI',system-ui,sans-serif}.kdp-t small{display:block;font-size:10.5px;font-weight:600;white-space:nowrap}" +
    ".kdp-t:hover{transform:translateY(-1px);box-shadow:0 3px 10px rgba(30,27,75,.12)}" +
    ".kdp-t.g{background:#ecfdf5;border-color:#a7f3d0;color:#047857}.kdp-t.s{background:#f8fafc;border-color:#e2e8f0;color:#475569}" +
    ".kdp-t.e{background:#fff1f2;border-color:#fecdd3;color:#be123c}.kdp-t.p{background:#eef2ff;border-color:#c7d2fe;color:#3730a3}" +
    ".kdp-t.on{outline:2px solid #f5b942;outline-offset:0}.kdp-static .kdp-t{pointer-events:none}" +
    ".kdp-fnote{font-size:10.5px;color:#5b5f8a;margin:2px 0 5px}.kdp-fnote[hidden]{display:none}" +
    ".kdp-fnote button{all:unset;cursor:pointer;color:#3730a3;font-weight:700;margin-left:4px}" +
    ".panel[data-kf=done] tbody tr:not(.r-done),.panel[data-kf=skip] tbody tr:not(.r-skip),.panel[data-kf=err] tbody tr:not(.r-err),.panel[data-kf=pend] tbody tr:not(.r-pend){display:none}" +
    ".panel[data-kf=done] .kdp-flt>:not(.r-done),.panel[data-kf=skip] .kdp-flt>:not(.r-skip),.panel[data-kf=err] .kdp-flt>:not(.r-err),.panel[data-kf=pend] .kdp-flt>:not(.r-pend){display:none}" +
    ".why.err{color:#be123c}" +
    /* progress-এর লেখা */
    "details.kdp-log>summary{font-weight:600}details.kdp-log .logbox{margin:0 10px 8px;display:block!important}" +
    ".progtxt b{font-size:17px;color:#1e1b6b}.progtxt .kdp-now{display:block;font-size:11px;font-weight:500;color:#475569;margin-top:2px;line-height:1.35}" +
    /* নিয়ম এক লাইনে */
    ".kdp-rule{display:flex;align-items:center;flex-wrap:wrap;gap:4px;margin-top:8px;padding:7px 9px;border:1px solid #d4d8f5;border-radius:10px;background:#fff;font-size:11.5px;cursor:pointer}" +
    ".kdp-rule>b{color:#3730a3;font-size:10.5px;letter-spacing:.5px;text-transform:uppercase;margin-right:2px}" +
    ".kdp-chip{display:inline-block;border-radius:99px;padding:1px 7px;font-size:10.5px;font-weight:650}.kdp-chip.y{background:#d1fae5;color:#047857}.kdp-chip.n{background:#f1f5f9;color:#64748b}.kdp-chip.o{background:#fff4d6;color:#92400e}" +
    ".kdp-rule .kdp-lock{margin-left:auto;font-size:10px;color:#94a3b8}" +
    /* ⚙ Advanced */
    "details.kdp-adv{margin-top:8px;border:1px solid #d4d8f5;border-radius:10px;background:#fff}" +
    "details.kdp-adv>summary{cursor:pointer;list-style:none;padding:8px 10px;font-size:12px;font-weight:700;color:#3730a3;user-select:none}" +
    "details.kdp-adv>summary::-webkit-details-marker{display:none}details.kdp-adv>summary:before{content:'▸ ';display:inline-block;transition:transform .15s}" +
    "details.kdp-adv[open]>summary:before{transform:rotate(90deg)}" +
    "details.kdp-adv>summary small{font-weight:500;color:#5b5f8a;margin-left:4px}" +
    ".kdp-advb{padding:0 10px 8px}.kdp-advb .gate{margin-top:0}.kdp-advb .gate+.gate{margin-top:6px}.kdp-speed .kdspd{margin:6px 0 0!important}" +
    /* নিচের action bar */
    ".kdp-act{position:sticky;bottom:0;z-index:3;margin:10px calc(-1 * var(--kdp-pad,14px)) 0;padding:8px var(--kdp-pad,14px);background:linear-gradient(rgba(238,240,255,.94),#e9ecfd);border-top:1px solid #d4d8f5;backdrop-filter:blur(6px)}" +
    ".kdp-row{display:flex;gap:6px}.kdp-row .btn{margin:0}.kdp-row .btn.fill{flex:2}.kdp-row .btn.stop{flex:1.2}" +
    ".kdp-row .kdp-mbtn{flex:none;width:42px;padding:0!important;font-size:17px!important;line-height:1}" +
    ".kdp-more{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:6px}.kdp-more[hidden]{display:none}.kdp-more .btn{margin:0;font-size:12px}" +
    ":host-context(html.kd-dark) .kdp-rule,:host-context(html.kd-dark) details.kdp-adv{background:#1b2250;border-color:#2b3366;color:#e2e8ff}" +
    ":host-context(html.kd-dark) .kdp-act{background:#151b3d;border-color:#2b3366}:host-context(html.kd-dark) .progtxt .kdp-now{color:#a5b4fc}";

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (m) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]; }); }

  // items: [{ k: "done"|"skip"|"err"|"pend", n: 12, l: "সফল", c: "g"|"s"|"e"|"p" }]  (খালি = টালি লুকানো)
  function tiles(box, note, panel, items) {
    if (!box || !panel) return;
    if (!box.dataset.kdp) {
      box.dataset.kdp = "1";
      box.addEventListener("click", function (e) {
        var b = e.target.closest && e.target.closest("button[data-k]"); if (!b) return;
        var k = b.getAttribute("data-k");
        if (panel.getAttribute("data-kf") === k) panel.removeAttribute("data-kf"); else panel.setAttribute("data-kf", k);
        paint();
      });
      if (note) note.addEventListener("click", function (e) {
        if (e.target.tagName === "BUTTON") { panel.removeAttribute("data-kf"); paint(); }
      });
    }
    box._items = items || [];
    if (!note) box.classList.add("kdp-static");   // পাশে তালিকা নেই: টালি শুধু দেখায়
    function paint() {
      var its = box._items, f = panel.getAttribute("data-kf");
      if (f && !its.some(function (x) { return x.k === f && x.n > 0; })) { panel.removeAttribute("data-kf"); f = null; }
      box.innerHTML = its.map(function (x) {
        return "<button type='button' class='kdp-t " + x.c + (f === x.k ? " on" : "") + "' data-k='" + x.k + "' title='চাপলে নিচের তালিকায় শুধু এগুলো'><b>" + x.n + "</b><small>" + esc(x.l) + "</small></button>";
      }).join("");
      if (note) {
        var cur = f && its.filter(function (x) { return x.k === f; })[0];
        note.hidden = !cur;
        if (cur) note.innerHTML = "তালিকায় শুধু <b>" + esc(cur.l) + "</b> (" + cur.n + ")<button type='button'>✕ সব দেখাও</button>";
      }
    }
    paint();
  }
  function rowClass(status) {
    return status === "done" ? "r-done" : status === "error" ? "r-err" : status === "skipped" ? "r-skip" : "r-pend";
  }

  function adv(d, key) {
    if (!d || d.dataset.kdp) return; d.dataset.kdp = "1";
    var k = "kdp_adv_" + key;
    try { d.open = localStorage.getItem(k) === "1"; } catch (e) {}
    d.addEventListener("toggle", function () { try { localStorage.setItem(k, d.open ? "1" : "0"); } catch (e) {} });
  }

  function more(btn, box) {
    if (!btn || !box || btn.dataset.kdp) return; btn.dataset.kdp = "1";
    btn.addEventListener("click", function () { box.hidden = !box.hidden; btn.textContent = box.hidden ? "⋯" : "✕"; });
    box.addEventListener("click", function (e) {   // কাজ চাপার পরে menu বন্ধ
      if (e.target.closest && e.target.closest("button")) setTimeout(function () { box.hidden = true; btn.textContent = "⋯"; }, 0);
    });
  }

  // এখন যে worker-এর পালা (প্রথম pending / filled), নেই হলে null
  function now(r) {
    var gs = (r && r.groups) || [];
    for (var i = 0; i < gs.length; i++) {
      var ws = gs[i].workers || [];
      for (var j = 0; j < ws.length; j++) if (ws[j].status === "pending" || ws[j].status === "filled") return { g: gs[i], w: ws[j] };
    }
    return null;
  }
  // আন্দাজে বাকি সময়: portal-এ যাওয়া row-গুলোর (done/error) সময়ের ফাঁক থেকে গড়
  function eta(r, pend) {
    var ts = [];
    ((r && r.groups) || []).forEach(function (g) { (g.workers || []).forEach(function (w) { if ((w.status === "done" || w.status === "error") && w.at) ts.push(w.at); }); });
    if (ts.length < 3 || !pend) return "";
    ts.sort(function (a, b) { return a - b; });
    ts = ts.slice(-30);                                   // শেষের ৩০টা — portal-এর এখনকার গতি
    var per = (ts[ts.length - 1] - ts[0]) / (ts.length - 1);
    if (!(per > 0)) return "";
    var min = Math.round(per * pend / 60000);
    return min < 1 ? "১ মিনিটের কম" : min < 60 ? "~" + min + " মিনিট" : "~" + Math.floor(min / 60) + " ঘণ্টা " + (min % 60) + " মিনিট";
  }

  window.KDP = { css: CSS, tiles: tiles, rowClass: rowClass, adv: adv, more: more, now: now, eta: eta, esc: esc };
})();
