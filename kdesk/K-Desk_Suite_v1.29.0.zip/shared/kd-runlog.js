/* =====================================================================
   kd-runlog.js — K-Desk Suite by Koushik · "Today's runs" record (isolated world, loaded right after xlsx)
   Every K-Desk log/report Excel goes through XLSX.writeFile. This wraps it (the feature code is not touched):
   after the file is downloaded, a short summary goes to chrome.storage "kd_runs" (feature, time, counts of the
   Result/Status column, warn flag) and the sheets themselves to "kd_runlog::<id>" so the Dashboard can download
   the same log again. A second file of the same feature within 90 s (e.g. results + activity log) is added to
   that run, not a new row. Runs older than 30 days are removed with their logs.
   ===================================================================== */
(function () {
  "use strict";
  if (!window.XLSX || window.XLSX.__kdRun) return;
  var X = window.XLSX, orig = X.writeFile;
  if (typeof orig !== "function") return;
  try { X.__kdRun = true; } catch (e) { return; }

  var KEEP_DAYS = 30, MAX_RUNS = 300, MAX_ROWS = 5000, MERGE_MS = 90000;
  var FEATS = [
    [/^WorkDemand/i, "Work Demand", "#3730a3"],
    [/^(WorkAllocation|Demand-Allocation)/i, "Work Allocation", "#2563eb"],
    [/^Readiness/i, "Readiness Report", "#0891b2"],
    [/^NPCI/i, "NPCI (ABPS Enable)", "#10b981"],
    [/^Wagelist-IAY/i, "Generate Wage List (IAY)", "#c2770a"],
    [/^Wagelist-/i, "Generate Wage List", "#c2770a"],
    [/^SendForPayment-TEST/i, "Send for Payment · Test", "#0f766e"],
    [/^SendForPayment/i, "Send for Payment", "#0f766e"],
    [/^WL-Export/i, "WL Export", "#9333ea"],
    [/^MusterRolls/i, "MR Excel", "#7c3aed"],
    [/^MRFill-Attendance/i, "Fill Attendance", "#db2777"],
    [/^MRFill-Payment/i, "Payment only", "#e11d48"],
    [/^4A-list/i, "4A list", "#475569"]
  ];
  var BAD = /not found|fail|error|held|check|stopped|skip|not saved|not enabled|retry|reject|বাকি|নেই|হয়নি|ভুল/i;
  var GOOD = /^(ok|saved|success|sent|generated|done|would|✓)/i;

  function feature(file) {
    for (var i = 0; i < FEATS.length; i++) if (FEATS[i][0].test(file)) return { name: FEATS[i][1], c: FEATS[i][2] };
    return { name: String(file).replace(/[-_]?\d{6,}.*$/, "").replace(/\.xlsx$/i, "") || "Report", c: "#64748b" };
  }
  function sheets(wb) {
    return (wb.SheetNames || []).map(function (n) {
      var aoa = []; try { aoa = X.utils.sheet_to_json(wb.Sheets[n], { header: 1, raw: false, defval: "" }); } catch (e) {}
      if (aoa.length > MAX_ROWS) aoa = aoa.slice(0, MAX_ROWS);
      return { n: n, aoa: aoa };
    });
  }
  // short result line from the first sheet's Result/Status column, plus problem sheets ("Not ready", "Held back", …)
  function summarise(sh) {
    var first = sh[0] || { aoa: [] }, head = first.aoa[0] || [], rows = first.aoa.slice(1).filter(function (r) { return r.some(function (v) { return String(v).trim(); }); });
    var col = -1;
    head.forEach(function (h, i) { if (col < 0 && /^(result|status|outcome|ফল|অবস্থা)$/i.test(String(h).trim())) col = i; });
    if (col < 0) head.forEach(function (h, i) { if (col < 0 && /result|status/i.test(String(h))) col = i; });
    var parts = [], warn = false, ok = 0, bad = 0;
    if (col >= 0 && rows.length) {
      var cnt = {};
      rows.forEach(function (r) { var v = String(r[col] || "").trim() || "(blank)"; cnt[v] = (cnt[v] || 0) + 1; });
      Object.keys(cnt).sort(function (a, b) { return cnt[b] - cnt[a]; }).forEach(function (k) {
        var isBad = BAD.test(k) && !GOOD.test(k);
        if (isBad) { warn = true; bad += cnt[k]; } else ok += cnt[k];
        parts.push({ k: k, n: cnt[k], bad: isBad });
      });
    } else { ok = rows.length; if (rows.length) parts.push({ k: "row", n: rows.length, bad: false }); }
    sh.slice(1).forEach(function (s) {
      if (/not ready|held|fail|skip|problem|error/i.test(s.n)) {
        var n = Math.max(0, s.aoa.length - 1);
        if (n) { warn = true; parts.push({ k: s.n, n: n, bad: true }); }
      }
    });
    return { rows: rows.length, ok: ok, bad: bad, parts: parts.slice(0, 4), warn: warn };
  }

  function record(wb, file) {
    var sh = sheets(wb); if (!sh.length) return;
    var f = feature(file), sum = summarise(sh), now = Date.now();
    chrome.storage.local.get("kd_runs", function (d) {
      var runs = (d && d.kd_runs) || [], o = {}, drop = [];
      var cut = now - KEEP_DAYS * 864e5;
      runs = runs.filter(function (r) { if (r.t < cut) { drop.push("kd_runlog::" + r.id); return false; } return true; });
      var last = runs[0];
      if (last && last.name === f.name && now - last.t < MERGE_MS) {
        // same run's second file: keep the first file's summary, add the sheets to its log
        chrome.storage.local.get("kd_runlog::" + last.id, function (g) {
          var lg = (g && g["kd_runlog::" + last.id]) || { files: [] };
          lg.files.push({ file: file, sheets: sh });
          last.files = (last.files || 1) + 1; if (sum.warn && !last.warn) { last.warn = true; last.parts = last.parts.concat(sum.parts.filter(function (p) { return p.bad; })).slice(0, 4); }
          var o2 = {}; o2["kd_runlog::" + last.id] = lg; o2.kd_runs = runs; chrome.storage.local.set(o2);
        });
        if (drop.length) chrome.storage.local.remove(drop);
        return;
      }
      var id = now.toString(36) + Math.random().toString(36).slice(2, 6);
      runs.unshift({ id: id, t: now, name: f.name, c: f.c, file: file, rows: sum.rows, ok: sum.ok, bad: sum.bad, parts: sum.parts, warn: sum.warn, files: 1, page: location.pathname.split("/").pop() });
      while (runs.length > MAX_RUNS) drop.push("kd_runlog::" + runs.pop().id);
      o.kd_runs = runs; o["kd_runlog::" + id] = { files: [{ file: file, sheets: sh }] };
      chrome.storage.local.set(o);
      if (drop.length) chrome.storage.local.remove(drop);
    });
  }

  X.writeFile = function (wb, file) {
    var out = orig.apply(this, arguments);
    try { record(wb, String(file || "")); } catch (e) {}
    return out;
  };
})();
