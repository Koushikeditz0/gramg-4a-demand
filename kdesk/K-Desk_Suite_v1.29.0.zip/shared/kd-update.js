// K-Desk Suite by Koushik — নতুন version এসেছে কিনা দেখা (v1.20.0)
// Extension unpacked (Chrome Web Store-এ নেই), তাই Chrome নিজে update করতে পারে না।
// এখানে শুধু Gram Setu site-এর একটা ছোট JSON পড়া হয়; নতুন version থাকলে Dashboard-এ banner আর
// toolbar icon-এ "NEW" badge দেখায়। Zip নামিয়ে একই folder-এ বসিয়ে Reload করতে হয় (ধাপ banner-এ লেখা)।
// popup.html (<script>) আর background/kd-bg.js (importScripts) দুজনেই এই file ব্যবহার করে।
(function (g) {
  var URL_LATEST = 'https://gramsetu.koushiktech.co.in/kdesk/latest.json';
  var EVERY = 6 * 3600e3;            // ৬ ঘণ্টায় একবারের বেশি network-এ যায় না
  var K = 'kd_upd';                  // { at, data, err }
  var KS = 'kd_upd_snooze';          // { v, until } — "পরে" চাপলে ওই version ২৪ ঘণ্টা চুপ

  function cur() { try { return chrome.runtime.getManifest().version; } catch (e) { return '0'; } }
  // "1.19.1" < "1.20.0" ঠিকভাবে তুলনা (সংখ্যা ধরে, string নয়)
  function cmp(a, b) {
    var x = String(a || '0').split('.'), y = String(b || '0').split('.');
    for (var i = 0; i < Math.max(x.length, y.length); i++) {
      var p = parseInt(x[i] || '0', 10) || 0, q = parseInt(y[i] || '0', 10) || 0;
      if (p !== q) return p < q ? -1 : 1;
    }
    return 0;
  }
  function valid(d) { return d && typeof d.version === 'string' && /^\d+(\.\d+){1,3}$/.test(d.version); }
  async function fetchLatest() {
    var ctl = new AbortController(), tm = setTimeout(function () { ctl.abort(); }, 8000);
    try {
      var r = await fetch(URL_LATEST + '?t=' + Date.now(), { cache: 'no-store', signal: ctl.signal });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var d = await r.json();
      if (!valid(d)) throw new Error('bad json');
      return d;
    } finally { clearTimeout(tm); }
  }
  // force=true: এখনই network থেকে পড়ে (Settings-এর "Update দেখুন" বোতাম)
  async function check(force) {
    var s = (await chrome.storage.local.get([K, KS])), c = s[K] || {}, now = Date.now();
    // আগের বার network না পেলে ৩০ মিনিট পরেই আবার চেষ্টা
    if (force || !c.at || now - c.at > (c.err ? 30 * 60e3 : EVERY)) {
      try { c = { at: now, data: await fetchLatest() }; }
      catch (e) { c = { at: now, data: valid(c.data) ? c.data : null, err: String(e && e.message || e) }; }
      await chrome.storage.local.set({ [K]: c });
    }
    return info(c, s[KS]);
  }
  function info(c, snooze) {
    var d = (c && c.data) || null, v = cur();
    var newer = !!(d && cmp(v, d.version) < 0);
    var must = !!(newer && d.min_version && cmp(v, d.min_version) < 0);
    var snoozed = !!(newer && !must && snooze && snooze.v === d.version && snooze.until > Date.now());
    return { current: v, latest: d ? d.version : null, newer: newer, must: must, snoozed: snoozed, data: d, at: c ? c.at : 0, err: c ? c.err : null };
  }
  // toolbar icon-এ badge: নতুন version = সোনালি "NEW", জরুরি = লাল "!"
  function badge(i) {
    try {
      var on = i && i.newer && !i.snoozed;
      chrome.action.setBadgeText({ text: on ? (i.must ? '!' : 'NEW') : '' });
      if (on) chrome.action.setBadgeBackgroundColor({ color: i.must ? '#dc2626' : '#e08e0b' });
      chrome.action.setTitle({ title: on ? 'K-Desk Suite — নতুন version v' + i.latest + ' এসেছে' : 'K-Desk Suite by Koushik' });
    } catch (e) {}
  }
  async function snooze(v) {
    await chrome.storage.local.set({ [KS]: { v: v, until: Date.now() + 864e5 } });
  }
  g.KDUpdate = { URL: URL_LATEST, check: check, cmp: cmp, badge: badge, snooze: snooze, current: cur };
})(typeof self !== 'undefined' ? self : this);
