/* kskin.js — K-Desk Suite by Koushik · "Indigo glass" theme.
   প্রতিটা panel নিজের style-এর পরে এই CSS যোগ করে, যাতে সব panel একই রকম দেখায়। */
(function () {
  "use strict";
  if (window.KD_SKIN) return;
  window.KD_SKIN =
    ".panel{color:#1e1b4b!important;background:linear-gradient(180deg,rgba(238,240,255,.97),rgba(227,230,251,.97))!important;border:1px solid #c9cef3!important;border-radius:16px!important;box-shadow:0 18px 50px rgba(30,27,75,.30),0 2px 8px rgba(30,27,75,.12)!important;backdrop-filter:blur(10px)}" +
    ".hd{background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%)!important;border-bottom:0!important;position:relative}" +
    ".hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".ttl{display:block;min-width:0}.ttl b{display:block}.ttl small{display:block;font-size:9.5px;color:#c7d2fe;letter-spacing:.9px;text-transform:uppercase;white-space:nowrap}.ttl small i{font-style:normal;color:#f5b942;font-weight:700}" +
    ".bd{background:transparent!important}" +
    ".btn.ghost{background:#f5f6ff!important;border:1px solid #d4d8f5!important;color:#1e1b4b!important}.btn.ghost:hover:not(:disabled){background:#fff!important}" +
    ".btn.ghost.danger{background:#fff1f2!important;border-color:#fecdd3!important;color:#be123c!important}" +
    ".btn.pick{background:#f5f6ff!important;border:1.5px dashed #a5acec!important;color:#3730a3!important}" +
    ".summary{background:#dfe3ff!important;color:#312e81!important}" +
    ".progbar{background:#d4d8f5!important}" +
    ".st{background:#f5f6ff!important;color:#1e1b4b}.st.ok{background:#dcfce7!important;color:#166534!important}.st.warn{background:#fef3c7!important;color:#92400e!important}" +
    ".scroll,.gate,.top,.cfm,.disclaimer,.hint{border-color:#d4d8f5!important}.scroll,.gate,.top,.disclaimer{background:#f5f6ff!important}" +
    "th{background:#e3e6fb!important;color:#1e1b6b!important}td{border-color:#e3e6fb!important}" +
    ".sec{color:#3730a3!important;border-top-color:#d4d8f5!important}" +
    ".foot{background:rgba(255,255,255,.55)!important;border-top:1px solid #d4d8f5!important;color:#5b5f8a!important}.foot b{color:#1e1b4b!important}.foot em{color:#c2770a!important}" +
    /* ---- v1.3.1: নিজস্ব layout (drawer, ring, ভাঁজ করা log) ---- */
    ".ttl{display:flex!important;flex-direction:column-reverse}.hd .ttl b,.ttl b{font-size:15.5px!important;letter-spacing:.2px}.hd{padding:13px 14px 12px!important}" +
    ":host([data-kd=drawer]) .logo{display:none!important}" +
    ":host([data-kd=drawer]) .panel{width:380px!important;height:auto;max-height:100vh;display:flex;flex-direction:column;border-radius:18px 0 0 18px!important;border-right:0!important}" +
    ":host([data-kd=drawer]) .bd{flex:1 1 auto;min-height:0;max-height:none!important;overflow:auto}" +
    ":host([data-kd=drawer]) .panel:has(.bd[style*='none']){height:auto}" +
    ".summary{background:#fff!important;border:1px solid #d4d8f5;border-left:4px solid #f5b942!important;border-radius:12px!important;padding:9px 12px!important;font-size:12.5px!important;color:#1e1b4b!important}" +
    ".btn{border-radius:11px!important;min-height:36px}" +
    ".btn.fill{color:#1a1300!important;border:0!important;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)!important;box-shadow:0 4px 12px rgba(224,142,11,.30)}" +
    ".btn.fill:disabled{background:#efe3c4!important;color:#8a7a55!important;box-shadow:none}" +
    ".btn.stop{background:#fff!important;color:#be123c!important;border:1px solid #fecdd3!important}.btn.stop:disabled{opacity:.5}" +
    ".prog{display:flex!important;align-items:center;gap:12px;background:#fff;border:1px solid #d4d8f5;border-radius:14px;padding:10px 12px;margin:10px 0!important}" +
    ".prog[hidden]{display:none!important}.prog .progbar{display:none!important}" +
    ".kring{--p:0;width:62px;height:62px;border-radius:50%;flex:none;background:conic-gradient(#f5b942 calc(var(--p) * 1%),#e3e6fb 0);display:grid;place-items:center}" +
    ".kring span{width:48px;height:48px;border-radius:50%;background:#fff;display:grid;place-items:center;font:700 13.5px 'Segoe UI',sans-serif;color:#1e1b6b}" +
    ".prog .progtxt{flex:1;text-align:left!important;font-size:12.5px!important;margin:0!important;color:#1e1b6b!important}" +
    ".sec.kfold{cursor:pointer;display:flex;align-items:center;gap:6px;background:#fff;border:1px solid #d4d8f5!important;border-radius:10px;padding:8px 10px!important;margin:10px 0 6px!important;user-select:none;text-transform:none!important;letter-spacing:0!important;font-size:12px!important}" +
    ".sec.kfold .kar{display:inline-block;transition:transform .15s}.sec.kfold.open .kar{transform:rotate(90deg)}.sec.kfold .kcnt{margin-left:auto;font-weight:600;color:#5b5f8a;font-size:11px}" +
    ".logbox.kclosed,.logbox:empty{display:none!important}" +
    "details.kguide{margin-top:10px;background:#f5f6ff;border:1px solid #d4d8f5;border-radius:10px;padding:6px 10px;font-size:11px;color:#5b5f8a}" +
    "details.kguide summary{cursor:pointer;font-weight:600;color:#3730a3;font-size:11.5px}details.kguide .hint,details.kguide .disclaimer{background:transparent!important;border:0!important;padding:4px 0 0!important;margin:0!important}";

  // Panel-এর ভেতরের layout বদলানো: progress ring, ভাঁজ করা Activity log, নির্দেশনা এক জায়গায়।
  // বারবার চালালেও সমস্যা নেই (data-kd চিহ্ন দেখে আগে করা কাজ বাদ দেয়)।
  var LOG_KEY = "kd_log_open";
  function logOpen() { try { return localStorage.getItem(LOG_KEY) === "1"; } catch (e) { return false; } }
  function enhance(root) {
    root.querySelectorAll(".prog").forEach(function (pg) {
      if (pg.dataset.kd) return; pg.dataset.kd = "1";
      var fill = pg.querySelector(".progfill"); if (!fill) return;
      var ring = document.createElement("div"); ring.className = "kring"; ring.innerHTML = "<span>0%</span>";
      pg.insertBefore(ring, pg.firstChild);
      var upd = function () {
        var w = parseFloat(fill.style.width) || 0; if (w > 100) w = 100;
        ring.style.setProperty("--p", w); ring.firstChild.textContent = Math.round(w) + "%";
      };
      upd(); new MutationObserver(upd).observe(fill, { attributes: true, attributeFilter: ["style"] });
    });
    root.querySelectorAll(".logbox").forEach(function (lb) {
      if (lb.dataset.kd) return; lb.dataset.kd = "1";
      var sec = lb.previousElementSibling; if (!sec || !sec.classList.contains("sec")) return;
      var label = sec.textContent; sec.textContent = "";
      var ar = document.createElement("span"); ar.className = "kar"; ar.textContent = "▸";
      var tx = document.createElement("span"); tx.textContent = label;
      var cnt = document.createElement("span"); cnt.className = "kcnt";
      sec.append(ar, tx, cnt); sec.classList.add("kfold");
      var set = function (open) { sec.classList.toggle("open", open); lb.classList.toggle("kclosed", !open); };
      var count = function () { var n = lb.children.length; cnt.textContent = n ? n + " entry" : ""; };
      set(logOpen()); count();
      new MutationObserver(count).observe(lb, { childList: true });
      sec.addEventListener("click", function () { var o = !sec.classList.contains("open"); set(o); try { localStorage.setItem(LOG_KEY, o ? "1" : "0"); } catch (e) {} });
    });
    root.querySelectorAll(".bd").forEach(function (bd) {
      if (bd.dataset.kdg) return;
      var items = [].slice.call(bd.children).filter(function (c) { return c.classList.contains("hint") || c.classList.contains("disclaimer"); });
      if (!items.length) return; bd.dataset.kdg = "1";
      var d = document.createElement("details"); d.className = "kguide";
      var sm = document.createElement("summary"); sm.textContent = "ⓘ নির্দেশনা ও সতর্কতা"; d.appendChild(sm);
      bd.insertBefore(d, items[0]); items.forEach(function (c) { d.appendChild(c); });
    });
  }
  // Shadow root বা document-এ theme যোগ করা
  window.KD_applySkin = function (root) {
    try { var s = document.createElement("style"); s.textContent = window.KD_SKIN; root.appendChild(s); } catch (e) {}
    try {
      var run = function () { try { enhance(root); } catch (e) {} };
      setTimeout(run, 0);
      var t = null; new MutationObserver(function () { clearTimeout(t); t = setTimeout(run, 50); }).observe(root, { childList: true, subtree: true });
    } catch (e) {}
  };
})();
