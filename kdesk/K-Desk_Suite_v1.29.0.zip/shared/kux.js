/* kux.js — K-Desk Suite by Koushik · UX layer (v1.4.0)
   সব panel-এর উপরে একসাথে কাজ করে, panel-এর নিজের code না বদলে:
   Dark / Compact mode, panel-এর বাঁ ধার টেনে চওড়া করা, keyboard shortcut, ধাপে ধাপে guide,
   কাজ শেষ হলে notification + শব্দ, আজকের হিসাব (Dashboard-এর জন্য) আর প্রথমবারের tour। */
(function () {
  "use strict";
  if (window.top !== window || window.__KUX) return; window.__KUX = true;
  if (!document.body || document.body.tagName === "FRAMESET") return;

  var UI_KEY = "kh_ui", TOUR_KEY = "kd_tour_v1";
  var ui = { dark: false, compact: false, sound: true, notify: true };
  var HOSTS = ["dxwd-host", "dxwa-host", "dxabps-host", "khnp-host", "khwls-host", "kdrd-host", "mrfa-host", "mrfp-host"];
  var NAMES = { "dxwd-host": "Work Demand", "dxwa-host": "Work Allocation", "dxabps-host": "ABPS Data Sync", "khnp-host": "ABPS Enable (NPCI)", "khwls-host": "Wage List Status", "kdrd-host": "Readiness Report", "mrfa-host": "Fill Attendance only", "mrfp-host": "Payment only", "mrbp": "MR Batch Print" };
  var abpsMeta = {};

  function $(id) { return document.getElementById(id); }
  function lsJson(k) { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch (e) { return null; } }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function today() { var d = new Date(); return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); }
  function isToday(t) { if (!t) return false; var d = new Date(t), n = new Date(); return d.toDateString() === n.toDateString(); }

  /* ---------------------- Dark / Compact ---------------------- */
  function applyModes() {
    var h = document.documentElement;
    h.classList.toggle("kd-dark", !!ui.dark);
    h.classList.toggle("kd-compact", !!ui.compact);
  }
  function saveUi() { var o = {}; o[UI_KEY] = ui; try { chrome.storage.local.set(o); } catch (e) {} }

  // প্রতিটা panel-এর shadow root-এ একবার যোগ হয়
  var SHADOW_CSS =
    /* animation */
    "@keyframes kdIn{from{transform:translateX(26px);opacity:0}to{transform:none;opacity:1}}" +
    ".panel{position:relative;animation:kdIn .24s cubic-bezier(.2,.8,.2,1)}" +
    ".btn,button{transition:transform .12s,box-shadow .12s,background .15s,filter .15s}" +
    /* resize */
    ":host([data-kdw]) .panel{width:var(--kdw)!important;max-width:calc(100vw - 70px)}" +
    ":host([data-kd=drawer]) .bd{overflow-x:hidden!important}" +
    ".kdrs{position:absolute;left:0;top:0;bottom:0;width:7px;cursor:ew-resize;z-index:5}" +
    ".kdrs:hover,.kdrs.on{background:linear-gradient(90deg,rgba(245,185,66,.55),transparent)}" +
    /* step guide */
    ".kdsteps{display:flex;align-items:center;gap:4px;margin:0 0 10px;padding:7px 8px;border-radius:12px;background:#fff;border:1px solid #d4d8f5;font:600 11px 'Segoe UI','Nirmala UI',sans-serif;color:#8a8fb8;flex-wrap:wrap}" +
    ".kdsteps .s{display:inline-flex;align-items:center;gap:5px;white-space:nowrap}" +
    ".kdsteps .n{width:18px;height:18px;border-radius:50%;display:grid;place-items:center;font-size:10.5px;background:#e3e6fb;color:#5b5f8a;flex:none}" +
    ".kdsteps .s.done{color:#15803d}.kdsteps .s.done .n{background:#dcfce7;color:#15803d}" +
    ".kdsteps .s.cur{color:#1e1b4b}.kdsteps .s.cur .n{background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b);color:#1a1300;box-shadow:0 0 0 3px rgba(245,185,66,.25)}" +
    ".kdsteps .s.cur.run .n{animation:kdPulse 1.2s ease-in-out infinite}" +
    "@keyframes kdPulse{0%,100%{box-shadow:0 0 0 2px rgba(245,185,66,.25)}50%{box-shadow:0 0 0 6px rgba(245,185,66,.08)}}" +
    ".kdsteps i{flex:1;min-width:8px;height:2px;border-radius:2px;background:#e3e6fb}.kdsteps i.done{background:#86efac}" +
    ".kdspd{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:0 0 10px;padding:6px 8px;border-radius:12px;background:#fff;border:1px solid #d4d8f5;font:600 11px 'Segoe UI','Nirmala UI',sans-serif;color:#5b5f8a}" +
    ".kdspd .g{display:inline-flex;border:1px solid #d4d8f5;border-radius:9px;overflow:hidden}" +
    ".kdspd button{border:0;border-right:1px solid #d4d8f5;background:#f5f6ff;color:#1e1b4b;font:600 11px 'Segoe UI','Nirmala UI',sans-serif;padding:4px 9px;cursor:pointer}.kdspd button:last-child{border-right:0}" +
    ".kdspd button.on{color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}" +
    ".kdspd small{flex-basis:100%;font-weight:400;font-size:10.5px;color:#7a7fa8}" +
    ":host-context(html.kd-dark) .kdspd{background:#161d45;border-color:#2b3366;color:#c7d2fe}:host-context(html.kd-dark) .kdspd .g,:host-context(html.kd-dark) .kdspd button{border-color:#343d7a}" +
    ":host-context(html.kd-dark) .kdspd button:not(.on){background:#1b2250;color:#e2e8ff}:host-context(html.kd-dark) .kdspd small{color:#a5b4fc}" +
    ".kdsteps .tip{flex-basis:100%;font-weight:400;color:#5b5f8a;font-size:11px;margin-top:2px}" +
    /* skeleton */
    "@keyframes kdShim{from{background-position:-200px 0}to{background-position:200px 0}}" +
    ".skel{display:inline-block;height:11px;width:100%;max-width:260px;border-radius:6px;background:linear-gradient(90deg,#e3e6fb 0,#f5f6ff 50%,#e3e6fb 100%);background-size:400px 100%;animation:kdShim 1.1s linear infinite;vertical-align:middle}" +
    /* compact */
    ":host-context(html.kd-compact) .panel{font-size:12px!important}" +
    ":host-context(html.kd-compact) .hd{padding:8px 12px!important}:host-context(html.kd-compact) .hd .ttl b,:host-context(html.kd-compact) .hd b{font-size:13.5px!important}" +
    ":host-context(html.kd-compact) .bd{padding:8px 10px 0!important}" +
    ":host-context(html.kd-compact) .btn{min-height:29px!important;padding:4px 8px!important;font-size:11.5px!important}" +
    ":host-context(html.kd-compact) td,:host-context(html.kd-compact) th{padding:3px 6px!important}" +
    ":host-context(html.kd-compact) .summary{padding:6px 9px!important;font-size:11.5px!important}" +
    ":host-context(html.kd-compact) .kring{width:46px;height:46px}:host-context(html.kd-compact) .kring span{width:36px;height:36px;font-size:11px}" +
    ":host-context(html.kd-compact) .kdsteps{padding:5px 6px;margin-bottom:7px}" +
    /* dark */
    ":host-context(html.kd-dark) .panel{background:linear-gradient(180deg,#151b3d,#0f1430)!important;color:#e2e8ff!important;border-color:#2b3366!important;box-shadow:0 18px 50px rgba(0,0,0,.55)!important}" +
    ":host-context(html.kd-dark) .bd{background:transparent!important}" +
    ":host-context(html.kd-dark) .summary,:host-context(html.kd-dark) .pill,:host-context(html.kd-dark) .msg{background:#1b2250!important;color:#e2e8ff!important;border-color:#2b3366!important}" +
    ":host-context(html.kd-dark) .btn:not(.fill),:host-context(html.kd-dark) .btn.ghost{background:#1b2250!important;color:#e2e8ff!important;border-color:#343d7a!important}" +
    ":host-context(html.kd-dark) .btn.pick{background:#161d45!important;color:#c7d2fe!important;border-color:#4a54a0!important}" +
    ":host-context(html.kd-dark) .btn.ghost.danger,:host-context(html.kd-dark) .btn.stop{background:#3a1424!important;color:#fda4af!important;border-color:#6b2139!important}" +
    ":host-context(html.kd-dark) .st,:host-context(html.kd-dark) .gatehint{background:#1b2250!important;color:#e2e8ff!important}" +
    ":host-context(html.kd-dark) .st.ok,:host-context(html.kd-dark) .msg.ok{background:#0f3d2a!important;color:#86efac!important}" +
    ":host-context(html.kd-dark) .st.warn,:host-context(html.kd-dark) .msg.warn{background:#3d2f0f!important;color:#fcd34d!important}" +
    ":host-context(html.kd-dark) .scroll,:host-context(html.kd-dark) .gate,:host-context(html.kd-dark) .top,:host-context(html.kd-dark) .disclaimer,:host-context(html.kd-dark) details.kguide,:host-context(html.kd-dark) .sec.kfold,:host-context(html.kd-dark) .prog,:host-context(html.kd-dark) .kdsteps{background:#161d45!important;border-color:#2b3366!important;color:#c7d2fe!important}" +
    ":host-context(html.kd-dark) th{background:#1f2760!important;color:#e2e8ff!important}:host-context(html.kd-dark) td{border-color:#2b3366!important;color:#e2e8ff}" +
    ":host-context(html.kd-dark) .foot{background:#0f1430!important;border-color:#2b3366!important;color:#9aa3d6!important}:host-context(html.kd-dark) .foot b{color:#e2e8ff!important}" +
    ":host-context(html.kd-dark) .kring{background:conic-gradient(#f5b942 calc(var(--p) * 1%),#2b3366 0)!important}:host-context(html.kd-dark) .kring span{background:#151b3d!important;color:#e2e8ff!important}" +
    ":host-context(html.kd-dark) input,:host-context(html.kd-dark) select,:host-context(html.kd-dark) textarea{background:#161d45;color:#e2e8ff;border-color:#2b3366}" +
    ":host-context(html.kd-dark) .hint,:host-context(html.kd-dark) .gatehd,:host-context(html.kd-dark) label,:host-context(html.kd-dark) .progtxt,:host-context(html.kd-dark) .unk{color:#a5b4fc!important}" +
    ":host-context(html.kd-dark) details.kguide summary,:host-context(html.kd-dark) .sec.kfold{color:#c7d2fe!important}:host-context(html.kd-dark) .pill b{color:#f5b942!important}:host-context(html.kd-dark) .bar{border-color:#2b3366!important}" +
    ":host-context(html.kd-dark) .ok{color:#4ade80!important}:host-context(html.kd-dark) .no{color:#fb7185!important}" +
    ":host-context(html.kd-dark) .kdsteps .n{background:#2b3366;color:#c7d2fe}:host-context(html.kd-dark) .kdsteps .s.cur{color:#fff}:host-context(html.kd-dark) .kdsteps i{background:#2b3366}" +
    ":host-context(html.kd-dark) .kdsteps .s.done .n{background:#0f3d2a;color:#86efac}:host-context(html.kd-dark) .kdsteps .tip{color:#a5b4fc}" +
    ":host-context(html.kd-dark) .skel{background:linear-gradient(90deg,#1f2760 0,#2b3366 50%,#1f2760 100%);background-size:400px 100%}";

  // MR panel shadow DOM ব্যবহার করে না, তাই document-এ
  var DOC_CSS =
    "html.kd-dark #mrbp{--ink:#e2e8ff;--navy:#e2e8ff;--mut:#9aa3d6;--line:#2b3366;--soft:#161d45;background:#151b3d!important;border-color:#2b3366!important}" +
    "html.kd-dark #mrbp .bd{background:#151b3d!important}html.kd-dark #mrbp .card{background:#1b2250!important}" +
    "html.kd-dark #mrbp .drop{background:#161d45!important;border-color:#4a54a0!important;color:#c7d2fe!important}" +
    "html.kd-dark #mrbp input,html.kd-dark #mrbp textarea,html.kd-dark #mrbp select{background:#161d45!important;color:#e2e8ff!important;border-color:#2b3366!important}" +
    "#kdrd-btn{transition:transform .12s}#kdrd-btn:hover{transform:translateY(-1px)}";

  function decorate() {
    HOSTS.forEach(function (id) {
      var h = $(id); if (!h || !h.shadowRoot) return;
      var r = h.shadowRoot;
      if (!r.getElementById("kux-style")) {
        var s = document.createElement("style"); s.id = "kux-style"; s.textContent = SHADOW_CSS; r.appendChild(s);
        var w = 0; try { w = parseInt(localStorage.getItem("kd_w_" + id), 10) || 0; } catch (e) {}
        if (w) { h.style.setProperty("--kdw", w + "px"); h.setAttribute("data-kdw", "1"); }
      }
      var p = r.querySelector(".panel");
      if (p && !p.querySelector(":scope > .kdrs")) addResize(h, p, id);
      steps(id, h, r);
    });
  }

  /* ---------------------- panel resize ---------------------- */
  function addResize(host, panel, id) {
    var g = document.createElement("div"); g.className = "kdrs"; g.title = "টেনে চওড়া / সরু করুন (double-click = আগের মাপ)";
    panel.appendChild(g);
    var sx = 0, sw = 0, on = false;
    g.addEventListener("mousedown", function (e) {
      on = true; sx = e.clientX; sw = panel.getBoundingClientRect().width; g.classList.add("on");
      e.preventDefault(); e.stopPropagation();
    });
    document.addEventListener("mousemove", function (e) {
      if (!on) return;
      var w = Math.max(300, Math.min(window.innerWidth - 80, Math.round(sw + (sx - e.clientX))));
      host.style.setProperty("--kdw", w + "px"); host.setAttribute("data-kdw", "1");
    });
    document.addEventListener("mouseup", function () {
      if (!on) return; on = false; g.classList.remove("on");
      try { localStorage.setItem("kd_w_" + id, String(parseInt(host.style.getPropertyValue("--kdw"), 10) || "")); } catch (e) {}
    });
    g.addEventListener("dblclick", function () {
      host.style.removeProperty("--kdw"); host.removeAttribute("data-kdw");
      try { localStorage.removeItem("kd_w_" + id); } catch (e) {}
    });
  }

  /* ---------------------- step guide ---------------------- */
  function liveStop(root) {
    return [].slice.call(root.querySelectorAll("button")).some(function (b) { return !b.disabled && /stop/i.test(b.textContent || ""); });
  }
  function runCounts(r) {
    var t = 0, done = 0, pend = 0;
    ((r && r.groups) || []).forEach(function (g) { (g.workers || []).forEach(function (w) { t++; if (w.status === "pending" || w.status === "filled") pend++; else done++; }); });
    return { t: t, done: done, pend: pend };
  }
  function stepState(id, root) {
    if (id === "dxwd-host" || id === "dxwa-host") {
      var r = lsJson(id === "dxwd-host" ? "dxwd_run" : "dxwa_run"), c = runCounts(r);
      var S = ["List load", "Rule দেখুন", "Start", "Export"];
      if (!r || !c.t) return { s: S, cur: 0, tip: "Excel বেছে নিন বা Gram Setu থেকে list আনুন।" };
      if (r.active) return { s: S, cur: 2, run: true, tip: "চলছে: " + c.done + "/" + c.t + " শেষ।" };
      if (c.pend) return { s: S, cur: c.done ? 2 : 1, tip: c.done ? "বাকি " + c.pend + " জন, Start চাপলে আবার চলবে।" : "eKYC / ABPS rule দেখে Start চাপুন।" };
      return { s: S, cur: 3, tip: "সব শেষ। ⋯ → Export results দিয়ে ফল রাখুন।" };
    }
    if (id === "dxabps-host") {
      var S2 = ["Panchayat বাছুন", "Sync", "Data ready"];
      if (liveStop(root)) return { s: S2, cur: 1, run: true, tip: "Village-গুলো পড়া হচ্ছে…" };
      var has = Object.keys(abpsMeta).length > 0, fresh = Object.keys(abpsMeta).some(function (k) { var m = abpsMeta[k]; return m && m.savedAt && Date.now() - m.savedAt < 7 * 864e5; });
      var vs = document.querySelector('select[id$="DDL_Village"]'), hasV = vs && vs.options.length > 1;
      if (fresh) return { s: S2, cur: 3, tip: "Data তৈরি। Demand / Allocation / Readiness এখন এটা ব্যবহার করবে।" };
      if (!hasV) return { s: S2, cur: 0, tip: "উপরে Panchayat বেছে নিন, village list এলে Sync চাপুন।" };
      return { s: S2, cur: 1, tip: has ? "Data ৭ দিনের বেশি পুরনো, আবার Sync করুন।" : "Sync all villages চাপুন।" };
    }
    if (id === "khnp-host") {
      var r3 = lsJson("khnp_run"), S3 = ["Village খুলুন", "Start", "Not enabled list"];
      if (r3 && r3.active) return { s: S3, cur: 1, run: true, tip: "Check with NPCI চলছে…" };
      if (r3 && r3.results && r3.results.length) return { s: S3, cur: 2, tip: "শেষ। Not enabled list download করুন।" };
      return { s: S3, cur: 0, tip: "যে village থেকে শুরু করবেন সেটা খুলে Start চাপুন।" };
    }
    if (id === "kdrd-host") {
      var S4 = ["List", "Account check", "Print / Excel"];
      if (liveStop(root)) return { s: S4, cur: 1, run: true, tip: "Pension page থেকে account আনা হচ্ছে…" };
      var unk = /check হয়নি/.test((root.querySelector("tbody") || {}).textContent || "");
      if (unk) return { s: S4, cur: 1, tip: "Account check চাপুন।" };
      return { s: S4, cur: 2, tip: "Print বা Excel নিন।" };
    }
    return null;
  }
  // Demand / Allocation-এর গতি: portal ধীর থাকলে "ধীর" করলে data load হওয়ার আগে পরের ধাপে যায় না।
  // মান localStorage kd_speed-এ থাকে (driver-গুলো সেখান থেকেই পড়ে), চলমান run-এও পরের ধাপ থেকে লাগে।
  var SPEEDS = [["3", "খুব ধীর"], ["2", "ধীর"], ["1", "স্বাভাবিক"], ["0.6", "দ্রুত"]];
  var SPEED_HINT = { "3": "Portal খুব ধীর হলে। প্রতিটা ধাপে ৩ গুণ সময় দেয়।", "2": "Portal ধীর হলে। প্রতিটা ধাপে ২ গুণ সময় দেয়।", "1": "আগের মতই (default)।", "0.6": "Portal ভালো চললে। ধাপের মাঝের বিরতি কমে, data-র জন্য অপেক্ষা কমে না।" };
  function speedNow() { var v = null; try { v = localStorage.getItem("kd_speed"); } catch (e) {} return SPEED_HINT[v] ? v : "1"; }
  function speedBox(root, after) {
    var box = root.querySelector(".kdspd");
    if (!box) {
      box = document.createElement("div"); box.className = "kdspd";
      var slot = root.querySelector(".kdp-speed");   // v1.26.0: clean panel-এ গতি ⚙ Advanced-এর ভেতরে
      if (slot) slot.appendChild(box); else after.parentNode.insertBefore(box, after.nextSibling);
      box.addEventListener("click", function (e) {
        var b = e.target.closest && e.target.closest("button[data-v]"); if (!b) return;
        try { if (b.dataset.v === "1") localStorage.removeItem("kd_speed"); else localStorage.setItem("kd_speed", b.dataset.v); } catch (x) {}
        box.removeAttribute("data-v"); speedBox(root, after);
      });
    }
    var cur = speedNow();
    if (box.getAttribute("data-v") === cur) return;
    box.setAttribute("data-v", cur);
    box.innerHTML = "⏱ গতি <span class='g'>" + SPEEDS.map(function (x) { return "<button type='button' data-v='" + x[0] + "' class='" + (x[0] === cur ? "on" : "") + "'>" + x[1] + "</button>"; }).join("") + "</span><small></small>";
    box.querySelector("small").textContent = SPEED_HINT[cur];
  }
  function steps(id, host, root) {
    // v1.26.0 (Koushik): clean Demand/Allocation panel-এ ১-২-৩-৪ ধাপের সারি আর লাগবে না — শুধু গতি (⚙ Advanced-এ)
    if (root.querySelector(".kdp-act")) {   // v1.28.0: যেকোনো clean panel-এ ধাপের সারি নেই
      var old = root.querySelector(".kdsteps"); if (old) old.remove();
      if ((id === "dxwd-host" || id === "dxwa-host") && root.querySelector(".kdp-speed")) speedBox(root, null);
      return;
    }
    var st = stepState(id, root); if (!st) return;
    var bd = root.querySelector(".bd") || root.querySelector(".bar"); if (!bd) return;
    var box = root.querySelector(".kdsteps");
    if (!box) {
      box = document.createElement("div"); box.className = "kdsteps";
      if (bd.classList.contains("bar")) { box.style.margin = "10px 14px 0"; bd.parentNode.insertBefore(box, bd.nextSibling); }
      else bd.insertBefore(box, bd.firstChild);
    }
    if (id === "dxwd-host" || id === "dxwa-host") speedBox(root, box);
    var sig = st.cur + "|" + !!st.run + "|" + st.tip;
    if (box.getAttribute("data-sig") === sig) return;
    box.setAttribute("data-sig", sig);
    var html = "";
    st.s.forEach(function (lbl, i) {
      var cls = i < st.cur ? "done" : i === st.cur ? "cur" + (st.run ? " run" : "") : "";
      if (i) html += "<i class='" + (i <= st.cur ? "done" : "") + "'></i>";
      html += "<span class='s " + cls + "'><span class='n'>" + (i < st.cur ? "✓" : i + 1) + "</span>" + lbl + "</span>";
    });
    html += "<span class='tip'></span>";
    box.innerHTML = html;
    box.querySelector(".tip").textContent = st.tip || "";
  }

  /* ---------------------- কাজ শেষ হলে জানানো ---------------------- */
  function lsActive(k) { var r = lsJson(k); return !!(r && r.active); }
  function jobs() {
    var ls = [], panel = [];
    if (lsActive("dxwd_run")) ls.push("Work Demand");
    if (lsActive("dxwa_run")) ls.push("Work Allocation");
    if (lsActive("khnp_run")) ls.push("ABPS Enable (NPCI)");
    if (lsActive("mrfa_run")) ls.push("Fill Attendance only");
    if (lsActive("mrfp_run")) ls.push("Payment only");
    HOSTS.concat(["mrbp"]).forEach(function (id) {
      var h = $(id); if (!h) return;
      var n = NAMES[id]; if (ls.indexOf(n) >= 0) return;
      if (liveStop(h.shadowRoot || h)) panel.push(n);
    });
    return { ls: ls, panel: panel, path: location.pathname.toLowerCase() };
  }
  function prevJobs() { try { return JSON.parse(sessionStorage.getItem("kd_jobs") || "null"); } catch (e) { return null; } }
  function watchJobs() {
    var now = jobs(), prev = prevJobs(), ended = [];
    if (prev) {
      (prev.ls || []).forEach(function (n) { if (now.ls.indexOf(n) < 0) ended.push(n); });
      if (prev.path === now.path) (prev.panel || []).forEach(function (n) { if (now.panel.indexOf(n) < 0 && now.ls.indexOf(n) < 0) ended.push(n); });
    }
    try { sessionStorage.setItem("kd_jobs", JSON.stringify(now)); } catch (e) {}
    ended.forEach(finished);
  }
  function finished(name) {
    var msg = name + " শেষ হয়েছে";
    toast("✓ " + msg);
    if (ui.sound) chime();
    if (ui.notify) { try { chrome.runtime.sendMessage({ type: "kd-notify", title: "K-Desk Suite", msg: msg + " (" + (document.title || location.hostname) + ")" }); } catch (e) {} }
  }
  function chime() {
    try {
      var A = window.AudioContext || window.webkitAudioContext; if (!A) return;
      var ctx = new A(), t = ctx.currentTime;
      [[880, 0], [1320, 0.16]].forEach(function (x) {
        var o = ctx.createOscillator(), g = ctx.createGain();
        o.type = "sine"; o.frequency.value = x[0];
        g.gain.setValueAtTime(0.0001, t + x[1]); g.gain.exponentialRampToValueAtTime(0.18, t + x[1] + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + x[1] + 0.35);
        o.connect(g); g.connect(ctx.destination); o.start(t + x[1]); o.stop(t + x[1] + 0.4);
      });
      setTimeout(function () { try { ctx.close(); } catch (e) {} }, 1200);
    } catch (e) {}
  }

  /* ---------------------- নিজের ছোট UI: toast, help, tour ---------------------- */
  var uiHost, uiRoot;
  var UI_CSS =
    ":host{all:initial}" +
    ".toast{position:fixed;left:18px;bottom:18px;z-index:3;display:flex;align-items:center;gap:8px;padding:10px 14px;border-radius:12px;color:#fff;font:600 13px 'Segoe UI','Nirmala UI',sans-serif;background:linear-gradient(135deg,#0b1437,#3730a3);border-left:4px solid #f5b942;box-shadow:0 10px 30px rgba(11,20,55,.4);animation:tIn .25s ease-out}" +
    "@keyframes tIn{from{transform:translateY(14px);opacity:0}}" +
    ".ov{position:fixed;inset:0;z-index:2;background:rgba(11,20,55,.45);font-family:'Segoe UI','Nirmala UI',sans-serif}" +
    ".card{font-family:'Segoe UI','Nirmala UI',system-ui,sans-serif;position:fixed;z-index:4;width:330px;max-width:calc(100vw - 100px);background:linear-gradient(180deg,#eef0ff,#e3e6fb);color:#1e1b4b;border:1px solid #c9cef3;border-radius:16px;box-shadow:0 20px 60px rgba(11,20,55,.45);overflow:hidden;animation:cIn .22s ease-out}" +
    "@keyframes cIn{from{transform:translateX(16px);opacity:0}}" +
    ".card .ch{padding:11px 14px;color:#fff;background:linear-gradient(135deg,#0b1437,#1e1b6b 55%,#3730a3);font-weight:700;font-size:14.5px;position:relative}" +
    ".card .ch small{display:block;font-size:9.5px;letter-spacing:.9px;text-transform:uppercase;color:#c7d2fe;font-weight:600}.card .ch small i{font-style:normal;color:#f5b942}" +
    ".card .ch:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}" +
    ".card .cb{padding:11px 14px;font-size:12.5px;line-height:1.55}.card .cb b{color:#3730a3}" +
    ".card kbd{display:inline-block;min-width:18px;padding:1px 6px;border-radius:6px;background:#fff;border:1px solid #c9cef3;border-bottom-width:2px;font:600 11px Consolas,monospace;color:#1e1b4b;text-align:center}" +
    ".card table{border-collapse:collapse;width:100%}.card td{padding:3px 0;vertical-align:top}.card td:first-child{white-space:nowrap;padding-right:10px}" +
    ".card .cf{display:flex;align-items:center;gap:6px;padding:0 14px 12px}.card .dots{flex:1;display:flex;gap:4px}.card .dots span{width:7px;height:7px;border-radius:50%;background:#c9cef3}.card .dots span.on{background:#e08e0b}" +
    ".card button{height:32px;padding:0 12px;border-radius:10px;font:600 12px 'Segoe UI','Nirmala UI',sans-serif;cursor:pointer;border:1px solid #d4d8f5;background:#f5f6ff;color:#1e1b4b}" +
    ".card button.p{border:0;color:#1a1300;background:linear-gradient(135deg,#ffd77a,#f5b942 50%,#e08e0b)}" +
    ".arrow{position:fixed;z-index:4;width:0;height:0;border:9px solid transparent;border-left-color:#eef0ff;filter:drop-shadow(2px 0 1px rgba(11,20,55,.2))}" +
    ".ring{position:fixed;border-radius:14px;box-shadow:0 0 0 3px #f5b942,0 0 0 9999px rgba(11,20,55,.45);pointer-events:none;transition:all .25s}" +
    ":host-context(html.kd-dark) .card{background:linear-gradient(180deg,#151b3d,#0f1430);color:#e2e8ff;border-color:#2b3366}:host-context(html.kd-dark) .card .cb b{color:#f5b942}" +
    ":host-context(html.kd-dark) .card button:not(.p){background:#1b2250;color:#e2e8ff;border-color:#343d7a}:host-context(html.kd-dark) .card kbd{background:#1b2250;color:#e2e8ff;border-color:#343d7a}" +
    ":host-context(html.kd-dark) .arrow{border-left-color:#151b3d}";
  function ensureUi() {
    if (uiRoot) return uiRoot;
    uiHost = document.createElement("div"); uiHost.id = "kux-host";
    uiHost.style.cssText = "position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;";
    document.body.appendChild(uiHost);
    uiRoot = uiHost.attachShadow({ mode: "open" });
    var s = document.createElement("style"); s.textContent = UI_CSS; uiRoot.appendChild(s);
    return uiRoot;
  }
  function toast(msg) {
    var r = ensureUi(), t = document.createElement("div"); t.className = "toast"; t.textContent = msg;
    r.appendChild(t); setTimeout(function () { t.remove(); }, 5000);
  }
  var SHORTCUTS = [["Alt + K", "K-Dock bar ছোট / বড়"], ["Alt + R", "Readiness Report খোলা / বন্ধ"], ["Alt + N", "Dark mode চালু / বন্ধ"], ["Alt + C", "Compact mode চালু / বন্ধ"], ["Esc", "খোলা panel লুকানো"], ["Alt + /", "এই তালিকা"]];
  function shortcutTable() { return "<table>" + SHORTCUTS.map(function (x) { return "<tr><td><kbd>" + x[0].split(" + ").join("</kbd> + <kbd>") + "</kbd></td><td>" + x[1] + "</td></tr>"; }).join("") + "</table>"; }
  function closeCards() { if (!uiRoot) return; [].forEach.call(uiRoot.querySelectorAll(".ov,.card,.arrow,.ring"), function (e) { e.remove(); }); }
  function showHelp() {
    closeCards();
    var r = ensureUi(), ov = document.createElement("div"); ov.className = "ov"; ov.onclick = closeCards;
    var c = document.createElement("div"); c.className = "card"; c.style.cssText = "left:50%;top:50%;transform:translate(-50%,-50%)";
    c.innerHTML = "<div class='ch'><small><i>K-Desk</i> Suite</small>Keyboard shortcut</div><div class='cb'>" + shortcutTable() + "</div><div class='cf'><span class='dots'></span><button class='p'>ঠিক আছে</button></div>";
    c.querySelector("button").onclick = closeCards;
    r.append(ov, c);
  }

  var TOUR = [
    { t: "এটা K-Dock", sel: "rail", b: "ডান ধারের এই bar-এ সব feature এক জায়গায়। যে page খোলা তার icon <b>উজ্জ্বল</b>, panel খোলা থাকলে <b>gold</b>। Icon-এ click করলে panel খোলে / লুকায়, অন্য page-এর icon চাপলে সেই page খোলে।" },
    { t: "উপরের K", sel: "k", b: "<b>K</b>-তে click করলে bar ছোট হয়ে শুধু একটা K button থাকে, আবার click করলে ফিরে আসে। bar-এর একদম নিচের <b>«</b> বোতাম চাপলে icon-এর সাথে <b>নাম</b>-ও দেখায় (Maximize)।" },
    { t: "Panel", sel: "panel", b: "Panel-এর মাথায় <b>ধাপগুলো</b> দেখায়: কোনটা হয়ে গেছে (✓), এখন কোনটা করতে হবে (gold)। Panel-এর <b>বাঁ ধার টেনে</b> চওড়া বা সরু করা যায়, double-click করলে আগের মাপ।" },
    { t: "Keyboard shortcut", sel: null, b: null },
    { t: "Dashboard", sel: null, b: "Chrome-এর উপরে <b>K-Desk icon</b>-এ click করলে Dashboard: feature On/Off, <b>Dark / Compact mode</b>, আজকের কাজের হিসাব। লম্বা কাজ শেষ হলে <b>notification আর শব্দ</b> দিয়ে জানাবে। এই tour আবার দেখতে Dashboard-এ \"Tour আবার দেখুন\"।" }
  ];
  function dockRoot() { var h = $("kdock-host"); return h && h.shadowRoot; }
  function tour(i) {
    closeCards();
    if (i >= TOUR.length) { var o = {}; o[TOUR_KEY] = true; try { chrome.storage.local.set(o); } catch (e) {} return; }
    var st = TOUR[i], r = ensureUi(), dr = dockRoot(), target = null;
    if (st.sel === "rail" && dr) target = dr.querySelector(".rail");
    if (st.sel === "k" && dr) target = dr.querySelector(".rail .k");
    if (st.sel === "panel") { HOSTS.some(function (id) { var h = $(id); if (h && h.style.display !== "none" && h.shadowRoot && h.shadowRoot.querySelector(".panel")) { target = h.shadowRoot.querySelector(".panel"); return true; } return false; }); }
    var rect = target && target.getBoundingClientRect();
    if (rect && (!rect.width || !rect.height)) rect = null;
    if (rect) { var ring = document.createElement("div"); ring.className = "ring"; ring.style.cssText = "left:" + (rect.left - 4) + "px;top:" + (rect.top + 2) + "px;width:" + (rect.width + 8) + "px;height:" + Math.min(rect.height - 4, window.innerHeight - 8) + "px"; r.appendChild(ring); }
    else { var ov = document.createElement("div"); ov.className = "ov"; r.appendChild(ov); }
    var c = document.createElement("div"); c.className = "card";
    var dots = TOUR.map(function (x, k) { return "<span class='" + (k === i ? "on" : "") + "'></span>"; }).join("");
    c.innerHTML = "<div class='ch'><small><i>K-Desk</i> Suite · পরিচয় " + (i + 1) + "/" + TOUR.length + "</small>" + st.t + "</div><div class='cb'>" + (st.b || "এগুলো যেকোনো portal page-এ কাজ করে:<br>" + shortcutTable()) + "</div>" +
      "<div class='cf'><span class='dots'>" + dots + "</span>" + (i ? "<button class='bk'>আগের</button>" : "<button class='sk'>বাদ দিন</button>") + "<button class='p nx'>" + (i === TOUR.length - 1 ? "শেষ" : "পরের") + "</button></div>";
    r.appendChild(c);
    var cw = c.offsetWidth || 330, ch = c.offsetHeight || 200;
    if (rect) {
      var left = Math.max(12, rect.left - cw - 18), top = Math.max(12, Math.min(window.innerHeight - ch - 12, rect.top + (st.sel === "rail" ? 60 : 10)));
      if (rect.left - cw - 18 < 12) { left = Math.min(window.innerWidth - cw - 12, rect.right + 18); }
      c.style.left = left + "px"; c.style.top = top + "px";
      if (left < rect.left) { var a = document.createElement("div"); a.className = "arrow"; a.style.left = (left + cw) + "px"; a.style.top = (top + 22) + "px"; r.appendChild(a); }
    } else { c.style.left = "50%"; c.style.top = "50%"; c.style.transform = "translate(-50%,-50%)"; }
    var sk = c.querySelector(".sk"), bk = c.querySelector(".bk");
    if (sk) sk.onclick = function () { tour(TOUR.length); };
    if (bk) bk.onclick = function () { tour(i - 1); };
    c.querySelector(".nx").onclick = function () { tour(i + 1); };
  }
  function maybeTour() {
    try {
      chrome.storage.local.get(TOUR_KEY, function (d) {
        if (d && d[TOUR_KEY]) return;
        var n = 0, iv = setInterval(function () {
          if (dockRoot() && dockRoot().querySelector(".rail")) { clearInterval(iv); setTimeout(function () { tour(0); }, 900); }
          else if (++n > 20) clearInterval(iv);
        }, 500);
      });
    } catch (e) {}
  }

  /* ---------------------- keyboard ---------------------- */
  function visibleDrawers() { return HOSTS.map($).filter(function (h) { return h && h.style.display !== "none"; }); }
  document.addEventListener("keydown", function (e) {
    var k = (e.key || "").toLowerCase();
    if (k === "escape") {
      if (uiRoot && uiRoot.querySelector(".card")) { closeCards(); return; }
      var tg = e.target && e.target.tagName; if (/INPUT|TEXTAREA|SELECT/.test(tg || "")) return;
      var v = visibleDrawers(); if (!v.length) return;
      var h = v[v.length - 1];
      if (h.id === "kdrd-host" && window.KD_READINESS) window.KD_READINESS.toggle(); else h.style.display = "none";
      return;
    }
    if (!e.altKey || e.ctrlKey || e.metaKey) return;
    var done = true;
    if (k === "k" && window.KDOCK) window.KDOCK.toggle();
    else if (k === "r" && window.KD_READINESS) window.KD_READINESS.toggle();
    else if (k === "n") { ui.dark = !ui.dark; applyModes(); saveUi(); toast(ui.dark ? "🌙 Dark mode চালু" : "☀ Dark mode বন্ধ"); }
    else if (k === "c") { ui.compact = !ui.compact; applyModes(); saveUi(); toast(ui.compact ? "Compact mode চালু" : "Compact mode বন্ধ"); }
    else if (k === "/" || k === "?") showHelp();
    else done = false;
    if (done) { e.preventDefault(); e.stopPropagation(); }
  }, true);

  /* ---------------------- আজকের হিসাব (Dashboard পড়ে) ---------------------- */
  // চলতি run আর শেষ হওয়া run-এর copy (…_lastResults) দুটো থেকেই আজ "done" হওয়া worker গোনা;
  // একই দিনে কয়েকটা run হলেও যোগ হয় (worker-এর চিহ্ন দিয়ে, দুবার গোনা হয় না)
  var todaySig = "";
  function doneToday(keys) {
    var out = {};
    keys.forEach(function (k) {
      var r = lsJson(k);
      ((r && r.groups) || []).forEach(function (g) { (g.workers || []).forEach(function (w) {
        if (w.status === "done" && isToday(w.at)) out[(w.reg || "") + "|" + (w.applicant || "") + "|" + (g.workCode || "") + "|" + w.at] = 1;
      }); });
    });
    return out;
  }
  function mirrorToday() {
    var d = doneToday(["dxwd_run", "dxwd_lastResults"]), a = doneToday(["dxwa_run", "dxwa_lastResults"]);
    var sig = today() + JSON.stringify(d) + JSON.stringify(a);
    if (sig === todaySig) return; todaySig = sig;
    try {
      chrome.storage.local.get("kd_today", function (x) {
        var cur = (x && x.kd_today) || {};
        if (cur.date !== today()) cur = { date: today(), dk: {}, ak: {} };
        cur.dk = cur.dk || {}; cur.ak = cur.ak || {};
        var ch = false, k;
        for (k in d) if (!cur.dk[k]) { cur.dk[k] = 1; ch = true; }
        for (k in a) if (!cur.ak[k]) { cur.ak[k] = 1; ch = true; }
        if (!ch && cur.demand != null) return;
        cur.demand = Object.keys(cur.dk).length; cur.alloc = Object.keys(cur.ak).length;
        chrome.storage.local.set({ kd_today: cur });
      });
    } catch (e) {}
  }

  /* ---------------------- start ---------------------- */
  function start() {
    var st = document.createElement("style"); st.id = "kux-doc"; st.textContent = DOC_CSS; (document.head || document.documentElement).appendChild(st);
    chrome.storage.local.get([UI_KEY, "dxAbpsMeta"], function (d) {
      var u = (d && d[UI_KEY]) || {}; for (var k in u) ui[k] = u[k];
      abpsMeta = (d && d.dxAbpsMeta) || {};
      applyModes();
    });
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local") return;
      if (ch[UI_KEY]) { var u = ch[UI_KEY].newValue || {}; for (var k in u) ui[k] = u[k]; applyModes(); }
      if (ch.dxAbpsMeta) abpsMeta = ch.dxAbpsMeta.newValue || {};
      if (ch[TOUR_KEY] && ch[TOUR_KEY].newValue === false) tour(0);
    });
    decorate(); setInterval(decorate, 1000);
    setInterval(watchJobs, 2000); watchJobs();
    setInterval(mirrorToday, 1500); mirrorToday();
    maybeTour();
    window.KUX = { help: showHelp, tour: function () { tour(0); } };
  }
  try {
    KH_LICENSE.check(function (ok, name, info) {
      if (!ok) return;
      chrome.storage.local.get("kh_off", function (o) { if (!(o && o.kh_off)) start(); });
      // Trial বা মেয়াদি key শেষ হতে ৩ দিন বা কম বাকি থাকলে দিনে একবার মনে করিয়ে দেয়
      if (info && (info.type === "trial" || info.type === "timed") && info.left <= 3) {
        var day = new Date().toDateString();
        try { if (localStorage.getItem("kd_lic_warn") === day) return; localStorage.setItem("kd_lic_warn", day); } catch (e) {}
        setTimeout(function () { toast("⏳ K-Desk " + (info.type === "trial" ? "Trial" : "License") + " শেষ হতে " + info.left + " দিন বাকি — Dashboard থেকে নতুন key দিন"); }, 2500);
      }
    });
  } catch (e) {}
})();
