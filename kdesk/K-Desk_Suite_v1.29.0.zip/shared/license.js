/* license.js — K-Desk Suite by Koushik · প্রতি PC-তে একবার key দিয়ে activation।
   Device ID এই PC-র Chrome profile-এ একবার তৈরি হয় (kh_device)। Key হলো Koushik-এর
   private key দিয়ে "KH1|<Device ID>"-এর ECDSA P-256 signature; এখানে শুধু public key আছে,
   তাই code পড়েও নতুন key বানানো যায় না।
   v1.4.1: মেয়াদি key "KH3.<নাম>.<YYYYMMDD>.<sig>" (ওই দিনের শেষ পর্যন্ত চলে), আর key না থাকলে
   প্রথম ব্যবহারের দিন থেকে ৩ দিনের Trial (v1.8.8 থেকে, আগে ৭)। KH1/KH2 key আগের মতোই আজীবন চলে।
   v1.8.0: GP key "KH4.<নাম>.<GP code,…>.<YYYYMMDD বা ফাঁকা>.<sig>": কোনো PC-তে বাঁধা নয়, ওই GP-র
   যত PC খুশি। Demand, Allocation আর ABPS Sync শুধু key-তে থাকা GP-র Job Card-এ চলে (gpCheck)।
   v1.8.1: GP + PC key "KH5.<নাম>.<GP code,…>.<Device ID,…>.<YYYYMMDD বা ফাঁকা>.<sig>": GP-র নিয়ম একই,
   আর শুধু key-তে লেখা PC-গুলোতে (যেমন ২টা) চলে। */
(function () {
  "use strict";
  if (window.KH_LICENSE) return;
  var PUB = {"kty": "EC", "crv": "P-256", "x": "2A3a0CsK6fmg1JDQeQkUrAayysI84UN8jSPiftuco0Q", "y": "kyBWrEETz92IImjIQvJMftdEI3PX2DNq7cBVMDpcDFE"};
  var ALPH = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

  function newDeviceId() {
    var a = new Uint8Array(10); crypto.getRandomValues(a);
    var s = ""; for (var i = 0; i < a.length; i++) s += ALPH[a[i] % 32];
    return "KH-" + s.slice(0, 5) + "-" + s.slice(5);
  }
  function cleanKey(k) { return String(k || "").replace(/\s+/g, "").replace(/^KH1\./i, ""); }
  function b64u(s) {
    s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
    var bin = atob(s), u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  var pubKey = null;
  function sigOk(sigB64, msg) {
    try {
      var sig = b64u(sigB64); if (sig.length !== 64) return Promise.resolve(false);
      var p = pubKey || (pubKey = crypto.subtle.importKey("jwk", PUB, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]));
      return p.then(function (k) {
        return crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, k, sig, new TextEncoder().encode(msg));
      }).catch(function () { return false; });
    } catch (e) { return Promise.resolve(false); }
  }
  var DAY = 86400000, TRIAL_DAYS = 3;
  // দুই রকম key: পুরনো "KH1.<sig>" (নাম ছাড়া) আর নতুন "KH2.<নাম>.<sig>" (Licensed to নাম সহ)।
  // ফল: { ok, name }
  // GP code তুলনা: district-block-GP সংখ্যা দিয়ে, তাই "WB-08-005-014", "WB-8-5-14" আর state অক্ষর ছাড়া
  // "08-005-014-013/001" একই GP। ফল "8-5-14", বুঝতে না পারলে "".
  function gpNorm(c) {
    var a = String(c || "").toUpperCase().replace(/\s+/g, "").split("/")[0].split("-");
    if (/^[A-Z]{2}$/.test(a[0])) a = a.slice(1);
    if (a.length < 3) return "";
    for (var i = 0; i < 3; i++) { if (!/^\d+$/.test(a[i])) return ""; a[i] = String(parseInt(a[i], 10)); }
    return a.slice(0, 3).join("-");
  }
  function parse(key) {
    var k = String(key || "").replace(/\s+/g, "");
    var f = /^KH5\.([A-Za-z0-9_-]*)\.([A-Za-z]{2}(?:-\d+){3}(?:,[A-Za-z]{2}(?:-\d+){3})*)\.(KH-[A-Z0-9]{5}-[A-Z0-9]{5}(?:,KH-[A-Z0-9]{5}-[A-Z0-9]{5})*)\.(\d{8})?\.([A-Za-z0-9_-]+)$/i.exec(k);
    if (f) { try { return { v: 5, name: f[1] ? new TextDecoder().decode(b64u(f[1])) : "", gps: f[2].toUpperCase(), devs: f[3].toUpperCase(), exp: f[4] || "", sig: f[5] }; } catch (e) { return null; } }
    var g = /^KH4\.([A-Za-z0-9_-]*)\.([A-Za-z]{2}(?:-\d+){3}(?:,[A-Za-z]{2}(?:-\d+){3})*)\.(\d{8})?\.([A-Za-z0-9_-]+)$/i.exec(k);
    if (g) { try { return { v: 4, name: g[1] ? new TextDecoder().decode(b64u(g[1])) : "", gps: g[2].toUpperCase(), exp: g[3] || "", sig: g[4] }; } catch (e) { return null; } }
    var t = /^KH3\.([A-Za-z0-9_-]*)\.(\d{8})\.([A-Za-z0-9_-]+)$/i.exec(k);
    if (t) { try { return { v: 3, name: t[1] ? new TextDecoder().decode(b64u(t[1])) : "", exp: t[2], sig: t[3] }; } catch (e) { return null; } }
    var m = /^KH2\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/i.exec(k);
    if (m) { try { return { v: 2, name: new TextDecoder().decode(b64u(m[1])), sig: m[2] }; } catch (e) { return null; } }
    return { v: 1, name: "", sig: cleanKey(k) };
  }
  function verifyFull(deviceId, key) {
    var p = parse(key); if (!p) return Promise.resolve({ ok: false, name: "" });
    if (p.v === 5 && p.devs.split(",").indexOf(String(deviceId || "").toUpperCase()) < 0) return Promise.resolve({ ok: false, name: "" });
    var msg = p.v === 5 ? "KH5|" + p.gps + "|" + p.devs + "|" + p.name + "|" + p.exp : p.v === 4 ? "KH4|" + p.gps + "|" + p.name + "|" + p.exp : p.v === 3 ? "KH3|" + deviceId + "|" + p.name + "|" + p.exp : p.v === 2 ? "KH2|" + deviceId + "|" + p.name : "KH1|" + deviceId;
    return sigOk(p.sig, msg).then(function (ok) { return { ok: !!ok, name: ok ? p.name : "", exp: ok && p.exp ? expEnd(p.exp) : 0, gps: ok && p.gps ? p.gps.split(",") : null }; });
  }
  // "YYYYMMDD" → সেই দিনের রাত 23:59:59 (এই PC-র সময়ে)
  function expEnd(d) { return new Date(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6, 8), 23, 59, 59, 999).getTime(); }
  function daysLeft(end, now) { return Math.max(0, Math.ceil((end - now) / DAY)); }

  // Trial শুরুর দিন আর "সবচেয়ে বেশি দেখা সময়" local + sync দুই জায়গায় থাকে: extension মুছে আবার
  // বসালে (একই Chrome account-এ) Trial নতুন করে শুরু হয় না, আর PC-র ঘড়ি পিছিয়ে মেয়াদ বাড়ানো যায় না।
  function clock(cb) {
    var now = Date.now();
    function done(st) { cb(Math.max(now, st.seen || 0), st); }
    try {
      chrome.storage.local.get("kh_trial", function (a) {
        var la = (a && a.kh_trial) || {};
        var fin = function (sa) {
          sa = sa || {};
          var st = { s: Math.min(la.s || now, sa.s || now), seen: Math.max(la.seen || 0, sa.seen || 0) };
          // প্রতিবার না লিখে ঘণ্টায় একবার লেখা হয় (sync-এর লেখার সীমা আছে)
          if (st.s !== la.s || st.s !== sa.s || now > st.seen + 3600000) {
            var w = { s: st.s, seen: Math.max(st.seen, now) };
            try { chrome.storage.local.set({ kh_trial: w }); } catch (e) {}
            try { chrome.storage.sync.set({ kh_trial: w }); } catch (e) {}
          }
          done(st);
        };
        try { chrome.storage.sync.get("kh_trial", function (b) { fin(chrome.runtime.lastError ? null : b && b.kh_trial); }); }
        catch (e) { fin(null); }
      });
    } catch (e) { cb(now, { s: now }); }
  }
  function verify(deviceId, key) { return verifyFull(deviceId, key).then(function (r) { return r.ok; }); }
  // Device ID ফেরত দেয় (না থাকলে তৈরি করে, যদি create=true)
  function deviceId(create, cb) {
    chrome.storage.local.get("kh_device", function (r) {
      if (r && r.kh_device) return cb(r.kh_device);
      if (!create) return cb(null);
      var id = newDeviceId(); chrome.storage.local.set({ kh_device: id }, function () { cb(id); });
    });
  }
  // cb(ok, name, info): এই PC-তে চালানো যাবে কিনা, key-তে থাকা "Licensed to" নাম, আর
  // info = { type: "life" | "timed" | "trial" | "trial-over" | "expired", exp, left (দিন) }
  function check(cb) {
    try {
      chrome.storage.local.get(["kh_device", "kh_license"], function (r) {
        var p = r && r.kh_device && r.kh_license ? verifyFull(r.kh_device, r.kh_license) : Promise.resolve({ ok: false });
        p.then(function (x) {
          clock(function (now, st) {
            if (x.ok && !x.exp) return cb(true, x.name, { type: "life", gps: x.gps });
            if (x.ok && now <= x.exp) return cb(true, x.name, { type: "timed", exp: x.exp, left: daysLeft(x.exp, now), gps: x.gps });
            var tEnd = st.s + TRIAL_DAYS * DAY;
            if (now < tEnd) return cb(true, "", { type: "trial", exp: tEnd, left: daysLeft(tEnd, now), lapsed: x.ok ? x.exp : 0 });
            if (x.ok) return cb(false, x.name, { type: "expired", exp: x.exp, left: 0, gps: x.gps });
            cb(false, "", { type: "trial-over", exp: tEnd, left: 0 });
          });
        });
      });
    } catch (e) { cb(false, "", { type: "trial-over" }); }
  }
  // নতুন key যাচাই করে সঠিক হলে জমা রাখে
  function activate(key, cb) {
    deviceId(true, function (id) {
      verifyFull(id, key).then(function (x) {
        if (!x.ok) return cb(false, "");
        if (x.exp && Date.now() > x.exp) return cb(false, "", { expired: true });
        chrome.storage.local.set({ kh_license: String(key).replace(/\s+/g, "") }, function () { cb(true, x.name, { exp: x.exp, gps: x.gps }); });
      });
    });
  }
  // GP key থাকলে দেওয়া Job Card / GP code-গুলোর মধ্যে key-এর বাইরের GP খোঁজে।
  // cb(null) = সব ঠিক বা GP-বাঁধা key নয় (Trial, KH1/KH2/KH3); নইলে cb({ bad: [GP code], gps: [key-এর GP] })
  function gpCheck(cards, cb) {
    check(function (ok, name, info) {
      if (!ok || !info || !info.gps) return cb(null);
      var allow = {}; info.gps.forEach(function (c) { allow[gpNorm(c)] = 1; });
      var bad = [], seen = {};
      (cards || []).forEach(function (c) {
        var n = gpNorm(c); if (!n || allow[n] || seen[n]) return;
        seen[n] = 1; var p = String(c).toUpperCase().replace(/\s+/g, "").split("/")[0].split("-"); bad.push(p.slice(0, /^[A-Z]{2}$/.test(p[0]) ? 4 : 3).join("-"));
      });
      cb(bad.length ? { bad: bad, gps: info.gps } : null);
    });
  }
  function gpText(r) { return "এই License শুধু " + r.gps.join(", ") + " GP-র জন্য। অন্য GP-র Job Card: " + r.bad.join(", ") + "। Koushik-এর কাছ থেকে ওই GP-র key নিন।"; }
  window.KH_LICENSE = { check: check, activate: activate, deviceId: deviceId, verify: verify, gpCheck: gpCheck, gpText: gpText, gpNorm: gpNorm };
})();
