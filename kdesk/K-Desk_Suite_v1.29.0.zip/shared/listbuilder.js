/* Demand & Allocation Helper by Koushik — List Builder
   Builds the 4A worker list (Work Demand / Work Allocation) from the synced eKYC/ABPS
   dataset instead of copy-pasting from the registers: type "1/10" and every applicant on
   job card <GP>-001/010 is listed with their eKYC / ABPS status; tick who goes in, then
   load straight into the queue or download the Excel the panels already read.
   Used by the Demand + Allocation panels (modal) and builder.html (full tab). One draft
   (chrome.storage.local "dxListDraft") is shared by all of them. */
(function () {
  "use strict";

  var RANGE_CAP = 200;
  var SEP_RE = /[\s,;]+/;

  /* ---------------------- entry parser (pure) ----------------------
     Tokens are split on spaces / commas / semicolons / newlines, so a column pasted
     from Excel works too.
       1/10  001/010      village 1, household 10 of the current GP
       1/10-15            households 10..15 of village 1
       10  /10  10-15     household(s) of the last village used
       WB-06-003-006-001/010   a full card (the state letters may be left out)
     Suffix * ticks every member, + ticks only eKYC + ABPS members. */
  function parseEntry(text, lastVillage) {
    var items = [], errors = [], lv = +lastVillage || 0;
    String(text == null ? "" : text).split(SEP_RE).forEach(function (raw) {
      var t = raw.trim().toUpperCase(); if (!t) return;
      var tick = "none", last = t.charAt(t.length - 1);
      if (last === "*") { tick = "all"; t = t.slice(0, -1); } else if (last === "+") { tick = "elig"; t = t.slice(0, -1); }
      var m, v, lo, hi, state = "", mid = "";
      if ((m = t.match(/^(?:([A-Z]{2})-?)?(\d{1,3}-\d{1,4}-\d{1,4})-(\d{1,4})\/(\d{1,5})$/))) {
        state = m[1] || ""; mid = m[2]; v = +m[3]; lo = hi = +m[4];
      } else if ((m = t.match(/^(\d{1,4})\/(\d{1,5})(?:-(\d{1,5}))?$/))) {
        v = +m[1]; lo = +m[2]; hi = m[3] ? +m[3] : lo;
      } else if ((m = t.match(/^\/?(\d{1,5})(?:-(\d{1,5}))?$/))) {
        if (!lv) { errors.push({ raw: raw, why: "which village? type village/household, e.g. 1/" + m[1] }); return; }
        v = lv; lo = +m[1]; hi = m[2] ? +m[2] : lo;
      } else { errors.push({ raw: raw, why: "not a village/household number" }); return; }
      if (hi < lo) { var s = lo; lo = hi; hi = s; }
      if (!v || !lo) { errors.push({ raw: raw, why: "village and household start at 1" }); return; }
      if (hi - lo + 1 > RANGE_CAP) { errors.push({ raw: raw, why: "range too long (max " + RANGE_CAP + " households)" }); return; }
      for (var h = lo; h <= hi; h++) items.push({ raw: raw, state: state, mid: mid, v: v, h: h, tick: tick });
      lv = v;
    });
    return { items: items, errors: errors, lastVillage: lv };
  }

  if (typeof window === "undefined") {           // node: expose the parser for tests only
    if (typeof module === "object" && module.exports) module.exports = { parseEntry: parseEntry, RANGE_CAP: RANGE_CAP };
    return;
  }
  if (window.GNList) return;

  var DRAFT_KEY = "dxListDraft";

  /* ---------------------- small helpers ---------------------- */
  function pad(n, w) { n = String(n); while (n.length < w) n = "0" + n; return n; }
  function pad2(n) { return pad(n, 2); }
  function todayDMY() { var d = new Date(); return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear(); }
  function isoToDMY(s) { var m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? m[3] + "/" + m[2] + "/" + m[1] : ""; }
  function dmyToIso(s) { var m = String(s || "").match(/^(\d{2})\/(\d{2})\/(\d{4})$/); return m ? m[3] + "-" + m[2] + "-" + m[1] : ""; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function store() { try { return (chrome && chrome.storage && chrome.storage.local) || null; } catch (e) { return null; } }
  function norm(v) { return window.DX && DX.normKey ? DX.normKey(v, "id") : String(v || "").toUpperCase(); }
  // "001/010" — the village/household tail of a portal job card
  function tailOf(card) { var p = String(card || "").split("-"); return p.length > 4 ? p.slice(4).join("-") : String(card || ""); }
  function ageText(m) { return DX.syncedWhen(m); }
  function portalBase(d) {
    if (/\.dord\.gov\.in$/i.test(location.hostname)) return location.origin;
    return (d && d.origin) || "";
  }

  /* ---------------------- shared draft ---------------------- */
  function blankDraft() { return { v: 1, gp: "", lastVillage: 0, from: "", days: "", code: "", fe: false, fa: false, fams: [], rows: [], origin: "", updatedAt: 0 }; }
  // "Show only" filter: none ticked = everyone; eKYC and/or ABPS narrow it (applicant or list row)
  function passes(d, a) { return (!d.fe || !!a.ekyc) && (!d.fa || !!a.abps); }
  function countOf(d) { return (d.rows || []).filter(function (r) { return passes(d, r); }).length; }
  function fixDraft(x) {
    var d = blankDraft(); if (!x || typeof x !== "object") return d;
    for (var k in d) if (x[k] != null) d[k] = x[k];
    if (!Array.isArray(d.fams)) d.fams = []; if (!Array.isArray(d.rows)) d.rows = [];
    return d;
  }
  function loadDraft(cb) {
    var s = store(); if (!s) { cb(blankDraft()); return; }
    try { s.get(DRAFT_KEY, function (o) { cb(fixDraft(o && o[DRAFT_KEY])); }); } catch (e) { cb(blankDraft()); }
  }
  function saveDraft(d) {
    d.updatedAt = Date.now();
    var s = store(); if (!s) return;
    try { var o = {}; o[DRAFT_KEY] = d; s.set(o); } catch (e) {}
  }
  // for the panels' "＋ Build list (N)" label
  function draftCount(cb) { loadDraft(function (d) { cb(countOf(d)); }); }
  function onDraftChange(cb) {
    try { chrome.storage.onChanged.addListener(function (ch, area) { if (area === "local" && ch[DRAFT_KEY]) cb(fixDraft(ch[DRAFT_KEY].newValue)); }); } catch (e) {}
  }

  /* ---------------------- styles (the panels' own tokens) ---------------------- */
  var STYLE =
    ":host{all:initial}[hidden]{display:none!important}" +
    ".panel{font-family:Noto Sans Bengali,Noto Sans,Arial,sans-serif;font-size:13px;color:#0f172a;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #4338ca;border-radius:14px;box-shadow:0 14px 36px rgba(11,20,55,.28);overflow:hidden;box-sizing:border-box}" +
    ".panel *{box-sizing:border-box}" +
    ".hd{background:linear-gradient(115deg,#0b1437,#3730a3);border-bottom:3px solid #f5b942;color:#fff;padding:10px 11px;display:flex;align-items:center;justify-content:space-between}" +".origin-strip{display:flex;align-items:center;gap:6px;padding:6px 10px;background:#f5f7ff;border-bottom:1px solid #c7d2fe;color:#0b1437;font-size:10px;font-weight:700;line-height:1.35}" +".origin-dot{width:7px;height:7px;border-radius:50%;background:#4338ca;flex:0 0 auto}" +".hd b{font-size:12.5px;font-weight:600}" +
    ".hdl{display:flex;align-items:center;gap:7px;min-width:0}" +
    ".logo{width:20px;height:20px;border-radius:4px;flex:0 0 auto;background:#fff}" +
    ".mn{cursor:pointer;background:rgba(255,255,255,.2);border:none;color:#fff;width:22px;height:22px;border-radius:5px;font-size:13px;line-height:1;flex:0 0 auto}" +
    ".bd{padding:10px}" +
    ".btn{padding:8px 9px;border:none;border-radius:9px;font-size:12.5px;font-weight:650;cursor:pointer;font-family:inherit}" +
    ".btn.pick{background:#f5f7ff;color:#3730a3;border:1px solid #3730a3}" +
    ".btnrow{display:flex;gap:6px;margin-top:8px}.btnrow .btn{flex:1}" +
    ".btn.fill{background:#4338ca;color:#fff}.btn.fill:hover{background:#1e1b6b}.btn.fill:disabled{background:#a5b4fc;cursor:not-allowed}" +
    ".btn.ghost{background:#f5f7ff;color:#334;border:1px solid #d7dce6}.btn.ghost:disabled{color:#aab;cursor:not-allowed}" +
    ".btn.ghost.danger{background:#fdecea;color:#c5221f;border-color:#f3b4b0}.btn.ghost.danger:hover{background:#fbdbd8}.btn.ghost.danger:disabled{background:#f5f7ff;color:#c9a9a8;border-color:#e6d3d2}" +
    ".summary{font-size:11.5px;color:#3730a3;background:#eef2ff;border-radius:7px;padding:6px 8px;margin:0 0 8px;line-height:1.35}" +
    ".summary a,.st a{color:#3730a3;font-weight:600}" +
    ".st{margin-top:8px;font-size:11.5px;padding:6px 8px;border-radius:6px;background:#f5f7ff;min-height:15px;line-height:1.35}" +
    ".st.ok{background:#e7f4ec;color:#137333}.st.warn{background:#fef7e0;color:#9a6700}" +
    ".sec{font-weight:700;color:#3730a3;margin:10px 0 6px;border-top:1px solid #e2e8f0;padding-top:8px;font-size:12px;display:flex;align-items:center;justify-content:space-between;gap:6px}" +
    ".sec .n{font-weight:600;color:#5b6472;font-size:11px}" +
    ".inp{padding:6px 7px;border:1px solid #cbd5e1;border-radius:7px;font-size:12.5px;font-family:inherit;background:#fff;color:#0f172a}" +
    ".inp:focus{outline:none;border-color:#3730a3;box-shadow:0 0 0 2px rgba(129,140,248,.2)}" +
    ".top{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end;padding:7px 8px;border:1px solid #e2e8f0;border-radius:7px;background:#fbfcff}" +
    ".fld{display:flex;flex-direction:column;gap:3px}.fld label{font-size:11px;font-weight:700;color:#3730a3}" +
    ".fld.gp{flex:1 1 200px}.fld.gp .inp{width:100%}" +
    ".fchk{display:flex;gap:14px;align-items:center;height:32px}" +
    ".fchk label{display:flex;align-items:center;gap:6px;font-size:12.5px;font-weight:600;color:#0f172a;cursor:pointer}" +
    ".fchk input{margin:0;width:15px;height:15px;accent-color:#3730a3;cursor:pointer}" +
    ".fnote{font-size:10.5px;color:#9a6700;padding:4px 7px;background:#fef7e0;border-top:1px dashed #f2d98a}" +
    ".days{width:70px}.code{width:190px}" +
    ".entry{display:flex;gap:6px;margin-top:8px;align-items:stretch}" +
    ".vsel{width:230px;max-width:100%}" +
    ".tagbox{flex:1;min-width:0;display:flex;flex-wrap:wrap;align-items:center;gap:4px;padding:4px 6px;border:1px solid #cbd5e1;border-radius:7px;background:#fff;cursor:text;min-height:38px}" +
    ".tagbox>span{display:contents}" +
    ".tagbox:focus-within{border-color:#3730a3;box-shadow:0 0 0 2px rgba(129,140,248,.2)}" +
    ".tagin{flex:1;min-width:150px;border:0;outline:0;font-family:inherit;font-size:14px;padding:4px 2px;background:transparent;color:#0f172a}" +
    ".tag{display:inline-flex;align-items:center;gap:2px;background:#f5f7ff;color:#3730a3;border:1px solid #3730a3;border-radius:12px;padding:1px 3px 1px 9px;font-size:12px;font-weight:700;white-space:nowrap}" +
    ".tag.bad{background:#fdecea;color:#c5221f;border-color:#f3b4b0}" +
    ".tag .tx{background:none;border:0;color:inherit;cursor:pointer;font-size:13px;line-height:1;padding:0 4px;opacity:.75;font-family:inherit}.tag .tx:hover{opacity:1}" +
    ".hint{font-size:10.5px;color:#5b6472;margin-top:4px;line-height:1.35}.hint code{background:#f5f7ff;border-radius:4px;padding:0 4px;font-family:inherit;font-weight:700;color:#3730a3}" +
    ".cols{display:flex;gap:10px;flex-wrap:wrap}.col{flex:1 1 340px;min-width:0}" +
    ".scroll{max-height:44vh;overflow:auto;border:1px solid #e2e8f0;border-radius:7px}" +
    ".empty{font-size:11.5px;color:#8a92a0;padding:10px;text-align:center}" +
    ".fam{border-bottom:1px solid #e2e8f0}.fam:last-child{border-bottom:0}" +
    ".famhd{display:flex;align-items:center;gap:6px;padding:5px 7px;background:#f8fafc;font-size:11.5px;font-weight:700;color:#3730a3}" +
    ".famhd .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
    ".famhd .t span{font-weight:600;color:#5b6472}" +
    ".fam.miss .famhd{background:#fdecea;color:#c5221f}.fam.miss .famhd .t span{color:#c5221f}" +
    ".lk{background:none;border:none;color:#3730a3;font-weight:600;font-size:11px;cursor:pointer;padding:0 3px;font-family:inherit;white-space:nowrap}.lk:hover{text-decoration:underline}" +
    ".x{background:none;border:0;color:#c5221f;cursor:pointer;font-size:13px;padding:0 3px;line-height:1;font-family:inherit}" +
    ".mem{display:flex;align-items:center;gap:7px;padding:4px 7px;cursor:pointer;font-size:12px;border-top:1px dashed #eef0f4}.mem:hover{background:#f2f6fd}" +
    ".mem.on{background:#eef2ff}" +
    ".mem input{margin:0;flex:0 0 auto;cursor:pointer}" +
    ".mem .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
    ".mem .ap{font-size:10.5px;color:#8a92a0;flex:0 0 auto}" +
    ".chip{font-size:10px;font-weight:700;padding:1px 6px;border-radius:10px;flex:0 0 auto;white-space:nowrap}" +
    ".chip.ok{background:#e7f4ec;color:#137333}.chip.err{background:#fdecea;color:#c5221f}" +
    "table{border-collapse:collapse;width:100%;font-size:11px}" +
    "th,td{border-bottom:1px solid #eef0f4;padding:3px 5px;text-align:left;vertical-align:middle}" +
    "th{position:sticky;top:0;background:#f8fafc;color:#3730a3;font-weight:600;z-index:1}" +
    "td.c,th.c{text-align:center}" +
    "td .inp{padding:2px 4px;font-size:11px;border-radius:5px;width:100%}" +
    "td .inp.ovr{border-color:#3730a3;background:#eef2ff}" +
    "td.nm{max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
    ".disclaimer{margin-top:9px;font-size:9.5px;color:#8a92a0;line-height:1.35;background:#fbfbfd;border:1px solid #eef0f4;border-radius:6px;padding:5px 7px}" +
    ".foot{margin-top:8px;text-align:center;font-size:10px;color:#8a92a0;line-height:1.35}" +
    ".foot a.vt{color:#3730a3;text-decoration:none}.foot a.vt:hover{text-decoration:underline}" +
    // modal
    ".ov{position:fixed;inset:0;background:rgba(15,20,30,.45);display:flex;align-items:center;justify-content:center;padding:16px;z-index:2147483647}" +
    ".ov .panel{width:900px;max-width:100%;max-height:94vh;display:flex;flex-direction:column}" +
    ".ov .bd{overflow:auto;flex:1 1 auto}" +
    // full tab
    ".panel.page{border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 1px 3px rgba(20,30,60,.05)}" +
    ".panel.page .bd{padding:14px}.panel.page .scroll{max-height:58vh}";

  var THEME = ".panel{font-family:'Segoe UI','Nirmala UI',Noto Sans Bengali,system-ui,sans-serif;border:1px solid rgba(255,255,255,.6);border-left:0;border-radius:16px;box-shadow:0 18px 50px rgba(11,20,55,.28),0 2px 8px rgba(11,20,55,.12)}.hd{position:relative;background:linear-gradient(135deg,#0b1437 0%,#1e1b6b 55%,#3730a3 100%);border-bottom:0;padding:12px 12px 12px 14px;user-select:none}.hd:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,#f5b942,#e08e0b,transparent)}.hdl{gap:10px}.logo{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;flex:none;font:800 19px/1 Georgia,'Times New Roman',serif;color:#1a1300;background:linear-gradient(145deg,#ffe29a,#f5b942 45%,#e08e0b);box-shadow:0 3px 10px rgba(245,185,66,.45),inset 0 1px 0 rgba(255,255,255,.6)}.ttl{display:block;min-width:0}.hd .ttl b{display:block;font-size:14.5px;font-weight:700;letter-spacing:.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ttl small{display:block;font-size:11px;color:#c7d2fe;letter-spacing:.3px;white-space:nowrap}.ttl small i{font-style:normal;color:#f5b942;font-weight:600}.mn{width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,.12);font:700 15px/1 system-ui}.mn:hover{background:rgba(255,255,255,.25)}.bd{padding:12px 14px 0;background:linear-gradient(#fbfcff,#fff)}.btn{border-radius:10px;font-family:inherit;font-weight:600;transition:.15s}.btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 4px 12px rgba(15,23,42,.1)}.btn.pick{border:1.5px dashed #c7d2fe;background:#f5f7ff;color:#3730a3}.btn.pick:hover:not(:disabled){background:#eef2ff}.btn.fill{min-height:36px;color:#fff;border:0;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.fill:hover{background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.fill:disabled{opacity:.45;background:linear-gradient(135deg,#4338ca,#3730a3 60%,#1e1b6b)}.btn.stop{min-height:36px;color:#b91c1c;border:1px solid #fecaca;background:#fff5f5}.btn.stop:disabled{opacity:.45;background:#fff5f5;color:#b91c1c}.btn.ghost{background:#f8fafc;color:#0f172a;border:1px solid #e2e8f0}.btn.ghost:hover:not(:disabled){background:#eef2ff}.btn.ghost.danger{background:#fff5f5;color:#b91c1c;border-color:#fecaca}.summary{background:#eef2ff;color:#3730a3;border-radius:10px;padding:7px 10px}.progbar{background:#eef2ff;border-radius:99px}.progfill{border-radius:99px;background:linear-gradient(90deg,#34d399,#10b981,#f5b942)}.progtxt{color:#3730a3}.scroll{border-radius:10px;border-color:#e2e8f0}th{background:#f8fafc;color:#0b1437}.gate,.top{border-radius:10px;background:#fff}.gatehd{color:#64748b;text-transform:uppercase;letter-spacing:.6px}.st{border-radius:8px;background:#f8fafc}.sec{color:#64748b;text-transform:uppercase;letter-spacing:.6px;font-size:11px;font-weight:600;border-top-color:#e2e8f0}.logbox{max-height:140px;background:#0b1437;color:#c7d2fe;border:0;border-radius:10px;padding:8px 10px;font:11px/1.5 Consolas,monospace}.logbox div{border-bottom:1px dotted rgba(199,210,254,.14)}.l-err{color:#fca5a5}.l-warn{color:#fcd34d}.l-ok{color:#6ee7b7}.l-info{color:#c7d2fe}.logbox .lt{color:#7c89c9}.disclaimer{border-radius:8px}.foot{display:flex;justify-content:space-between;align-items:center;gap:8px;margin:10px -14px 0;padding:7px 14px;font-size:10.5px;color:#64748b;border-top:1px solid #e2e8f0;background:#f8fafc;text-align:left}.foot b{color:#0b1437;letter-spacing:.4px}.foot em{font-style:normal;color:#e08e0b}";
  STYLE = STYLE + THEME;

  var HTML =
    "<div class='hd' data-r='hd'><span class='hdl'><div class='logo' data-r='logo'>K</div><span class='ttl'><b>List Builder</b><small><i>K-Desk</i> Suite · by Koushik</small></span></span><button class='mn' data-r='close' title='Close (Esc)'>✕</button></div>" +
    "" +
    "<div class='bd'>" +
      "<div class='summary' data-r='gpmsg'>Loading ABPS data…</div>" +
      "<div class='top'>" +
        "<div class='fld gp' data-r='gpwrap' hidden><label>Panchayat</label><select class='inp' data-r='gpsel'></select></div>" +
        "<div class='fld'><label>Show only</label><div class='fchk'>" +
          "<label title='Show and list only workers whose eKYC is done'><input type='checkbox' data-r='fe'>eKYC done</label>" +
          "<label title='Show and list only ABPS-enabled workers'><input type='checkbox' data-r='fa'>ABPS enabled</label></div></div>" +
        "<div class='fld'><label>Village</label><select class='inp vsel' data-r='vsel' title='Used when you type only a household number, e.g. 12'></select></div>" +
        "<div class='fld'><label>Work From</label><input class='inp' type='date' data-r='from'></div>" +
        "<div class='fld'><label>No. of days</label><input class='inp days' type='number' min='1' max='366' data-r='days'></div>" +
        "<div class='fld' data-r='codewrap'><label>Work Code</label><input class='inp code' type='text' data-r='code' autocomplete='off' placeholder='e.g. 3206003006/IF/…'></div>" +
      "</div>" +
      "<div class='entry'>" +
        "<div class='tagbox' data-r='tagbox'><span data-r='tags'></span><input class='tagin' data-r='entry' autocomplete='off' spellcheck='false' placeholder='1/10  Tab  12  Tab …  then Enter'></div>" +
        "<button class='btn pick' data-r='add'>＋ Add</button>" +
      "</div>" +
      "<div class='hint'>Type <code>village/household</code> — <code>1/10</code> or <code>001/010</code> — and press <code>Tab</code> (or space / comma) to make a capsule; <code>Enter</code> looks them all up. " +
        "<code>1/10-15</code> is a range, <code>12</code> alone uses the Village above. End with <code>*</code> to tick everyone, <code>+</code> to tick eKYC + ABPS only. Pasting a column works too; <code>Backspace</code> removes the last capsule.</div>" +
      "<div class='cols'>" +
        "<div class='col'>" +
          "<div class='sec'><span>Families</span><span><span class='n' data-r='famn'></span> <button class='lk' data-r='hideall'>Hide all</button></span></div>" +
          "<div class='scroll' data-r='fams'></div>" +
        "</div>" +
        "<div class='col'>" +
          "<div class='sec'><span>4A list</span><span class='n' data-r='listn'></span></div>" +
          "<div class='scroll' data-r='list'></div>" +
        "</div>" +
      "</div>" +
      "<div class='btnrow'>" +
        "<button class='btn fill' data-r='load'>▶ Load into queue</button>" +
        "<button class='btn ghost' data-r='xlsx'>⭳ Download Excel</button>" +
        "<button class='btn ghost danger' data-r='clear'>🗑 Clear list</button>" +
      "</div>" +
      "<div class='st' data-r='st'></div>" +
      "<div class='disclaimer'>⚠ Automated entry can make mistakes. This tool assists — it does not replace you. Check every family and worker before loading, keep a person in the loop, and verify entries on the portal before relying on them. Use at your own responsibility.</div>" +
      "<div class='foot'><span>✦ Crafted by <b>KOUSHIK</b></span><em>v<span data-r='ver'></span></em></div>" +
    "</div>";

  /* ---------------------- the builder ----------------------
     mount(parent, opts) renders into `parent` (inside a shadow root).
     opts: { mode: "demand"|"alloc", onLoad(rows) | null, onClose() | null, page: bool } */
  function mount(parent, opts) {
    opts = opts || {};
    var mode = opts.mode === "alloc" ? "alloc" : "demand";
    var D = blankDraft(), map = {}, meta = {}, ready = false;
    var box = document.createElement("div"); box.className = "panel" + (opts.page ? " page" : "");
    box.innerHTML = HTML; parent.appendChild(box);
    var R = {}; [].forEach.call(box.querySelectorAll("[data-r]"), function (el) { R[el.getAttribute("data-r")] = el; });

    try {
      if (chrome && chrome.runtime) { R.logo.src = chrome.runtime.getURL("assets/icons/icon48.png"); R.ver.textContent = chrome.runtime.getManifest().version; }
    } catch (e) {}
    if (opts.page) R.hd.hidden = true;
    if (!opts.onClose) R.close.hidden = true;
    if (!opts.onLoad) {
      R.load.hidden = true;
    }

    function status(msg, kind) { R.st.textContent = msg || ""; R.st.className = "st" + (kind ? " " + kind : ""); }
    function save() { saveDraft(D); }
    function gpKeys() { return Object.keys(meta).sort(function (a, b) { return (meta[b].savedAt || 0) - (meta[a].savedAt || 0); }); }
    function curGp() { var ks = gpKeys(); return meta[D.gp] ? D.gp : (ks[0] || ""); }
    function eff(row, f) { return (row[f] != null && row[f] !== "") ? row[f] : D[f]; }
    function rowId(key, a) { return key + "|" + (a.app || a.name); }
    function hasRow(id) { for (var i = 0; i < D.rows.length; i++) if (D.rows[i].id === id) return i; return -1; }
    function members(key) { return map[key] || []; }

    function addRowFor(key, a) {
      var id = rowId(key, a); if (hasRow(id) >= 0) return false;
      var row = { id: id, key: key, card: a.card || key, app: a.app || "", name: a.name || "", ekyc: !!a.ekyc, abps: !!a.abps };
      // keep a family's workers together: insert after its last row
      var at = -1; for (var i = 0; i < D.rows.length; i++) if (D.rows[i].key === key) at = i;
      if (at < 0) D.rows.push(row); else D.rows.splice(at + 1, 0, row);
      return true;
    }
    function removeRow(id) { var i = hasRow(id); if (i >= 0) D.rows.splice(i, 1); }
    function tickFamily(key, how) {        // how: "all" | "elig" | "none"
      members(key).forEach(function (a) {
        if (!passes(D, a)) return;                  // hidden by "Show only": leave as it is
        var id = rowId(key, a), want = how === "all" || (how === "elig" && a.ekyc && a.abps);
        if (want) addRowFor(key, a); else removeRow(id);
      });
    }

    /* ---- GP / data status ---- */
    function renderGp() {
      var ks = gpKeys(), g = curGp(), m = meta[g];
      R.gpwrap.hidden = ks.length < 2;
      if (ks.length >= 2) {
        R.gpsel.innerHTML = ks.map(function (k) { return "<option value='" + esc(k) + "'>" + esc(DX.abpsLabel(meta[k], k)) + "</option>"; }).join("");
        R.gpsel.value = g;
      }
      R.gpmsg.textContent = ""; R.gpmsg.className = "summary";
      if (!m) {
        R.gpmsg.className = "st warn"; R.gpmsg.style.marginTop = "0"; R.gpmsg.style.marginBottom = "8px";
        R.gpmsg.appendChild(document.createTextNode("No eKYC / ABPS data synced yet — the builder needs it to list each family. "));
        var base = portalBase(D);
        if (base) {
          var a = document.createElement("a"); a.href = base + "/vbgramg/UID/AppABPSRpt.aspx"; a.target = "_blank"; a.rel = "noopener";
          a.textContent = "Open the ABPS report ↗"; R.gpmsg.appendChild(a);
          R.gpmsg.appendChild(document.createTextNode(" and click Sync all villages."));
        } else R.gpmsg.appendChild(document.createTextNode("Open the portal's Aadhaar / ABPS Status Report and click Sync all villages."));
        return;
      }
      R.gpmsg.style.marginTop = ""; R.gpmsg.style.marginBottom = "";
      R.gpmsg.appendChild(document.createTextNode("Panchayat " + DX.abpsLabel(m, g) + " · " + m.count + " applicants · ABPS data synced " + ageText(m) +
        (m.complete === false ? " (partial sync)" : "") + "."));
      if (DX.abpsStale(m)) {
        R.gpmsg.className = "st warn"; R.gpmsg.style.marginTop = "0"; R.gpmsg.style.marginBottom = "8px";
        R.gpmsg.appendChild(document.createTextNode(" Older than a week — eKYC / ABPS status may have changed. "));
        var base2 = portalBase(D);
        if (base2) { var a2 = document.createElement("a"); a2.href = base2 + "/vbgramg/UID/AppABPSRpt.aspx"; a2.target = "_blank"; a2.rel = "noopener"; a2.textContent = "Re-sync ↗"; R.gpmsg.appendChild(a2); }
      }
    }

    /* ---- families ---- */
    function renderFams() {
      if (!D.fams.length) {
        R.fams.innerHTML = "<div class='empty'>Type a village/household above — e.g. <b>1/10</b> — and press Enter.</div>";
        R.famn.textContent = ""; R.hideall.hidden = true; return;
      }
      R.hideall.hidden = false;
      R.famn.textContent = D.fams.length + " shown";
      var h = "";
      D.fams.forEach(function (f) {
        var list = members(f.key);
        if (!list.length) {
          h += "<div class='fam miss'><div class='famhd'><span class='t'>" + esc(f.label) + " <span>— not in ABPS data (sync the ABPS report)</span></span>" +
            "<button class='x' data-a='hide' data-k='" + esc(f.key) + "' title='Hide'>✕</button></div></div>";
          return;
        }
        var all = list, hid = 0;
        list = all.filter(function (a) { return passes(D, a); }); hid = all.length - list.length;
        var nOn = 0; list.forEach(function (a) { if (hasRow(rowId(f.key, a)) >= 0) nOn++; });
        h += "<div class='fam'><div class='famhd'><span class='t' title='" + esc(all[0].card || f.key) + "'>" + esc(tailOf(all[0].card) || f.label) +
          " <span>· " + all.length + " member" + (all.length === 1 ? "" : "s") + (nOn ? " · " + nOn + " ticked" : "") + "</span></span>" +
          (list.length ? "<button class='lk' data-a='all' data-k='" + esc(f.key) + "'>" + (nOn === list.length ? "Untick all" : "Tick all") + "</button>" : "") +
          "<button class='lk' data-a='elig' data-k='" + esc(f.key) + "' title='Tick only members with eKYC done and ABPS enabled'>Tick eKYC+ABPS</button>" +
          "<button class='x' data-a='hide' data-k='" + esc(f.key) + "' title='Hide this family (ticked workers stay in the list)'>✕</button></div>";
        list.forEach(function (a) {
          var on = hasRow(rowId(f.key, a)) >= 0;
          h += "<label class='mem" + (on ? " on" : "") + "'><input type='checkbox' data-a='tog' data-k='" + esc(f.key) + "' data-i='" + esc(a.app || a.name) + "'" + (on ? " checked" : "") + ">" +
            "<span class='nm' title='" + esc(a.name) + "'>" + esc(a.name || "(no name)") + "</span>" +
            (a.app ? "<span class='ap'>App " + esc(a.app) + "</span>" : "") +
            "<span class='chip " + (a.ekyc ? "ok" : "err") + "'>eKYC " + (a.ekyc ? "✓" : "✗") + "</span>" +
            "<span class='chip " + (a.abps ? "ok" : "err") + "'>ABPS " + (a.abps ? "✓" : "✗") + "</span></label>";
        });
        if (hid) h += "<div class='fnote'>" + (list.length ? hid + " more hidden" : "All " + hid + " hidden") + " by Show only (" + filterText() + ").</div>";
        h += "</div>";
      });
      R.fams.innerHTML = h;
    }

    /* ---- the 4A list ---- */
    function filterText() { return D.fe && D.fa ? "eKYC + ABPS" : D.fe ? "eKYC done" : "ABPS enabled"; }
    function outRows() { return D.rows.filter(function (r) { return passes(D, r); }); }
    function renderList() {
      var rows = outRows(), hid = D.rows.length - rows.length;
      var fams = {}; rows.forEach(function (r) { fams[r.key] = 1; });
      var nf = Object.keys(fams).length;
      R.listn.textContent = (rows.length ? rows.length + " worker" + (rows.length === 1 ? "" : "s") + " · " + nf + " famil" + (nf === 1 ? "y" : "ies") : "") +
        (hid ? (rows.length ? " · " : "") + hid + " hidden by filter" : "");
      R.load.disabled = !rows.length; R.xlsx.disabled = !rows.length; R.clear.disabled = !D.rows.length && !D.fams.length;
      if (!rows.length) {
        R.list.innerHTML = "<div class='empty'>" + (hid ? "All " + hid + " ticked worker(s) are hidden by Show only (" + filterText() + ")." : "Tick workers in a family to add them here.") + "</div>";
        return;
      }
      var alloc = mode === "alloc";
      var h = "<table><thead><tr><th class='c'>#</th><th>Reg</th><th>Applicant</th><th>Work From</th><th class='c'>Days</th>" + (alloc ? "<th>Work Code</th>" : "") + "<th></th></tr></thead><tbody>";
      rows.forEach(function (r, i) {
        var ov = function (f) { return (r[f] != null && r[f] !== "") ? " ovr" : ""; };
        h += "<tr><td class='c'>" + (i + 1) + "</td><td title='" + esc(r.card) + "'>" + esc(tailOf(r.card)) + "</td>" +
          "<td class='nm' title='" + esc(r.name) + (r.ekyc && r.abps ? "" : " — " + (r.ekyc ? "" : "eKYC not done ") + (r.abps ? "" : "ABPS not enabled")) + "'>" + esc(r.name) +
            (r.ekyc && r.abps ? "" : " <span class='chip err'>" + (!r.ekyc ? "eKYC ✗" : "ABPS ✗") + "</span>") + "</td>" +
          "<td style='width:118px'><input class='inp" + ov("from") + "' type='date' data-a='rf' data-f='from' data-id='" + esc(r.id) + "' value='" + esc(dmyToIso(eff(r, "from"))) + "'></td>" +
          "<td class='c' style='width:64px'><input class='inp" + ov("days") + "' type='number' min='1' max='366' data-a='rf' data-f='days' data-id='" + esc(r.id) + "' value='" + esc(eff(r, "days")) + "'></td>" +
          (alloc ? "<td style='width:150px'><input class='inp" + ov("code") + "' type='text' data-a='rf' data-f='code' data-id='" + esc(r.id) + "' value='" + esc(eff(r, "code")) + "'></td>" : "") +
          "<td class='c'><button class='x' data-a='rm' data-id='" + esc(r.id) + "' title='Remove'>✕</button></td></tr>";
      });
      R.list.innerHTML = h + "</tbody></table>";
    }

    function renderTop() {
      R.codewrap.hidden = mode !== "alloc";
      if (document.activeElement !== R.from && R.from.value !== dmyToIso(D.from)) R.from.value = dmyToIso(D.from);
      if (R.days.value !== String(D.days || "")) R.days.value = D.days || "";
      if (R.code.value !== String(D.code || "")) R.code.value = D.code || "";
      R.fe.checked = !!D.fe; R.fa.checked = !!D.fa;
      renderVillages();
    }
    // villages of the current GP, from the synced cards; names once a sync has recorded them
    var vcache = { gp: null, n: -1, list: [] };
    function villages() {
      var g = curGp(), n = Object.keys(map).length;
      if (vcache.gp === g && vcache.n === n) return vcache.list;
      var cnt = {}, pre = g + "-";
      for (var k in map) {
        if (k.indexOf(pre) !== 0) continue;
        var v = parseInt(k.slice(pre.length).split("/")[0], 10); if (v) cnt[v] = (cnt[v] || 0) + 1;
      }
      var names = (meta[g] && meta[g].vnames) || {};
      var list = Object.keys(cnt).map(Number).sort(function (a, b) { return a - b; }).map(function (v) {
        var nm = String(names[v] || ""); nm = nm.indexOf("/") > 0 ? nm.slice(nm.indexOf("/") + 1).trim() : nm;
        return { v: v, name: nm, fams: cnt[v] };
      });
      vcache = { gp: g, n: n, list: list };
      return list;
    }
    function hasVillage(v) { var l = villages(); if (!l.length) return true; for (var i = 0; i < l.length; i++) if (l[i].v === +v) return true; return false; }
    function villageRange() { var l = villages(); return l.length ? pad(l[0].v, 3) + "–" + pad(l[l.length - 1].v, 3) : ""; }
    function renderVillages() {
      var list = villages(), sig = curGp() + ":" + list.length + ":" + D.lastVillage;
      if (R.vsel.getAttribute("data-sig") === sig) return;
      var h = "<option value='0'>" + (list.length ? "Pick a village…" : "— sync ABPS data —") + "</option>", has = false;
      list.forEach(function (x) {
        if (x.v === +D.lastVillage) has = true;
        h += "<option value='" + x.v + "'>" + pad(x.v, 3) + (x.name ? " · " + esc(x.name) : "") + " (" + x.fams + " families)</option>";
      });
      if (D.lastVillage && !has) D.lastVillage = 0;
      R.vsel.innerHTML = h; R.vsel.value = String(+D.lastVillage || 0); R.vsel.setAttribute("data-sig", sig);
    }

    /* ---- capsules: Tab / space / comma turns what was typed into resolved capsules ---- */
    var tags = [];
    function canonOf(p) {                       // one token's parse -> exact text to look up + what to show
      var a = p.items[0], b = p.items[p.items.length - 1], rng = b.h !== a.h;
      var suf = a.tick === "all" ? "*" : a.tick === "elig" ? "+" : "";
      var pre = a.mid ? (a.state ? a.state + "-" : "") + a.mid + "-" : "";
      return {
        canon: pre + a.v + "/" + a.h + (rng ? "-" + b.h : "") + suf,
        label: pad(a.v, 3) + "/" + pad(a.h, 3) + (rng ? "–" + pad(b.h, 3) : "") + (suf === "*" ? " ✱" : suf === "+" ? " +" : "")
      };
    }
    function makeTags(text) {
      String(text || "").split(SEP_RE).forEach(function (t) {
        if (!t) return;
        var p = parseEntry(t, D.lastVillage);
        if (p.errors.length) { tags.push({ ok: false, raw: t, label: t, why: p.errors[0].why }); return; }
        if (!p.items.length) return;
        var a0 = p.items[0];
        if (!a0.mid && !hasVillage(a0.v)) {
          var gm = meta[curGp()];
          tags.push({ ok: false, raw: t, label: t, why: "no village " + pad(a0.v, 3) + " in " + (gm && gm.name ? gm.name : "this Panchayat") + " (villages " + villageRange() + ")" });
          return;
        }
        var c = canonOf(p);
        tags.push({ ok: true, raw: t, label: c.label, canon: c.canon });
        D.lastVillage = p.lastVillage;
      });
      save(); renderTags(); renderVillages();
    }
    function tagTitle(t) {
      if (!t.ok) return t.why;
      var m = /\*$/.test(t.canon) ? " — tick everyone" : /\+$/.test(t.canon) ? " — tick eKYC + ABPS only" : "";
      return "You typed " + t.raw + m;
    }
    function renderTags() {
      R.tags.innerHTML = tags.map(function (t, i) {
        return "<span class='tag" + (t.ok ? "" : " bad") + "' title='" + esc(tagTitle(t)) + "'>" + esc(t.label) +
          "<button class='tx' data-i='" + i + "' title='Remove'>×</button></span>";
      }).join("");
      R.entry.placeholder = tags.length ? "" : "1/10  Tab  12  Tab …  then Enter";
    }
    function submitTags() {
      if (R.entry.value.trim()) { makeTags(R.entry.value); R.entry.value = ""; }
      var good = tags.filter(function (t) { return t.ok; }), bad = tags.filter(function (t) { return !t.ok; });
      if (!good.length) {
        if (bad.length) status("Fix or remove the red capsule(s): " + bad.map(function (t) { return "\"" + t.raw + "\" (" + t.why + ")"; }).join("; ") + ".", "warn");
        return;
      }
      tags = bad; renderTags();
      addEntry(good.map(function (t) { return t.canon; }).join(" "), bad);
    }
    function renderAll() { renderGp(); renderTop(); renderFams(); renderList(); }

    /* ---- actions ---- */
    function addEntry(text, bad) {
      if (!ready) return;
      var g = curGp();
      if (!g) { status("Sync the eKYC / ABPS data first — the builder lists families from it.", "warn"); return; }
      var p = parseEntry(text, D.lastVillage);
      if (!p.items.length && !p.errors.length) return;
      var added = 0, miss = 0, ticked = 0, state = g.split("-")[0], gpMid = g.split("-").slice(1).join("-");
      var seen = {};
      // newest on top, in the order typed
      var fresh = [];
      p.items.forEach(function (it) {
        var key = norm((it.state || state) + "-" + (it.mid || gpMid) + "-" + it.v + "/" + it.h);
        if (seen[key]) return; seen[key] = 1;
        var list = members(key);
        if (!list.length) miss++;
        var label = pad(it.v, 3) + "/" + pad(it.h, 3);
        if (it.mid) label = (it.state ? it.state + "-" : "") + it.mid + "-" + label;
        fresh.push({ key: key, label: label });
        if (it.tick !== "none" && list.length) { var before = D.rows.length; tickFamily(key, it.tick); ticked += D.rows.length - before; }
        added++;
      });
      var keys = {}; fresh.forEach(function (f) { keys[f.key] = 1; });
      D.fams = fresh.concat(D.fams.filter(function (f) { return !keys[f.key]; })).slice(0, 300);
      if (hasVillage(p.lastVillage)) D.lastVillage = p.lastVillage;
      save(); renderAll();
      var msg = added ? added + " famil" + (added === 1 ? "y" : "ies") + " shown" + (ticked ? ", " + ticked + " worker(s) ticked" : "") + "." : "";
      if (miss) msg += " " + miss + " not found in the ABPS data.";
      if (bad && bad.length) msg += " Still to fix (red): " + bad.map(function (t) { return "\"" + t.raw + "\" (" + t.why + ")"; }).join("; ") + ".";
      status(msg.trim(), (miss || (bad && bad.length)) ? "warn" : "ok");
    }

    function exportRows() {
      var alloc = mode === "alloc";
      return outRows().map(function (r) {
        var o = { "Reg No": r.card, "Applicant": r.name, "Work From": eff(r, "from"), "No of Days": eff(r, "days") };
        if (alloc) o["Work Code"] = eff(r, "code");
        return o;
      });
    }
    function missingFields() {
      var n = 0; outRows().forEach(function (r) { if (!eff(r, "from") || !eff(r, "days") || (mode === "alloc" && !eff(r, "code"))) n++; });
      return n;
    }
    function doLoad() {
      if (!opts.onLoad || !outRows().length) return;
      var miss = missingFields();
      if (miss) { status(miss + " worker(s) have no Work From / No. of days" + (mode === "alloc" ? " / Work Code" : "") + " — fill them in first.", "warn"); return; }
      var res; try { res = opts.onLoad(exportRows()); } catch (e) { status("Could not load: " + (e && e.message ? e.message : e), "warn"); return; }
      if (res === false) return;                         // the panel refused (e.g. a run is active) and said why
      if (opts.onClose) opts.onClose();
    }
    function doXlsx() {
      if (!outRows().length) return;
      if (!window.XLSX) { status("The spreadsheet library isn't loaded — reload the page.", "warn"); return; }
      var alloc = mode === "alloc";
      var head = ["Reg No", "Applicant", "Work From", "No of Days"]; if (alloc) head.push("Work Code");
      var aoa = [head]; exportRows().forEach(function (o) { aoa.push(head.map(function (k) { return o[k]; })); });
      var ws = XLSX.utils.aoa_to_sheet(aoa), wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, alloc ? "Work Allocation" : "Work Demand");
      var m = meta[curGp()], gpc = String((m && m.code) || curGp() || "GP").replace(/[^\w\-]+/g, "_");
      var d = new Date(), name = "4A-list-" + gpc + "-" + pad2(d.getDate()) + "-" + pad2(d.getMonth() + 1) + "-" + d.getFullYear() + ".xlsx";
      XLSX.writeFile(wb, name);
      var miss = missingFields();
      status("Saved " + name + " — " + outRows().length + " worker(s)." + (miss ? " Note: " + miss + " row(s) have empty fields." : ""), miss ? "warn" : "ok");
    }
    function doClear() {
      if (!D.rows.length && !D.fams.length) return;
      if (D.rows.length && !confirm("Clear the list of " + D.rows.length + " worker(s)?")) return;
      D.rows = []; D.fams = []; save(); renderAll(); status("List cleared.", "ok"); R.entry.focus();
    }

    /* ---- wiring ---- */
    R.entry.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.ctrlKey && !e.metaKey) { e.preventDefault(); submitTags(); return; }
      var soft = e.key === " " || e.key === "," || e.key === ";";
      if ((e.key === "Tab" || soft) && !e.shiftKey && R.entry.value.trim()) { e.preventDefault(); makeTags(R.entry.value); R.entry.value = ""; return; }
      if (soft) { e.preventDefault(); return; }                     // nothing typed yet: ignore stray separators
      if (e.key === "Backspace" && !R.entry.value && tags.length) { e.preventDefault(); tags.pop(); renderTags(); }
    });
    // a pasted column / list becomes capsules straight away
    R.entry.addEventListener("paste", function (e) {
      var t = ""; try { t = (e.clipboardData || window.clipboardData).getData("text") || ""; } catch (x) {}
      if (!SEP_RE.test(t.trim())) return;
      e.preventDefault(); makeTags(R.entry.value + " " + t); R.entry.value = "";
    });
    R.tagbox.addEventListener("mousedown", function (e) { if (e.target === R.tagbox || e.target === R.tags) { e.preventDefault(); R.entry.focus(); } });
    R.tags.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("button.tx") : null; if (!b) return;
      tags.splice(+b.getAttribute("data-i"), 1); renderTags(); R.entry.focus();
    });
    [R.fe, R.fa].forEach(function (c) {
      c.addEventListener("change", function () { D.fe = R.fe.checked; D.fa = R.fa.checked; save(); renderFams(); renderList(); });
    });
    R.vsel.addEventListener("change", function () { D.lastVillage = +R.vsel.value || 0; save(); renderVillages(); R.entry.focus(); });
    R.add.addEventListener("click", function () { submitTags(); R.entry.focus(); });
    R.gpsel.addEventListener("change", function () { D.gp = R.gpsel.value; save(); renderAll(); });
    R.from.addEventListener("change", function () { D.from = isoToDMY(R.from.value); save(); renderList(); });
    R.days.addEventListener("input", function () { D.days = String(R.days.value || "").replace(/[^0-9]/g, ""); save(); renderList(); });
    R.code.addEventListener("input", function () { D.code = String(R.code.value || "").trim(); save(); renderList(); });
    R.hideall.addEventListener("click", function () { D.fams = []; save(); renderFams(); });
    R.load.addEventListener("click", doLoad);
    R.xlsx.addEventListener("click", doXlsx);
    R.clear.addEventListener("click", doClear);
    R.close.addEventListener("click", function () { if (opts.onClose) opts.onClose(); });
    box.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); doLoad(); }
      else if (e.key === "Escape" && opts.onClose) { e.preventDefault(); opts.onClose(); }
    });
    R.fams.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("button[data-a]") : null; if (!b) return;
      var k = b.getAttribute("data-k"), a = b.getAttribute("data-a");
      if (a === "hide") D.fams = D.fams.filter(function (f) { return f.key !== k; });
      else if (a === "all") {
        var list = members(k).filter(function (m) { return passes(D, m); }), all = list.length && list.every(function (m) { return hasRow(rowId(k, m)) >= 0; });
        tickFamily(k, all ? "none" : "all");
      } else if (a === "elig") tickFamily(k, "elig");
      save(); renderFams(); renderList();
    });
    R.fams.addEventListener("change", function (e) {
      var c = e.target; if (!c || c.getAttribute("data-a") !== "tog") return;
      var k = c.getAttribute("data-k"), idv = c.getAttribute("data-i");
      var a = members(k).filter(function (m) { return (m.app || m.name) === idv; })[0]; if (!a) return;
      if (c.checked) addRowFor(k, a); else removeRow(rowId(k, a));
      save(); renderFams(); renderList();
    });
    R.list.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("button[data-a='rm']") : null; if (!b) return;
      removeRow(b.getAttribute("data-id")); save(); renderFams(); renderList();
    });
    R.list.addEventListener("change", function (e) {
      var c = e.target; if (!c || c.getAttribute("data-a") !== "rf") return;
      var i = hasRow(c.getAttribute("data-id")); if (i < 0) return;
      var f = c.getAttribute("data-f"), r = D.rows[i];
      var v = f === "from" ? isoToDMY(c.value) : f === "days" ? String(c.value || "").replace(/[^0-9]/g, "") : String(c.value || "").trim();
      if (!v || v === D[f]) delete r[f]; else r[f] = v;     // same as the top value → follows the top value again
      save(); renderList();
    });
    // another surface (the tab page / another portal tab) changed the draft
    onDraftChange(function (nd) { if (nd.updatedAt && nd.updatedAt !== D.updatedAt) { D = nd; renderAll(); } });

    // load data + draft, then render
    loadDraft(function (d) {
      D = d;
      if (/\.dord\.gov\.in$/i.test(location.hostname) && D.origin !== location.origin) { D.origin = location.origin; }
      if (!D.from) D.from = todayDMY();
      DX.abpsLoad(function (m, mt) {
        map = m || {}; meta = mt || {}; ready = true;
        if (!meta[D.gp]) D.gp = curGp();
        save(); renderAll();
        try { R.entry.focus(); } catch (e) {}
      });
    });
    try { chrome.storage.onChanged.addListener(function (ch, area) { if (area === "local" && (ch.dxAbpsMap || ch.dxAbpsMeta)) DX.abpsLoad(function (m, mt) { map = m || {}; meta = mt || {}; renderAll(); }); }); } catch (e) {}

    return {
      el: box,
      setMode: function (m) { mode = m === "alloc" ? "alloc" : "demand"; renderAll(); },
      focus: function () { try { R.entry.focus(); } catch (e) {} },
      status: status
    };
  }

  /* ---------------------- modal (Demand / Allocation panels) ---------------------- */
  function open(opts) {
    opts = opts || {};
    var old = document.getElementById("gnlist-host"); if (old) old.remove();
    var host = document.createElement("div"); host.id = "gnlist-host";
    host.style.cssText = "position:fixed;inset:0;z-index:2147483647;";
    (document.body || document.documentElement).appendChild(host);
    var root = host.attachShadow({ mode: "open" });
    var css = document.createElement("style"); css.textContent = STYLE; root.appendChild(css); if (window.KD_applySkin) KD_applySkin(root);
    var ov = document.createElement("div"); ov.className = "ov"; root.appendChild(ov);
    function close() { try { host.remove(); } catch (e) {} if (opts.onClosed) opts.onClosed(); }
    ov.addEventListener("mousedown", function (e) { if (e.target === ov) close(); });
    var ctl = mount(ov, { mode: opts.mode, onLoad: opts.onLoad, onClose: close });
    ctl.close = close;
    return ctl;
  }

  window.GNList = { open: open, mount: mount, STYLE: STYLE, parseEntry: parseEntry, draftCount: draftCount, countOf: countOf, onDraftChange: onDraftChange };
})();
