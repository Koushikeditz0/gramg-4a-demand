/* =====================================================================
   drv-kit.js — MR Fill by Koushik · driver helpers (PAGE / MAIN world)
   Attendance আর Payment দুই driver-ই এটা ব্যবহার করে: সময় (portal Date ভেঙে রাখে, তাই
   performance.*), dialog override (confirm = OK, alert ধরে রাখা), run state, page helpers।
   কিছুই বাইরে পাঠায় না — সব কিছু portal-এর নিজের localStorage-এ থাকে।
   ===================================================================== */
(function () {
  "use strict";
  if (window.MRF_KIT) return;

  function nowMs() { try { return Math.round((performance.timeOrigin || 0) + performance.now()); } catch (e) { return 0; } }
  function sleep(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }
  function $(id) { return document.getElementById(id); }
  function byName(n) { return document.getElementsByName(n)[0] || null; }
  function norm(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  // today in India as yyyymmdd, without Date
  function todayIST() {
    var t = Math.floor((nowMs() + 19800000) / 86400000), z = t + 719468, era = Math.floor(z / 146097), doe = z - era * 146097;
    var yoe = Math.floor((doe - Math.floor(doe / 1460) + Math.floor(doe / 36524) - Math.floor(doe / 146096)) / 365);
    var doy = doe - (365 * yoe + Math.floor(yoe / 4) - Math.floor(yoe / 100)), mp = Math.floor((5 * doy + 2) / 153);
    var d = doy - Math.floor((153 * mp + 2) / 5) + 1, m = mp < 10 ? mp + 3 : mp - 9, y = yoe + era * 400 + (m <= 2 ? 1 : 0);
    return y * 10000 + m * 100 + d;
  }
  function dmyNum(s) { var m = /^\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\s*$/.exec(String(s || "")); return m ? (+m[3]) * 10000 + (+m[2]) * 100 + (+m[1]) : 0; }
  function spd() { try { var v = parseFloat(localStorage.getItem("mrf_speed")); if (v >= 0.5 && v <= 4) return v; } catch (e) {} return 1; }

  // ns: "mrfa" (attendance) or "mrfp" (payment)
  window.MRF_KIT = function (ns) {
    var LS_RUN = ns + "_run", LS_ALERT = ns + "_lastAlert", SRC = ns.toUpperCase() + "_DRV";
    var origAlert = window.alert, origConfirm = window.confirm, overridden = false;
    var K = {
      nowMs: nowMs, sleep: sleep, $: $, byName: byName, norm: norm, todayIST: todayIST, dmyNum: dmyNum,
      pace: function () { return Math.round(400 * spd()); },
      overrideDialogs: function () {
        if (overridden) return; overridden = true;
        window.alert = function (m) {
          try {
            var prev = JSON.parse(localStorage.getItem(LS_ALERT) || "null"), msg = String(m == null ? "" : m);
            localStorage.setItem(LS_ALERT, JSON.stringify({ t: nowMs(), msg: prev && prev.msg ? prev.msg + " | " + msg : msg }));
          } catch (e) {}
        };
        window.confirm = function () { return true; };
      },
      restoreDialogs: function () { if (!overridden) return; overridden = false; window.alert = origAlert; window.confirm = origConfirm; },
      takeAlert: function () { try { var a = JSON.parse(localStorage.getItem(LS_ALERT) || "null"); localStorage.removeItem(LS_ALERT); return a ? a.msg : ""; } catch (e) { return ""; } },
      loadRun: function () { try { return JSON.parse(localStorage.getItem(LS_RUN) || "null"); } catch (e) { return null; } },
      saveRun: function (r) { try { r.updatedAt = nowMs(); localStorage.setItem(LS_RUN, JSON.stringify(r)); } catch (e) {} try { window.postMessage({ source: SRC, type: "sync" }, "*"); } catch (e) {} },
      log: function (r, level, text) { (r.log = r.log || []).push({ t: nowMs(), level: level, text: text }); if (r.log.length > 3000) r.log = r.log.slice(-3000); },
      // off-guard (isolated world) "0" লিখলে তবেই চলে
      modOff: function () { try { return localStorage.getItem(ns + "_off") !== "0"; } catch (e) { return true; } },
      loggedOut: function () { return !$("ddlWorkCode"); },
      loginPage: function () { return !!document.querySelector("input[type=password]"); },
      // v1.9.7: postback-এর পরে page ধীরে বা আধখানা load হলে ddlWorkCode দেরিতে আসে — একটু অপেক্ষা
      waitForm: async function (ms) { var w = 0; while (w < ms && K.loggedOut() && !K.loginPage()) { await sleep(500); w += 500; } return !K.loggedOut(); },
      portalMsg: function () {
        return ["lblError", "lblmsg", "lblMsg", "acclosemsg"].map(function (id) { var e = $(id); return e ? norm(e.innerText || e.textContent) : ""; }).filter(Boolean).join(" | ");
      },
      msrOptions: function () {
        var s = $("ddlMsrNo"); if (!s) return [];
        return [].filter.call(s.options, function (o) { return o.value && o.value !== "0" && !/select/i.test(o.text); }).map(function (o) { return o.value; });
      },
      // fire the dropdown's own onchange (setTimeout('__doPostBack(…)')) — a full reload
      choose: function (id, value) {
        var s = $(id); if (!s) return false;
        s.value = value; if (s.value !== value) return false;
        s.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      },
      tooManyTries: function (r, key) {
        if (r.selKey === key) r.selTries = (r.selTries || 0) + 1; else { r.selKey = key; r.selTries = 1; }
        return r.selTries > 3;
      },
      // an MR No from the Excel → the dropdown's value (matches value or the option's text, as a whole number)
      findMsr: function (mr) {
        var s = $("ddlMsrNo"); if (!s) return "";
        var want = String(mr).replace(/^0+/, ""), o = [].filter.call(s.options, function (x) {
          return x.value && x.value !== "0" && (String(x.value).trim().replace(/^0+/, "") === want || String(x.text).trim().replace(/^0+/, "") === want || new RegExp("(^|\\D)0*" + want + "(\\D|$)").test(x.text));
        })[0];
        return o ? o.value : "";
      },
      formNum: function (name) { var e = byName(name); var v = e ? parseInt(e.value, 10) : NaN; return isNaN(v) ? 0 : v; },
      saveButton: function () {
        var b = [].filter.call(document.querySelectorAll("input[type=submit],input[type=button],button"), function (x) { return /promp\s*\(/.test(x.getAttribute("onclick") || ""); })[0];
        return b || $("btnsave") || $("btnSave") || null;
      },
      pageText: function () { return norm(document.body && (document.body.innerText || document.body.textContent)).slice(0, 6000); },
      // Programme Officer login: one Panchayat per run
      gpProblem: function (r) {
        var s = document.querySelector("select[id$='ddlPanchayat']"); if (!s || ![].some.call(s.options, function (o) { return String(o.value || "").replace(/\D/g, "").length >= 10; })) return "";
        var o = s.selectedIndex >= 0 ? s.options[s.selectedIndex] : null;
        var v = o ? String(o.value || "").replace(/\D/g, "") : "", name = o ? norm(o.text) : "";
        var picked = v.length >= 10 && !!name && !/select/i.test(name);
        var g = r.gp, label = g ? (g.name || g.gp10) : "this run's Panchayat";
        if (!picked) return "Pick the Panchayat " + label + " in the form, then press Resume.";
        if (g && g.gp10.slice(4) !== v.slice(4, 10)) return "This run is for " + label + ", but the form shows " + name + ". Pick " + label + ", then press Resume.";
        return "";
      },
      /* v1.9.6 (K-Desk, Payment; v1.9.9 Attendance-ও): যে MR আটকে যায় (খুলছে না, Save হয়নি, safety check, amount target মেলেনি)
         সেটা এখন run থামায় না — "Retry later" হয়ে পরে যায়; সব work শেষ হলে সেগুলো আর একবার চলে (pass 2)।
         "not found"-ধরনের skip (MR/work page-এ নেই, MB নেই, period not over, already entered) আর চলে না। */
      retryOnce: false,
      canDefer: function (r) { return !!K.retryOnce && r.pass !== 2; },
      defer: function (r, info, why) {
        K.result(r, info, "Retry later", why);
        (r.retryQ = r.retryQ || []).push({ work: info.work, msr: info.msr });
        K.log(r, "warn", info.work + " · MR " + info.msr + ": আপাতত skip, শেষে আবার চেষ্টা হবে — " + why);
      },
      result: function (r, info, res, msg) {
        (r.results = r.results || []).push({ t: nowMs(), work: info.work, msr: info.msr, from: info.from || "", to: info.to || "", workers: info.workers || 0, detail: info.detail || "", pres: info.pres || "", result: res, msg: msg || "" });
        var s = r.stats = r.stats || { saved: 0, skipped: 0, notSaved: 0, errors: 0 };
        if (res === "Saved" || res === "Would save (test)") s.saved++; else if (res === "Skipped") s.skipped++; else if (res === "Not saved") s.notSaved++;
        else if (res === "Manual" || res === "Would pause (test)") s.manual = (s.manual || 0) + 1;
        else if (res === "Retry later") s.later = (s.later || 0) + 1; else s.errors++;
        (r.done = r.done || {})[info.work + "|" + info.msr] = 1;
      },
      /* The shared run loop. For every ticked work, every muster roll in its list not done yet:
         open it (each selection is a full reload, so the loop resumes on the next load), then
         opt.process(r, work, msr) fills it and returns "saving" after pressing Save, or records
         a result itself. opt.onSaved(r, info, ok) runs after the Save reload. */
      makeLoop: function (opt) {
        var OK_RE = /success|saved|updated/i, ERR_RE = /error|fail|not\s+(been\s+)?saved|unable|invalid|cannot|already|exceed/i;
        var BRAKE = 5, NAV_WAIT = 120000;
        if (opt.retryOnce) K.retryOnce = true;
        function resolveSave(r) {
          var s = r.saving; r.saving = null;
          var text = [K.takeAlert(), K.portalMsg()].filter(Boolean).join(" | ");
          var ok = OK_RE.test(text) && !ERR_RE.test(text);
          if (!text) {
            // v1.10.0: portal কোনো message দেয়নি (page ধীরে/আধখানা এসেছে) — Save হয়েছে কিনা, work আবার খুলে MR list দেখে ঠিক করা হবে
            r.verify = s; K.log(r, "warn", s.work + " · MR " + s.msr + ": portal কোনো message দেয়নি — Save হয়েছে কিনা MR list দেখে মিলিয়ে নিচ্ছি…");
            K.saveRun(r); return;
          }
          if (!ok && K.canDefer(r)) K.defer(r, s, "NOT saved — " + (text || "no message from the portal"));
          else {
            K.result(r, s, ok ? "Saved" : "Not saved", text || "no message from the portal — check this muster roll on the portal");
            K.log(r, ok ? "ok" : "err", s.work + " · MR " + s.msr + ": " + (ok ? "saved" : "NOT saved") + " — " + (text || "no message from the portal"));
          }
          r.consec = ok ? 0 : (r.consec || 0) + 1;
          if (opt.onSaved) opt.onSaved(r, s, ok);
          K.saveRun(r);
        }
        return async function runLoop() {
          var r = K.loadRun(); if (!r || !r.active) { K.restoreDialogs(); return; }
          K.overrideDialogs();
          await sleep(300);                                        // the page's own load-time alerts land first
          await K.waitForm(15000);
          r = K.loadRun(); if (!r || !r.active) { K.restoreDialogs(); return; }
          if (r.saving) { resolveSave(r); r = K.loadRun(); }
          else { var stray = K.takeAlert(); if (stray) { K.log(r, "info", "Portal: " + stray); K.saveRun(r); } }

          while (true) {
            if (K.modOff()) return;
            r = K.loadRun(); if (!r) { K.restoreDialogs(); return; }
            if (r.stopRequested || !r.active) { if (r.stopRequested) { r.active = false; r.stopRequested = false; r.current = ""; K.log(r, "warn", "Stopped by user."); K.saveRun(r); } K.restoreDialogs(); return; }
            if (K.loggedOut() && !(await K.waitForm(3000))) {
              // v1.9.7: আসলে logout না হলে (login page নেই) page নিজে আবার খোলে, ৩ বার পর্যন্ত — আগে এখানে run থেমে যেত, Resume চাপলেই চলত
              r = K.loadRun(); if (!r || !r.active || r.stopRequested) continue;
              if (!K.loginPage() && (r.lostTries || 0) < 3) {
                r.lostTries = (r.lostTries || 0) + 1;
                K.log(r, "warn", "Page ঠিকমত load হয়নি — আবার খোলা হচ্ছে (" + r.lostTries + "/3)…"); K.saveRun(r);
                location.href = location.href.split("#")[0];
                await sleep(NAV_WAIT); return;
              }
              r.active = false; r.lostTries = 0; K.log(r, "err", "The page closed or the session expired — log in, open the page from the menu and press Resume."); K.saveRun(r); K.restoreDialogs(); return;
            }
            if (r.lostTries) { r.lostTries = 0; K.saveRun(r); }
            if ((r.consec || 0) >= BRAKE) { r.active = false; K.log(r, "err", "Stopped: " + BRAKE + " muster rolls in a row were not saved. Check the page, then Resume."); K.saveRun(r); K.restoreDialogs(); return; }
            var gpw = K.gpProblem(r);
            if (gpw) { r.active = false; r.current = ""; K.log(r, "err", "Paused — " + gpw); K.saveRun(r); K.restoreDialogs(); return; }

            var work = (r.works || [])[r.wi];
            if (!work && K.canDefer(r) && r.retryQ && r.retryQ.length) {
              // pass 2: শুধু আটকে যাওয়া MR-গুলো, আর একবার
              var only = {}, order = [];
              r.retryQ.forEach(function (q) {
                if (!(q.work in only)) { only[q.work] = []; order.push(q.work); }
                if (q.msr === "—") only[q.work] = null;                  // পুরো work খোলেনি: আবার পুরো work
                else { if (only[q.work]) only[q.work].push(q.msr); if (r.done) delete r.done[q.work + "|" + q.msr]; }
              });
              K.log(r, "info", "প্রথম দফা শেষ। আটকে যাওয়া " + r.retryQ.length + "টা MR (" + order.length + "টা work) আর একবার চালানো হচ্ছে…");
              r.pass = 2; r.retryOnly = only; r.works = order; r.wi = 0; r.retryQ = []; r.consec = 0; r.selKey = null; r.selTries = 0;
              K.saveRun(r); continue;
            }
            if (!work) { r.active = false; r.finishedAt = nowMs(); r.current = ""; K.log(r, "ok", "Finished all works."); K.saveRun(r); K.restoreDialogs(); return; }

            // 1. the work
            if (norm($("ddlWorkCode").value) !== work) {
              if (K.tooManyTries(r, "W" + work)) {
                if (K.canDefer(r)) K.defer(r, { work: work, msr: "—" }, "work would not open");
                else K.log(r, "err", "Work " + work + " would not open — skipped.");
                r.wi++; K.saveRun(r); continue;
              }
              r.current = "opening " + work; K.log(r, "info", "Work " + (r.wi + 1) + "/" + r.works.length + ": " + work); K.saveRun(r);
              if (!K.choose("ddlWorkCode", work)) { r = K.loadRun(); K.log(r, "warn", "Work " + work + " is no longer in the list — skipped."); K.result(r, { work: work, msr: "—" }, "Skipped", "work no longer in the page's list"); r.wi++; K.saveRun(r); continue; }
              await sleep(NAV_WAIT); return;                       // full reload → resumes on the next load
            }

            // 1b. message ছাড়া Save: MR আর list-এ না থাকলে Save হয়ে গেছে; থাকলে Save হয়নি
            if (r.verify && r.verify.work === work) {
              var v = r.verify, still = !!K.findMsr(v.msr); r.verify = null;
              if (!still) {
                K.result(r, v, "Saved", "portal gave no message, but this MR is no longer in the work's muster roll list — the Save went through");
                K.log(r, "ok", work + " · MR " + v.msr + ": saved (MR আর list-এ নেই, তাই Save হয়ে গেছে)");
                r.consec = 0; if (opt.onSaved) opt.onSaved(r, v, true);
              } else if (K.canDefer(r)) { K.defer(r, v, "NOT saved — no message from the portal and the MR is still in the list"); r.consec = (r.consec || 0) + 1; }
              else { K.result(r, v, "Not saved", "no message from the portal and the MR is still in the list — check this muster roll on the portal"); K.log(r, "err", work + " · MR " + v.msr + ": NOT saved — MR এখনো list-এ আছে"); r.consec = (r.consec || 0) + 1; }
              K.saveRun(r); continue;
            }
            if (r.verify) { var v2 = r.verify; r.verify = null; K.result(r, v2, "Not saved", "no message from the portal — check this muster roll on the portal"); K.saveRun(r); }

            // 2. its next muster roll not done yet (v1.5.0: only the MR Nos from the Excel, when it gave them)
            var done = r.done || {}, opts = K.msrOptions(), next = null, want = (r.pass === 2 && r.retryOnly && r.retryOnly[work]) || (r.mrMap || {})[work];
            if (want && want.length) {
              var missing = false;
              for (var q = 0; q < want.length; q++) {
                if (done[work + "|" + want[q]]) continue;
                var hit = K.findMsr(want[q]);
                if (!hit) { K.result(r, { work: work, msr: want[q] }, "Skipped", r.pass === 2 ? "MR No " + want[q] + " is no longer in this work's list — the earlier Save probably went through (the portal gave no message); check it on the portal" : "MR No " + want[q] + " (from the Excel) is not in this work's muster roll list on the page"); K.log(r, "warn", work + " · MR " + want[q] + ": not in this work's list — skipped"); missing = true; continue; }
                if (hit !== want[q]) { want[q] = hit; if (done[work + "|" + hit]) continue; }
                next = hit;
                break;
              }
              if (missing) K.saveRun(r);
              opts = want;
            } else for (var i = 0; i < opts.length; i++) if (!done[work + "|" + opts[i]]) { next = opts[i]; break; }
            if (!next) {
              K.log(r, "ok", work + ": done (" + opts.length + " muster roll(s) listed).");
              if (!opts.length && !Object.keys(done).some(function (k) { return k.indexOf(work + "|") === 0; })) K.result(r, { work: work, msr: "—" }, "Skipped", "no muster roll listed for this work");
              r.wi++; r.current = ""; K.saveRun(r); continue;
            }

            // 3. open it
            if (norm($("ddlMsrNo").value) !== next) {
              if (K.tooManyTries(r, "M" + work + "|" + next)) {
                if (K.canDefer(r)) K.defer(r, { work: work, msr: next }, "this muster roll would not open");
                else { K.result(r, { work: work, msr: next }, "Error", "this muster roll would not open"); r.consec = (r.consec || 0) + 1; }
                K.saveRun(r); continue;
              }
              r.current = work + " · MR " + next; K.saveRun(r);
              if (!K.choose("ddlMsrNo", next)) { r = K.loadRun(); K.result(r, { work: work, msr: next }, "Error", "could not select this muster roll"); K.saveRun(r); continue; }
              await sleep(NAV_WAIT); return;
            }

            // 4. fill it, or skip with the reason
            r.current = work + " · MR " + next;
            var pr = opt.process(r, work, next);
            if (pr === "saving") { await sleep(NAV_WAIT); return; }
            if (pr === "paused") return;                            // user fixes this MR by hand, then Resume
            await sleep(K.pace());
          }
        };
      },
      // the driver's process() calls this to press Save (promp(): confirm answered OK → full reload)
      pressSave: function (r, info, what) {
        r.saving = info; r.selKey = null;
        K.log(r, "info", info.work + " · MR " + info.msr + ": saving — " + what + "…");
        K.saveRun(r); K.takeAlert();
        K.saveButton().click();
        return "saving";
      },
      // run loop wiring: kick on start message, every second while active, and once after the off-guard had time to write
      boot: function (runLoop) {
        var busy = false;
        function kick() {
          if (K.modOff() || busy) return;
          var r = K.loadRun(); if (!r || !r.active) return;
          busy = true;
          Promise.resolve().then(runLoop).then(function () { busy = false; }, function (e) {
            busy = false;
            var rr = K.loadRun(); if (rr && rr.active) { rr.active = false; K.log(rr, "err", "Stopped by an error: " + (e && e.message ? e.message : e) + ". Press Resume."); K.saveRun(rr); }
            K.restoreDialogs();
          });
        }
        var r0 = K.loadRun();
        if (r0 && r0.active) K.overrideDialogs();                 // before the portal's post-save alert
        window.addEventListener("message", function (ev) {
          if (!ev.data || ev.data.source !== ns.toUpperCase() + "_UI") return;
          if (ev.data.type === "start") { K.overrideDialogs(); kick(); }
          else if (ev.data.type === "stop") { var rr = K.loadRun(); if (rr) { rr.stopRequested = true; K.saveRun(rr); } }
        });
        setInterval(function () { var rr = K.loadRun(); if (rr && rr.active && !rr.stopRequested) kick(); }, 1000);
        setTimeout(kick, 1500);
      }
    };
    return K;
  };
})();
