/* =====================================================================
   portal-map.js — K-Desk Suite by Koushik · Portal Map (v1.25.0)

   Portal-এর সব page path আর field ID এক জায়গায়। শুধু DATA — কোনো code চলে না।
   Portal কোনো field-এর ID বদলালে এখানে সেই field-এর "id" বদলালেই হবে
   (README_BN.md → "Portal বদলালে কী করবেন")। পরের version-এ এই map
   Gram Setu (Supabase) থেকেও আসবে, তখন extension আবার বানাতে হবে না।

   এই ফাইল দুই world-এই load হয় (MAIN driver আর isolated panel), তাই এখানে
   chrome.* বা Date ব্যবহার নেই (portal page নিজের Date বদলে রাখে)।

   Field-এর ঘর:
     id     portal-এর ID (prefix ছাড়া)। একাধিক নাম হলে array, প্রথমটা আসল।
     raw    true = prefix লাগে না (MR Fill-এর পুরোনো ধাঁচের page)
     by     "name" = name="…" দিয়ে খোঁজা (id নয়)
     bn     Health Check-এ দেখানো বাংলা নাম
     start  true = Start চাপার সময় page-এ থাকতেই হবে, না থাকলে Start হবে না
     label  (ঐচ্ছিক) portal-এ field-এর পাশে লেখা — ID না মিললে কাছাকাছি field খুঁজতে
   rows: grid-এর প্রতিটা row-এর field। anchor দিয়ে প্রথম row খোঁজা হয়, তারপর
     সেই row-এর prefix + suffix। need true = row থাকলে এই field থাকতেই হবে।
   ===================================================================== */
(function () {
  "use strict";
  if (window.KD_MAP) return;

  var MAP = {
    mapVersion: "1.25.0-bundled",
    prefix: { id: "ctl00_ContentPlaceHolder1_", name: "ctl00$ContentPlaceHolder1$" },
    pages: {
      demand: {
        bn: "Work Demand", path: /\/demand_new\.aspx$/i, feature: "demand",
        fields: {
          village: { id: "DDL_Village", bn: "Village dropdown", start: true, label: "Village" },
          reg: { id: "DDL_Registration", bn: "Registration (Job Card) dropdown", label: "Registration" },
          grid: { id: "gvData", bn: "Worker grid (gvData)" },
          proceed: { id: "btnProceed", bn: "Proceed বোতাম" }
        },
        rows: {
          grid: "grid", anchor: "_job", bn: "worker row",
          fields: {
            job: { suffix: "_job", bn: "Worker-এর নাম", need: true },
            app: { suffix: "_dt_app", bn: "Date of Application box", need: true },
            from: { suffix: "_dt_from", bn: "Work From box", need: true },
            days: { suffix: "_d3", bn: "দিনের সংখ্যা box", need: true },
            to: { suffix: "_dt_to", bn: "Work To box", need: true },
            aadhaar: { suffix: "_Is_Aadhaar_Auth", bn: "Aadhaar flag" }
          }
        }
      },
      allocation: {
        bn: "Work Allocation", path: /\/workalloc\.aspx$/i, feature: "allocation",
        fields: {
          cat: { id: "ddlworkcategory", bn: "Work Category dropdown", start: true, label: "Category" },
          search: { id: "txtwrksearchkey", bn: "Work search box" },
          work: { id: "ddlWork_code", bn: "Work Code dropdown", label: "Work" },
          grid: { id: "GridView1", bn: "Applicant grid (GridView1)" },
          save: { id: "cmdSave", bn: "Save বোতাম" }
        },
        rows: {
          grid: "grid", anchor: "_chkAllocate", bn: "applicant row",
          fields: {
            chk: { suffix: "_chkAllocate", bn: "Allocate tick", need: true },
            dfrom: { suffix: "_txtDemandFrom", bn: "Demand From" },
            from: { suffix: "_txtAllocFrom", bn: "Allocation From box", need: true },
            days: { suffix: "_txtWorkBalDays", bn: "Allocation দিন box", need: true },
            to: { suffix: "_txtAllocTo", bn: "Allocation To box", need: true }
          }
        }
      },
      sendpay: {
        bn: "Send Wagelist for Payment", path: /\/sendforpay\.aspx$/i, feature: "sendpay",
        fields: {
          fy: { id: "ddlfin", bn: "Financial Year dropdown", start: true, label: "Financial Year" },
          wl: { id: "ddl_sel", bn: "Wagelist No. dropdown", label: "Wagelist" },
          send: { id: "btnsubmit", bn: "Send Wagelist For Payment বোতাম" }
        },
        rows: {
          grid: null, anchorSel: "input[type=radio][id*='GridView1_'][id*='rdbPayment']", anchorRe: /^(.*GridView1_ctl\d+)_/, bn: "agency row",
          fields: {
            code: { suffix: "_Lbl_wg_ag_code", bn: "Agency code", need: true },
            amt: { suffix: "_txt_chk_amt", bn: "Amount", need: true }
          }
        }
      },
      wagegen: {
        bn: "Generate Wagelist", path: /\/sendmsrtopo\.aspx$/i, feature: "wlgen",
        fields: {
          agency: { id: "exe_agency", bn: "Agency (Panchayat) dropdown", start: true, label: "Agency" },
          fy: { id: "ddlstFinyear", bn: "Financial Year dropdown" },
          from: { id: "wgfromdt", bn: "From date" },
          to: { id: "wgtodt", bn: "To date" },
          go: { id: "go", bn: "Proceed বোতাম" },
          list: { id: "wagelist_msr", bn: "Work list table" },
          view: { id: "btn_go", bn: "View Wagelist বোতাম" },
          msg: { id: "lblmsg", bn: "Portal message" }
        }
      },
      bank: {
        bn: "Bank A/c Update", path: /\/editappbank\.aspx$/i, feature: "bank",
        fields: {
          bank: { id: "ddlBankCodeName", bn: "Bank dropdown", start: true, label: "Bank" },
          ifsc: { id: "txtifsc", bn: "IFSC box", start: true, label: "IFSC" },
          ifscGo: { id: "ImageButton1", bn: "IFSC search বোতাম" },
          branch: { id: "ddlBrCodeName", bn: "Branch dropdown", label: "Branch" },
          jc: { id: "jcr_srch_key", bn: "Job Card search box", start: true },
          jcGo: { id: "ImgbtnSearch", bn: "Job Card search বোতাম", start: true },
          grid: { id: "grdData", bn: "Worker grid (grdData)" },
          update: { id: "BtnUpdate", bn: "Update বোতাম" }
        },
        rows: {
          grid: "grid", anchor: "_HF_Reg_No", bn: "worker row",
          fields: {
            app: { suffix: "_HF_Applicant_no", bn: "Applicant No", need: true },
            chk: { suffix: "_input_chkRowEdit", bn: "Edit tick", need: true },
            ac: { suffix: "_txtAcNo", bn: "Account No box", need: true },
            ac2: { suffix: "_txtAcNo1", bn: "Account No (আবার) box", need: true },
            holder: { suffix: "_txtApp_Name_BankPO", bn: "Account holder name box" }
          }
        }
      },
      mrattend: {
        bn: "Fill Attendance only", path: /\/mustrollattend\.aspx$/i, feature: "mrattend",
        fields: {
          work: { id: "ddlWorkCode", raw: true, bn: "Work Code dropdown", start: true, label: "Work Code" },
          msr: { id: "ddlMsrNo", raw: true, bn: "Muster Roll No dropdown", start: true, label: "Muster Roll" },
          from: { id: "txtDatefrm", raw: true, bn: "MR From date" },
          to: { id: "txtDateTo", raw: true, bn: "MR To date" },
          wstart: { id: "txtWrkStartDate", raw: true, bn: "Work Start Date box" },
          zero: { id: "chk_zeroAtt", raw: true, bn: "Zero attendance tick" },
          save: { id: ["btnsave", "btnSave"], raw: true, bn: "Save বোতাম" },
          rows: { id: "totrecord", raw: true, by: "name", bn: "Worker সংখ্যা (totrecord)" },
          cols: { id: "colcnt", raw: true, by: "name", bn: "দিনের সংখ্যা (colcnt)" },
          all1: { id: "All1", raw: true, by: "name", bn: "প্রথম worker-এর tick (All1)" },
          day1: { id: "c1_1", raw: true, by: "name", bn: "প্রথম worker-এর দিন ১ (c1_1)" }
        }
      },
      mrpay: {
        bn: "Payment only", path: /\/msrpayment\.aspx$/i, feature: "mrpay",
        fields: {
          work: { id: "ddlWorkCode", raw: true, bn: "Work Code dropdown", start: true, label: "Work Code" },
          msr: { id: "ddlMsrNo", raw: true, bn: "Muster Roll No dropdown", start: true, label: "Muster Roll" },
          from: { id: "lblDateFrom", raw: true, bn: "MR From date" },
          to: { id: "lblDateTo", raw: true, bn: "MR To date" },
          rate: { id: "lblWageRate", raw: true, bn: "Wage rate" },
          wst: { id: "txtWrkStDate", raw: true, bn: "Work start date" },
          mb: { id: "mb_no_txt", raw: true, bn: "Measurement Book No box" },
          page: { id: "page_no_txt", raw: true, bn: "Page No box" },
          save: { id: ["btnSave", "btnsave"], raw: true, bn: "Save বোতাম" },
          rows: { id: "totrecord", raw: true, by: "name", bn: "Worker সংখ্যা (totrecord)" },
          minw: { id: "min_wage", raw: true, by: "name", bn: "Minimum wage (min_wage)" },
          wage1: { id: "wage_per_day1", raw: true, by: "name", bn: "প্রথম worker-এর Wage Per Day" },
          att1: { id: "totAtt1", raw: true, by: "name", bn: "প্রথম worker-এর মোট দিন" },
          amt1: { id: "APATA1", raw: true, by: "name", bn: "প্রথম worker-এর Amount" },
          tc1: { id: "TCA1", raw: true, by: "name", bn: "প্রথম worker-এর Total Cash" }
        }
      },
      abps: {
        bn: "ABPS Sync (AppABPSRpt)", path: /\/appabpsrpt\.aspx$/i, feature: "abps",
        fields: {
          village: { id: "DDL_Village", bn: "Village dropdown", start: true, label: "Village" },
          active: { id: "rdbtn_IsActive", by: "name", bn: "Active / All Workers বিকল্প", start: true },
          fresh: { id: "chbx_freshCase", by: "name", bn: "Fresh case tick", start: true },
          rgno: { id: "rdbtn_rgno_familyid", by: "name", bn: "Reg No / Family ID বিকল্প", start: true },
          link: { id: "LinkButton1", bn: "Show (LinkButton1) বোতাম" },
          grid: { id: "gvData", bn: "Worker table (gvData)" }
        }
      },
      npci: {
        bn: "NPCI Check (VUID_NPCI)", path: /\/vuid_npci\.aspx$/i, feature: "npci",
        fields: {
          village: { id: "DDL_Village", bn: "Village dropdown", start: true, label: "Village" },
          grid: { id: "gvData", bn: "Worker grid (gvData)" },
          save: { id: "btnProceed2", bn: "Save Records of this page বোতাম" }
        },
        rows: {
          grid: "grid", anchor: "_lbl_jobcardno", bn: "worker row",
          fields: {
            jc: { suffix: "_lbl_jobcardno", bn: "Job Card No", need: true },
            reg: { suffix: "_Reg_No", bn: "Reg No (hidden)" },
            app: { suffix: "_applicant_no", bn: "Applicant No (hidden)" },
            name: { suffix: "_applicant_name", bn: "Worker-এর নাম" },
            aname: { suffix: "_txtName_as_per_Aadhar", bn: "Aadhaar অনুযায়ী নাম" },
            show: { suffix: "_btn_showuid", bn: "Show Aadhaar Number বোতাম" },
            verify: { suffix: "_btn_verifyuid", bn: "Check with NPCI বোতাম" },
            msg: { suffix: "_lbl_msg", bn: "ফলাফল লেখা (lbl_msg)" }
          }
        }
      },
      pension: {
        bn: "Pension Scheme (Account Sync / Readiness)", path: /\/pension_scheme\.aspx$/i, feature: "acsync",
        fields: {
          village: { id: "ddlVillage", bn: "Village dropdown", start: true, label: "Village" },
          reg: { id: "ddlReg", bn: "Registration (Job Card) dropdown", label: "Registration" },
          grid: { id: "grdData", bn: "Worker table (grdData)" }
        },
        rows: {
          grid: "grid", anchor: "_lblappNo", bn: "worker row",
          fields: {
            app: { suffix: "_lblappNo", bn: "Applicant No / নাম", need: true },
            bank: { suffix: "_lblbankDtl", bn: "Bank details (A/c, IFSC)", need: true },
            hf: { suffix: "_HiddenField1", bn: "Hidden Job Card field" }
          }
        }
      },
      mrprint: {
        bn: "MR Reprint (MR Batch Print)", path: /\/reprintmsr\.aspx$/i, feature: "mr",
        fields: {
          skill: { id: "ssk", raw: true, by: "name", bn: "Unskilled / Skilled বিকল্প (ssk)" },
          search: { id: "txtWork", raw: true, bn: "Work search box", start: true },
          searchGo: { id: "imgButtonSearch", raw: true, bn: "Work search বোতাম", start: true },
          work: { id: "ddlworkcode", raw: true, bn: "Work Code dropdown" },
          msr: { id: "ddlmsrno", raw: true, bn: "MR No dropdown" },
          proceed: { id: "btnproceed", raw: true, bn: "Proceed বোতাম" }
        }
      },
      wlview: {
        bn: "View Wagelist (WL Status / Caste / Export)", path: /\/view_wagelist\.aspx$/i, feature: "wls",
        fields: {
          wl: { id: ["ddl_sel", "ctl00_ContentPlaceHolder1_ddl_sel"], raw: true, bn: "Wagelist No. dropdown", start: true, label: "Wagelist" },
          fy: { id: ["ddlFinYr", "ctl00_ContentPlaceHolder1_ddlFinYr"], raw: true, bn: "Financial Year dropdown", label: "Financial Year" }
        }
      },
      mate: {
        bn: "Mate Mapping (Mate sync)", path: /\/matemapping\.aspx$/i, feature: "msync",
        fields: {
          mate: { id: "ddl_mate", bn: "Mate dropdown", start: true, label: "Mate" }
        }
      },
      cert: {
        bn: "Work Entry (Certificate Auto-Fill)", path: /\/work_entry(_edit)?\.aspx$/i, feature: "cert",
        fields: {
          c1file: { id: "File_pre_estimation_file_name", bn: "Certificate ১ (Pre-estimation / Feasibility) · PDF file", start: true },
          c1name: { id: "txtpre_estimation_person_name", bn: "Certificate ১ · Name box", start: true },
          c1desig: { id: "txtpre_estimation_designation", bn: "Certificate ১ · Designation box", start: true },
          c1dept: { id: "txtpre_estimation_department", bn: "Certificate ১ · Department box", start: true },
          c1mob: { id: "txtpre_estimation_mobile", bn: "Certificate ১ · Mobile box", start: true },
          c1email: { id: "txtpre_estimation_emailid", bn: "Certificate ১ · Email box", start: true },
          c2file: { id: "File_double_wrks_file_name", bn: "Certificate ২ (No duplication (BDO)) · PDF file", start: true },
          c2name: { id: "txtdouble_wrks_person_name", bn: "Certificate ২ · Name box", start: true },
          c2desig: { id: "txtdouble_wrks_designation", bn: "Certificate ২ · Designation box", start: true },
          c2dept: { id: "txtdouble_wrks_department", bn: "Certificate ২ · Department box", start: true },
          c2mob: { id: "txtdouble_wrks_mobile", bn: "Certificate ২ · Mobile box", start: true },
          c2email: { id: "txtdouble_wrks_emailid", bn: "Certificate ২ · Email box", start: true },
          c3file: { id: "File_spliting_wrk_fie_name", bn: "Certificate ৩ (Non-splitting (BDO)) · PDF file", start: true },
          c3name: { id: "non_spliting_person_name", bn: "Certificate ৩ · Name box", start: true },
          c3desig: { id: "txtnon_spliting_wrk_designation", bn: "Certificate ৩ · Designation box", start: true },
          c3dept: { id: "txtnon_spliting_wrks_department", bn: "Certificate ৩ · Department box", start: true },
          c3mob: { id: "txtnon_spliting_wrks_Mobile", bn: "Certificate ৩ · Mobile box", start: true },
          c3email: { id: "txtnon_spliting_wrk_Email", bn: "Certificate ৩ · Email box", start: true },
          c4file: { id: "File_permissible_wrk", bn: "Certificate ৪ (Permissible category (BDO)) · PDF file", start: true },
          c4name: { id: "txtpermissible_wrk_person_name", bn: "Certificate ৪ · Name box", start: true },
          c4desig: { id: "txtpermissible_wrk_designation", bn: "Certificate ৪ · Designation box", start: true },
          c4dept: { id: "txtpermissible_wrk_department", bn: "Certificate ৪ · Department box", start: true },
          c4mob: { id: "txtpermissible_wrk_mobile", bn: "Certificate ৪ · Mobile box", start: true },
          c4email: { id: "txtpermissible_wrk_emailid", bn: "Certificate ৪ · Email box", start: true },
          c5file: { id: "File_beneficiary_file_name", bn: "Certificate ৫ (Beneficiary selection (BDO)) · PDF file", start: true },
          c5name: { id: "txtbeneficiary_person_name", bn: "Certificate ৫ · Name box", start: true },
          c5desig: { id: "txtbeneficiary_designation", bn: "Certificate ৫ · Designation box", start: true },
          c5dept: { id: "txtbeneficiary_department", bn: "Certificate ৫ · Department box", start: true },
          c5mob: { id: "txtbeneficiary_mobile", bn: "Certificate ৫ · Mobile box", start: true },
          c5email: { id: "txtbeneficiary_emailid", bn: "Certificate ৫ · Email box", start: true },
          c6file: { id: "File_dpr_prep_file_name", bn: "Certificate ৬ (DPR preparation) · PDF file", start: true },
          c6name: { id: "txtdpr_prep_person_name", bn: "Certificate ৬ · Name box", start: true },
          c6desig: { id: "txtdpr_prep_designation", bn: "Certificate ৬ · Designation box", start: true },
          c6dept: { id: "txtdpr_prep_department", bn: "Certificate ৬ · Department box", start: true },
          c6mob: { id: "txtdpr_prep_mobile", bn: "Certificate ৬ · Mobile box", start: true },
          c6email: { id: "txtdpr_prep_emailid", bn: "Certificate ৬ · Email box", start: true },
          c6radio: { id: "rdodpr_preparation_0", bn: "Certificate ৬ · Yes বিকল্প" },
          c7file: { id: "File_conv_dept_file_name", bn: "Certificate ৭ (Convergence clearance) · PDF file", start: true },
          c7name: { id: "txtconv_dept_person_name", bn: "Certificate ৭ · Name box", start: true },
          c7desig: { id: "txtconv_dept_designation", bn: "Certificate ৭ · Designation box", start: true },
          c7dept: { id: "txtconv_dept", bn: "Certificate ৭ · Department box", start: true },
          c7mob: { id: "txtconv_dept_mobile", bn: "Certificate ৭ · Mobile box", start: true },
          c7email: { id: "txtconv_dept_emailid", bn: "Certificate ৭ · Email box", start: true },
          c7radio: { id: "rdoConvergenece_0", bn: "Certificate ৭ · Yes বিকল্প" },
          c8file: { id: "File_non_negotiables_file_name", bn: "Certificate ৮ (Non-negotiables (BDO)) · PDF file", start: true },
          c8name: { id: "txtnon_negotiables_person_name", bn: "Certificate ৮ · Name box", start: true },
          c8desig: { id: "txtnon_negotiables_designation", bn: "Certificate ৮ · Designation box", start: true },
          c8dept: { id: "txtnon_negotiables_department", bn: "Certificate ৮ · Department box", start: true },
          c8mob: { id: "txtnon_negotiables_mobile", bn: "Certificate ৮ · Mobile box", start: true },
          c8email: { id: "txtnon_negotiables_emailid", bn: "Certificate ৮ · Email box", start: true }
        }
      }
    }
  };

  function ids(f) { return [].concat(f.id || []); }
  // by "name" হলে name-এর prefix (ctl00$…$), নইলে id-র prefix (ctl00_…_)
  function full(f, id) { return f.raw ? id : (f.by === "name" ? MAP.prefix.name : MAP.prefix.id) + id; }

  var API = {
    data: MAP,
    // এই URL কোন page? (path দিয়ে) → page key, নইলে ""
    pageOf: function (path) {
      var p = String(path || ""), ks = Object.keys(MAP.pages);
      for (var i = 0; i < ks.length; i++) if (MAP.pages[ks[i]].path.test(p)) return ks[i];
      return "";
    },
    page: function (key) { return MAP.pages[key] || null; },
    // driver-এর জন্য: field-এর আসল ID (prefix ছাড়া); না থাকলে দেওয়া default
    id: function (page, key, dflt) {
      try { var f = MAP.pages[page].fields[key]; var v = ids(f)[0]; return v || dflt; } catch (e) { return dflt; }
    },
    // row field-এর suffix (যেমন "_lbl_msg"); না থাকলে দেওয়া default
    suffix: function (page, key, dflt) {
      try { return MAP.pages[page].rows.fields[key].suffix || dflt; } catch (e) { return dflt; }
    },
    prefixId: function (dflt) { return (MAP.prefix && MAP.prefix.id) || dflt; },
    prefixName: function (dflt) { return (MAP.prefix && MAP.prefix.name) || dflt; },
    fullId: function (page, key) {
      try { var f = MAP.pages[page].fields[key]; return full(f, ids(f)[0]); } catch (e) { return ""; }
    },
    ids: ids,
    full: full
  };
  window.KD_MAP = API;
})();
