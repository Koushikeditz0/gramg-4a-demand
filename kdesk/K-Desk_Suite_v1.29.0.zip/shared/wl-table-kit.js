/* wl-table-kit.js — K-Desk Suite by Koushik
   Table reading rules of the on-page Caste Breakup (content/wage/wage-caste-map.js), usable on any document
   (the live page or a wage list read in the background). Used by wl-caste-bulk.js and caste-register.js. */
(function () {
  'use strict';
  if (window.KDWCBKIT) return;
  var JC_RE = /[A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+/i;

  // element-এর লেখা: প্রতিটা text node-এর মাঝে space, যাতে fetch করা page-এও শব্দ জুড়ে না যায়
  function spaced(el) {
    if (!el) return '';
    var out = [], w = (el.ownerDocument || el).createTreeWalker(el, 4 /* SHOW_TEXT */, null), n;
    while ((n = w.nextNode())) { var p = n.parentNode && n.parentNode.nodeName; if (p === 'SCRIPT' || p === 'STYLE') continue; out.push(n.nodeValue); }
    return out.join(' ').replace(/ /g, ' ').replace(/\s+/g, ' ').trim();
  }
  function txt(el) { return spaced(el); }
  function normId(v) { return String(v == null ? '' : v).toUpperCase().replace(/\s+/g, '').replace(/\d+/g, function (m) { return String(parseInt(m, 10)); }); }
  function cellStr(v) { return v == null ? '' : String(v).trim(); }
  function nonEmpty(r) { var c = 0; for (var i = 0; i < r.length; i++) if (cellStr(r[i]) !== '') c++; return c; }
  function firstText(r) { for (var i = 0; i < r.length; i++) { var v = cellStr(r[i]); if (v) return v; } return ''; }
  function isSerialRow(r) {
    var nums = []; for (var i = 0; i < r.length; i++) { var v = cellStr(r[i]); if (v) nums.push(v); }
    if (nums.length < Math.max(3, r.length - 2)) return false;
    for (var j = 0; j < nums.length; j++) if (String(j + 1) !== nums[j]) return false;
    return true;
  }
  function labelScore(r) { var lab = 0, tot = 0; for (var i = 0; i < r.length; i++) { var v = cellStr(r[i]); if (!v) continue; tot++; if (!/^[\d.,\/\-]+$/.test(v)) lab++; } return tot ? lab / tot : 0; }
  var JUNK_FIRST = /^(sub ?total|total\b|rupees\b.*only|signature|report completed|payment by|bank name|wage list|state\s*[:：]|district\s*[:：]|block\s*[:：]|financial year|mustroll period|wage list agency|view wage list|signout|home$)/i;
  function cleanTable(rowsIn) {
    var all = rowsIn.map(function (r) { return r.slice(); });
    if (!all.length) return { headers: [], rows: [] };
    var freq = {}; all.forEach(function (r) { if (r.length >= 2) freq[r.length] = (freq[r.length] || 0) + 1; });
    var W = 0, best = -1; Object.keys(freq).forEach(function (k) { if (freq[k] > best) { best = freq[k]; W = +k; } });
    if (!W) W = all[0].length;
    var hcand = null;
    for (var i = 0; i < all.length; i++) { var hr = all[i]; if (hr.length < 3 || isSerialRow(hr) || labelScore(hr) < 0.7) continue; if (hr.length > (hcand ? hcand.length : 0)) hcand = hr; }
    if (hcand && hcand.length > W) W = hcand.length;
    var header = null, headerIdx = -1;
    for (var j = 0; j < all.length; j++) { if (all[j].length === W && !isSerialRow(all[j]) && labelScore(all[j]) >= 0.7) { header = all[j].slice(); headerIdx = j; break; } }
    var dataRows = [];
    for (var r0 = 0; r0 < all.length; r0++) {
      if (r0 === headerIdx) continue;
      var row = all[r0];
      if (!nonEmpty(row) || row.length !== W || isSerialRow(row) || JUNK_FIRST.test(firstText(row))) continue;
      if (header && row.join('') === header.join('')) continue;
      dataRows.push(row);
    }
    var H = header ? header.slice() : [];
    for (var h = H.length; h < W; h++) H.push('col' + (h + 1));
    return { headers: H.slice(0, W).map(function (x, idx) { return cellStr(x) || ('col' + (idx + 1)); }), rows: dataRows };
  }
  // document-এর সব leaf <tr> (nested table থাকা layout row বাদ)
  function rawUnion(doc, skipSel) {
    var rows = [];
    Array.prototype.forEach.call(doc.querySelectorAll('tr'), function (tr) {
      if (tr.querySelector('table')) return;
      if (skipSel && tr.closest && tr.closest(skipSel)) return;
      var vals = [];
      for (var i = 0; i < tr.children.length; i++) { var c = tr.children[i]; if (c.tagName === 'TD' || c.tagName === 'TH') vals.push(txt(c)); }
      if (vals.length) rows.push(vals);
    });
    return cleanTable(rows);
  }
  function colIndex(t, re) { for (var i = 0; i < t.headers.length; i++) if (re.test(String(t.headers[i] || ''))) return i; return -1; }
  function bucket(c) { var s = String(c == null ? '' : c).trim().toUpperCase(); if (s === 'SC') return 'SC'; if (s === 'ST') return 'ST'; return 'OTH'; }
  function hasJobCardRow(doc) { try { return Array.prototype.some.call(doc.querySelectorAll('tr'), function (tr) { return JC_RE.test(tr.textContent || ''); }); } catch (e) { return false; } }

  window.KDWCBKIT = { JC_RE: JC_RE, spaced: spaced, txt: txt, normId: normId, cellStr: cellStr, cleanTable: cleanTable, rawUnion: rawUnion,
    colIndex: colIndex, bucket: bucket, hasJobCardRow: hasJobCardRow,
    KEY: 'kh_caste_map_v2', META_KEY: 'kh_caste_meta_v2' };
})();
