/* List Builder tab: mount the shared builder (listbuilder.js) full-page and remember the
   Demand / Allocation choice. (Inline scripts are blocked by the MV3 CSP.) */
KH_LICENSE.check(function (ok) {
  if (!ok) { var lh = document.getElementById("lbHost"); if (lh) lh.textContent = "🔒 এই PC activated নয়। Extension Dashboard-এ key দিয়ে Activate করুন।"; return; }
(function () {
  "use strict";
  var MODE_KEY = "gnlist_mode";
  var host = document.getElementById("lbHost");
  if (!host || !window.GNList) return;
  var root = host.attachShadow({ mode: "open" });
  var css = document.createElement("style"); css.textContent = GNList.STYLE; root.appendChild(css); if (window.KD_applySkin) KD_applySkin(root);

  var mode = "demand";
  try { if (localStorage.getItem(MODE_KEY) === "alloc") mode = "alloc"; } catch (e) {}
  var ctl = GNList.mount(root, { mode: mode, onLoad: null, page: true });

  var bD = document.getElementById("mDemand"), bA = document.getElementById("mAlloc");
  function setMode(m) {
    mode = m; ctl.setMode(m);
    bD.className = m === "demand" ? "on" : ""; bA.className = m === "alloc" ? "on" : "";
    try { localStorage.setItem(MODE_KEY, m); } catch (e) {}
    ctl.focus();
  }
  bD.addEventListener("click", function () { setMode("demand"); });
  bA.addEventListener("click", function () { setMode("alloc"); });
  setMode(mode);
})();
});
