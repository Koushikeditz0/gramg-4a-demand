/* K-Register: turns the read data into printable register pages (plain HTML tables, A4). */
(function () {
  "use strict";
  const KR = (window.KR = window.KR || {});
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const money = (v) => (v === "" || v == null ? "" : Number(v).toLocaleString("en-IN", { maximumFractionDigits: 2 }));
  const lakh = (v) => (v ? money(Math.round(v * 100000)) : "");

  function table(cols, rows, o) {
    o = o || {};
    const nums = cols.map((_, i) => `<th class="n">${i + 1}</th>`).join("");
    const body = rows.length ? rows.map((r) => "<tr>" + r.map((c) => `<td>${esc(c)}</td>`).join("") + "</tr>").join("")
      : `<tr><td colspan="${cols.length}" class="empty">${esc(o.empty || "Nothing on the report site for this period.")}</td></tr>`;
    return `<table class="reg"><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr><tr>${nums}</tr></thead><tbody>${body}</tbody></table>`;
  }
  const blankRows = (n, w) => Array.from({ length: n }, () => Array(w).fill(""));
  function section(id, title, m, inner, landscape) {
    return `<section class="sheet${landscape ? " land" : ""}" data-reg="${id}"><header><div class="rno">Register ${id}</div><h2>${esc(title)}</h2>
      <div class="gpl">Gram Panchayat: <b>${esc(m.gp.gp)}</b> · Block: <b>${esc(m.gp.block)}</b> · District: <b>${esc(m.gp.district)}</b> · State: <b>${esc(m.gp.state)}</b> · FY <b>${esc(m.fyLabel)}</b>${m.period !== "year" ? " · " + esc(m.periodLabel) : ""}</div></header>${inner}
      <footer>Source: public ${esc(m.siteLabel)} pages, read ${esc(m.readOn)}. Check before signing.</footer></section>`;
  }
  const inP = (s, m, monthFirst) => KR.inPeriod(KR.parseDate(s, monthFirst), m.fy, m.period);

  const REGS = [
    { id: "I", name: "Job Card register" }, { id: "II", name: "Gram Sabha register" }, { id: "III", name: "Demand, allocation and wages" },
    { id: "IV", name: "Work register" }, { id: "V", name: "Fixed asset register" }, { id: "VI", name: "Complaint register" }, { id: "VII", name: "Material register" }];

  const B = {
    I(d, m) {
      const A = d.cards || [];
      const aRow = (c, i) => [i + 1, c.jc, c.issued, c.head + (c.member && c.member !== c.head ? " (" + c.member + ")" : ""), c.ageSex, c.rel, c.caste, c.cat, c.land, c.acct, c.bank, c.assets];
      const aCols = ["S N", "Job Card No.", "Date of issue", "Head of HH (member)", "Age / Sex", "Relationship", "SC / ST / Others", "AAY / BPL / …", "Land holding", "Bank / PO A/c", "Bank / PO name", "Individual assets"];
      const apps = (d.apps || []).filter((a) => m.period === "year" ? true : inP(a.applied, m));
      const issued = A.filter((c) => inP(c.issued, m));
      const D = (d.partD || []).slice().sort((x, y) => (+y.worked || 0) - (+x.worked || 0));
      return section("I", "Register No. 1 Part A · Job Card (application, registration, issue) and household employment", m, table(aCols, A.map(aRow)), true) +
        section("I", "Register No. 1 Part B · Applications for job cards", m, table(["S N", "Date of application", "Applicant", "Father / Husband", "Head of HH", "Sex", "Age", "SC / ST / Others", "Job Card No.", "Date of issue", "Remarks"],
          apps.map((a, i) => [i + 1, a.applied, a.name, a.father, a.head, a.sex, a.age, a.caste, a.jc, a.issued, a.remarks])), true) +
        section("I", "Register No. 1 Part C · Job cards issued in the period", m, table(aCols, issued.map(aRow)), true) +
        section("I", "Register No. 1 Part D · Households that worked", m, table(["S N", "Job Card No.", "Head of HH (member)", "Age / Sex", "Days demanded", "Days worked", "Work", "MSR No.", "Paid (Rs)", "Due (Rs)"],
          D.map((p, i) => [i + 1, p.jc, p.head + (p.member && p.member !== p.head ? " (" + p.member + ")" : ""), p.ageSex, p.demanded, p.worked, p.work, p.msr, p.paid, p.due])), true);
    },
    II(d, m) {
      const L = d.wlist || {}, X = d.wmoney || {};
      const works = Object.keys(L).filter((c) => (L[c].fy || "").replace(/\s/g, "").startsWith(m.fy.slice(0, 4)) || (X[c] && String(X[c].fy).startsWith(m.fy.slice(0, 4))));
      const rows = works.sort().map((c, i) => [i + 1, L[c].priority || (X[c] && X[c].priority) || "", c, L[c].name, L[c].category, (X[c] && X[c].agency) || "", lakh(X[c] && X[c].est), ""]);
      return section("II", "Register II · Prioritised list of works approved by the Gram Sabha", m,
          table(["S N", "Priority no.", "Work code", "Name of the work", "Category", "Implementing agency", "Estimated cost (Rs)", "Gram Sabha resolution no. / date"], rows, { empty: "No works of this year on the List of work page." }), true) +
        section("II", "Register II · Gram Sabha meetings and minutes", m,
          table(["S N", "Date of Gram Sabha", "Type (regular / special / social audit)", "Members present", "Main decisions", "Action taken", "Signature"], blankRows(12, 7)), true);
    },
    III(d, m) {
      const J = KR.demandRows(d.demand || [], d.offers || [], d.pay || []).filter((j) => inP(j.d.from, m) || inP(j.d.applied, m));
      const rows = J.map((j, i) => [i + 1, j.d.jc, j.d.name, j.d.applied, j.d.from, j.d.days, j.code, j.a ? j.a.work : "", j.a ? KR.showDate(KR.parseDate(j.a.from, true)) : "", j.a ? KR.showDate(KR.parseDate(j.a.to, true)) : "", j.days, money(j.amount)]);
      const ua = (d.ua || []).filter((u) => inP(u.from, m));
      return section("III", "Register III · Demand for work, allocation of work and payment of wages", m,
          table(["S N", "Job Card", "Name of worker", "Date of application", "Work demanded from", "Days demanded", "Allocated work code", "Allocated work", "Allocated from", "Allocated to", "Days worked on this work (year)", "Wages paid on this work (Rs, year)"], rows), true) +
        (ua.length ? section("III", "Register III · Unemployment allowance payable", m, table(["S N", "Job Card", "Name", "Demand from", "Days demanded", "Eligible days", "Delay days", "Rate", "Payable (Rs)"],
          ua.map((u, i) => [i + 1, u.jc, u.name, u.from, u.days, u.eligible, u.delay, u.rate, u.payable])), true) : "");
    },
    IV(d, m) {
      const X = d.wmoney || {}, L = d.wlist || {};
      const W = d.works || [];
      const rows = W.map((w, i) => [i + 1, w.code + " " + (w.name || (L[w.code] && L[w.code].name) || ""), w.priority || (L[w.code] && L[w.code].priority) || "", w.ts || "", w.as || "",
        w.agency || (X[w.code] && X[w.code].agency) || "", w.start || "", w.estEnd || "", w.end || "", w.sanU || lakh(X[w.code] && X[w.code].estU), w.sanM || lakh(X[w.code] && X[w.code].estM), lakh(X[w.code] && X[w.code].spent)]);
      let out = section("IV", "Register IV Part A · Work register (index of works)", m,
        table(["S N", "Work code / name", "Priority no.", "Date of TS", "Date of AS", "Implementing agency", "Start date", "Est. completion", "Actual completion", "Sanction unskilled (Rs)", "Sanction material (Rs)", "Spent till date (Rs)"], rows), true);
      const det = d.details || {};
      W.filter((w) => det[w.code]).forEach((w) => {
        const t = det[w.code];
        const inner = `<h3>${esc(w.code)} · ${esc(w.name || "")}</h3>` +
          table(["S N", "MSR No.", "Wage list No.", "Person days", "Paid (Rs)", "Due (Rs)"], t.wage.map((r, i) => [i + 1, r.msr, r.wl, r.pd, r.paid, r.due]), { empty: "No wage rows." }) +
          (t.skilled.length ? "<h4>Skilled / semi-skilled</h4>" + table(["S N", "MSR No.", "Wage list No.", "Person days", "Paid (Rs)", "Due (Rs)"], t.skilled.map((r, i) => [i + 1, r.msr, r.wl, r.pd, r.paid, r.due])) : "") +
          "<h4>Material</h4>" + table(["S N", "Bill No.", "Voucher No.", "Date", "Paid (Rs)", "Due (Rs)"], t.material.map((r, i) => [i + 1, r.bill, r.voucher, r.date, r.paid, r.due]), { empty: "No material bills." });
        out += section("IV", "Register IV Part B · Work details", m, inner, false);
      });
      return out;
    },
    V(d, m) {
      const L = d.wlist || {}, X = d.wmoney || {};
      const rows = Object.keys(L).filter((c) => L[c].assetId).sort().map((c, i) => [i + 1, L[c].assetId, c, L[c].name, L[c].category, L[c].fy, L[c].status, lakh(X[c] && X[c].est), lakh(X[c] && X[c].spent), (X[c] && X[c].mandays) || "", ""]);
      return section("V", "Register V · Fixed asset register", m,
        table(["S N", "Asset ID", "Work code", "Name of the asset / work", "Category", "Work year", "Status", "Estimated cost (Rs)", "Spent (Rs)", "Person days", "Present condition / remarks"], rows, { empty: "No work with an Asset ID on the List of work page." }), true);
    },
    VI(d, m) {
      return section("VI", "Register VI · Complaint register", m,
        table(["S N", "Complainant (name, address)", "Date of complaint", "Nature of complaint", "Complaint against", "Receipt given (yes/no)", "Action taken", "Date of disposal", "Reply sent to complainant", "Signature"], blankRows(15, 10)), true);
    },
    VII(d, m) {
      const rows = (d.material || []).filter((x) => inP(x.date, m)).map((x, i) => [i + 1, x.work + " (" + x.code + ")", x.bill, x.date, x.vendor, x.item, x.rate, x.qty, x.amount, x.total, x.paidOn]);
      return section("VII", "Register VII · Material register", m,
        table(["S N", "Work name (code)", "Bill No.", "Bill date", "Vendor", "Material", "Rate (Rs)", "Quantity", "Amount (Rs)", "Bill total (Rs)", "Date of payment"], rows), true);
    }
  };

  function cover(m, regs) {
    return `<section class="sheet cover"><div class="cv"><div class="k">7 Registers</div><h1>${esc(m.gp.gp)} Gram Panchayat</h1>
      <p>${esc(m.gp.block)} Block · ${esc(m.gp.district)} District · ${esc(m.gp.state)}</p><p>Financial year <b>${esc(m.fyLabel)}</b>${m.period !== "year" ? " · " + esc(m.periodLabel) : ""}</p>
      <ol>${regs.map((id) => `<li><b>Register ${id}</b> · ${esc(REGS.find((r) => r.id === id).name)}</li>`).join("")}</ol>
      <p class="sm">Filled from the public ${esc(m.siteLabel)} pages on ${esc(m.readOn)}. Registers II and VI are mostly kept by hand, so their pages are ready formats.</p></div></section>`;
  }
  KR.REGS = REGS;
  KR.makeBook = function (data, m, regs) { return cover(m, regs) + regs.map((id) => B[id](data, m)).join(""); };
})();
