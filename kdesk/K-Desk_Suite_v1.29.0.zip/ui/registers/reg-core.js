/* K-Register core: reads the public report pages politely and turns their tables into plain data.
   No DOM of the app page is touched here, so every parser can be tested with a saved page. */
(function () {
  "use strict";
  const KR = (window.KR = window.KR || {});

  const SITES = {
    new: { key: "new", label: "VB-G RAM G reports", base: "https://vbgramgrep.dord.gov.in/VBGRAMG/" },
    old: { key: "old", label: "MGNREGA reports (old)", base: "https://mnregaweb4.dord.gov.in/netnrega/" }
  };
  // state codes of the report sites
  const STATES = [["32", "WEST BENGAL"], ["01", "ANDAMAN AND NICOBAR"], ["02", "ANDHRA PRADESH"], ["03", "ARUNACHAL PRADESH"], ["04", "ASSAM"],
    ["05", "BIHAR"], ["33", "CHHATTISGARH"], ["07", "DN HAVELI AND DD"], ["10", "GOA"], ["11", "GUJARAT"], ["12", "HARYANA"], ["13", "HIMACHAL PRADESH"],
    ["14", "JAMMU AND KASHMIR"], ["34", "JHARKHAND"], ["15", "KARNATAKA"], ["16", "KERALA"], ["37", "LADAKH"], ["19", "LAKSHADWEEP"],
    ["17", "MADHYA PRADESH"], ["18", "MAHARASHTRA"], ["20", "MANIPUR"], ["21", "MEGHALAYA"], ["22", "MIZORAM"], ["23", "NAGALAND"], ["24", "ODISHA"],
    ["25", "PUDUCHERRY"], ["26", "PUNJAB"], ["27", "RAJASTHAN"], ["28", "SIKKIM"], ["29", "TAMIL NADU"], ["36", "TELANGANA"], ["30", "TRIPURA"],
    ["31", "UTTAR PRADESH"], ["35", "UTTARAKHAND"]];

  const clean = (s) => String(s == null ? "" : s).replace(/\s+/g, " ").trim();
  const num = (s) => { const v = Number(String(s == null ? "" : s).replace(/,/g, "")); return isFinite(v) ? v : 0; };
  const isNo = (s) => /^\d+$/.test(clean(s));
  const JC = /^[A-Z]{2}-\d/;
  const CODE = /\d{10}\/\S+/;

  /* ---------- years and dates ---------- */
  const fyOf = (d) => { const y = d.getFullYear(), m = d.getMonth() + 1; return m >= 4 ? `${y}-${y + 1}` : `${y - 1}-${y}`; };
  const siteFor = (fy) => (+String(fy).slice(0, 4) >= 2026 ? SITES.new : SITES.old);
  function yearList(stateCode, now) {
    const top = +fyOf(now || new Date()).slice(0, 4), out = [];
    for (let y = top; y >= 2005; y--) {
      const quiet = String(stateCode) === "32" && y >= 2022 && y <= 2025; // no MGNREGA work in West Bengal these years
      out.push({ fy: `${y}-${y + 1}`, label: `${y}-${String(y + 1).slice(2)}`, quiet });
    }
    return out;
  }
  function periodList(fy) {
    const y = +fy.slice(0, 4), M = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const out = [{ v: "year", label: "Whole year" }, { v: "q1", label: "Q1 (Apr–Jun)" }, { v: "q2", label: "Q2 (Jul–Sep)" }, { v: "q3", label: "Q3 (Oct–Dec)" }, { v: "q4", label: "Q4 (Jan–Mar)" }];
    for (let i = 0; i < 12; i++) { const m = ((i + 3) % 12) + 1, yy = m >= 4 ? y : y + 1; out.push({ v: `m:${yy}-${String(m).padStart(2, "0")}`, label: `${M[m - 1]} ${yy}` }); }
    return out;
  }
  // "dd/mm/yyyy" or "dd-mm-yyyy" → [y,m,d]; monthFirst for pages that write m/d/yyyy
  function parseDate(s, monthFirst) {
    const m = /^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})/.exec(clean(s)); if (!m) return null;
    return monthFirst ? [+m[3], +m[1], +m[2]] : [+m[3], +m[2], +m[1]];
  }
  const dayNo = (a) => (a ? a[0] * 10000 + a[1] * 100 + a[2] : 0);
  const showDate = (a) => (a ? `${String(a[2]).padStart(2, "0")}-${String(a[1]).padStart(2, "0")}-${a[0]}` : "");
  function inPeriod(a, fy, p) {
    if (!a) return false;
    const y = +fy.slice(0, 4), n = dayNo(a);
    if (n < y * 10000 + 401 || n > (y + 1) * 10000 + 331) return false;
    if (!p || p === "year") return true;
    const q = /^q([1-4])$/.exec(p);
    if (q) { const m = a[1], qq = m >= 4 && m <= 6 ? 1 : m >= 7 && m <= 9 ? 2 : m >= 10 ? 3 : 4; return qq === +q[1]; }
    const mm = /^m:(\d{4})-(\d{2})$/.exec(p);
    return mm ? a[0] === +mm[1] && a[1] === +mm[2] : true;
  }

  /* ---------- polite page reader ---------- */
  // One page at a time with a gap. The report site keeps a session cookie (not a login), so cookies are sent.
  // On a 5xx (the sites answer 503 when read fast) it waits and tries again.
  class Reader {
    constructor(o) { o = o || {}; this.gap = o.gap == null ? 3500 : o.gap; this.wait = o.wait || [30000, 60000, 120000]; this.stopped = o.stopped || (() => false); this.onWait = o.onWait || (() => {}); this.last = 0; this.pages = 0; }
    async sleep(ms) { const end = Date.now() + ms; while (Date.now() < end) { if (this.stopped()) throw new Error("stopped"); await new Promise((r) => setTimeout(r, Math.min(500, end - Date.now()))); } }
    async doc(url, init) {
      if (/login/i.test(url)) throw new Error("K-Register never opens a login page.");
      for (let t = 0; ; t++) {
        const since = Date.now() - this.last; if (since < this.gap) await this.sleep(this.gap - since);
        if (this.stopped()) throw new Error("stopped");
        let r = null, why = "";
        try { r = await fetch(url, Object.assign({ credentials: "include", cache: "no-store" }, init || {})); } catch (e) { why = "no answer"; }
        this.last = Date.now();
        if (r && r.status < 500) {
          const text = await r.text(); this.pages++;
          const doc = new DOMParser().parseFromString(text, "text/html");
          return { doc, url: r.url || url, status: r.status, size: text.length, title: clean((doc.querySelector("title") || {}).textContent || "") };
        }
        if (!why) why = "site busy (" + r.status + ")";
        if (t >= this.wait.length) throw new Error("The report site is not answering (" + why + "). Try again later — what was read is kept.");
        this.onWait({ why, ms: this.wait[t] });
        await this.sleep(this.wait[t]);
      }
    }
  }

  /* ---------- page helpers ---------- */
  function links(doc, base) {
    return Array.from(doc.querySelectorAll("a[href]")).map((a) => {
      let u = ""; try { u = new URL(a.getAttribute("href"), base).href; } catch (e) {}
      return { text: clean(a.textContent), url: u };
    }).filter((l) => l.url && !/^javascript:/i.test(l.url));
  }
  // a report link on the GP page, by its text (case and spaces ignored); `alts` are other spellings
  function findLink(doc, base, ...texts) {
    const want = texts.map((t) => clean(t).toUpperCase()), all = links(doc, base);
    for (const w of want) { const l = all.find((x) => x.text.toUpperCase() === w); if (l) return l; }
    return null;
  }
  // list pages: districts link to Homedist.aspx, blocks to PoIndexFrame.aspx, GPs to IndexFrame.aspx
  function listItems(doc, base, kind) {
    const re = { district: /\/Homedist\.aspx/i, block: /\/PoIndexFrame\.aspx/i, gp: /\/IndexFrame\.aspx/i }[kind], seen = new Set();
    return links(doc, base).filter((l) => re.test(l.url) && l.text && !seen.has(l.text) && seen.add(l.text))
      .map((l) => ({ name: l.text, url: l.url })).sort((a, b) => a.name.localeCompare(b.name));
  }
  const statePage = (code, name) => `${SITES.new.base}homestciti.aspx?state_code=${code}&state_name=${encodeURIComponent(name)}&lflag=eng`;
  // the GP page's form carries all its codes
  function gpCodes(doc, base) {
    const f = doc.querySelector("form[action*='anchayat_Code'], form[action*='anchayat_code']"); if (!f) return null;
    let u; try { u = new URL(f.getAttribute("action"), base); } catch (e) { return null; }
    const q = {}; u.searchParams.forEach((v, k) => { q[k.toLowerCase()] = v; });
    const gp10 = String(q.panchayat_code || "").replace(/\D/g, ""); if (gp10.length !== 10) return null;
    return { gp10, gp: clean(q.panchayat_name), block: clean(q.block_name), district: clean(q.district_name), state: clean(q.state_name),
      stateCode: gp10.slice(0, 2), districtCode: gp10.slice(0, 4), blockCode: gp10.slice(0, 7) };
  }
  function gpPage(g, fy) {
    const p = [["lflag", "eng"], ["state_code", g.stateCode], ["state_name", g.state], ["district_code", g.districtCode], ["district_name", g.district],
      ["block_code", g.blockCode], ["block_name", g.block], ["Panchayat_Code", g.gp10], ["Panchayat_name", g.gp], ["fin_year", fy], ["check", "1"]];
    return siteFor(fy).base + "IndexFrame.aspx?" + p.map(([k, v]) => k + "=" + encodeURIComponent(v).replace(/%20/g, "+")).join("&");
  }
  // every row of every innermost table, as cell texts (+ .href: first link in each cell)
  function tableRows(doc, base) {
    doc.querySelectorAll("td br, th br").forEach((br) => br.replaceWith(doc.createTextNode(" ")));
    const out = [];
    doc.querySelectorAll("tr").forEach((tr) => {
      if (tr.querySelector("table")) return;
      const cells = Array.from(tr.cells);
      const row = cells.map((c) => clean(c.textContent));
      row.href = cells.map((c) => { const a = c.querySelector("a[href]"); if (!a) return ""; try { return new URL(a.getAttribute("href"), base).href; } catch (e) { return ""; } });
      out.push(row);
    });
    return out;
  }
  // ASP.NET post-back body: hidden fields + current selects, then the changes
  function postBody(doc, changes) {
    const f = new URLSearchParams();
    doc.querySelectorAll("input[type=hidden]").forEach((i) => i.name && f.set(i.name, i.value || ""));
    doc.querySelectorAll("select").forEach((s) => s.name && f.set(s.name, s.value));
    Object.entries(changes || {}).forEach(([k, v]) => f.set(k, v));
    return { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: f.toString() };
  }
  const selectLike = (doc, part) => Array.from(doc.querySelectorAll("select")).find((s) => new RegExp(part, "i").test(s.name || s.id)) || null;
  function optionLike(doc, part, text) {
    const s = selectLike(doc, part); if (!s) return null;
    const w = clean(text).toUpperCase(), o = Array.from(s.options).find((x) => clean(x.textContent).toUpperCase() === w || clean(x.value).toUpperCase() === w);
    return o ? { name: s.name, value: o.value } : null;
  }

  /* ---------- parsers (rows in → plain records out) ---------- */
  const splitHead = (s) => { const m = /^(.*?)\s*\((.*)\)\s*$/.exec(s); return m ? [clean(m[1]), clean(m[2])] : [s, s]; };
  // Register No. 1 Part-A: Sl | JC | issue date | head (member) | age/sex | relation | caste | AAY/BPL… | land | account | bank | assets
  const jobCards = (rows) => rows.filter((r) => r.length >= 12 && isNo(r[0]) && JC.test(r[1])).map((r) => {
    const [head, member] = splitHead(r[3]);
    return { jc: r[1], issued: r[2], head, member, ageSex: r[4].replace(/\s+/g, ""), rel: r[5], caste: r[6], cat: r[7], land: r[8], acct: r[9], bank: r[10], assets: r[11] };
  });
  // Registration Application Register: head and caste written once per household
  function applications(rows) {
    let head = "", caste = ""; const out = [];
    rows.forEach((r) => {
      if (r.length < 14 || !isNo(r[0])) return;
      if (r[1]) { head = r[1]; caste = r[2]; }
      out.push({ head, caste, name: r[3].replace(/\*$/, ""), father: r[4], sex: r[5], age: r[6], applied: r[7], jc: r[8], issued: r[9], remarks: r[10] });
    });
    return out;
  }
  // Register No. 1 Part-D: Sl | JC | head (member) | age/sex | demanded | worked | work | MSR | paid | due
  const partD = (rows) => rows.filter((r) => r.length >= 10 && isNo(r[0]) && JC.test(r[1])).map((r) => {
    const [head, member] = splitHead(r[2]);
    return { jc: r[1], head, member, ageSex: r[3].replace(/\s+/g, ""), demanded: r[4], worked: r[5], work: r[6], msr: r[7], paid: r[8], due: r[9] };
  });
  // Demand for Work: S No | village | job card (blank = above) | name | applied | from | days
  function demands(rows) {
    let v = "", jc = ""; const out = [];
    rows.forEach((r) => { if (r.length < 7 || !isNo(r[0])) return; if (r[1]) v = r[1]; if (r[2]) jc = r[2]; out.push({ village: v, jc, name: r[3], applied: r[4], from: r[5], days: r[6] }); });
    return out;
  }
  // Employment Offered: S No | village | job card | name | from | to (month first) | work name
  function offers(rows) {
    let v = "", jc = ""; const out = [];
    rows.forEach((r) => { if (r.length < 7 || !isNo(r[0])) return; if (r[1]) v = r[1]; if (r[2]) jc = r[2]; out.push({ village: v, jc, name: r[3], from: r[4], to: r[5], work: r[6] }); });
    return out;
  }
  // Payment to Worker: S No | village | job card | name | father | "(CODE) work" | days | amount
  function payments(rows) {
    let jc = ""; const out = [];
    rows.forEach((r) => {
      if (r.length < 8 || !isNo(r[0])) return; if (r[2]) jc = r[2];
      const m = /^\((\d{10}\/[^)]+)\)\s*(.*)$/.exec(r[5]); if (!m) return;
      out.push({ village: r[1], jc, name: r[3], father: r[4], code: m[1], work: m[2], days: num(r[6]), amount: num(r[7]) });
    });
    return out;
  }
  // Unemployment allowance: one line per worker, found by pattern (the new site puts the whole table in one cell)
  function allowances(rows) {
    const t = rows.map((r) => r.join(" ")).join(" "), out = [];
    const re = /\b([A-Z]{2}-\d{2}-\d{3}-\d{3}-\d{3}\/\d+)\s+(.+?)\s+[\d.]+\s+(\d{1,2}\/\d{1,2}\/\d{4})\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)\s+([\d.]+)/g;
    let m; while ((m = re.exec(t))) out.push({ jc: m[1], name: m[2], from: m[3], days: m[4], eligible: m[5], delay: m[6], rate: m[7], payable: m[8] });
    return out;
  }
  // Work Register (Register IV Part A): Sl | "CODE name" | priority | TS | AS | agency | start | est. end | end | sanction unskilled | material | page (+ detail link)
  const workRegister = (rows) => rows.filter((r) => r.length >= 12 && isNo(r[0]) && CODE.test(r[1])).map((r) => {
    const m = /^(\d{10}\/\S+)\s*(.*)$/.exec(r[1]);
    return { code: m ? m[1] : r[1], name: m ? m[2] : "", priority: r[2], ts: r[3], as: r[4], agency: r[5], start: r[6], estEnd: r[7], end: r[8], sanU: r[9], sanM: r[10], detail: r.href[1] || r.href[11] || "" };
  });
  // a work's detail page (Register IV Part B): wage / skilled rows by MSR, material bills, and the money summary
  function workDetail(rows) {
    const out = { wage: [], skilled: [], material: [], total: null }; let part = "";
    const has = (r, re) => r.some((c) => re.test(c));
    rows.forEach((r) => {
      if (has(r, /^MSR NO\.?$/i)) { part = part === "" ? "wage" : "skilled"; return; }
      if (has(r, /^Bill NO\.?$/i)) { part = "material"; return; }
      if (has(r, /^Wage$/i) && has(r, /^Material$/i)) { part = "sum"; return; }
      if (part === "sum" && r.length >= 8 && r.every((c) => /^[\d.]*$/.test(c))) { out.total = r.slice(0, 8).map(Number); return; }
      if (!isNo(r[0])) return;
      if (part === "wage" || part === "skilled") out[part].push({ msr: r[1], wl: r[2], pd: r[3], paid: r[4], due: r[5] });
      else if (part === "material") out.material.push({ bill: r[1], voucher: r[2], date: r[3], paid: r[4], due: r[5] });
    });
    return out;
  }
  // Material Procured Report: ": work (CODE)" line, then per bill "Bill No. : x | : total | Bill Date : d | Date of Payment : d", "Vendor name : v | Financial Year : fy", then item rows
  function materials(rows) {
    const out = []; let work = null, bill = null;
    const after = (s) => clean(String(s || "").replace(/^[^:]*:\s*/, ""));
    rows.forEach((r) => {
      let m;
      if (r.length === 1 && (m = /^:\s*(.*?)\s*\((\d{10}\/[^)]+)\)\s*$/.exec(r[0] || ""))) { work = { code: m[2], name: m[1] }; return; }
      if (/^Bill No\b/i.test(r[0] || "")) { bill = { no: after(r[0]), total: after(r[1]), date: after(r[2]), paidOn: after(r[3]) }; return; }
      if (/^Vendor name\b/i.test(r[0] || "") && bill) { bill.vendor = after(r[0]); return; }
      if (r.length === 4 && bill && work && !/^Material$/i.test(r[0]) && /^[\d.]+$/.test(r[3]))
        out.push({ code: work.code, work: work.name, bill: bill.no, total: bill.total, date: bill.date, paidOn: bill.paidOn, vendor: bill.vendor || "",
          item: clean(r[0].replace(/^[A-Z]{0,3}\d+-/, "")), rate: r[1], qty: r[2], amount: r[3] });
    });
    return out;
  }
  const codeOf = (t) => { const m = /\((\d{10}\/[^()]+)\)\s*$/.exec(clean(t)); return m ? m[1] : ""; };
  const nameOf = (t) => clean(String(t || "").replace(/\s*\((\d{10}\/[^()]+)\)\s*$/, "")).replace(/^["'“”\s]+|["'“”\s]+$/g, "");
  // Work Expenditure (year ALL): S No | "name (CODE)" | status | FY | agency | category | priority | … | mandays | estimate ×6 | expenditure ×6 (lakh)
  function workMoney(rows) {
    const out = {};
    rows.forEach((r) => {
      if (r.length < 21 || !isNo(r[0])) return; const c = codeOf(r[1]); if (!c) return;
      out[c] = { name: nameOf(r[1]), status: r[2], fy: r[3], agency: r[4], category: r[5], priority: r[6], mandays: r[8], est: num(r[14]), estU: num(r[9]), estM: num(r[12]), spent: num(r[20]), spentU: num(r[15]), spentM: num(r[18]) };
    });
    return out;
  }
  // List of work (category, status, year ALL): S No | "name (CODE)" | status | FY | category | priority | Asset Id
  function workList(rows) {
    const out = {};
    rows.forEach((r) => { if (r.length < 7 || !isNo(r[0])) return; const c = codeOf(r[1]); if (!c) return;
      out[c] = { name: nameOf(r[1]), status: r[2], fy: r[3], category: r[4], priority: r[5], assetId: /^\d{6,}$/.test(r[6]) ? r[6] : "" }; });
    return out;
  }

  /* ---------- joins ---------- */
  const who = (jc, n) => jc + "|" + clean(n).toUpperCase();
  const workKey = (s) => clean(s).toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 40);
  // Register III: each demand with the allocation that starts 0–15 days after it (nearest; a tie matches none) and that work's code
  function demandRows(dem, off, pay) {
    const A = {}, P = {};
    off.forEach((a) => (A[who(a.jc, a.name)] = A[who(a.jc, a.name)] || []).push(a));
    pay.forEach((p) => (P[who(p.jc, p.name)] = P[who(p.jc, p.name)] || []).push(p));
    return dem.map((d) => {
      const k = who(d.jc, d.name), f = parseDate(d.from), row = { d, a: null, code: "", days: "", amount: "" };
      if (!f) return row;
      const t0 = Date.UTC(f[0], f[1] - 1, f[2]);
      const near = (A[k] || []).map((a) => { const af = parseDate(a.from, true); return { a, gap: af ? (Date.UTC(af[0], af[1] - 1, af[2]) - t0) / 864e5 : -1 }; })
        .filter((x) => x.gap >= 0 && x.gap <= 15).sort((x, y) => x.gap - y.gap);
      if (!near.length || (near.length > 1 && near[0].gap === near[1].gap)) return row;
      row.a = near[0].a;
      const hits = (P[k] || []).filter((p) => workKey(p.work) === workKey(row.a.work));
      const codes = [...new Set(hits.map((p) => p.code))];
      if (codes.length === 1) { row.code = codes[0]; row.days = hits.reduce((s, p) => s + p.days, 0); row.amount = hits.reduce((s, p) => s + p.amount, 0); }
      return row;
    });
  }
  // Part D for a year without the ready-made page: one line per worker and work from payments; days demanded from demands
  function partDFromPay(pay, dem, cards) {
    const D = {}; dem.forEach((d) => { const k = who(d.jc, d.name); D[k] = (D[k] || 0) + num(d.days); });
    const age = {}, head = {}; cards.forEach((c) => { age[who(c.jc, c.member)] = c.ageSex; if (!head[c.jc]) head[c.jc] = c.head; });
    const seen = new Set();
    return pay.slice().sort((a, b) => a.jc.localeCompare(b.jc) || a.name.localeCompare(b.name)).map((p) => {
      const k = who(p.jc, p.name), first = !seen.has(k); seen.add(k);
      return { jc: p.jc, head: head[p.jc] || p.name, member: p.name, ageSex: first ? age[k] || "" : "", demanded: first && D[k] ? String(D[k]) : "", worked: String(p.days),
        work: p.code + " " + p.work, msr: "", paid: String(Math.round(p.amount)), due: "" };
    });
  }
  // works of an old year: every work that paid wages or bought material in it
  function worksFromYear(pay, mat) {
    const W = new Map();
    pay.forEach((p) => W.has(p.code) || W.set(p.code, { code: p.code, name: p.work }));
    mat.forEach((m) => W.has(m.code) || W.set(m.code, { code: m.code, name: m.work }));
    return [...W.values()].sort((a, b) => a.code.localeCompare(b.code));
  }

  Object.assign(KR, { SITES, STATES, clean, num, fyOf, siteFor, yearList, periodList, parseDate, dayNo, showDate, inPeriod, Reader,
    links, findLink, listItems, statePage, gpCodes, gpPage, tableRows, postBody, selectLike, optionLike,
    jobCards, applications, partD, demands, offers, payments, allowances, workRegister, workDetail, materials, workMoney, workList,
    demandRows, partDFromPay, worksFromYear });
})();
