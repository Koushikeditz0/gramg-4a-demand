/* K-Desk 📚 7 Registers page (v1.29.0): opened only from Gram Setu Admin (background checks the Admin login).
   GP Admin: only the own GP (Job Card prefix block+GP digits and name must match). Super Admin: any GP.
   Reads the public report pages (vbgramgrep / mnregaweb4) from this PC; nothing is sent anywhere. */
(function () {
  "use strict";
  const KR = window.KR, $ = (id) => document.getElementById(id);
  const FRESH = 12 * 3600e3, LIST_FRESH = 7 * 864e5;
  const SCOPE_HOURS = 12;
  const S = { scope: null, running: false, stop: false, lists: {}, years: [], periods: [], data: null, gp: null };

  /* storage: chrome.storage.local in the extension, localStorage elsewhere (tests) */
  const store = {
    async get(k) {
      try { if (window.chrome && chrome.storage && chrome.storage.local) return (await chrome.storage.local.get(k))[k]; } catch (e) {}
      try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; }
    },
    async set(k, v) {
      try { if (window.chrome && chrome.storage && chrome.storage.local) return await chrome.storage.local.set({ [k]: v }); } catch (e) {}
      try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
    }
  };
  const say = (t, cls) => { $("msg").textContent = t || ""; $("msg").className = cls || ""; };
  const opts = (sel, items, first) => { sel.innerHTML = (first ? `<option value="">${first}</option>` : "") + items.map((x, i) => `<option value="${i}">${x.name || x.label}</option>`).join(""); };
  const reader = () => new KR.Reader({ stopped: () => S.stop, onWait: (w) => say(`Report site busy (${w.why}). Waiting ${Math.round(w.ms / 1000)} s, then going on by itself.`, "warn") });

  /* ---------- GP choice ---------- */
  async function listFrom(url, kind) {
    const key = "kd_reg_list:" + url, c = await store.get(key);
    if (c && Date.now() - c.at < LIST_FRESH && c.items.length) return c.items;
    const p = await reader().doc(url), items = KR.listItems(p.doc, p.url, kind);
    if (items.length) { await store.set(key, { at: Date.now(), items }); return items; }
    // nothing found: say what the site gave, so a screenshot tells us why
    const e = new Error(`the site gave no ${kind} list (answer ${p.status}, ${Math.round(p.size / 1024)} KB, page "${p.title || "no title"}", ${KR.links(p.doc, p.url).length} links)`);
    e.url = url; throw e;
  }
  async function pick(level, i) {
    const next = { st: ["di", "district"], di: ["bl", "block"], bl: ["gp", "gp"] }[level];
    const chain = ["di", "bl", "gp"]; chain.slice(chain.indexOf(next[0])).forEach((id) => opts($(id), [], "—"));
    let url;
    if (level === "st") { const s = KR.STATES[i]; if (!s) return; url = KR.statePage(s[0], s[1]); fillYears(s[0]); }
    else { const it = (S.lists[level] || [])[i]; if (!it) return; url = it.url; }
    $(next[0]).innerHTML = "<option>loading…</option>"; $("listHelp").hidden = true;
    try { S.lists[next[0]] = await listFrom(url, next[1]); opts($(next[0]), S.lists[next[0]], "— choose —"); say(""); }
    catch (e) {
      opts($(next[0]), [], "—"); if (e.message === "stopped") return;
      const h = $("listHelp"); h.hidden = false;
      h.innerHTML = `Could not load the ${next[1]} list: ${e.message.replace(/</g, "&lt;")}.<br>Open <a href="${url}" target="_blank">this report page</a> once in a tab (it sets the site's cookie), then choose again. If the page opens fine but this still fails, send a screenshot of both.`;
    }
  }
  function fillYears(stateCode) {
    S.years = KR.yearList(stateCode); opts($("fy"), S.years.map((y) => ({ label: y.label + (y.quiet ? " (no work in WB)" : "") })));
    fillPeriods();
  }
  function fillPeriods() {
    const y = S.years[+$("fy").value] || S.years[0]; if (!y) return;
    S.periods = KR.periodList(y.fy); opts($("pd"), S.periods);
    $("siteHint").textContent = "Read from " + KR.siteFor(y.fy).label + " (" + KR.siteFor(y.fy).base.replace(/^https:\/\//, "") + ")";
  }
  async function drawRecent() {
    const r = ((await store.get("kd_reg_recent")) || []).filter((g) => allowedGp(g));
    $("recent").innerHTML = r.map((g, i) => `<button data-i="${i}" title="${g.block}, ${g.district}">${g.gp}</button>`).join("");
    $("recent").querySelectorAll("button").forEach((b) => b.onclick = () => { S.recent = r[+b.dataset.i]; $("gp").innerHTML = `<option value="r">${S.recent.gp} (${S.recent.block})</option>`; $("gp").value = "r"; });
  }
  async function remember(g) {
    let r = (await store.get("kd_reg_recent")) || []; r = [{ gp10: g.gp10, gp: g.gp, block: g.block, district: g.district, state: g.state, stateCode: g.stateCode, districtCode: g.districtCode, blockCode: g.blockCode }]
      .concat(r.filter((x) => x.gp10 !== g.gp10)).slice(0, 8);
    await store.set("kd_reg_recent", r); drawRecent();
  }

  /* ---------- reading ---------- */
  const STEPS = {
    cards: { label: "Job cards", src: "Register No. 1 Part-A · Registration Application Register" },
    partD: { label: "Households that worked", src: "Register No. 1 Part-D (or built from payments)" },
    demand: { label: "Demand, allocation, payment", src: "Demand for Work · Employment Offered · Payment to Worker · Unemployment Allowance" },
    works: { label: "Works", src: "Work Register (or works with payment / material in the year)" },
    details: { label: "Each work's page", src: "Work Register → each work (Register IV Part B)" },
    winfo: { label: "All works: category, estimate, Asset ID", src: "Work Expenditure · List of work (all years)" },
    material: { label: "Material bills", src: "Material Procured Report" }
  };
  function stepsFor(regs, site, details) {
    const need = new Set(), add = (...k) => k.forEach((x) => need.add(x)), has = (r) => regs.includes(r);
    if (has("I")) add("cards", "partD"); if (has("I") && site === "old") add("demand");
    if (has("III")) add("demand");
    if (has("IV")) { add("works", "winfo"); if (details && site === "new") add("details"); if (site === "old") add("demand", "material"); }
    if (has("II") || has("V")) add("winfo");
    if (has("VII")) add("material");
    const order = site === "new" ? ["cards", "partD", "demand", "works", "details", "winfo", "material"] : ["cards", "demand", "partD", "material", "works", "winfo"];
    return order.filter((k) => need.has(k));
  }
  function drawSteps(list, st) {
    const done = list.filter((k) => st[k] && st[k].done).length, pct = list.length ? Math.round((done / list.length) * 100) : 0;
    $("barFill").style.width = pct + "%"; $("pct").textContent = pct + "%"; $("pages").textContent = S.R ? S.R.pages + " pages read" : "";
    $("steps").innerHTML = list.map((k, i) => { const s = st[k] || {};
      return `<div class="st ${s.done ? "ok" : s.now ? "now" : ""}"><span class="n">${s.done ? "✓" : i + 1}</span><span><b>${STEPS[k].label}</b><small>${STEPS[k].src}</small>${s.note ? `<small>${s.note}</small>` : ""}</span><span class="r">${s.count || (s.now ? "reading…" : "waiting")}</span></div>`; }).join("");
  }
  const chosenRegs = () => Array.from(document.querySelectorAll("#regs input:checked")).map((x) => x.value);
  function drawStats() {
    const d = S.data || {}, n = (x) => (x ? (Array.isArray(x) ? x.length : Object.keys(x).length) : 0);
    const t = [["Job card members", n(d.cards)], ["Demands", n(d.demand)], ["Works", n(d.works) || n(d.wlist)], ["Material lines", n(d.material)]];
    $("stats").innerHTML = t.map(([a, b]) => `<div><b>${b.toLocaleString("en-IN")}</b><span>${a}</span></div>`).join(""); $("stats").hidden = false;
  }

  const normName = (s) => String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  // GP Admin's own GP: Job Card prefix "WB-08-005-014" → block 005 + GP 014 = the report code's last 6 digits
  function allowedGp(g) {
    const sc = S.scope; if (!sc || sc.role === "super_admin") return true;
    const m = /-(\d{3})-(\d{3})$/.exec(sc.jc || ""); if (!m) return false;
    return String(g.gp10).slice(-6) === m[1] + m[2] && normName(g.gp) === normName(sc.gp);
  }
  async function start() {
    if (S.running) return;
    const regs = chosenRegs(); if (!regs.length) return say("Tick at least one register.", "warn");
    const gpIt = $("gp").value === "r" ? S.recent : (S.lists.gp || [])[+$("gp").value];
    if (!gpIt) return say("Choose a Gram Panchayat.", "warn");
    const y = S.years[+$("fy").value], site = KR.siteFor(y.fy).key;
    S.running = true; S.stop = false; $("start").hidden = true; $("stop").hidden = false; $("make").disabled = $("preview").disabled = true; $("stats").hidden = true; say("");
    const R = (S.R = reader()), st = {}, list = stepsFor(regs, site, $("details").checked);
    try {
      let g = gpIt.gp10 ? gpIt : null;
      if (!g) { const p = await R.doc(gpIt.url); g = KR.gpCodes(p.doc, p.url); if (!g) throw new Error("The GP page did not show the GP's codes."); }
      if (!allowedGp(g)) throw new Error(`This GP Admin login can make registers only for ${S.scope.gp} GP. ${g.gp} is another GP.`);
      await remember(g); S.gp = g;
      $("gpLine").textContent = `${g.gp} Gram Panchayat`; $("gpSub").textContent = `${g.block} · ${g.district} · FY ${y.label}`;
      const key = `kd_reg_data:${g.gp10}:${y.fy}`, d = (await store.get(key)) || { at: {}, details: {} };
      d.at = d.at || {}; d.details = d.details || {}; S.data = d; S.key = key; S.y = y; S.regs = regs;
      const save = () => store.set(key, d), fresh = (k) => d.at[k] && Date.now() - d.at[k] < FRESH;
      drawSteps(list, st);
      const home = await R.doc(KR.gpPage(g, y.fy));
      const open = async (...texts) => { const l = KR.findLink(home.doc, home.url, ...texts); if (!l) return null; const p = await R.doc(l.url); return { p, rows: KR.tableRows(p.doc, p.url) }; };
      const missing = [];
      for (const k of list) {
        st[k] = { now: true }; drawSteps(list, st);
        if (k === "cards") {
          if (!fresh(k)) {
            const a = await open("Register No. 1 Part-A", "Register No.1 Part-A", "Register No. 1 Part A"); d.cards = a ? KR.jobCards(a.rows) : [];
            const b = await open("Registration Application Register"); d.apps = b ? KR.applications(b.rows) : [];
            if (!a) missing.push("Register No. 1 Part-A"); d.at[k] = Date.now(); await save();
          }
          st[k] = { done: true, count: d.cards.length + " members", note: d.apps.length + " applications" };
        } else if (k === "partD") {
          if (!fresh(k)) {
            const a = site === "new" ? await open("Register No. 1 Part-D", "Register No.1 Part-D", "Register No. 1 Part D") : null;
            d.partD = a ? KR.partD(a.rows) : KR.partDFromPay(d.pay || [], d.demand || [], d.cards || []);
            d.at[k] = Date.now(); await save();
          }
          st[k] = { done: true, count: d.partD.length + " lines" };
        } else if (k === "demand") {
          if (!fresh(k)) {
            const a = await open("Demand for Work"), b = await open("Employment Offered"), c = await open("Consoliodate Report of Payment to Worker", "Consolidate Report of Payment to Worker", "Consolidated Report of Payment to Worker");
            let u = null; try { u = await open("Unemployment Allownces", "Unemployment Allowances", "Unemployment Allowance"); } catch (e) { if (S.stop) throw e; }
            d.demand = a ? KR.demands(a.rows) : []; d.offers = b ? KR.offers(b.rows) : []; d.pay = c ? KR.payments(c.rows) : []; d.ua = u ? KR.allowances(u.rows) : [];
            if (!a) missing.push("Demand for Work"); if (!b) missing.push("Employment Offered"); if (!c) missing.push("Payment to Worker");
            d.at[k] = Date.now(); await save();
          }
          st[k] = { done: true, count: d.demand.length + " demands", note: d.offers.length + " allocations · " + d.pay.length + " payment lines" };
        } else if (k === "works") {
          if (!fresh(k)) {
            const a = await open("Work Register");
            d.works = a ? KR.workRegister(a.rows) : [];
            if (!d.works.length) d.works = KR.worksFromYear(d.pay || [], d.material || []);
            d.at[k] = Date.now(); await save();
          }
          st[k] = { done: true, count: d.works.length + " works" };
        } else if (k === "details") {
          let read = 0, kept = 0, errs = 0; const W = d.works || [];
          for (let i = 0; i < W.length; i++) {
            const w = W[i];
            if (d.details[w.code] && Date.now() - (d.details[w.code].at || 0) < FRESH) { kept++; continue; }
            if (!w.detail) { errs++; continue; }
            st[k] = { now: true, count: `${i + 1} / ${W.length}` }; drawSteps(list, st);
            try { const p = await R.doc(w.detail); d.details[w.code] = Object.assign(KR.workDetail(KR.tableRows(p.doc, p.url)), { at: Date.now() }); read++; }
            catch (e) { if (S.stop || /not answering|stopped/.test(e.message)) throw e; errs++; }
            if (read % 10 === 0) await save();
          }
          await save();
          st[k] = { done: true, count: W.length + " works", note: errs ? errs + " pages could not be read" : "" };
        } else if (k === "winfo") {
          if (!fresh(k)) {
            const we = KR.findLink(home.doc, home.url, "Work Expenditure");
            d.wmoney = {};
            if (we) {
              const p = await R.doc(we.url), y1 = KR.selectLike(p.doc, "ddfin"), btn = p.doc.querySelector("input[type=submit]");
              if (y1 && btn) { const q = await R.doc(p.url, KR.postBody(p.doc, { __EVENTTARGET: "", __EVENTARGUMENT: "", [y1.name]: "ALL", [btn.name]: btn.value })); d.wmoney = KR.workMoney(KR.tableRows(q.doc, q.url)); }
            } else missing.push("Work Expenditure");
            const lw = KR.findLink(home.doc, home.url, "List of work", "List of Works");
            d.wlist = {};
            if (lw) {
              let p = await R.doc(lw.url);
              for (const part of ["workcat", "ddlwork_status", "ddlfin_year"]) {
                const s = KR.selectLike(p.doc, part); if (!s) break;
                p = await R.doc(p.url, KR.postBody(p.doc, { __EVENTTARGET: s.name, __EVENTARGUMENT: "", [s.name]: "ALL" }));
              }
              d.wlist = KR.workList(KR.tableRows(p.doc, p.url));
            } else missing.push("List of work");
            d.at[k] = Date.now(); await save();
          }
          const ids = Object.values(d.wlist || {}).filter((w) => w.assetId).length;
          st[k] = { done: true, count: Object.keys(d.wlist || {}).length + " works", note: ids + " with an Asset ID" };
        } else if (k === "material") {
          if (!fresh(k)) { const a = await open("Material Procured Report"); d.material = a ? KR.materials(a.rows) : []; if (!a) missing.push("Material Procured Report"); d.at[k] = Date.now(); await save(); }
          st[k] = { done: true, count: d.material.length + " material lines" };
        }
        drawSteps(list, st);
      }
      d.readOn = new Date().toLocaleString("en-IN"); await save();
      say(missing.length ? "Read. Not on this year's GP page: " + missing.join(", ") + "." : "Read. Press Make registers.", missing.length ? "warn" : "ok");
      $("make").disabled = $("preview").disabled = false; drawStats();
    } catch (e) {
      say(e.message === "stopped" ? "Stopped. Start again goes on from where it stopped." : e.message, e.message === "stopped" ? "warn" : "bad");
    } finally {
      S.running = false; $("start").hidden = false; $("stop").hidden = true; drawSteps(list, st);
    }
  }

  function build() {
    if (!S.data || !S.gp) return false;
    const p = S.periods[+$("pd").value] || S.periods[0];
    const m = { gp: S.gp, fy: S.y.fy, fyLabel: S.y.label, period: p.v, periodLabel: p.label, siteLabel: KR.siteFor(S.y.fy).label, readOn: S.data.readOn || "" };
    $("book").innerHTML = KR.makeBook(S.data, m, S.regs);
    document.title = `${S.gp.gp} 7 Registers ${S.y.label}`;
    return true;
  }
  function make() { if (build()) { $("pv").hidden = true; setTimeout(() => window.print(), 50); } }
  function preview() {
    if (!build()) return;
    $("pvBody").innerHTML = $("book").innerHTML;
    const ids = [...new Set(Array.from($("pvBody").querySelectorAll(".sheet[data-reg]")).map((x) => x.dataset.reg))];
    $("pvTabs").innerHTML = ids.map((id) => `<button data-r="${id}">Register ${id}</button>`).join("");
    $("pvTabs").querySelectorAll("button").forEach((b) => b.onclick = () => {
      $("pvTabs").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
      const el = $("pvBody").querySelector(`.sheet[data-reg="${b.dataset.r}"]`); if (el) el.scrollIntoView({ behavior: "smooth" });
    });
    $("pv").hidden = false;
  }

  /* ---------- init ---------- */
  function locked(msg) {
    document.querySelector(".layout").innerHTML = `<section class="card" style="grid-column:1/-1;text-align:center;padding:40px 20px"><h3>📚 7 Registers opens from Gram Setu</h3><p style="color:var(--mute)">${msg}</p></section>`;
  }
  (async function init() {
    const sc = await store.get("kd_reg_scope");
    if (!sc || Date.now() - sc.at > SCOPE_HOURS * 3600e3) return locked("Open Gram Setu Admin → 📚 7 Registers on this PC and press <b>Make registers in K-Desk</b>. (A GP Admin or Super Admin login is needed.)");
    const lic = await new Promise((res) => { try { KH_LICENSE.check((ok, name, info) => res({ ok, info })); } catch (e) { res({ ok: false }); } });
    if (!lic.ok) return locked("K-Desk licence is not active on this PC. Open the K-Desk popup to activate it.");
    S.scope = sc;
    $("who").textContent = sc.role === "super_admin" ? "Super Admin · any GP" : `GP Admin · ${sc.gp} GP only`;
    if (sc.role !== "super_admin") $("gpRule").textContent = `This login can make registers only for ${sc.gp} GP. Choose it below once; it is remembered.`;
    opts($("st"), KR.STATES.map((s) => ({ name: s[1] })));
    const SMALL = { I: "Part A–D: job cards, applications, households that worked", II: "Prioritised works + Gram Sabha minutes format", III: "Each demand with its allocation and wages",
      IV: "Index of works (+ each work's page)", V: "Works with an Asset ID", VI: "Ready format to fill by hand", VII: "Bills and materials of each work" };
    $("regs").innerHTML = KR.REGS.map((r) => `<label class="rg"><input type="checkbox" value="${r.id}" checked><span class="rn">${r.id}</span><span><b>${r.name}</b><small>${SMALL[r.id]}</small></span></label>`).join("");
    const all = (v) => (e) => { e.preventDefault(); document.querySelectorAll("#regs input").forEach((x) => (x.checked = v)); };
    $("allOn").onclick = all(true); $("allOff").onclick = all(false);
    $("preview").onclick = preview; $("pvPrint").onclick = make; $("pvClose").onclick = () => ($("pv").hidden = true);
    fillYears("32");
    $("st").onchange = () => pick("st", +$("st").value);
    $("di").onchange = () => $("di").value !== "" && pick("di", +$("di").value);
    $("bl").onchange = () => $("bl").value !== "" && pick("bl", +$("bl").value);
    $("fy").onchange = () => { fillPeriods(); $("make").disabled = $("preview").disabled = true; };
    $("start").onclick = start; $("make").onclick = make;
    $("stop").onclick = () => { S.stop = true; say("Stopping after this page…", "warn"); };
    await drawRecent();
    pick("st", 0);
    // what the Admin chose in Gram Setu
    const q = sc.req || {};
    const yi = S.years.findIndex((y) => y.fy === q.fy); if (yi >= 0) { $("fy").value = String(yi); fillPeriods(); }
    const pi = S.periods.findIndex((p) => p.v === q.period); if (pi >= 0) $("pd").value = String(pi);
    if (Array.isArray(q.regs) && q.regs.length) document.querySelectorAll("#regs input").forEach((x) => (x.checked = q.regs.includes(x.value)));
    $("details").checked = !!q.details;
    // a GP Admin who made registers before: the own GP is ready in the recent list
    const own = ((await store.get("kd_reg_recent")) || []).find((g) => allowedGp(g));
    if (own && sc.role !== "super_admin") { S.recent = own; $("gp").innerHTML = `<option value="r">${own.gp} (${own.block})</option>`; $("gp").value = "r"; }
  })();
})();
