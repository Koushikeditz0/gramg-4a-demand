// খোলার সময়ের ধাপ মাপা (Settings → খোলার সময়): কোন ধাপে দেরি হচ্ছে বোঝার জন্য
window.KDT = [['head', performance.now()]];
window.kdm = function (n) { window.KDT.push([n, performance.now()]); };
